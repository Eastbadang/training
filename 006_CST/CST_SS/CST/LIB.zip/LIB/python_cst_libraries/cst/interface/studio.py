"""
Wrapper module around _cst_interface
"""

from _cst_interface import DesignEnvironment as DesignEnvironmentBase
from _cst_interface import Project, ProjectType, running_design_environments, install_paths

class DesignEnvironment(DesignEnvironmentBase):
    """
    This class provides an interface to the CST Studio Suite main frontend. 
    It allows to connect to, and open new CST Studio Suite instances. Furthermore it allows to
    open or create .cst projects.
    """

    def __init__(self, mode=DesignEnvironmentBase.StartMode.New, pid=-1):
        super(DesignEnvironment, self).__init__(mode, pid)
        self._post_init()
