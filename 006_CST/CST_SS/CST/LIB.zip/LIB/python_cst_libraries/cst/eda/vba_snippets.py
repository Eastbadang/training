
def LayoutDB(pcbfile, ldbname='pcb.ldb', cadtype='ldb', LoadDB=True):
    cmd = r"""
With LayoutDB
     .Reset 
     .SourceFileName "%s" 
     .LdbFileName "*%s" 
     .PcbType "%s" 
     .KeepSynchronized "True" 
     .CreateDB
    """ % (pcbfile, ldbname, cadtype)
    if LoadDB:
        cmd += "     .LoadDB\n"
    cmd += "End With\n"
    return cmd


def eda_std_template():
    return r"""
'set the units
With Units
    .Geometry "mm"
    .Frequency "GHz"
    .Voltage "V"
    .Resistance "Ohm"
    .Inductance "NanoH"
    .TemperatureUnit  "Kelvin"
    .Time "ns"
    .Current "A"
    .Conductance "Siemens"
    .Capacitance "PikoF"
End With

'----------------------------------------------------------------------------

Plot.DrawBox False

' Background Material

With Background
     .ResetBackground
     .Type "Normal"
     .Epsilon "1.0"
     .Mue "1.0"
     .Rho "1.204"
     .ThermalType "Normal"
     .ThermalConductivity "0.026"
     .SpecificHeat "1005"

     .ApplyInAllDirections "False"
     .XminSpace "0.0"
     .XmaxSpace "0.0"
     .YminSpace "0.0"
     .YmaxSpace "0.0"
     .ZminSpace 10e-3 * Units.GetGeometrySIToUnit()
     .ZmaxSpace 10e-3 * Units.GetGeometrySIToUnit()
End With

' Boundary Conditions

With Boundary
     .Xmin "open"
     .Xmax "open"
     .Ymin "open"
     .Ymax "open"
     .Zmin "open"
     .Zmax "open"
     .Xsymmetry "none"
     .Ysymmetry "none"
     .Zsymmetry "none"
End With

' Hex Mesh Settings (Only standard Hex Mesh, No more legacy mesh settings)
With MeshSettings
     .SetMeshType "Hex"
     .Set "Version", 0%
     .Set "RatioLimitGeometry", "25"
     .Set "EquilibrateOn", "1"
     .Set "Equilibrate", "1.9"
     .Set "EdgeRefinementOn", "0"
End With

' T Solver Settings
With Solver
	.SteadyStateLimit "-40"
	.NumberOfPulseWidths "200"
	.ActivatePowerLoss1DMonitor "False"
End With

' Tet Mesh Settings (Only standard Tet Mesh, No more leagacy mesh settings)
With MeshSettings
     .SetMeshType "Tet"
     .Set "VolMeshGradation", "3"
     .Set "SrfMeshGradation", "3"
     .Set "NormalTolerance", "60"
End With
With MeshSettings
     .SetMeshType "Unstr"
     .Set "OptimizeForPlanarStructures", "1"
End With

' F Solver Settings
With FDSolver
     .Reset
     .Method "Tetrahedral Mesh"
     .TDCompatibleMaterials "True"
     .CalcPowerLoss "False"
     .AddSampleInterval "max(Solver.GetFmax/3, Solver.GetFmin)", "max(Solver.GetFmax/3,Solver.GetFmin)", "1", "Single", "True"
     .AddSampleInterval "", "", "", "Automatic", "False"
End With

' EDA Import Defaults
With ImportEDADefaults
	.PortGeometry "FaceToPec"
	.LumpedElementGeometry "Face"
	.LumpedElementMonitors "False"
	.MeshDensityX "Medium"
	.MeshDensityY "Medium"
	.MeshLinesSubstrate "1"
	.Create
End With

'----------------------------------------------------------------------------

'set the frequency range
Solver.FrequencyRange "0", "10"

'----------------------------------------------------------------------------

With MeshSettings
     .SetMeshType "Hex"
     .Set "Version", 1%
End With

With Mesh
     .MeshType "PBA"
End With

'set the solver type
ChangeSolverType("HF Time Domain")


"""


def set_defaults(d, **args):
    for k, v in args.items():
        if k not in d:
            d[k] = v


def radiated_emission_template(length_unit, frequency_unit, f_samples):
    format_data = {}
    format_data['length_unit'] = length_unit
    format_data['frequency_unit'] = frequency_unit    
    format_data['fmin'] = 0
    format_data['fmax'] = max(f_samples)

    res = r"""
'set the units
With Units
    .Geometry "{length_unit}"
    .Frequency "{frequency_unit}"
    .Voltage "V"
    .Resistance "Ohm"
    .Inductance "NanoH"
    .TemperatureUnit  "Kelvin"
    .Time "ns"
    .Current "A"
    .Conductance "Siemens"
    .Capacitance "PikoF"
End With

'----------------------------------------------------------------------------

'set the frequency range
Solver.FrequencyRange "{fmin}", "{fmax}"

'----------------------------------------------------------------------------

Plot.DrawBox True

With Background
     .ResetBackground
     .Type "Normal"
     .Epsilon "1.0"
     .Mu "1.0"
     .Rho "1.204"
     .ThermalType "Normal"
     .ThermalConductivity "0.026"
     .SpecificHeat "1005"
     .ApplyInAllDirections "True"
End With

With Boundary
     .Xmin "expanded open"
     .Xmax "expanded open"
     .Ymin "expanded open"
     .Ymax "expanded open"
     .Zmin "expanded open"
     .Zmax "expanded open"
     .Xsymmetry "none"
     .Ysymmetry "none"
     .Zsymmetry "none"
End With

Solver.SteadyStateLimit "-40"


'EMC template setting TLMmesh PCB
With Mesh
     .MeshType "HexahedralTLM"
     .SetCreator "High Frequency"
End With
With MeshSettings
     .SetMeshType "HexTLM"
     .Set "Version", 1%
     'MAX CELL - WAVELENGTH REFINEMENT
     .Set "StepsPerWaveNear", "15"
     .Set "StepsPerWaveFar", "10"
     .Set "WavelengthRefinementSameAsNear", "0"
     'MAX CELL - GEOMETRY REFINEMENT
     .Set "StepsPerBoxNear", "15"
     .Set "StepsPerBoxFar", "10"
     .Set "MaxStepNear", "0"
     .Set "MaxStepFar", "0"
     .Set "ModelBoxDescrNear", "maxedge"
     .Set "ModelBoxDescrFar", "maxedge"
     .Set "UseMaxStepAbsolute", "0"
     .Set "GeometryRefinementSameAsNear", "0"
     'MIN CELL
     .Set "UseRatioLimitGeometry", "1"
     .Set "RatioLimitGeometry", "100"
     .Set "MinStepGeometryX", "0"
     .Set "MinStepGeometryY", "0"
     .Set "MinStepGeometryZ", "0"
     .Set "UseSameMinStepGeometryXYZ", "1"
End With
With MeshSettings
     .Set "PlaneMergeVersion", "2"
End With
With MeshSettings
     .SetMeshType "HexTLM"
     .Set "FaceRefinementOn", "0"
     .Set "FaceRefinementPolicy", "2"
     .Set "FaceRefinementRatio", "2"
     .Set "FaceRefinementStep", "0"
     .Set "FaceRefinementNSteps", "3"
     .Set "EllipseRefinementOn", "0"
     .Set "EllipseRefinementPolicy", "2"
     .Set "EllipseRefinementRatio", "2"
     .Set "EllipseRefinementStep", "0"
     .Set "EllipseRefinementNSteps", "20"
     .Set "FaceRefinementBufferLines", "2"
     .Set "EdgeRefinementOn", "1"
     .Set "EdgeRefinementPolicy", "3"
     .Set "EdgeRefinementRatio", "2"
     .Set "EdgeRefinementStep", "0"
     .Set "EdgeRefinementBufferLines", "2"
     .Set "RefineEdgeMaterialGlobal", "0"
     .Set "RefineAxialEdgeGlobal", "0"
     .Set "BufferLinesNear", "2"
     .Set "UseDielectrics", "1"
     .Set "EquilibrateOn", "1"
     .Set "Equilibrate", "4"
     .Set "IgnoreThinPanelMaterial", "1"
End With
With MeshSettings
     .SetMeshType "HexTLM"
     .Set "SnapToAxialEdges", "1"
     .Set "SnapToPlanes", "1"
     .Set "SnapToSpheres", "1"
     .Set "SnapToEllipses", "1"
     .Set "SnapToCylinders", "1"
     .Set "SnapToCylinderCenters", "0"
     .Set "SnapToEllipseCenters", "0"
     .Set "SnapCellCenters", "1"
     .Set "SnapProbeCellCenters", "0"
End With
With MeshSettings
     .SetMeshType "HexTLM"
     .Set "LimitCellSizeType", "Maxcellsizefarfrommodel"
     .Set "LimitCellSizeAbsolute", "0"
     .Set "UseCellSizeSmoothingRatio", "0"
     .Set "CellSizeSmoothingRatio", "4"
     .Set "LimitCellConnects", "0"
     .Set "PBAMetalAndThin", "1"
     .Set "PBADielectrics", "0"
     .Set "PBATimeStepReduction", "2"
End With
With Discretizer
     .PointAccEnhancement "0"
End With

'EMC template setting Hexmesh PCB
With Mesh
     .MeshType "PBA"
     .SetCreator "High Frequency"
End With
With MeshSettings
     .SetMeshType "Hex"
     .Set "Version", 1%
     'MAX CELL - WAVELENGTH REFINEMENT
     .Set "StepsPerWaveNear", "15"
     .Set "StepsPerWaveFar", "10"
     .Set "WavelengthRefinementSameAsNear", "0"
     'MAX CELL - GEOMETRY REFINEMENT
     .Set "StepsPerBoxNear", "15"
     .Set "StepsPerBoxFar", "10"
     .Set "MaxStepNear", "0"
     .Set "MaxStepFar", "0"
     .Set "ModelBoxDescrNear", "maxedge"
     .Set "ModelBoxDescrFar", "maxedge"
     .Set "UseMaxStepAbsolute", "0"
     .Set "GeometryRefinementSameAsNear", "0"
     'MIN CELL
     .Set "UseRatioLimitGeometry", "1"
     .Set "RatioLimitGeometry", "35"
     .Set "MinStepGeometryX", "0"
     .Set "MinStepGeometryY", "0"
     .Set "MinStepGeometryZ", "0"
     .Set "UseSameMinStepGeometryXYZ", "1"
End With
With MeshSettings
     .Set "PlaneMergeVersion", "2"
End With
With MeshSettings
     .SetMeshType "Hex"
     .Set "FaceRefinementOn", "0"
     .Set "FaceRefinementPolicy", "2"
     .Set "FaceRefinementRatio", "2"
     .Set "FaceRefinementStep", "0"
     .Set "FaceRefinementNSteps", "2"
     .Set "EllipseRefinementOn", "0"
     .Set "EllipseRefinementPolicy", "2"
     .Set "EllipseRefinementRatio", "2"
     .Set "EllipseRefinementStep", "0"
     .Set "EllipseRefinementNSteps", "2"
     .Set "FaceRefinementBufferLines", "3"
     .Set "EdgeRefinementOn", "0"
     .Set "EdgeRefinementPolicy", "1"
     .Set "EdgeRefinementRatio", "2"
     .Set "EdgeRefinementStep", "0"
     .Set "EdgeRefinementBufferLines", "3"
     .Set "RefineEdgeMaterialGlobal", "0"
     .Set "RefineAxialEdgeGlobal", "0"
     .Set "BufferLinesNear", "3"
     .Set "UseDielectrics", "1"
     .Set "EquilibrateOn", "1"
     .Set "Equilibrate", "5"
     .Set "IgnoreThinPanelMaterial", "0"
End With
With MeshSettings
     .SetMeshType "Hex"
     .Set "SnapToAxialEdges", "1"
     .Set "SnapToPlanes", "1"
     .Set "SnapToSpheres", "1"
     .Set "SnapToEllipses", "1"
     .Set "SnapToCylinders", "1"
     .Set "SnapToCylinderCenters", "1"
     .Set "SnapToEllipseCenters", "1"
End With
With Discretizer
     .MeshType "PBA"
     .PBAType "Fast PBA"
     .AutomaticPBAType "True"
     .FPBAAccuracyEnhancement "enable"
     .ConnectivityCheck "True"
     .ConvertGeometryDataAfterMeshing "True"
     .UsePecEdgeModel "False"
     .GapDetection "False"
     .FPBAGapTolerance "1e-3"
     .PointAccEnhancement "0"
     .UseSplitComponents "True"
     .EnableSubgridding "False"
     .PBAFillLimit "99"
     .AlwaysExcludePec "False"
End With

'EMC template setting loss monitor off

With Solver
     .SteadyStateDurationType "Number of pulses"
     .NumberOfPulseWidths "40"
     .FrequencySamples "5001"
     .FrequencyLogSamples "5"
     .SurfaceImpedanceOrder "10"
     .ActivatePowerLoss1DMonitor "False"
     .SetDispNonLinearMaterialMonitor "False"
     .SetTimePowerLossSIMaterialMonitor "False"
     .ConsiderTwoPortReciprocity "False"
End With

'EMC template setting Tetmesh PCB
With Mesh
     .MeshType "Tetrahedral"
     .SetCreator "High Frequency"
End With
With MeshSettings
     .SetMeshType "Tet"
     .Set "Version", 1%
     'MAX CELL - WAVELENGTH REFINEMENT
     .Set "StepsPerWaveNear", "4"
     .Set "StepsPerWaveFar", "4"
     .Set "PhaseErrorNear", "0.02"
     .Set "PhaseErrorFar", "0.02"
     .Set "CellsPerWavelengthPolicy", "automatic"
     'MAX CELL - GEOMETRY REFINEMENT
     .Set "StepsPerBoxNear", "10"
     .Set "StepsPerBoxFar", "1"
     .Set "ModelBoxDescrNear", "maxedge"
     .Set "ModelBoxDescrFar", "maxedge"
     'MIN CELL
     .Set "UseRatioLimit", "0"
     .Set "RatioLimit", "35"
     .Set "MinStep", "0"
     'MESHING METHOD
     .SetMeshType "Unstr"
     .Set "Method", "0"
End With
With MeshSettings
     .SetMeshType "Tet"
     .Set "CurvatureOrder", "1"
     .Set "CurvatureOrderPolicy", "automatic"
     .Set "CurvRefinementControl", "NormalTolerance"
     .Set "NormalTolerance", "60"
     .Set "SrfMeshGradation", "2.7"
     .Set "SrfMeshOptimization", "1"
End With
With MeshSettings
     .SetMeshType "Unstr"
     .Set "UseMaterials",  "1"
End With
With MeshSettings
     .SetMeshType "Tet"
     .Set "UseAnisoCurveRefinement", "1"
     .Set "UseSameSrfAndVolMeshGradation", "1"
     .Set "VolMeshGradation", "2.7"
     .Set "VolMeshOptimization", "1"
End With
With MeshSettings
     .SetMeshType "Unstr"
     .Set "SmallFeatureSize", "0"
     .Set "CoincidenceTolerance", "1e-005"
     .Set "SelfIntersectionCheck", "1"
     .Set "OptimizeForPlanarStructures", "1"
End With
With Mesh
     .SetParallelMesherMode "Tet", "maximum"
     .SetMaxParallelMesherThreads "Tet", "1"
End With

'EMC template setting fsolver general purpose
'EMC template setting fsolver general purpose
Mesh.SetCreator "High Frequency"

With FDSolver
     .Reset
     .SetMethod "Tetrahedral", "General purpose"
     .OrderTet "Second"
     .OrderSrf "First"
     .Stimulation "All", "1"
     .ResetExcitationList
     .AutoNormImpedance "False"
     .NormingImpedance "0"
     .ModesOnly "False"
     .ConsiderPortLossesTet "True"
     .SetShieldAllPorts "False"
     .AccuracyHex "1e-6"
     .AccuracyTet "1e-4"
     .AccuracySrf "1e-3"
     .LimitIterations "False"
     .MaxIterations "0"
     .SetCalculateExcitationsInParallel "True", "False", ""
     .StoreAllResults "False"
     .StoreResultsInCache "False"
     .UseHelmholtzEquation "True"
     .LowFrequencyStabilization "True"
       .Type "Direct"
     .MeshAdaptionHex "False"
     .MeshAdaptionTet "True"
     .AcceleratedRestart "False"
     .FreqDistAdaptMode "Distributed"
     .NewIterativeSolver "True"
     .TDCompatibleMaterials "False"
     .ExtrudeOpenBC "False"
     .SetOpenBCTypeHex "Default"
     .SetOpenBCTypeTet "Default"
     .AddMonitorSamples "True"
     .CalcStatBField "False"
     .CalcPowerLoss "False"
     .CalcPowerLossPerComponent "False"
     .StoreSolutionCoefficients "False"
     .UseDoublePrecision "False"
     .UseDoublePrecision_ML "True"
     .MixedOrderSrf "False"
     .MixedOrderTet "True"
     .PreconditionerAccuracyIntEq "0.15"
     .MLFMMAccuracy "Default"
     .MinMLFMMBoxSize "0.20"
     .UseCFIEForCPECIntEq "true"
     .UseFastRCSSweepIntEq "false"
     .UseSensitivityAnalysis "False"
     .SetStopSweepIfCriterionMet "True"
     .SetSweepThreshold "S-Parameters", "0.01"
    .UseSweepThreshold "S-Parameters", "True"
     .SetSweepThreshold "Probes", "0.05"
     .UseSweepThreshold "Probes", "False"
     .SweepErrorChecks "2"
     .SweepMinimumSamples "3"
     .SweepConsiderAll "True"
     .SweepConsiderReset
     .SetNumberOfResultDataSamples "10001"
     .SetResultDataSamplingMode "Automatic"
     .SweepWeightEvanescent "1.0"
     .AccuracyROM "1e-4"
     .AddSampleInterval "", "", "1", "Automatic", "True"
     .AddSampleInterval "", "", "", "Automatic", "False"
     .CreateLegacy1DSignals "False"
     .MPIParallelization "False"
     .UseDistributedComputing "False"
     .NetworkComputingStrategy "RunRemote"
     .NetworkComputingJobCount "3"
     .UseParallelization "True"
     .MaxCPUs "48"
     .MaximumNumberOfCPUDevices "2"
End With

With IESolver
     .Reset
     .UseFastFrequencySweep "True"
     .UseIEGroundPlane "False"
     .SetRealGroundMaterialName ""
     .CalcFarFieldInRealGround "False"
     .RealGroundModelType "Auto"
     .PreconditionerType "Auto"
End With

With IESolver
     .SetFMMFFCalcStopLevel "0"
     .SetFMMFFCalcNumInterpPoints "6"
     .UseFMMFarfieldCalc "True"
     .SetCFIEAlpha "0.500000"
     .LowFrequencyStabilization "False"
     .LowFrequencyStabilizationML "True"
     .Multilayer "False"
     .SetiMoMACC_I "0.0001"
     .SetiMoMACC_M "0.0001"
     .DeembedExternalPorts "True"
     .SetOpenBC_XY "True"
     .OldRCSSweepDefintion "False"
     .SetAccuracySetting "Custom"
     .CalculateSParaforFieldsources "True"
     .NumberOfModesCMA "3"
     .StartFrequencyCMA "-1.0"
     .SetAccuracySettingCMA "Default"
     .FrequencySamplesCMA "0"
     .SetMemSettingCMA "Auto"
End With

'EMC template setting fsolver coarse adaptation

With MeshAdaption3D
    .SetType "HighFrequencyTet"
    .SetAdaptionStrategy "ExpertSystem"
    .MinPasses "2"
    .MaxPasses "4"
    .ClearStopCriteria
    .MaxDeltaS "0.04"
    .NumberOfDeltaSChecks "1"
    .EnableInnerSParameterAdaptation "True"
    .PropagationConstantAccuracy "0.005"
    .NumberOfPropConstChecks "1"
    .EnablePortPropagationConstantAdaptation "True"
    .AddSParameterStopCriterion "True", "", "", "0.02", "1", "False"
    .MinimumAcceptedCellGrowth "0.5"
    .RefThetaFactor ""
    .SetMinimumMeshCellGrowth "5"
    .ErrorEstimatorType "Automatic"
    .RefinementType "Automatic"
    .SnapToGeometry "True"
    .SubsequentChecksOnlyOnce "False"
    .WavelengthBasedRefinement "True"
    .EnableLinearGrowthLimitation "True"
    .SetLinearGrowthLimitation ""
    .SingularEdgeRefinement "2"
End With


'----------------------------------------------------------------------------

With MeshSettings
     .SetMeshType "Hex"
     .Set "Version", 1%
End With

With Mesh
     .MeshType "PBA"
End With

'set the solver type
ChangeSolverType("HF Time Domain")

'----------------------------------------------------------------------------

""".format(**format_data)

    for f in f_samples:
        if f > 0:
            s = r"""
'----------------------------------------------------------------------------
' Define Farfield Monitors
With Monitor
    .Reset
    .Name "farfield (f={freq})"
    .Domain "Frequency"
    .FieldType "Farfield"
    .MonitorValue {freq}
    .ExportFarfieldSource "False"
    .Create
End With
""".format(freq=f)
            res += "\n" + s + "\n"

    return res


def T_solver_settings():
    res = r"""
Mesh.SetCreator "High Frequency" 

With Solver 
     .Method "Hexahedral"
     .CalculationType "TD-S"
     .StimulationPort "Selected"
     .StimulationMode "All"
     .SteadyStateLimit "-40"
     .MeshAdaption "False"
     .AutoNormImpedance "False"
     .NormingImpedance "50"
     .CalculateModesOnly "False"
     .SParaSymmetry "False"
     .StoreTDResultsInCache  "False"
     .FullDeembedding "False"
     .SuperimposePLWExcitation "False"
     .UseSensitivityAnalysis "False"
End With
"""
    return res


def simulateneous_excitation(portlist, label='simultaneous'):
    exs = ''
    for portnumber in portlist:
        ex = '     .ExcitationPortMode "{portnumber}", "{mode}", "{amplitude}", "{timeshift}", "{signal}", "{active}"\n'
        ex = ex.format(portnumber=portnumber, mode=1, amplitude=1,
                       timeshift=0, signal="default", active=True)
        exs += ex
    res = r"""
With Solver 
     .ResetExcitationModes 
     .SParameterPortExcitation "False" 
     .SimultaneousExcitation "True" 
     .SetSimultaneousExcitAutoLabel "True" 
     .SetSimultaneousExcitationLabel "{label}" 
     .SetSimultaneousExcitationOffset "Timeshift" 
     .PhaseRefFrequency "4.5" 
     .ExcitationSelectionShowAdditionalSettings "False" 
{exs}
End With 
""".format(exs=exs, label=label)

    return res


def units(Geometry='mm', Frequency='GHz', Time='ns'):
    return """
With Units 
     .Geometry "%s" 
     .Frequency "%s" 
     .Time "%s" 
     .TemperatureUnit "Kelvin" 
     .Voltage "V" 
     .Current "A" 
     .Resistance "Ohm" 
     .Conductance "Siemens" 
     .Capacitance "PikoF" 
     .Inductance "NanoH" 
     .SetResultUnit "frequency", "frequency", "" 
End With 
""" % (Geometry, Frequency, Time)


def test_brick():
    return """
With Brick
    .Reset
    .Name "solid123"
    .Component "component1"
    .Material "PEC"
    .Xrange "0", "2"
    .Yrange "0", "3"
    .Zrange "0", "4"
    .Create
End With
"""


def test_boundaries_all_electric():
    return """
With Boundary
     .Xmin "electric"
     .Xmax "electric"
     .Ymin "electric"
     .Ymax "electric"
     .Zmin "electric"
     .Zmax "electric"
     .Xsymmetry "none"
     .Ysymmetry "none"
     .Zsymmetry "none"
     .ApplyInAllDirections "True"
End With
"""
