
# layoutdbPy should not be used directly, no backward compatibility is guarenteed when doing so
import layoutdbPy.pcb


class PCB(layoutdbPy.pcb.PCB):
    """Provides an interface to a Printed Circuit Board (PCB) based on CST ldb files."""

    def __init__(self, filename):
        super(PCB, self).__init__(filename)

    def save_and_generate3D(self, targetfile, simulation_settings=None):
        import os
        import sys
        import subprocess

        from cst.interface import install_paths as ins

        self.save(targetfile)

        if os.path.exists(targetfile + '3d'):
            os.remove(targetfile + '3d')

        env = os.environ.copy()

        lib_env_var = 'PATH'
        if sys.platform.lower().startswith('linux'):
            lib_env_var = 'LD_LIBRARY_PATH'
        cur_lib_env = env.get(lib_env_var)
        if not cur_lib_env:
            env[lib_env_var] = ins.acis_bin64()
        else:
            env[lib_env_var] = ins.acis_bin64() + os.pathsep + cur_lib_env

        edaexe = os.path.join(ins.bin64(), 'pcbimport_AMD64')
        cmd = [edaexe, '-hide']
        cmd.extend(['-parent', str(os.getpid()), '-i', targetfile])

        if simulation_settings is not None:
            import tempfile
            #fd, ss_file = tempfile.mkstemp()
            ss_file = targetfile+".py"
            with open(ss_file, 'w') as f:
                for k, v in simulation_settings.items():
                    f.write('%s = %s\n' % (k, repr(v)))
            cmd.extend(['-simulation_settings', ss_file])

        res = subprocess.run(cmd, env=env)
        return res.returncode == 0
