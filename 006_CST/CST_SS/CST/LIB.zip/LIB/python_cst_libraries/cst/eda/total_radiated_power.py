"""
The total_radiated_power module offers a simplified interface for setting up a Total Radiated Power simulation
starting from a single pcb CAD-file.
"""

from os.path import join, exists, isabs
import os

from cst.interface import DesignEnvironment
from . import vba_snippets


class Input:
    #: The directory containing the input data
    input_dir = ''

    #: The CAD-file containing the PCB-Design which should lie in the directory given by :py:attr:`input_dir`
    pcb_file = ''

    #: The directory to be used to generate the output data
    result_dir = ''

    #: A list of net names to be considered as POWER nets
    power_nets = None

    #: A list of net names to be considered as GROUND nets
    ground_nets = None

    #: Pin names to be excited as a common-mode excitation
    #: Example: [('U1','1'), ('U1','2')] 
    near_end_pin_names = None

    #: Pin names each to be terminated with reference load (50 Ohm)
    #: Example: [('U2','1'), ('U2','2')] 
    far_end_pin_names = None

    #: The length unit to be used in the project (dfault: 'mm')
    length_unit = 'mm'

    #: The frequency unit to be used in the project (default: 'GHz')
    frequency_unit = 'GHz'

    #: A list of frequency points specifying the frequency points at which field monitors will be defined
    frequency_samples = None

    #: Starts the solver automatically when True.
    run = False


def simulate(trp_setup: Input):
    """
    Takes the setup as given by ``trp_setup`` of type :py:class:`.Input` and sets up a cst project ready for simulating the total radiated power.
    """

    def make_abs(file, basedir):
        if isabs(file):
            return file
        return join(basedir, file)

    print("SIMULATING TOTAL RADIATED POWER!")

    input_dir = trp_setup.input_dir
    result_dir = trp_setup.result_dir
    result_dir = make_abs(result_dir, input_dir)

    basedir = result_dir

    de = DesignEnvironment.new()
    cstfile = 'sim.cst'
    cstfilename_full = join(basedir, cstfile)

    prj = de.new_mws()
    prj.save(cstfilename_full)
    modeler = prj.modeler

    modeler.add_to_history(
        "project template",
        vba_snippets.radiated_emission_template(
            trp_setup.length_unit, trp_setup.frequency_unit, trp_setup.frequency_samples)
    )

    # trigger pcbconverter
    pcb_file = trp_setup.pcb_file
    pcb_file = make_abs(pcb_file, input_dir)
    ldbname = 'pcb.ldb'

    modeler.add_to_history(
        "pcb import",
        vba_snippets.LayoutDB(pcb_file, ldbname=ldbname,
                              LoadDB=False, cadtype='odbpp')
    )

    ldbname = join(cstfilename_full[:-4], 'Model', '3D', ldbname)

    from . pcb_api import PCB
    pcb = PCB(ldbname)

    # build net-to-pin map:
    net2pin = {}
    for comp in pcb.components():
        for pin in comp.pins():
            net = pin.net()
            net_name = net.name()
            if net_name not in net2pin:
                net2pin[net_name] = []
            net2pin[net_name].append((comp.name(), pin.name()))

    near_end_pin_names = trp_setup.near_end_pin_names
    far_end_pin_names = set()
    simulated_nets = set()
    for refdes, pinname in near_end_pin_names:
        comp = pcb.component(refdes)
        pin = comp.pin(pinname)
        net = pin.net()
        net_name = net.name()
        simulated_nets.add(net_name)
        for pin in net2pin[net_name]:
            far_end_pin_names.add(pin)  # tuple

    simulated_nets = list(simulated_nets)

    for pin in near_end_pin_names:
        far_end_pin_names.remove(pin)
    far_end_pin_names = list(far_end_pin_names)

    # remove old *.ldbss file because this will overwrite settings from .ldb file in import dialog:
    try:
        os.remove(ldbname + 'ss')
    except:
        pass

    sim_settings = {
        'Type': 'MWS',
        'selectedPins': near_end_pin_names + far_end_pin_names,
        'selectedNets': simulated_nets,
        'simulatedNets': simulated_nets,
        'referenceNets': trp_setup.ground_nets + trp_setup.power_nets,
        'ground_nets': trp_setup.ground_nets,
        'power_nets': trp_setup.power_nets,
        'selectionAreaFromNets': True,
    }

    # generate_3D
    ok = pcb.save_and_generate3D(ldbname, simulation_settings=sim_settings)
    if not ok:
        raise RuntimeError("Failed to generate 3D model from pcb")

    modeler.add_to_history(
        "load pcb geometry",
        "LayoutDB.LoadDB"
    )

    # define T-solver setup: simultaneous
    exc_label = 'simultaneous'
    portlist = list(range(1, len(trp_setup.near_end_pin_names) + 1))

    modeler.add_to_history(
        "excitation settings",
        vba_snippets.simulateneous_excitation(portlist, label=exc_label)
    )

    modeler.add_to_history(
        "t-solver settings",
        vba_snippets.T_solver_settings()
    )

    if trp_setup.run:
        prj.modeler.run_solver()

    prj.save()
    prj.close()

    if 1:
        # read the results
        from cst import results
        p = results.ProjectFile()
        p.init(cstfilename_full, allow_interactive=True)
        p = p.get_3d()
        i = p.get_result_item(
            r"1D Results\Power\Excitation [simultaneous]\Power Radiated")
        d = i.get_data()
        results = [(f, abs(pwr)) for f, pwr in d]

    de.close()

    return results
