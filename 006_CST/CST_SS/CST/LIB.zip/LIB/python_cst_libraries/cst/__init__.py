"""
The cst package provides a Python interface to the CST Studio Suite.
"""
def _check_supported_python_version():
    from sys import version_info
    if version_info.major != 3 or version_info.minor != 6:
        raise ImportError("The cst package supports only Python 3.6")

def _add_install_bin64_to_sys_path():
    import sys
    import os
    # this file should lie in <CST_INSTALL_DIR>/<Bin64>/python_cst_libraries/cst
    this_dir = os.path.dirname(os.path.abspath(__file__))
    if not this_dir.endswith(os.path.normcase("python_cst_libraries/cst")):
        return

    bin64 = os.path.normpath(os.path.join(this_dir, '../../'))

    install_path = os.path.normpath(os.path.join(bin64, '../'))
    if os.path.exists(os.path.join(install_path, 'Image_Version')):
        os.environ['CST_INSTALLPATH_2020'] = install_path

    if bin64 in sys.path:
        return

    sys.path.insert(0, bin64)

_check_supported_python_version()
_add_install_bin64_to_sys_path()
