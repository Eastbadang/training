# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\mgchkp\hkp.py
# Compiled at: 2018-08-27 21:46:15
# Size of source mod 2**32: 14719 bytes
"""
Provide possiblity of importing Mentor Graphics ASCII files (.hkp).
Example:
"
.FILETYPE CELL_LIBRARY

.VERSION "02.50"
.CREATOR "Mentor Graphics Corporation"
.DATE    "10:02 AM Wednesday, January 03, 2007"

.UNITS TH

.PACKAGE_CELL "SOP48"
 ..PACKAGE_GROUP GENERAL
 ..MOUNT_TYPE SURFACE
 ..NUMBER_LAYERS 4
 ..TIMESTAMP "2006/12/29@16:50:18"
 ..HISTORY "Cell translated: Dec 29, 2006 @ 04:50 PM by BurkhardDoliwa@BOCELLI"
 ..PIN "1"
  ...XY (-287.5,-188)
  ...NETNAME "(Net0)"
  ...PADSTACK "Pad Oblong 13x74,"
  ...ROTATION 90
  ...PIN_OPTIONS NONE
 ..PIN "2"
  ...XY (-262.5,-188)
  ...NETNAME "(Net0)"
  ...PADSTACK "Pad Oblong 13x74,"
  ...ROTATION 90
  ...PIN_OPTIONS NONE
 ..PIN "3"
  ...XY (-237.5,-188)
  ...NETNAME "(Net0)"
  ...PADSTACK "Pad Oblong 13x74,"
  ...ROTATION 90
  ...PIN_OPTIONS NONE
 ..PIN "4"
  ...XY (-212.5,-188)
  ...NETNAME "(Net0)"
"  
etc.
here are some repeated items (ASSEMBLY_OUTLINE)-> list
"
 ..ASSEMBLY_OUTLINE
  ...POLYLINE_PATH
   ....WIDTH 10
   ....XY (-87.5, 84.5)
          (-245, 84.5)
          (-245, -84.5)
          (-87.5, -84.5)
  ...DISPLAY_WIDTH 0
 ..ASSEMBLY_OUTLINE
  ...POLYLINE_PATH
   ....WIDTH 10
   ....XY (87.5, 84.5)
          (212.5, 84.5)
          (245, 52.5)
          (245, -52.5)
          (212.5, -84.5)
          (87.5, -84.5)
  ...DISPLAY_WIDTH 0
 ..PLACEMENT_OUTLINE
  ...HEIGHT 0
  ...UNDERSIDE_SPACE 0
  ...SIDE MNT_SIDE
  ...RECT_SHAPE
   ....XY (-207.5, -60) (207.5, 60)
   ....SHAPE_OPTIONS NOT_FILLED
"

"""
import string, types
from common import utils2d
from common.utils2d import R2
from common.units import get_length_unit_conversion_factor_getter, get_length_unit_conversion_factor_mu
from common.helpers import make_list
get_length_unit_conversion_factor = get_length_unit_conversion_factor_mu

def set_design_units(name):
    global get_length_unit_conversion_factor
    try:
        name = name.lower()
        if name == 'um':
            name = 'mu'
        get_length_unit_conversion_factor = get_length_unit_conversion_factor_getter(name)
    except:
        raise Exception('WRONG UNIT GIVEN (%s)' % name)


def get_typical_manufacturing_tolerance(name, tolmu=1.0):
    return tolmu / get_length_unit_conversion_factor_mu(name)


class FileWithPush:

    def __init__(this, file, progress_start=0, progressbar=None):
        this.progressbar, this.progress_start = progressbar, progress_start
        this.file = file
        this.pushed = []
        this.eof = False
        this.line_no = 0
        this.my_approx_pos = 0

    def readline(this):
        if len(this.pushed) > 0:
            return this.pushed.pop()
        else:
            l = this.file.readline()
            this.my_approx_pos += len(l)
            if this.line_no % 1000 == 0:
                if this.progressbar is not None:
                    this.progressbar.set(this.progress_start + this.my_approx_pos)
            this.line_no += 1
            if len(l) == 0:
                this.eof = True
            return l.strip()

    def push(this, line):
        if len(this.pushed) > 0:
            raise Exception('already pushed:%s' % this.pushed)
        this.pushed.append(line)

    def nextline(this):
        l = this.readline()
        while len(l) == 0 and not this.eof:
            l = this.readline()

        return l


ldots = ['.' * i for i in range(20)]
ndigits = 10

class HKPDB:
    __doc__ = '\n    '
    tolower = 0
    geotol = 1e-06

    def __init__(this, file, level=None, length_unit_conversion=None):
        lastattr = None
        while not file.eof:
            while not file.eof:
                l = file.nextline()
                if l.strip()[:1] != '!':
                    break

            if file.eof:
                break
            l = l.replace('XYR(', 'XYR (')
            a = l.split()
            if not len(a) > 0:
                raise AssertionError
            else:
                key = a[0]
                if this.tolower:
                    key = key.lower()
                lev = key.count('.')
                assert lev <= 0 or key[:lev] != ldots[lev] and lastattr is not None
                oldval = getattr(this, lastattr)
                val = l
                if type(oldval) == list:
                    oldval[(-1)] += ' ' + val
                    print('1:', l)
                    print(oldval[(-1)])
                else:
                    setattr(this, lastattr, oldval + ' ' + val)
                    continue
                    key = key[lev:]
                    if level is None or level == lev:
                        level = lev
                        if len(a) > 1:
                            val = ' '.join(a[1:])
                        else:
                            val = None
                        if not hasattr(this, key):
                            if key.lower() in ('units', 'output_in_db_units'):
                                length_unit_conversion = get_length_unit_conversion_factor(val)
                            else:
                                setattr(this, key, val)
                                lastattr = key
                        else:
                            if type(getattr(this, key)) == list:
                                getattr(this, key).append(val)
                            else:
                                setattr(this, key, [getattr(this, key), val])
                            lastattr = key
                    else:
                        if lev < level:
                            file.push(l)
                            break
                        elif lev > level:
                            if not lev == level + 1:
                                raise AssertionError
                            else:
                                assert lastattr is not None
                                file.push(l)
                                val = HKPDB(file, (level + 1), length_unit_conversion=length_unit_conversion)
                                oldval = getattr(this, lastattr)
                                if type(oldval) == list:
                                    tmp = oldval[(-1)]
                                    oldval[-1] = val
                                    oldval = tmp
                                else:
                                    setattr(this, lastattr, val)
                            if oldval is not None:
                                if 'Name' in val.__dict__:
                                    val.Name_orig = val.Name
                                try:
                                    val.Name = oldval.strip('"')
                                except:
                                    val.Name = oldval

                        raise Exception('fatal error in HKP reader')

        this.simplify(length_unit_conversion)

    def simplify(this, length_unit_conversion):
        newdict = {}
        for key, val in this.__dict__.items():
            if isinstance(val, HKPDB):
                continue
            if key in ('xy', 'XY', 'OFFSET'):
                if '(' in val:
                    val = [eval('(' + a) for a in val.split('(') if len(a) > 0]
                    assert len(val) > 0
                    if len(val) == 1:
                        val = val[0]
                        val = R2(val[0], val[1]) * length_unit_conversion
                    else:
                        val = [R2(v[0], v[1]) * length_unit_conversion for v in val]
                else:
                    val = val.replace(',', ' ')
                    a = val.split()
                if len(a) == 2:
                    val = R2(float(a[0]), float(a[1]))
                    val *= length_unit_conversion
                newdict[key] = val
            elif key in ('xyr', 'XYR'):
                if '(' in val:
                    val = [eval('(' + a) for a in val.split('(') if len(a) > 0]
                    assert len(val) > 0
                    if len(val) == 1:
                        val = (
                         R2(val[0], val[1]) * length_unit_conversion, val[2] * length_unit_conversion)
                    else:
                        val = [(R2(v[0], v[1]) * length_unit_conversion, v[2] * length_unit_conversion) for v in val]
                else:
                    print('Strange xyr entry: ', val)
                    val = eval(val)
                newdict[key] = val
            elif key.lower() in ('radius', 'width', 'diameter', 'hatch_width', 'hatch_spacing',
                                 'height', 'tie_leg_width', 'thermal_clearance',
                                 'layer_thickness'):
                newdict[key] = float(val) * length_unit_conversion
            elif type(val) == str and val[0] == '"' and val[(-1)] == '"':
                newdict[key] = val[1:-1]
            else:
                try:
                    newdict[key] = eval(val)
                except:
                    pass

        this.__dict__.update(newdict)

    def make_dict(this, attr):
        if not hasattr(this, attr):
            setattr(this, attr, {})
            return
        li = getattr(this, attr)
        if type(li) == dict:
            return
        di = {}
        for i in make_list(li):
            if isinstance(i, HKPDB):
                di[i.Name] = i
            else:
                if type(i) == str:
                    di[i] = None

        setattr(this, attr, di)

    def __str__(this):
        file = StringFile()
        fPrint(this, file)
        return file.s


def get_all_R2s(obj, res=None):
    if isinstance(obj, R2):
        res.append(obj)
        return
    else:
        if res is None:
            res = []
            doreturn = True
        else:
            doreturn = False
        if isinstance(obj, HKPDB):
            for key, val in obj.__dict__.items():
                if isinstance(val, HKPDB):
                    get_all_R2s(val, res=res)
                else:
                    if isinstance(val, list):
                        for v in val:
                            get_all_R2s(v, res=res)

                        continue

        if doreturn:
            return res


class StringFile:

    def __init__(this):
        this.s = ''

    def write(this, s):
        this.s += s


def fPrint(this, file, level=0):
    if isinstance(this, HKPDB):
        file.write('\n')
        for key in sorted(this.__dict__.keys()):
            file.write('\t' * level + key + ': ')
            val = this.__dict__[key]
            fPrint(val, file, level + 1)

    else:
        if type(this) == list:
            file.write('\n')
            for i in range(len(this)):
                val = this[i]
                file.write('\t' * level + '[%d]: ' % i)
                fPrint(val, file, level + 1)

        else:
            file.write(str(this) + '\n')


def plot(pylab, ao):
    if 'circle_path' in ao.__dict__:
        c = ao.circle_path
        pylab.plot(ucx * c.radius + c.xy[0], ucy * c.radius + c.xy[1], 'b')
    else:
        if 'polyline_path' in ao.__dict__:
            p = ao.polyline_path
            pylab.plot([x for x, y in p.xy], [y for x, y in p.xy], 'g')
        else:
            if 'polyarc_path' in ao.__dict__:
                p = ao.polyarc_path
                pylab.plot([x for x, y, r in p.xyr if r == 0], [y for x, y, r in p.xyr if r == 0], 'r')
            else:
                if 'rect_path' in ao.__dict__:
                    p = ao.rect_path
                    x0, y0 = p.xy[0]
                    x1, y1 = p.xy[1]
                    pylab.plot([x0, x1, x1, x0, x0], [y0, y0, y1, y1, y0], 'y')
                else:
                    if 'rect_shape' in ao.__dict__:
                        p = ao.rect_shape
                        x0, y0 = p.xy[0]
                        x1, y1 = p.xy[1]
                        pylab.plot([x0, x1, x1, x0, x0], [y0, y0, y1, y1, y0], 'b--')
                    else:
                        print('Not recognized: ', ao)


if __name__ == '__main__':
    import sys
    if len(sys.argv) == 1:
        filename = './a.hkp'
    else:
        filename = sys.argv[1]
    a = HKPDB(FileWithPush(open(filename)))
# okay decompiling hkp.pyc
