# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\mgchkp\geometry.py
# Compiled at: 2018-08-27 21:46:15
# Size of source mod 2**32: 23940 bytes
import layoutdbPy, utils2dPy
from common.helpers import mwsname, norm_netname, make_list
from common.utils2d import *
from common import utils2d
import mgchkp

def polyarc_path_to_trace(val):
    xyrs = val.XYR
    w = val.WIDTH
    if 0 and xyrs[0][0] == xyrs[(-1)][0]:
        print('Ignoring closed polyarc path:', xyrs)
        return []
    else:
        correct_arc_centers(xyrs)
        trace = layoutdbPy.Trace()
        for i in range(0, len(xyrs) - 1):
            p0, r0 = xyrs[i]
            if r0 != 0:
                pass
            else:
                p1, R = xyrs[(i + 1)]
                if R == 0:
                    trace.add_segment(utils2dPy.CurveSegment(p0, p1), w)
                else:
                    p2, r2 = xyrs[(i + 2)]
                    assert r2 == 0
                    if is_circle(p0, p2, p1, R):
                        print('ERROR: circle trace segment skipped:\n', val)
                    else:
                        trace.add_segment(utils2dPy.CurveSegment(p0, p2, p1, -R), w)

        return trace


def polyline_path_to_trace(val, tol=0.0):
    xys = val.XY
    w = val.WIDTH
    remove_identical_points2(xys, tol=tol)
    trace = layoutdbPy.Trace()
    if len(xys) < 2:
        print('WARNING: trace with less than 2 points (SKIPPED):\n', val)
        return
    else:
        plast = None
        for p in xys:
            if plast is not None:
                trace.add_segment(CurveSegment(plast, p), w)
            plast = p

        return trace


def shapes_from_mentor_shape(key, val, separate_segments=True, is_trace=False, point_match_tol=0):
    if key == 'POLYARC_SHAPE':
        if 'FILLED' not in val.SHAPE_OPTIONS.split():
            print('WARNING: non-filled polyarc shape encountered (SKIPPED)')
        else:
            if is_circle_shape(val.XYR):
                print('WARNING: polyarc-circle skipped')
                return []
            if len(val.XYR):
                a, ra = val.XYR[0]
                b, rb = val.XYR[(-1)]
                dist = (a - b).getNorm()
                if dist > 0:
                    if dist < point_match_tol:
                        val.XYR[-1] = (
                         a * 1, rb)
                    else:
                        val.XYR.append((a * 1, 0))
        shapes = [PolyarcShape(val.XYR)]
    else:
        if key == 'POLYARC_PATH':
            if val.WIDTH != 0:
                if is_trace:
                    shapes = [
                     polyarc_path_to_trace(val)]
                else:
                    shapes = polyarc_path_to_polyarc_shapes(val.XYR, val.WIDTH)
            else:
                shapes = [
                 PolyarcShape(val.XYR)]
        else:
            if key == 'POLYLINE_SHAPE':
                if 'FILLED' not in val.SHAPE_OPTIONS.split():
                    print('WARNING: non-filled polyline shape encountered')
                shapes = [PolylineShape(val.XY)]
            else:
                if key == 'POLYLINE_PATH':
                    if val.WIDTH != 0:
                        if is_trace:
                            shapes = [
                             polyline_path_to_trace(val, tol=point_match_tol)]
                        else:
                            xyrss = polyline_path_to_xyrs((val.XY), (val.WIDTH), roundcaps=(not hasattr(val, 'no_caps')),
                              separate_segments=separate_segments)
                            shapes = [PolyarcShape(xyrs) for xyrs in xyrss if xyrs is not None]
                    else:
                        shapes = [
                         PolylineShape(val.XY)]
                else:
                    if key == 'RECT_SHAPE':
                        assert len(val.XY) == 2
                        shapes = RectPath(val.XY[0], val.XY[1], 0)
                    else:
                        if key == 'RECT_PATH':
                            assert len(val.XY) == 2
                            shapes = RectPath(val.XY[0], val.XY[1], val.WIDTH)
                        else:
                            if key == 'CIRCLE_SHAPE':
                                shapes = [
                                 CircleShape(val.XY, val.RADIUS)]
                            else:
                                if key == 'CIRCLE_PATH':
                                    shapes = CirclePath(val.XY, val.RADIUS, val.WIDTH)
                                else:
                                    print('unknown shape : ', key)
                                    shapes = []
    return shapes


def shapes_from_mentor_shapes(ss, separate_segments=True, is_trace=False, point_match_tol=0):
    res = []
    for key, val in ss:
        try:
            res.extend(shapes_from_mentor_shape(key, val, separate_segments=separate_segments, is_trace=is_trace, point_match_tol=point_match_tol))
        except:
            print('WARNING: invalid shape (skipped)')

    return res


def get_all_shapes(obj, hatch=True):
    res = []
    if not isinstance(obj, mgchkp.hkp.HKPDB):
        return res
    else:
        for key, val in obj.__dict__.items():
            if not hatch:
                if key == 'APS_HATCH_DATA':
                    continue
            if key in ('POLYARC_SHAPE', 'POLYARC_PATH', 'CIRCLE_SHAPE', 'CIRCLE_PATH',
                       'POLYLINE_SHAPE', 'POLYLINE_PATH', 'RECT_SHAPE', 'RECT_PATH'):
                for v in make_list(val):
                    res.append((key, v))

            else:
                if isinstance(val, mgchkp.hkp.HKPDB):
                    res.extend(get_all_shapes(val, hatch=hatch))
                else:
                    if isinstance(val, list):
                        for v in val:
                            res.extend(get_all_shapes(v, hatch=hatch))

                        continue

        return res


def get_all_geometries(obj, hatch=True):
    return shapes_from_mentor_shapes(get_all_shapes(obj, hatch=hatch))


def get_pad_shapes(pad, xy=None, rotation=None, x_mirror=False, y_mirror=False):
    from math import pi, sqrt
    count = 0
    if hasattr(pad, 'ROUND'):
        shapes = [
         utils2d.CircleShape(R2(0, 0), pad.ROUND.DIAMETER * 0.5)]
        count += 1
    if hasattr(pad, 'OBLONG'):
        w, h = pad.OBLONG.WIDTH, pad.OBLONG.HEIGHT
        if w > h:
            W = h
            p0 = R2(-w / 2 + h / 2.0, 0)
            p1 = R2(w / 2 - h / 2.0, 0)
            xyrs = utils2d.straight_path_segment_to_XYR(p0, p1, W, roundcaps=True)
            shapes = [utils2d.PolyarcShape(xyrs)]
        else:
            if w < h:
                W = w
                p0 = R2(0, -w / 2 + h / 2.0)
                p1 = R2(0, w / 2 - h / 2.0)
                xyrs = utils2d.straight_path_segment_to_XYR(p0, p1, W, roundcaps=True)
                shapes = [utils2d.PolyarcShape(xyrs)]
            else:
                shapes = [
                 utils2d.CircleShape(R2(0, 0), w / 2.0)]
        count += 1
    if hasattr(pad, 'SQUARE'):
        dy = R2(0, pad.SQUARE.WIDTH * 0.5)
        dx = R2(pad.SQUARE.WIDTH * 0.5, 0)
        xys = [-dx - dy, -dx + dy, dx + dy, dx - dy, -dx - dy]
        shapes = [utils2d.PolylineShape(xys)]
        count += 1
    if hasattr(pad, 'RECTANGLE'):
        dy = R2(0, pad.RECTANGLE.HEIGHT * 0.5)
        dx = R2(pad.RECTANGLE.WIDTH * 0.5, 0)
        xys = [-dx - dy, -dx + dy, dx + dy, dx - dy, -dx - dy]
        shapes = [utils2d.PolylineShape(xys)]
        count += 1
    if hasattr(pad, 'OCTAGON'):
        o = pad.OCTAGON
        w = o.WIDTH
        w2 = w * 0.5
        l = w / 2.414213562373095
        l2 = l * 0.5
        lv = R2(0, l)
        lh = R2(l, 0)
        lx = l / 1.4142135623730951
        lq = R2(lx, -lx)
        xys = [R2(-w2, -l2)]
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] + lh)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] + lv)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] - lh)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] - lv)
        xys.append(xys[0])
        shapes = [utils2d.PolylineShape(xys)]
        count += 1
    if hasattr(pad, 'ELONGATED_OCTAGON'):
        o = pad.ELONGATED_OCTAGON
        w = o.WIDTH
        w2 = w * 0.5
        h = o.HEIGHT
        h2 = w * 0.5
        if w < h:
            l = w / 2.414213562373095
        else:
            l = h / 2.414213562373095
        lx = l / 1.4142135623730951
        lv = R2(0, h - 2 * lx)
        lh = R2(w - 2 * lx, 0)
        lq = R2(lx, -lx)
        xys = [R2(-w2, -lv.y * 0.5)]
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] + lh)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] + lv)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] - lh)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] - lv)
        xys.append(xys[0])
        shapes = [utils2d.PolylineShape(xys)]
        count += 1
    if hasattr(pad, 'RADIUS_CORNER_RECTANGLE'):
        rcr = pad.RADIUS_CORNER_RECTANGLE
        w, h, r = rcr.WIDTH, rcr.HEIGHT, rcr.RADIUS
        dy = R2(0, h * 0.5)
        dx = R2(w * 0.5, 0)
        if r == 0 or r > h * 0.49 or r > w * 0.49:
            xys = [
             -dx - dy, -dx + dy, dx + dy, dx - dy, -dx - dy]
            shapes = [utils2d.PolylineShape(xys)]
        else:
            dxr, dyr = R2(r, 0), R2(0, r)
            dxr = dx - dxr
            dyr = dy - dyr
            xyrs = [(-dx - dyr, 0), (-dx + dyr, 0), (-dxr + dyr, r), (-dxr + dy, 0), (dxr + dy, 0), (dxr + dyr, r), (dx + dyr, 0),
             (
              dx - dyr, 0), (dxr - dyr, r), (dxr - dy, 0), (-dxr - dy, 0), (-dxr - dyr, r), (-dx - dyr, 0)]
            shapes = [utils2d.PolyarcShape(xyrs)]
        count += 1
    if hasattr(pad, 'CHAMFERED_RECTANGLE'):
        cr = pad.CHAMFERED_RECTANGLE
        w, h, c = cr.WIDTH, cr.HEIGHT, float(cr.CHAMFER)
        if w < 2 * c:
            c = w * 0.5
        if c > h * 0.5:
            c = h * 0.5
            print('WARNING: corrected chamfered rectangle')
        w2 = w * 0.5
        h2 = w * 0.5
        lx = c
        l = lx * 1.4142135623730951
        lv = R2(0, h - 2 * lx)
        lh = R2(w - 2 * lx, 0)
        lq = R2(lx, -lx)
        xys = [R2(-w2, -lv.y * 0.5)]
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] + lh)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] + lv)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] - lh)
        lq.turn_left()
        xys.append(xys[(-1)] + lq)
        xys.append(xys[(-1)] - lv)
        xys.append(xys[0])
        shapes = [utils2d.PolylineShape(xys)]
        count += 1
    if hasattr(pad, 'ROUND_FINGER'):
        w, h = pad.ROUND_FINGER.WIDTH, pad.ROUND_FINGER.HEIGHT
        dx, dy = R2(w / 2.0, 0), R2(0, h / 2.0)
        dxh = R2(h / 2.0, 0)
        dyh = R2(0, h / 2.0)
        if w >= h:
            xyrs = [
             (
              -dx - dy, 0), (-dx + dy, 0), (dx - dxh + dy, 0), (dx - dxh, h / 2.0), (dx - dxh - dy, 0)]
        else:
            xyrs = [
             (
              -dx - dy, 0), (-dx + dy - dyh, 0), (dy - dyh, h / 2.0), (dx + dy - dyh, 0), (dx - dy, 0)]
        shapes = [
         utils2d.PolyarcShape(xyrs)]
        count += 1
    if hasattr(pad, 'OCTAGONAL_FINGER'):
        w, h = pad.OCTAGONAL_FINGER.WIDTH, pad.OCTAGONAL_FINGER.HEIGHT
        dx, dy = R2(w / 2.0, 0), R2(0, h / 2.0)
        if w >= h:
            l = h / 2.414213562373095
        else:
            l = w / 2.414213562373095
        lx = l / 1.4142135623730951
        if w >= h:
            xys = [
             -dx - dy, -dx + dy, dx + dy - R2(lx, 0), dx + dy - R2(0, lx), dx - dy + R2(0, lx), dx - dy - R2(lx, 0), -dx - dy]
        else:
            xys = [
             -dx - dy, -dx + dy - R2(0, lx), -dx + dy + R2(lx, 0), dx + dy - R2(lx, 0), dx + dy - R2(0, lx), dx - dy, -dx - dy]
        shapes = [
         utils2d.PolylineShape(xys)]
        count += 1
    if hasattr(pad, '4_WEB_ROUND_THERMAL_45') or hasattr(pad, '4_WEB_ROUND_THERMAL'):
        if hasattr(pad, '4_WEB_ROUND_THERMAL_45'):
            wrt = getattr(pad, '4_WEB_ROUND_THERMAL_45')
            turn = pi / 4.0
        else:
            wrt = getattr(pad, '4_WEB_ROUND_THERMAL')
            turn = 0.0
        tlw = wrt.TIE_LEG_WIDTH
        tlw2 = tlw / 2.0
        tc = wrt.THERMAL_CLEARANCE
        r1 = wrt.DIAMETER / 2.0
        r0 = r1 - tc
        if r0 <= 0:
            print('WARNING: 4_WEB_ROUND_THERMAL pad with r0<=0 encountered -> skipped')
            return []
        x0 = R2(tlw2, sqrt(r0 * r0 - tlw2 * tlw2))
        x1 = R2(tlw2, sqrt(r1 * r1 - tlw2 * tlw2))
        x2 = R2(x1.y, x1.x)
        x3 = R2(x0.y, x0.x)
        xyrs = [(x0, 0), (x1, 0), (R2(0, 0), r1), (x2, 0), (x3, 0), (R2(0, 0), -r0), (x0, 0)]
        shape = utils2d.PolyarcShape(xyrs)
        shapes = [
         shape, shape.clone(), shape.clone(), shape.clone()]
        o = R2(0, 0)
        shapes[0].rotate(turn + 0.0, o)
        shapes[1].rotate(turn + pi / 2, o)
        shapes[2].rotate(turn + pi, o)
        shapes[3].rotate(turn + 3 * pi / 2, o)
        count += 1
    if hasattr(pad, '4_WEB_SQUARE_THERMAL'):
        wst = getattr(pad, '4_WEB_SQUARE_THERMAL')
        w, tlw, c = wst.WIDTH, float(wst.TIE_LEG_WIDTH), float(wst.THERMAL_CLEARANCE)
        if c >= w * 0.5 or tlw >= w - 2 * c or tlw == 0:
            print('WARNING: invalid pad (skipped):\n %s' % str(pad))
        else:
            w2 = w * 0.5
            t2 = tlw * 0.5
            r2 = w2 - c
            xys = [R2(r2, t2), R2(w2, t2), R2(w2, w2), R2(t2, w2), R2(t2, r2), R2(r2, r2), R2(r2, t2)]
            shape = utils2d.PolylineShape(xys)
            shapes = [shape, shape.clone(), shape.clone(), shape.clone()]
            shapes[1].x_mirror()
            shapes[1].reverse()
            shapes[2].x_mirror()
            shapes[2].y_mirror()
            shapes[3].y_mirror()
            shapes[3].reverse()
            count += 1
    if hasattr(pad, '4_WEB_SQUARE_THERMAL_45'):
        wst = getattr(pad, '4_WEB_SQUARE_THERMAL_45')
        w, tlw, c = wst.WIDTH, float(wst.TIE_LEG_WIDTH), float(wst.THERMAL_CLEARANCE)
        w2 = w * 0.5
        t2 = tlw * 0.5
        r2 = w2 - c
        if c >= w2 or t2 >= r2 / 1.4142135623730951 or t2 == 0:
            print('WARNING: invalid pad (skipped):\n %s' % str(pad))
        else:
            h2 = w2 - t2 * 1.4142135623730951
            h1 = r2 - t2 * 1.4142135623730951
            xys = [R2(r2, h1), R2(r2, -h1), R2(w2, -h2), R2(w2, h2), R2(r2, h1)]
            shape = utils2d.PolylineShape(xys)
            shapes = [shape, shape.clone(), shape.clone(), shape.clone()]
            shapes[1].x_mirror()
            shapes[1].reverse()
            shapes[2].rotate(1.5707963267948966, R2(0, 0))
            shapes[3].rotate(-1.5707963267948966, R2(0, 0))
            count += 1
    if hasattr(pad, '2_WEB_ROUND_THERMAL_45') or hasattr(pad, '2_WEB_ROUND_THERMAL'):
        if hasattr(pad, '2_WEB_ROUND_THERMAL_45'):
            wrt = getattr(pad, '2_WEB_ROUND_THERMAL_45')
            is45 = True
        else:
            wrt = getattr(pad, '2_WEB_ROUND_THERMAL')
            is45 = False
        d, tlw, c = float(wrt.DIAMETER), float(wrt.TIE_LEG_WIDTH), float(wrt.THERMAL_CLEARANCE)
        tlw2 = tlw * 0.5
        if tlw == 0 or c >= d * 0.5 or tlw >= d or tlw >= d - 2 * c:
            print('WARNING: invalid pad (skipped):\n %s' % str(pad))
        else:
            R, r = d * 0.5, d * 0.5 - c
            dX = sqrt(R * R - tlw2 * tlw2)
            dx = sqrt(r * r - tlw2 * tlw2)
            oo = R2(0, 0)
            xyrs = [(R2(dX, tlw2), 0), (oo, -R), (R2(-dX, tlw2), 0), (R2(-dx, tlw2), 0), (oo, r), (R2(dx, tlw2), 0), (R2(dX, tlw2), 0)]
            shape = utils2d.PolyarcShape(xyrs)
            shapes = [shape, shape.clone()]
            shapes[1].y_mirror()
            shapes[1].reverse()
            if is45:
                shapes[0].rotate(0.7853981633974483, oo)
                shapes[1].rotate(0.7853981633974483, oo)
            count += 1
    if hasattr(pad, 'ROUND_DONUT'):
        rd = pad.ROUND_DONUT
        d, c = float(rd.DIAMETER), float(rd.THERMAL_CLEARANCE)
        if c < d * 0.5:
            swh = utils2d.ShapeWithHoles()
            swh.shape = utils2d.CircleShape(R2(0, 0), d * 0.5)
            swh.holes.append(utils2d.CircleShape(R2(0, 0), -(d * 0.5 - c)))
            shapes = [swh]
            count += 1
        else:
            print('WARNING: invalid round donut:\n%s' % str(pad))
    if hasattr(pad, 'SQUARE_DONUT'):
        sd = pad.SQUARE_DONUT
        w, c = sd.WIDTH, float(sd.THERMAL_CLEARANCE)
        if c < w * 0.5:
            swh = utils2d.ShapeWithHoles()
            swh.shape = utils2d.RectangleC(w, w)
            swh.holes.append(utils2d.RectangleC(w - 2 * c, w - 2 * c))
            swh.holes[0].reverse()
            shapes = [swh]
            count += 1
        else:
            print('WARNING: invalid round donut:\n%s' % str(pad))
    if hasattr(pad, 'CUSTOM'):
        shapes = shapes_from_mentor_shapes(get_all_shapes(pad.CUSTOM))
        count += 1
    if count > 1:
        print('Warning: more than one pad shape: case not considered yet!')
    if count == 0:
        print('WARNING: unknown pad shape!', pad)
        return []
    else:
        if hasattr(pad, 'OFFSET'):
            offset = -pad.OFFSET
        else:
            offset = None
        if offset is not None:
            for s in shapes:
                s.translate(offset)

        if rotation:
            for s in shapes:
                s.rotate(rotation * pi / 180.0, R2(0, 0))

        if x_mirror:
            for s in shapes:
                s.x_mirror()

        if y_mirror:
            for s in shapes:
                s.y_mirror()

        if xy:
            for s in shapes:
                s.translate(xy)

        return shapes
# okay decompiling geometry.pyc
