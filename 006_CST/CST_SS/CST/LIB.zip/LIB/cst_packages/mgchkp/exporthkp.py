# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\mgchkp\exporthkp.py
# Compiled at: 2019-03-13 21:58:21
# Size of source mod 2**32: 75723 bytes
import copy, os, sys, types
from functools import reduce
if __name__ == '__main__':
    sys.path = ['..'] + sys.path
    print(sys.path)
from common.utils2d import R2
import mgchkp.hkp
from mgchkp.geometry import *
from common import utils2d
import common.units
from common.helpers import mwsname, norm_netname, make_list
from common.layoutdb import DatabaseReadError, type_name_to_RLC_type, check_pin_names
from common.utils2d import ShapeProcessor
import utils2dPy, layoutdbPy
from utils2dPy import CShape, CShapeWithHoles, Shape, ShapeWithHoles
geotol = 0

def compute_area(points0):
    points = points0[:-1]
    area = 0.0
    while len(points) >= 3:
        p0, p1, p2 = points[0:3]
        area += 0.5 * abs((p1 - p0).cross(p2 - p0))
        del points[0]

    return area


def pequal(p1, p2, tol):
    return (p1 - p2).getNorm() < tol


def colortuple(c):
    return (
     c.Red / 255.0, c.Green / 255.0, c.Blue / 255.0)


def get_pcb_boundingbox(Layout):
    ss = shapes_from_mentor_shapes(get_all_shapes(Layout.BOARD_OUTLINE))
    if len(ss) == 0:
        print('ERROR: missing pcb BOARD_OUTLINE:', Layout.BOARD_OUTLINE)
    elif not len(ss) > 0:
        raise AssertionError
    from common.utils2d import BoundingBox
    res = BoundingBox(ss[0].bbox)
    for s in ss:
        res.extend(s.bbox)

    return res


class Export:
    __doc__ = '\n    '

    def __init__(this, pcb, logfile=None, directory=None, App=None, Doc=None, progressbar=None, userparams=None):
        this.pcb = pcb
        this.design_name = 'MGC-Expedition-Design'
        this.progressbar = progressbar
        this.App, this.Doc = App, Doc
        this.db_unit = pcb.design_units
        this.parse_Stackup()
        this.warnings = set()
        this.pcb.PDB.make_dict('Number')
        this.num2num = {}
        for n in list(this.pcb.PDB.Number.keys()):
            this.num2num[n.upper()] = n

    def parse_Stackup(this):
        stack = {}
        s = this.pcb.JobPrefs.LAYER_STACKUP_SECTION
        if hasattr(s, 'DIELECTRIC_LAYER'):
            for l in make_list(s.DIELECTRIC_LAYER):
                l.Name = int(l.Name)
                assert l.Name not in stack
                stack[l.Name] = l

        if hasattr(s, 'PLANE_LAYER'):
            for l in make_list(s.PLANE_LAYER):
                l.Name = int(l.Name)
                assert l.Name not in stack
                stack[l.Name] = l

        if hasattr(s, 'SIGNAL_LAYER'):
            for l in make_list(s.SIGNAL_LAYER):
                l.Name = int(l.Name)
                assert l.Name not in stack
                stack[l.Name] = l

        stack = [layer for layer in list(stack.values())]
        stack.sort(key=(lambda l: l.Name))
        for layer in stack:
            layer.num = str(layer.Name)

        this.stack = stack

    def to_LayoutDB(this):
        outline = get_all_shapes(this.pcb.Layout.BOARD_OUTLINE)
        outline_shape = shapes_from_mentor_shapes(outline)
        if len(outline_shape) != 1:
            outline = get_all_shapes(this.pcb.Layout.MANUFACTURING_OUTLINE)
            outline_shape = shapes_from_mentor_shapes(outline)
            if len(outline_shape) != 1:
                print('WARNING: non-contiguous/empty outline shape encountered, taking bbox instead')
                bbox = get_pcb_boundingbox(this.pcb.Layout)
                outline_shape = [utils2d.Bbox2Rectangle(bbox)]
        outline_shape = outline_shape[0]
        layoutdb = layoutdbPy.new_iLayoutDB()
        layoutdb.name = this.design_name
        layoutdb.length_unit = common.units.standardize(this.db_unit)
        layoutdb.tolerance = common.units.get_typical_manufacturing_tolerance((layoutdb.length_unit), tolmu=1)
        this.sp = ShapeProcessor(layoutdb.tolerance)
        outline_shape = this.sp(outline_shape, sense=1, info='board outline')
        if outline_shape is None:
            print('WARNING: broken outline shape encountered, taking bounding box instead')
            bbox = get_pcb_boundingbox(this.pcb.Layout)
            outline_shape = utils2d.Bbox2Rectangle(bbox)
        else:
            outline_shape = this.sp(outline_shape, sense=1, info='board outline')
            if outline_shape is None:
                raise DatabaseReadError('Board outline could not be created')
            layoutdb.board_outline = outline_shape
            layoutdb.origin = 'CST MENTOR GRAPHICS EXPEDITION IMPORT V2'
            layoutdb.part_model_db = layoutdbPy.PartModelDB()
            layoutdb.is_x_mirror_mode = False
            if hasattr(this.pcb.JobPrefs, 'PADSTACK_TECHNOLOGY'):
                this.padstack_technology_name = this.pcb.JobPrefs.PADSTACK_TECHNOLOGY.lower()
            else:
                this.padstack_technology_name = None
        this.set_keys_upper()
        this.export_stackup(layoutdb)
        this.export_nets(layoutdb)
        this.export_generated_planes(layoutdb)
        this.export_components(layoutdb)
        check_pin_names(layoutdb.components())
        this.export_component_models(layoutdb)
        return layoutdb

    def set_keys_upper(this):
        new_padstack = {}
        for key, value in this.pcb.Padstack.PADSTACK.items():
            new_padstack[key.upper()] = value

        this.pcb.Padstack.PADSTACK = new_padstack

    def export_stackup(this, layoutdb):
        from common.layoutdb import check_layer_stackup
        this.clname2layer = {}
        for layer in this.stack:
            tmp = str(layer.Name)
            if len(tmp) < 2:
                tmp = '0' + tmp
            name = tmp + '_' + layer.LAYER_DESCRIPTION
            new_layer = layoutdbPy.new_iLayer()
            mat = layoutdbPy.Material()
            mat.mu = 1.0
            is_positive = True
            if hasattr(layer, 'CONDUCTIVE_LAYER_NUMBER'):
                typ = layoutdbPy.LayerType.Signal
                name += '_%s' % str(layer.CONDUCTIVE_LAYER_NUMBER)
                this.clname2layer[layer.CONDUCTIVE_LAYER_NUMBER] = name
                if hasattr(layer, 'PLANE_TYPE'):
                    typ = layoutdbPy.LayerType.Plane
                    if layer.PLANE_TYPE.lower() == 'negative':
                        is_positive = False
                if hasattr(layer, 'LAYER_RESISTIVITY'):
                    try:
                        mat.type = layoutdbPy.MaterialType.Conductor
                        mat.name = 'conductor'
                        res = float(layer.LAYER_RESISTIVITY)
                        if res > 0:
                            mat.condtan = 1.0 / res
                        else:
                            mat.condtan = 58000000.0
                        mat.eps = 1.0
                        new_layer.material = mat
                    except:
                        pass

            else:
                typ = layoutdbPy.LayerType.Dielectric
                if hasattr(layer, 'DIELECTRIC_CONSTANT'):
                    try:
                        mat.type = layoutdbPy.MaterialType.Dielectric
                        mat.name = 'dielectric'
                        mat.condtan = 0.02
                        mat.eps = float(layer.DIELECTRIC_CONSTANT)
                        new_layer.material = mat
                    except:
                        pass

                new_layer.name = name
                new_layer.layer_type = typ
                new_layer.is_positive = is_positive
                new_layer.thickness = layer.LAYER_THICKNESS
                layoutdb.add_layer_below(new_layer, new_layer)

        check_layer_stackup(layoutdb)

    def export_nets(this, layoutdb):
        nets = list(this.pcb.Layout.NET.values())
        print('Processing %s nets ... ' % len(nets))
        if this.progressbar is not None:
            this.progressbar.reset('Processing %s nets' % len(nets), len(nets))
        i = 0
        for net in nets:
            if not isinstance(net, mgchkp.hkp.HKPDB):
                if net is not None:
                    print('SKIPPED NET: ', net)
            else:
                this.export_net(net, layoutdb)
                i += 1
                if this.progressbar is not None:
                    this.progressbar.set(i)

        if this.progressbar is not None:
            this.progressbar.finished()
        del this.pcb.Layout.NET
        print('After processing nets:')
        print('#shapes = ', reduce(lambda x, y: x + y, [l.n_plane_shapes() for l in layoutdb.layers()]))

    def export_net(this, net, layoutdb):
        this.min_trace_width = 1e+100
        if hasattr(net, 'TRACE'):
            ts = net.TRACE
            if type(ts) != list:
                ts = [
                 ts]
            allshapes = {}
            for t in ts:
                cl = int(t.ROUTE_LYR[4:])
                if cl not in this.clname2layer:
                    print('WARNING: net %s: route layer %s not found for trace' % (net.Name, t.ROUTE_LYR))
                else:
                    layer = layoutdb.layer(this.clname2layer[cl])
                    tmp = get_all_shapes(t)
                    for key, val in tmp:
                        if '_PATH' in key and hasattr(val, 'WIDTH') and val.WIDTH > 0 and (this.min_trace_width < 0 or val.WIDTH < this.min_trace_width):
                            this.min_trace_width = val.WIDTH

                    shapes = shapes_from_mentor_shapes(tmp, separate_segments=True, is_trace=True, point_match_tol=(layoutdb.tolerance))
                    shapes = [s for s in shapes if s is not None]
                    if cl in allshapes:
                        allshapes[cl].extend(shapes)
                    else:
                        allshapes[cl] = shapes
                    for shape in shapes:
                        if isinstance(shape, layoutdbPy.Trace):
                            layoutdb.add_net_dirty(net.Name)
                            shape.net_index = layoutdb.net_index(net.Name)
                            layer.add_trace(shape)
                        else:
                            shape = this.sp(shape, sense=1, info='trace')
                            if shape is not None:
                                layoutdb.add_net_dirty(net.Name)
                                shape.net_index = layoutdb.net_index(net.Name)
                                layer.add_plane_shape(shape)

        layoutdb.simulation_settings.lateral_reference_length = this.min_trace_width
        if hasattr(net, 'CONDUCTIVE_AREA'):
            cas = net.CONDUCTIVE_AREA
            if type(cas) != list:
                cas = [
                 cas]
            allshapes = {}
            for t in cas:
                if not hasattr(t, 'CONDUCTIVE_AREA_OPTIONS'):
                    continue
                else:
                    if t.CONDUCTIVE_AREA_OPTIONS != 'CONDUCTIVE_SHAPE':
                        continue
                    cl = int(t.ROUTE_LYR[4:])
                    if cl not in this.clname2layer:
                        print('WARNING: net %s: route layer %s not found for conductive area' % (net.Name, t.ROUTE_LYR))
                        continue
                    layer = layoutdb.layer(this.clname2layer[cl])
                    tmp = get_all_shapes(t)
                    shapes = shapes_from_mentor_shapes(tmp, separate_segments=True, is_trace=False)
                    shapes = [s for s in shapes if s is not None]
                    if cl in allshapes:
                        allshapes[cl].extend(shapes)
                    else:
                        allshapes[cl] = shapes
                for shape in shapes:
                    if isinstance(shape, layoutdbPy.Trace):
                        layoutdb.add_net_dirty(net.Name)
                        shape.net_index = layoutdb.net_index(net.Name)
                        layer.add_trace(shape)
                    else:
                        shape = this.sp(shape, sense=1, info='conductive area')
                        if shape is not None:
                            layoutdb.add_net_dirty(net.Name)
                            shape.net_index = layoutdb.net_index(net.Name)
                            layer.add_plane_shape(shape)

        if hasattr(net, 'VIA'):
            for via in make_list(net.VIA):
                negpads = []
                cl1, cl2 = [int(i[4:]) for i in via.LAYER_PAIR.split()]
                viapos = via.XY
                if not hasattr(via, 'PADSTACK'):
                    print('WARNING: net %s: via at %s has got no PADSTACK (skipped)' % (net.Name, str(viapos)))
                else:
                    if type(via.PADSTACK) == str:
                        designpadstack = this.pcb.Padstack.PADSTACK[via.PADSTACK.upper()]
                        negpads = []
                    else:
                        if isinstance(via.PADSTACK, mgchkp.hkp.HKPDB):
                            designpadstack = this.pcb.Padstack.PADSTACK[via.PADSTACK.Name.upper()]
                            if hasattr(via.PADSTACK, 'NEG_PAD_NAME'):
                                negpads = make_list(via.PADSTACK.NEG_PAD_NAME)
                                for negpad in negpads:
                                    negpad.pos = viapos

                        else:
                            raise Exception('strange PADSTACK')
                if designpadstack.PADSTACK_TYPE != 'VIA':
                    print('WARNING: net %s, via at %s: unsuitable padstack type %s (skipped)' % (net.Name, str(viapos), designpadstack.PADSTACK_TYPE))
                else:
                    lps = this.export_lpadstack(designpadstack, layoutdb, negpads)
                    if lps is None:
                        print('WARNING: no library padstack found (via position=%s)' % str(viapos))
                    else:
                        ps = layoutdbPy.new_iPadstack()
                        ps.library_padstack = lps
                        layoutdb.add_net_dirty(net.Name)
                        ps.net = layoutdb.net(net.Name)
                        ps.position = viapos
                        ps.rotation = 0
                        if cl1 > cl2:
                            cl1, cl2 = cl2, cl1
                        ps.layer_from = layoutdb.layer(this.clname2layer[cl1])
                        ps.layer_to = layoutdb.layer(this.clname2layer[cl2])
                        this.set_neg_pads(ps, negpads, layoutdb)
                        layoutdb.add_padstack(ps)

    def export_lpadstack(this, padstack, layoutdb, negpads=[], smd=False, opp_side=False):
        """
        For vias and pin-throughs.
        """
        if padstack.PADSTACK_TYPE not in ('VIA', 'PIN_THROUGH', 'PIN_SMD'):
            print('WARNING: padstack %s: unrecognized type %s (skipped)' % (padstack.Name, padstack.PADSTACK_TYPE))
            return
        else:
            padstackname = padstack.Name
            if opp_side:
                padstackname += '_opp_side'
            if layoutdb.has_lpadstack(padstackname):
                return layoutdb.lpadstack(padstackname)
            lps = layoutdbPy.new_iLPadstack()
            lps.name = padstackname
            padtech = padstack.TECHNOLOGY
            if type(padtech) == list:
                padtechs = padtech
                padtech = None
                for padtech in padtechs:
                    if padtech.Name.lower() == '(default)':
                        break
                else:
                    print('WARNING: padstack %s has no (Default) technology' % padstackname)
                    return

                if this.padstack_technology_name is not None and this.padstack_technology_name != '(default)':
                    for addpadtech in padtechs:
                        if addpadtech.Name.lower() == this.padstack_technology_name:
                            for k, v in addpadtech.__dict__.items():
                                if k.lower() != 'name':
                                    setattr(padtech, k, v)

                            break

            if hasattr(padtech, 'HOLE_NAME'):
                hole = this.pcb.Padstack.HOLE[padtech.HOLE_NAME.Name]
                if padtech.HOLE_NAME.OFFSET.getNorm2() != 0:
                    print('WARNING: padstack %s (technology): hole has non-vanishing offset (not supported, skipped)' % padstackname)
                    return
                if not hasattr(hole, 'ROUND'):
                    print('WARNING: non-ROUND vias not supported up to now:\n', hole)
                    return
                r_hole = hole.ROUND.DIAMETER * 0.5
                lps.via_hole_shape = utils2dPy.make_circle_shape(R2(0, 0), r_hole, False)
            if padtech.TECHNOLOGY_OPTIONS != 'NONE':
                if "technology warning '%s'" % str(padtech.TECHNOLOGY_OPTIONS) not in this.warnings:
                    print("WARNING: technology options '%s' not understood" % str(padtech.TECHNOLOGY_OPTIONS))
                    this.warnings.add("technology warning '%s'" % str(padtech.TECHNOLOGY_OPTIONS))
            if not (smd and opp_side):
                if hasattr(padtech, 'TOP_PAD'):
                    top_pad = this.export_lpad(this.pcb.Padstack.PAD[padtech.TOP_PAD], layoutdb)
                    lps.pad(layoutdbPy.WhereType.top, layoutdbPy.ConnectType.unknown, top_pad)
            if not (smd and not opp_side):
                if hasattr(padtech, 'BOTTOM_PAD'):
                    bot_pad = this.export_lpad(this.pcb.Padstack.PAD[padtech.BOTTOM_PAD], layoutdb)
                    lps.pad(layoutdbPy.WhereType.bottom, layoutdbPy.ConnectType.unknown, bot_pad)
            if hasattr(padtech, 'INTERNAL_PAD'):
                if not smd:
                    ip = padtech.INTERNAL_PAD
                    if hasattr(ip, 'LAYER'):
                        for ipl in make_list(ip.LAYER):
                            int_pad = this.export_lpad(this.pcb.Padstack.PAD[ipl.OVERRIDE_PAD], layoutdb)
                            lyr = this.clname2layer[int(ipl.Name)]
                            lyr = layoutdb.layer(lyr)
                            lps.pad(lyr, layoutdbPy.ConnectType.unknown, int_pad)

                    else:
                        if type(ip) != str:
                            print('WARNING: error processing padstack %s (skipped)' % padstackname)
                            return
                        int_pad = this.export_lpad(this.pcb.Padstack.PAD[ip], layoutdb)
                        lps.pad(layoutdbPy.WhereType.inner, layoutdbPy.ConnectType.unknown, int_pad)
            if negpads is not None:
                for negpad in negpads:
                    cl = int(negpad.PAD_LYR[4:])
                    if cl not in this.clname2layer:
                        print('WARNING: pad layer %s not found (skipped)' % str(cl))
                    else:
                        layer = layoutdb.layer(this.clname2layer[cl])
                        if layer.layer_type != layoutdbPy.LayerType.Plane:
                            print("WARNING: negative pad on non-'PLANE' layer %s (skipped)" % negpad.PAD_LYR)
                        else:
                            if layer.is_positive:
                                print('WARNING: negative pad on positive plane layer %s (skipped 2)' % negpad.PAD_LYR)
                            else:
                                neg_pad = this.export_lpad(this.pcb.Padstack.PAD[negpad.Name], layoutdb)
                                lyr = this.clname2layer[int(negpad.PAD_LYR[4:])]
                                lyr = layoutdb.layer(lyr)
                                lps.pad(lyr, layoutdbPy.ConnectType.clearance, neg_pad)

            layoutdb.add_lpadstack(lps)
            return lps

    def export_lpad(this, pad, layoutdb):
        if layoutdb.has_lpad(pad.Name):
            return layoutdb.lpad(pad.Name)
        else:
            lp = layoutdbPy.new_iLPad()
            lp.name = pad.Name
            for s in get_pad_shapes(pad, (R2(0, 0)), rotation=0):
                cs = this.sp(s, sense=1, info='pad')
                if cs is not None:
                    lp.add_shape(cs)

            layoutdb.add_lpad(lp)
            return lp

    def set_neg_pads(this, ps, negpads, layoutdb):
        for negpad in negpads:
            cl = int(negpad.PAD_LYR[4:])
            if cl not in this.clname2layer:
                print('WARNING: pad layer %s not found (skipped)' % str(cl))
            else:
                layer = layoutdb.layer(this.clname2layer[cl])
                if layer.layer_type != layoutdbPy.LayerType.Plane:
                    print("WARNING: negative pad on non-'PLANE' layer %s (skipped)" % negpad.PAD_LYR)
                elif layer.is_positive:
                    print('WARNING: negative pad on positive plane layer %s (skipped 2)' % negpad.PAD_LYR)
                else:
                    ps.connect(layer, layoutdbPy.ConnectType.clearance)

    def export_generated_planes(this, layoutdb):
        if not hasattr(this.pcb.Layout, 'GENERATED_DATA'):
            print('Warning: PCB has no generated plane data')
            return
        else:
            gpdata = this.pcb.Layout.GENERATED_DATA
            if not hasattr(gpdata, 'PLANE_LYR'):
                print('Warning: PCB has no generated plane data[2]')
                return
            players = make_list(gpdata.PLANE_LYR)
            del gpdata.PLANE_LYR
            if this.progressbar is not None:
                this.progressbar.reset('Processing plane data', len(players))
            i = 0
            players.reverse()
            while len(players) > 0:
                player = players.pop()
                if player.PLANE_TYPE.upper() not in ('POSITIVE', 'NEGATIVE'):
                    print('WARNING: unrecognized plane type %s on layer %s (skipped)' % (player.Name, player.PLANE_TYPE))
                else:
                    if player.PLANE_TYPE.upper() == 'POSITIVE':
                        this.export_positive_plane(player, layoutdb)
                    else:
                        this.export_negative_plane(player, layoutdb)
                    i += 1
                    if this.progressbar is not None:
                        this.progressbar.set(i)
                    del player

            if this.progressbar is not None:
                this.progressbar.finished()

    def export_positive_plane(this, player, layoutdb):
        import time
        from common import utils, utils2d
        from common.utils2d import aps2swh
        cl = int(player.Name[4:])
        layer = layoutdb.layer(this.clname2layer[cl])
        if not layer.is_positive:
            print('WARNING: confusion about polarity of positive layer %s (skipped)' % player.Name)
            return
        if not hasattr(player, 'PLANE_NET'):
            print("WARNING: 'PLANE' layer %s has got no 'PLANE_NET' attribute (skipped)" % player.Name)
            return
        for pnet in make_list(player.PLANE_NET):
            if type(pnet) == str:
                pass
            else:
                print('Processing generated plane data on net %s, layer %s ...' % (pnet.Name, player.Name))
                shapes, strokes, apss = [], [], []
                if hasattr(pnet, 'ACTUAL_PLANE_SHAPE'):
                    ss0 = []
                    for aps in make_list(pnet.ACTUAL_PLANE_SHAPE):
                        if hasattr(aps, 'APS_HATCH_DATA'):
                            del aps.APS_HATCH_DATA
                        if hasattr(aps, 'APS_TIE_LEG'):
                            ss0.extend(make_list(aps.APS_TIE_LEG))
                            del aps.APS_TIE_LEG
                        aps_shapes = get_all_shapes(aps)
                        for s in shapes_from_mentor_shapes(aps_shapes, point_match_tol=(layoutdb.tolerance * 0.01)):
                            try:
                                a = aps2swh(s, layoutdb.tolerance * 0.001)
                                apss.append(a)
                            except:
                                print('WARNING: Unable to extract actual plane shape:')
                                print(s)

                    for s in ss0:
                        if len(s.__dict__) != 1:
                            print('WARNING: internal error processing actual plane shapes on layer %s (skippping one shape)' % player.Name)
                            continue
                        else:
                            key, = list(s.__dict__.keys())
                            val = getattr(s, key)
                            if key == 'POLYLINE_PATH' and hasattr(val, 'no_caps'):
                                strokes.extend(shapes_from_mentor_shape(key, val))
                            else:
                                shapes.extend(shapes_from_mentor_shape(key, val))

                else:
                    tmp = get_all_shapes(pnet)
                    for key, val in tmp:
                        if key == 'POLYLINE_PATH' and len(val.XY) == 2 and (val.XY[0].x == val.XY[1].x or val.XY[0].y == val.XY[1].y):
                            val.no_caps = 1

                    strokes = shapes_from_mentor_shapes([(key, val) for key, val in tmp if key == 'POLYLINE_PATH' if hasattr(val, 'no_caps')])
                    shapes = shapes_from_mentor_shapes([(key, val) for key, val in tmp if key != 'POLYLINE_PATH' or not hasattr(val, 'no_caps')])
                print('%d shapes on layer %s, net %s.' % (len(shapes) + len(strokes) + len(apss), player.Name, pnet.Name))
            if len(shapes) + len(strokes) + len(apss) == 0:
                print('WARNING: No generated plane data found on layer %s, net %s!' % (player.Name, pnet.Name))
            else:
                n_orig = len(shapes)
                shapes = [shape for shape in shapes if utils2d.Make_CClockwise(shape)]
                strokes = [shape for shape in strokes if utils2d.Make_CClockwise(shape)]
                apss = [shape for shape in apss if utils2d.Make_CClockwise(shape)]
                if len(apss):
                    if len(apss) == 1:
                        print('1 Actual Plane Shape.')
                    else:
                        print(len(apss), 'Actual Plane Shapes.')
                if n_orig != len(shapes):
                    print('WARNING: %d/%d shapes have errors and are skipped.' % (n_orig - len(shapes), n_orig))
                cswhs = vectorShapeWithHoles()
                for shape in apss + strokes + shapes:
                    cswh = this.sp(shape, sense=1, info='plane shape')
                    if cswh is not None:
                        cswhs.append(cswh)

                swhs = cswhs
                layoutdb.add_net_dirty(pnet.Name)
                i = layoutdb.net_index(pnet.Name)
                if swhs != None:
                    for cswh in swhs:
                        cswh.net_index = i
                        layer.add_plane_shape(cswh)

                del swhs
                del cswhs
                del shapes
                del strokes
                del apss

    def export_negative_plane(this, player, layoutdb):
        import time
        from common import utils
        from common.utils2d import decompress_shape
        print('Exporting negative plane:', player.Name)
        cl = int(player.Name[4:])
        layer = layoutdb.layer(this.clname2layer[cl])
        if layer.is_positive:
            print('WARNING: confusion about polarity of negative layer %s (skipped)' % player.Name)
            return
        if not hasattr(player, 'PLANE_NET'):
            print("WARNING: 'PLANE' layer %s has got no 'PLANE_NET' attribute (skipped)" % player.Name)
            return
        cswhs = vectorShapeWithHoles()
        for pnet in make_list(player.PLANE_NET):
            print('Processing generated plane cutouts on net %s, layer %s ...' % (pnet.Name, player.Name))
            for key, s in get_all_shapes(pnet):
                shapes = shapes_from_mentor_shape(key, s)
                for shape in shapes:
                    shape2 = this.sp(shape, sense=1, info='plane_shape')
                    if shape2 is not None:
                        cswhs.append(cswh)
                        continue

        print('Uniting %d cutouts...' % len(cswhs))
        swhs, errs, planeproc = utils.boolean_add(cswhs, (layoutdb.bounding_box),
          use_boolean_add=1,
          healing_tol=(layoutdb.tolerance),
          check_arcs=1,
          n=1000000000)
        i = layoutdb.net_index('NONE')
        for cswh in swhs:
            cswh.net_index = i
            layer.add_plane_shape(cswh)

    def export_test_layer(this):
        n, width, dist = (1000, 20.0, 11.0)
        height = 100.0
        x = 0.0
        shapes = []
        for i in range(n):
            xyrs = utils2d.straight_path_segment_to_XYR(R2(x, -height * 0.5), R2(x, height * 0.5), width)
            shapes.append(utils2d.Polyarc(xyrs))
            x += dist

        layer = this.conductor_layers[1]
        posshape = utils2d.Rectangle(R2(x / 2, 0), x + 10 * width, 2 * height)
        negative_plane_name = 'NegativePlane'
        posutils2d.shape_write(shape, (this.modfile), (layer.LAYER_DESCRIPTION),
          negative_plane_name, (layer.LAYER_THICKNESS),
          (layer.elevation), ok=1)
        for s in shapes:
            compname = 'Shape:%d' % this.solidcount
            this.solidcount += 1
            utils2d.shape_write(s, (this.modfile), (layer.LAYER_DESCRIPTION),
              compname, (layer.LAYER_THICKNESS),
              (layer.elevation), ok=1)
            this.modfile.write('109!%s!%s!%s\n' % (layer.LAYER_DESCRIPTION,
             negative_plane_name, compname))

    def export_component_models(this, layoutdb):
        if not hasattr(this.pcb, 'PDB') or not hasattr(this.pcb.PDB, 'Number'):
            print('WARNING: no parts description present in database.')
            return
        comps = layoutdb.components()
        for comp in comps:
            this.export_component_model(comp, layoutdb)

    def export_component_model(this, comp, layoutdb):
        from common.helpers import float_with_unit
        number = comp.em_model
        if layoutdb.part_model_db.has_lumped_element(number):
            return
        if number not in this.num2num:
            print('WARNING: no part description for component %s (partnumber %s)' % (comp.name, number))
            return
        part = this.pcb.PDB.Number[this.num2num[number]]
        description = None
        if hasattr(part, 'Desc'):
            description = part.Desc
        else:
            label = None
            if hasattr(part, 'Label'):
                label = part.Label
            elif hasattr(part, 'Prop') and type(part.Prop) != dict:
                tmp = {}
                for t in make_list(part.Prop):
                    a = t.split('",')
                    if len(a) < 2:
                        continue
                    attr = a[0].strip().strip('"')
                    val = a[1].strip().strip('"')
                    tmp[attr] = val

                part.Prop = tmp
            else:
                part.Prop = {}
            part.make_dict('SwapGroup')
            if 'Type' in part.Prop:
                if part.Prop['Type'].lower() in ('diode', 'resistor', 'capacitor',
                                                 'inductor', 'rcnetwork', 'ic', 'connector'):
                    typ = part.Prop['Type'].lower()
                else:
                    typ = 'unknown'
            else:
                typ = 'unknown'
            if 'IBIS' in part.Prop:
                ibismodelname = part.Prop['IBIS']
                typ = 'IBIS'
            if 'Height' in part.Prop:
                try:
                    height = float(part.Prop['Height'].replace(',', '.'))
                except:
                    pass

            if 'Attachment' in part.Prop:
                attachment = part.Prop['Attachment']
            orig = ''
            value = None
            if 'Value' in part.Prop:
                try:
                    orig = part.Prop['Value']
                    value = float_with_unit(part.Prop['Value'].replace(',', '.'))
                except:
                    pass

            if 'Value2' in part.Prop:
                try:
                    orig = part.Prop['Value2']
                    value = float_with_unit(part.Prop['Value2'].replace(',', '.'))
                except:
                    pass

            if typ in ('resistor', 'capacitor', 'inductor'):
                if comp.n_pins() == 2:
                    e = layoutdbPy.LumpedElementModel()
                    e.name = number
                    e.type = type_name_to_RLC_type(typ)
                    if value is not None:
                        val = value
                    else:
                        val = 0
                    attr = typ[0].upper()
                    if attr not in 'RLC':
                        attr = 'L'
                    setattr(e, attr, val)
                    if val != 0:
                        print('Interpreted lumped element value (%s #%s):' % (typ, number), orig, '->', val)
                    layoutdb.part_model_db.add_lumped_element(e)

    def export_components(this, layoutdb):
        if not hasattr(this.pcb.Layout, 'PACKAGE_CELL'):
            print('WARNING: No Components defined in design.')
            return
        for pcell in make_list(this.pcb.Layout.PACKAGE_CELL):
            this.export_component(pcell, layoutdb)

    def export_component(this, cell, layoutdb):
        if hasattr(cell, 'COMPONENT_OPTIONS'):
            if 'NOT_PLACED' in cell.COMPONENT_OPTIONS:
                return
            else:
                if hasattr(cell, 'TEXT'):
                    for text in make_list(cell.TEXT):
                        if text.TEXT_TYPE == 'REF_DES':
                            ref_des = text.Name
                            break
                    else:
                        ref_des = None

                else:
                    ref_des = None
                if ref_des is None:
                    print('WARNING: cell %s has no REF_DES attribute (skipped)' % cell.Name)
                    return
                comp = layoutdbPy.new_iComponent()
                comp.name = ref_des
                partnumber = None
                if hasattr(cell, 'TEXT'):
                    for text in make_list(cell.TEXT):
                        if hasattr(text, 'TEXT_TYPE'):
                            if text.TEXT_TYPE == 'PARTNO':
                                partnumber = text.Name
                                break

                if partnumber is None:
                    print('WARNING: component %s was assigned no part (skipped)' % ref_des)
                    return
                partnumber = partnumber.upper()
                if partnumber not in this.num2num:
                    print('WARNING: part number not present in parts database (comp %s)' % ref_des)
                    return
            if cell.PLACEMENT_LYR[:4] != 'LYR_':
                print('WARNING: unrecognized placement layer %s of cell %s (skipped)' % (cell.PLACEMENT_LYR, str(ref_des)))
                return
        else:
            cl = int(cell.PLACEMENT_LYR[4:])
            if cell.FACEMENT not in ('TOP', 'BOTTOM'):
                print("WARNING: cell.FACEMENT=%s is neither 'TOP' nor 'BOTTOM' -> skipping cell %s" % (cell.FACEMENT, str(ref_des)))
                return
            else:
                if cell.FACEMENT == 'TOP':
                    if cl != min(this.clname2layer.keys()):
                        print('WARNING: found cell (%s) with top placement which is on layer ' % cell.Name, cl)
                        return
                    oppcl = max(this.clname2layer.keys())
                    comp.side = layoutdbPy.WhereType.top
                else:
                    if cell.FACEMENT == 'BOTTOM':
                        if cl != max(this.clname2layer.keys()):
                            print('WARNING: found cell (%s) with bottom placement which is on layer ' % cell.Name, cl)
                            return
                        oppcl = min(this.clname2layer.keys())
                        comp.side = layoutdbPy.WhereType.bottom
                    else:
                        print('WARNING: Strange: cell is neither on top nor bottom!')
                return
        placement = cell.FACEMENT
        reglayer = this.clname2layer[cl]
        comp.position = cell.XY
        comp.rotation = cell.ROTATION * pi / 180.0
        ft = this.component_footprint(comp, cell, this.num2num[partnumber], layoutdb)
        for dps, mgctype in ft['padstacks']:
            comp.add_padstack(dps)
            if mgctype == 'PIN_SMD':
                if comp.side == layoutdbPy.WhereType.bottom:
                    dps.layer_from = dps.layer_to = layoutdb.bottom_etch_layer()
                else:
                    dps.layer_from = dps.layer_to = layoutdb.top_etch_layer()

        if comp.side == layoutdbPy.WhereType.bottom:
            for dps, mgctype in ft['padstacks']:
                dps.is_flipped = True

        for p, pinname, net in ft['pins']:
            pin = new_Pin()
            pin.position = p
            pin.name = pinname
            pin.net = layoutdb.net(net)
            comp.add_pin(pin)

        for o in ft['outlines']:
            comp.add_outline_shape(o)

        comp.em_model = partnumber
        layoutdb.add_component(comp)

    def component_footprint(this, comp, pkgcell, partnumber, layoutdb):
        if not partnumber in this.pcb.PDB.Number:
            raise AssertionError
        else:
            part = this.pcb.PDB.Number[partnumber]
            if hasattr(part, 'TopCell'):
                if len(part.TopCell):
                    celltop = part.TopCell
                else:
                    celltop = ''
            elif hasattr(part, 'BottomCell') and len(part.BottomCell):
                cellbot = part.BottomCell
            else:
                cellbot = ''
            ftlib = ''
            if len(cellbot):
                if len(celltop):
                    print('WARNING: both cell at top/bottom not supported')
            if len(cellbot):
                ftlib = cellbot
            elif len(celltop):
                ftlib = celltop
        ftlocal = this.cellinfo(pkgcell, ftlib, layoutdb, partnumber)
        return ftlocal

    def equal_footprints(this, ft1, ft2, tol):
        tol2 = tol * tol
        if ft1.n_pins() != ft2.n_pins():
            return False
        else:
            if ft1.n_padstacks() != ft2.n_padstacks():
                return False
            for i in range(ft1.n_pins()):
                if (ft1.pin(i) - ft2.pin(i)).getNorm2() > tol2:
                    return False

            for i in range(ft1.n_padstacks()):
                ps1 = ft1.padstack(i)
                ps2 = ft2.padstack(i)
                if ps1.library_padstack != ps2.library_padstack:
                    return False
                if (ps1.position - ps2.position).getNorm2() > tol2:
                    return False
                if abs(ps1.rotation - ps2.rotation) > 0.0001:
                    return False

            return True

    def cellinfo(this, cell, libcell, layoutdb, partnumber=''):
        if libcell in this.pcb.Cell.PACKAGE_CELL:
            libcell = this.pcb.Cell.PACKAGE_CELL[libcell]
        else:
            libcell = None
            print('WARNING: no library cell found for part %s' % partnumber)
        ft = {'name':cell.Name, 
         'outlines':[],  'pins':[],  'padstacks':[]}
        if hasattr(cell, 'XY'):
            ftpos = cell.XY
        else:
            ftpos = R2(0, 0)
        if hasattr(cell, 'ROTATION'):
            ftrot = cell.ROTATION * pi / 180
        else:
            ftrot = 0
        mount_type = layoutdbPy.MountType.unknown
        mixed = False
        if hasattr(libcell, 'MOUNT_TYPE'):
            if libcell.MOUNT_TYPE == 'SURFACE':
                mount_type = layoutdbPy.MountType.surface
            else:
                if libcell.MOUNT_TYPE == 'MIXED':
                    mixed = True
                    mount_type = layoutdbPy.MountType.surface
                else:
                    if libcell.MOUNT_TYPE == 'THROUGH':
                        mount_type = layoutdbPy.MountType.through
                    else:
                        mount_type = layoutdbPy.MountType.unknown
        if mount_type == layoutdbPy.MountType.unknown:
            print('WARNING: unknown mount type for cell %s, assuming surface mount' % partnumber)
            mount_type = layoutdbPy.MountType.surface
        ft['mount_type'] = mount_type
        smd = mount_type == layoutdbPy.MountType.surface or mixed
        if hasattr(cell, 'PLACEMENT_OUTLINE'):
            po = cell.PLACEMENT_OUTLINE
            tmp = get_all_shapes(po)
            shapes = shapes_from_mentor_shapes(tmp, separate_segments=True, is_trace=True)
            shapes = [s for s in shapes if s is not None]
            for shape in shapes:
                if isinstance(shape, layoutdbPy.Trace):
                    print('WARNING: trace encountered in cell')
                    continue
                try:
                    cswh = this.sp(shape, sense=1, info='component outline')
                    if cswh is not None:
                        ft['outlines'].append(cswh)
                except:
                    print('WARNING: Broken outline shape ignored (cell %s)' % ft['name'])

        bbox = None
        for pin in make_list(cell.PIN):
            pinname = pin.Name
            if hasattr(pin, 'NETNAME'):
                netname = pin.NETNAME
            else:
                netname = 'NONE'
            pinpos = pin.XY * 1
            if bbox is None:
                bbox = utils2dPy.BoundingBox(pinpos, pinpos)
            else:
                bbox.extend(pinpos)
            ft['pins'].append((pinpos, pinname, netname))
            rotation = pin.ROTATION * pi / 180.0
            opp_side = 'OPP_SIDE' in pin.PIN_OPTIONS
            negpads = []
            if type(pin.PADSTACK) == str:
                designpadstack = this.pcb.Padstack.PADSTACK[pin.PADSTACK.upper()]
            else:
                designpadstack = this.pcb.Padstack.PADSTACK[pin.PADSTACK.Name.upper()]
                if hasattr(pin.PADSTACK, 'NEG_PAD_NAME'):
                    negpads = make_list(pin.PADSTACK.NEG_PAD_NAME)
                    for negpad in negpads:
                        negpad.pos = pin.XY

                if designpadstack.PADSTACK_TYPE not in ('PIN_SMD', 'PIN_THROUGH'):
                    print('WARNING: unrecognized design padstack type: %s -> cell %s skipped' % (str(designpadstack.PADSTACK_TYPE), str(ref_des)))
                    return
                ps = layoutdbPy.new_iPadstack()
                layoutdb.add_net_dirty(netname)
                ps.net = layoutdb.net(netname)
                ps.position = pinpos
                ps.rotation = rotation
                ps.layer_from = layoutdb.top_etch_layer()
                ps.layer_to = layoutdb.bottom_etch_layer()
                if opp_side:
                    ps.is_y_mirrowed = True
                if designpadstack.PADSTACK_TYPE == 'PIN_THROUGH':
                    if hasattr(pin.PADSTACK, 'NEG_PAD_NAME'):
                        negpads = make_list(pin.PADSTACK.NEG_PAD_NAME)
                    else:
                        negpads = []
                    lps = this.export_lpadstack(designpadstack, layoutdb, negpads=negpads, smd=smd, opp_side=opp_side)
                    if lps is None:
                        print('WARNING: missing library padstack (pos=%s)' % str(pinpos))
                    else:
                        ps.library_padstack = lps
                        this.set_neg_pads(ps, negpads, layoutdb)
                else:
                    lps = this.export_lpadstack(designpadstack, layoutdb, smd=smd, opp_side=opp_side)
                    if lps is None:
                        print('WARNING: missing library padstack (pos=%s)' % str(pinpos))
                    else:
                        ps.library_padstack = lps
            ft['padstacks'].append((ps, designpadstack.PADSTACK_TYPE))
            if len(ft['outlines']) == 0:
                print('WARNING: no placement outline available for cell %s, taking bounding box instead' % ft['name'])
                ft['outlines'].append(utils2dPy.CShapeWithHoles(utils2dPy.make_rectangle_shape(utils2dPy.R2(bbox.xmin, bbox.ymin), utils2dPy.R2(bbox.xmax, bbox.ymax), True)))

        return ft

    def get_pin_net(this, ref_des, pinnum):
        if ref_des is None:
            print('WARNING: cannot determine net of pin for a cell with ref_des=None')
            return '(Net0)'
        else:
            pin = ref_des + '-' + pinnum
            if pin in this.pin2net_map:
                return this.pin2net_map[pin]
            return

    def get_cell_names(this, cell):
        refdes = None
        partnumber = '?'
        if hasattr(cell, 'TEXT'):
            for text in make_list(cell.TEXT):
                if not hasattr(text, 'TEXT_TYPE'):
                    pass
                else:
                    typ = text.TEXT_TYPE.lower()
                    if typ == 'ref_des':
                        refdes = text.Name
                    else:
                        if typ == 'partno':
                            partnumber = text.Name
                        else:
                            if typ == 'part number':
                                partnumber = text.Name

        return (
         ref_des, partnumber)

    def export_cellcomponent(this, cell, layoutdb):
        from common.layoutdb import ComponentPy, vectorPin
        from math import pi
        refdes = None
        partnumber = '?'
        if hasattr(cell, 'TEXT'):
            for text in make_list(cell.TEXT):
                if not hasattr(text, 'TEXT_TYPE'):
                    pass
                else:
                    typ = text.TEXT_TYPE.lower()
                    if typ == 'ref_des':
                        refdes = text.Name
                    else:
                        if typ == 'partno':
                            partnumber = text.Name
                        else:
                            if typ == 'part number':
                                partnumber = text.Name

        if refdes is None:
            print('WARNING: cell %s has no ref_des!' % cell.Name)
        if cell.PLACEMENT_LYR[:4] != 'LYR_':
            print('WARNING: Cell (%s) placement layer name not recognized: %s -> skipped cell.' % (str(refdes), str(cell.PLACEMENT_LYR)))
            return
        cl = int(cell.PLACEMENT_LYR[4:])
        layername = this.clname2layer[cl]
        comp = ComponentPy()
        comp.init(refdes=refdes,
          layername=layername,
          partnumber=partnumber,
          pins=(vectorPin()),
          mount_type='',
          pos=(cell.XY * 1),
          rotation=(cell.ROTATION * pi / 180.0))
        layoutdb.set_component(comp)

    def export_RouteBorder(this, obj):
        pass

    def get_layer_colors(this):
        App, Doc = this.App, this.Doc
        gdc = Doc.ActiveView.DisplayControl.Global
        stack = this.LayerStack
        for num, layer in stack.items():
            try:
                if layer.is_conductor:
                    col = gdc.ConductorLayerColor(layer.CONDUCTIVE_LAYER_NUMBER, 1)
                    layer.tracecolor = (col.Red / 255.0, col.Green / 255.0, col.Blue / 255.0)
            except:
                print('FAILED DETERMINING COLORS OF LAYER ', num)
                layer.tracecolor = (1, 1, 1)


def remove_tangent_turns(xyrs):
    from math import atan2, pi
    remove = []
    tlast = None
    for i in range(1, len(xyrs) - 1):
        p0, r0 = xyrs[(i - 1)]
        p, r = xyrs[i]
        p1, r1 = xyrs[(i + 1)]
        if not r0 != 0:
            if r != 0 or r1 != 0:
                pass
            else:
                t0 = p - p0
                t0 /= t0.getNorm()
                t1 = p1 - p
                t1 /= t1.getNorm()
                phi = abs(atan2(t0.cross(t1), t0.dot(t1)))
                if abs(phi - pi) < 1e-05:
                    remove.append(i)

    remove.reverse()
    for i in remove:
        del xyrs[i]

    if len(xyrs) > 2:
        p0, r0 = xyrs[1]
        p, r = xyrs[0]
        p1, r1 = xyrs[(-2)]
        if r0 != 0 or r != 0 or r1 != 0:
            pass
        else:
            t0 = p - p0
            t0 /= t0.getNorm()
            t1 = p1 - p
            t1 /= t1.getNorm()
            phi = abs(atan2(t0.cross(t1), t0.dot(t1)))
            if abs(phi - pi) < 1e-05:
                del xyrs[0]
                del xyrs[-1]
                xyrs.append(xyrs[0])
                remove.append(1)
    return len(remove) != 0


def make_polyarc_shape(hkp):
    xyrs = hkp.XYR
    opts = hkp.SHAPE_OPTIONS.split()
    return PolyarcShape(xyrs)


def make_polyline_shape(hkp):
    xys = hkpp.XY
    opts = hkp.SHAPE_OPTIONS.split()
    return PolylineShape(xys)


def make_circle_shape(hkp):
    print('not covered: ', hkp)


def make_rect_shape(hkp):
    print('not covered: ', hkp)


def make_polyarcpath_shape(hkp):
    print('not covered: make_polyarcpath_shape', hkp)


def make_polylinepath_shape(hkp):
    xyrs = utils2d.polyline_path_to_xyrs(hkp, roundcaps=True)
    if len(xyrs):
        return PolyarcShape(xyrs)
    else:
        print('Warning: not covered: ', hkp)
        return


def make_circlepath_shape(hkp):
    print('not covered: ', hkp)


def make_rectpath_shape(hkp):
    print('not covered: ', hkp)


shape_dispatcher = {'POLYARC_SHAPE':make_polyarc_shape, 
 'POLYLINE_SHAPE':make_polyline_shape, 
 'CIRCLE_SHAPE':make_circle_shape, 
 'RECT_SHAPE':make_rect_shape, 
 'POLYARC_PATH':make_polyarcpath_shape, 
 'POLYLINE_PATH':make_polylinepath_shape, 
 'CIRCLE_PATH':make_circlepath_shape, 
 'RECT_PATH':make_rectpath_shape}
shape_dispatcher_keys = list(shape_dispatcher.keys())

def create_shape_object(key, val):
    if key in shape_dispatcher_keys:
        maker = shape_dispatcher[key]
        return maker(val)
    print('Unknown geometry object: key=%s' % key)
    print(val)
    raise Exception('not covered')


def create_shape_objects(liste):
    return [create_shape_object(key, val) for key, val in liste]


class PCBHKP:
    names = {'Cell':'cel', 
     'JobPrefs':'jpf',  'Layout':'lyt',  'Padstack':'psk',  'PDB':'pdb'}

    def __init__(this, path, subpath='Output/VBASCII', progressbar=None):
        import mgchkp.hkp as hkp, os.path
        hkpname = os.path.join(path, subpath, 'JobPrefs.hkp')
        tmp = mgchkp.hkp.HKPDB(mgchkp.hkp.FileWithPush(open(hkpname, encoding='cp1252')))
        if hasattr(tmp, 'DESIGN_UNITS'):
            this.design_units = tmp.DESIGN_UNITS
            print('DESIGN_UNITS = ', this.design_units)
        else:
            print('WARNING: no design units given (now using um)!')
            this.design_units = 'MU'
        try:
            hkp.set_design_units(tmp.DESIGN_UNITS)
        except:
            print('WARNING: no design units given (now using um)!')
            this.design_units = 'MU'
            hkp.set_design_units(tmp.DESIGN_UNITS)

        totalsize = 0
        for name in this.names:
            hkpname = os.path.join(path, subpath, name + '.hkp')
            totalsize += os.path.getsize(hkpname)

        if progressbar is not None:
            progressbar.reset('Reading ASCII files', totalsize)
        this.path = path
        progress = 0
        for name in this.names:
            hkpname = os.path.join(path, subpath, name + '.hkp')
            fwp = mgchkp.hkp.FileWithPush(open(hkpname, encoding='cp1252'), progress_start=progress, progressbar=progressbar)
            progress += os.path.getsize(hkpname)
            setattr(this, name, mgchkp.hkp.HKPDB(fwp))

        if progressbar is not None:
            progressbar.finished()
        this.Padstack.make_dict('PAD')
        this.Padstack.make_dict('HOLE')
        this.Padstack.make_dict('PADSTACK')
        this.Layout.make_dict('NET')
        this.Cell.make_dict('PACKAGE_CELL')


def valid_ascii_dir(dir):
    if not os.path.exists(dir):
        return 'ERROR: the directory "%s" does not exist' % dir
    else:
        l = os.listdir(dir)
        txt = 'The following ASCII files are missing\n[directory "%s"]:\n' % dir
        okay = True
        for name in PCBHKP.names:
            name += '.hkp'
            if name not in l:
                txt += '\t- %s\n' % name
                okay = False

        if okay:
            return 'ok'
        return txt


class App:

    def __init__(this):
        this.gui = GUI()

    def LockServer():
        pass

    def __getattr__(this, attr):
        if attr == 'Gui':
            return this.gui
        else:
            return


class Doc:

    def __init__(this):
        this.path = None

    def __getattr__(this, attr):
        if attr == 'Name':
            return input('design name?:')
        else:
            if attr == 'Path':
                if this.path is None:
                    this.path = input('path?:')
                return this.path
            return


class GUI:

    def StatusBarText(this, text):
        print('StatusBarText:', text)

    def ProgressBarInitialize(this, a, b, c, d):
        pass

    def ProgressBar(this, a):
        pass


def init_document():
    return (
     App(), Doc())


def exportfullhkp(hkppath=None, basedir=None):
    import os.path, shutil
    defcstpath = 'Output/CST'
    if hkppath is None:
        App, Doc = init_document()
        Gui = App.Gui
        defoutpath = 'Output/VBASCII'
        docname = Doc.Name
        prjpath = Doc.Path
        docpath = os.path.join(Doc.Path, docname)
        cstpath = os.path.join(Doc.Path, defcstpath)
        vbascii = os.path.join(cstpath, 'VBASCII')
        if not os.path.exists(vbascii):
            os.makedirs(vbascii)
        docmtime = os.path.getmtime(docpath)
        createhkp = []
        okhkp = []
        for name in PCBHKP.names:
            hkpname = name + '.hkp'
            hkppath = os.path.join(Doc.Path, defoutpath, hkpname)
            if os.path.exists(hkppath):
                if os.path.getmtime(hkppath) >= docmtime:
                    okhkp.append((name, hkppath))
                    continue
            hkppath = os.path.join(vbascii, hkpname)
            if os.path.exists(hkppath):
                if os.path.getmtime(hkppath) >= docmtime:
                    continue
            createhkp.append(name)

        for name, path in okhkp:
            fsrc = path
            fdst = os.path.join(vbascii, name + '.hkp')
            shutil.copyfile(fsrc, fdst)

        fatal = False
        unit = 'TH'
        for name in createhkp:
            try:
                tmpname = name + 'DB.' + PCBHKP.names[name]
                Gui.StatusBarText('Creating %s...' % tmpname)
                libname = os.path.join(prjpath, 'Layout', tmpname)
                hkpname = os.path.join(vbascii, name + '.hkp')
                cmd = '%sDB2HKP.exe -u %s -i %s -o %s' % (name, unit, libname, hkpname)
                print(cmd)
                retval = os.system(cmd)
                if retval:
                    fatal = True
                    Gui.Display('the following command failed: %s' % cmd)
            except:
                print('the following command failed: %s' % name)

    else:
        vbascii = hkppath
        if basedir is None:
            cstpath = os.path.join(hkppath, defcstpath)
        else:
            cstpath = basedir
        App, Doc = init_document()
        Gui = GUI()
    Gui.StatusBarText('Reading ASCII files...')
    pcb = PCBHKP(vbascii, subpath='')
    Gui.StatusBarText('Starting export to CST...')
    E = Export(pcb, directory=cstpath, App=App, Doc=Doc)
    E.export_nets()
    E.export_cells()
    E.export_generated_planes()
    E.finished()
    Gui.StatusBarText('export to CST finished successfully.')
    return E


def get_jobprefs(path):
    import mgchkp.hkp
    pathhkp = os.path.join(path, 'Output', 'VBASCII')
    if not os.path.exists(pathhkp):
        os.makedirs(pathhkp)
    pathhkp = os.path.join(pathhkp, 'JobPrefs.hkp')
    pathdb = os.path.exists(pathhkp) or os.path.join(path, 'Layout', 'JobPrefsDB.jpf')
    if not os.path.exists(pathdb):
        return
    cmd = 'JobPrefsDB2HKP.exe -u TH -i %s -o %s' % (pathdb, pathhkp)
    try:
        os.system(cmd)
    except:
        return
    else:
        return mgchkp.hkp.HKPDB(mgchkp.hkp.FileWithPush(open(pathhkp, encoding='cp1252')))


def Run(filename, importer):
    import os, sys
    vbascii = os.path.dirname(filename)
    s = valid_ascii_dir(vbascii)
    if s != 'ok':
        raise DatabaseReadError(s)
    print('=' * 60)
    print('Reading MGC Expedition database ...\n')
    layoutdb = None
    pcb = PCBHKP(vbascii, subpath='', progressbar=importer)
    e = Export(pcb, progressbar=importer)
    layoutdb = e.to_LayoutDB()
    print('Finished reading MGC Expedition database.')
    print('=' * 80)
    if layoutdb is not None:
        importer.db = layoutdb
    return 0


if __name__ == '__main__':
    import sys
    print(sys.argv)
    pcb = PCBHKP((sys.argv[1]), subpath='')
    E = Export(pcb)
    db = E.to_LayoutDB()
# okay decompiling exporthkp.pyc
