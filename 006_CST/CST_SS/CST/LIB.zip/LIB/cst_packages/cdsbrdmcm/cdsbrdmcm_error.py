# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\cdsbrdmcm\cdsbrdmcm.py
# Compiled at: 2019-07-26 18:49:21
# Size of source mod 2**32: 124072 bytes
Instruction context:
-> 
 L.2022         4  FOR_ITER             82  'to 82'
                   6  STORE_FAST               'ids'
import sys, os, types, math, re
from .eparser import parse_file, Parser
from common.utils2d import R2, CurveSegment, ArrayCurveSegment, Shape, Make_CClockwise, Make_Clockwise, BoundingBox, Planeprocessor, vectorShapeWithHoles
from common.utils2d import CircleShape, RectangleC, PolyarcShape, straight_path_segment_to_XYR, PolylineShape, Bbox2Rectangle
from common.utils2d import ShapeProcessor
from common.layoutdb import check_layer_stackup, check_pin_names
from common.layoutdb import DatabaseReadError
from common.helpers import to_float
from common.shapemanager import create_standart_shapes
from layoutdbPy import *
import layoutdbPy
from utils2dPy import *
import utils2dPy
from . import profile_parser

def convert(data, att, typ):
    for d in data:
        if hasattr(d, att):
            setattr(d, att, typ(getattr(d, att)))


def make_list(x):
    if type(x) != list:
        return [
         x]
    else:
        return x


def extract_segments(data):
    convert(data, 'GRAPHIC_DATA_NUMBER', int)
    segs = []
    for d in data:
        if d.GRAPHIC_DATA_NAME == 'ARC':
            a = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
            b = R2(float(d.GRAPHIC_DATA_3), float(d.GRAPHIC_DATA_4))
            c = R2(float(d.GRAPHIC_DATA_5), float(d.GRAPHIC_DATA_6))
            R, w = float(d.GRAPHIC_DATA_7), float(d.GRAPHIC_DATA_8)
            assert d.GRAPHIC_DATA_9 in ('CLOCKWISE', 'COUNTERCLOCKWISE')
            ccw = d.GRAPHIC_DATA_9 != 'CLOCKWISE'
            if not ccw:
                R = -R
            typ = d.GRAPHIC_DATA_10
            if a == b:
                m = c - a + c
                segs.append((CurveSegment(a, m, c, R), typ))
                segs.append((CurveSegment(m, b, c, R), typ))
            else:
                segs.append((CurveSegment(a, b, c, R), typ))
        elif d.GRAPHIC_DATA_NAME == 'LINE':
            a = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
            b = R2(float(d.GRAPHIC_DATA_3), float(d.GRAPHIC_DATA_4))
            w = float(d.GRAPHIC_DATA_5)
            seg = CurveSegment(a, b)
            typ = d.GRAPHIC_DATA_10
            segs.append((seg, typ))
        elif d.GRAPHIC_DATA_NAME == 'RECTANGLE':
            a0 = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
            a2 = R2(float(d.GRAPHIC_DATA_3), float(d.GRAPHIC_DATA_4))
            a1 = a0 * 1
            a1.x = a2.x
            a3 = a2 * 1
            a3.x = a0.x
            filled = d.GRAPHIC_DATA_5 != 0
            typ = 'POLYGON'
            segs.extend([(CurveSegment(a0, a1), typ), (CurveSegment(a1, a2), typ), (CurveSegment(a2, a3), typ), (CurveSegment(a3, a0), typ)])
        else:
            print('ERROR: Dont know how to handle this:', d)
            continue

    return segs


def group_segments(seglist):
    groups = []
    if not len(seglist):
        return groups
    else:
        p0 = None
        group = []
        for seg in seglist:
            group.append(seg)
            if p0 is None:
                p0 = seg.a
            else:
                if seg.b == p0:
                    groups.append(group)
                    group = []
                    p0 = None

        assert len(group) == 0
        return groups


def connected_shape_from_segments(segs, tol=0):
    N = len(segs)
    if N == 0:
        return
    segs = [seg for seg, typ, w in segs]
    done = [
     False] * N
    ordered = [segs[0]]
    done[0] = True
    count = 1
    p = ordered[0].b
    while count < N:
        for i in range(N):
            if not done[i]:
                seg = segs[i]
                if seg.a == p:
                    count += 1
                    done[i] = True
                    p = seg.b
                    ordered.append(seg)
                    break
                elif seg.b == p:
                    count += 1
                    done[i] = True
                    p = seg.a
                    seg.reverse()
                    ordered.append(seg)
                    break
        else:
            return

    try:
        s = segs2shape(ordered)
        return s
    except:
        return


def part_to_shapes(part, is_outline=False, tol=0.0):
    from common.utils2d import segment2shape, CircleShape, RectangleC
    part = [d for d in part if d.GRAPHIC_DATA_NAME != 'TEXT']
    if len(part) == 0:
        return []
    if part[0].GRAPHIC_DATA_NAME in ('RECTANGLE', ):
        assert len(part) == 1
        d = part[0]
        a0 = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
        a2 = R2(float(d.GRAPHIC_DATA_3), float(d.GRAPHIC_DATA_4))
        a1 = a0 * 1
        a1.x = a2.x
        a3 = a2 * 1
        a3.x = a0.x
        filled = d.GRAPHIC_DATA_5 != 0
        if is_outline:
            return segs2shape([CurveSegment(a0, a1), CurveSegment(a1, a2),
             CurveSegment(a2, a3), CurveSegment(a3, a0)])
        else:
            return [
             segs2shape([CurveSegment(a0, a1), CurveSegment(a1, a2),
              CurveSegment(a2, a3), CurveSegment(a3, a0)])]
    if part[0].GRAPHIC_DATA_NAME in ('FIG_RECTANGLE', 'FIG_SQUARE', 'SQUARE'):
        assert len(part) == 1
        d = part[0]
        pos = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
        w, h = float(d.GRAPHIC_DATA_3), float(d.GRAPHIC_DATA_4)
        if is_outline:
            return RectangleC(w, h, origin=pos)
        else:
            return [
             RectangleC(w, h, origin=pos)]
    if part[0].GRAPHIC_DATA_NAME in ('CIRCLE', 'FIG_CIRCLE'):
        if not len(part) == 1:
            raise AssertionError
        else:
            d = part[0]
            c = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
            Ra, Rb = float(d.GRAPHIC_DATA_3) * 0.5, float(d.GRAPHIC_DATA_4) * 0.5
            filled = d.GRAPHIC_DATA_5 != 0
            assert Ra == Rb
        if is_outline:
            return CircleShape(c, Ra)
        else:
            return [
             CircleShape(c, Ra)]
    not_treated = 0
    segs = []
    shapes = []
    for d in part:
        if d.GRAPHIC_DATA_10 == 'NOTCONNECT':
            if not is_outline:
                if d.CLASS not in ('PACKAGE GEOMETRY', 'COMPONENT GEOMETRY'):
                    continue
        if d.GRAPHIC_DATA_NAME == 'ARC':
            a = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
            b = R2(float(d.GRAPHIC_DATA_3), float(d.GRAPHIC_DATA_4))
            c = R2(float(d.GRAPHIC_DATA_5), float(d.GRAPHIC_DATA_6))
            R, w = float(d.GRAPHIC_DATA_7), float(d.GRAPHIC_DATA_8)
            assert d.GRAPHIC_DATA_9 in ('CLOCKWISE', 'COUNTERCLOCKWISE')
            ccw = d.GRAPHIC_DATA_9 != 'CLOCKWISE'
            if not ccw:
                R = -R
            typ = d.GRAPHIC_DATA_10
            if a == b:
                m = c - a + c
                segs.append((CurveSegment(a, m, c, R), typ, w))
                segs.append((CurveSegment(m, b, c, R), typ, w))
            else:
                seg = CurveSegment(a, b, c, R)
                segs.append((seg, typ, w))
        else:
            if d.GRAPHIC_DATA_NAME == 'LINE':
                a = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
                b = R2(float(d.GRAPHIC_DATA_3), float(d.GRAPHIC_DATA_4))
                w = float(d.GRAPHIC_DATA_5)
                seg = CurveSegment(a, b)
                typ = d.GRAPHIC_DATA_10
                segs.append((seg, typ, w))
            else:
                print('ERROR: Dont know how to handle this:', d.GRAPHIC_DATA_NAME)
                not_treated += 1
                continue

    if len(segs) == 0:
        return []
    problematic = False
    w0 = segs[0][2]
    for seg, typ, w in segs:
        if (w0 == 0) != (w == 0):
            problematic = True

    if problematic:
        return []
    elif w0 == 0 or is_outline:
        if d.CLASS not in ('PACKAGE GEOMETRY', 'COMPONENT GEOMETRY'):
            try:
                shape = segs2shape([seg for seg, typ, w in segs])
                return shape
            except:
                if is_outline:
                    return [seg for seg, typ, w in segs]
                else:
                    print('WARNING: ignored zero-width connect line near %s' % str(segs[0][0].a))
                    return []

    else:
        if d.CLASS in ('PACKAGE GEOMETRY', 'COMPONENT GEOMETRY'):
            s = connected_shape_from_segments(segs)
            if s is not None:
                return [s]
            else:
                w0 = tol * 10
                shapes = []
                for seg, typ, w in segs:
                    shapes.append(segment2shape(seg, w0, tol=0))

                return shapes
        else:
            traces = []
            for seg, typ, w in segs:
                t = Trace()
                t.add_segment(seg, w)
                traces.append(t)

            return traces


def segs2shape(segs):
    ss = ArrayCurveSegment(0)
    for s in segs:
        ss.append(s)

    return Shape(ss)


def cond_unit_to_SI(u):
    if u == 'mho/cm':
        return 100.0
    else:
        print('ERROR: Unable to convert %s to SI units!' % str(u))
        return 1.0


class BrdMcm:

    def __init__(this, filename, progressbar=None):
        this.filename = filename
        filenamebase, ext = os.path.splitext(filename)
        ext = ext.lower()
        this.design_type = ext[1:]
        if not this.design_type in ('brd', 'mcm', 'sip'):
            raise AssertionError
        else:
            filenamebase = os.path.abspath(filenamebase)
            from .run_extracta import Extracta
            this.progressbar = progressbar
            this.ports = None
            if progressbar != None:
                last_extracta_version = progressbar.get_cst_link_version()
            else:
                import PCBconverter
            p = PCBconverter.PCBconverter()
            last_extracta_version = p.get_cst_link_version()
        glob = {}
        if os.path.exists(filenamebase + '-select.sel'):
            exec(compile(open(filenamebase + '-select.sel').read(), filenamebase + '-select.sel', 'exec'), glob)
        this.selection_options = glob
        extracta_version = None
        cst_link_version = None
        if os.path.exists(filenamebase + '-version.txt'):
            glob = {}
            exec(compile(open(filenamebase + '-version.txt').read(), filenamebase + '-version.txt', 'exec'), glob)
            if 'cst_link_version' in glob:
                cst_link_version = glob['cst_link_version']
            if 'extracta_version' in glob:
                extracta_version = glob['extracta_version']
        parsed, found_some_old = this.parse_extracta_files(filenamebase, filename)
        this.running_extracta_from_mws = False
        this.skipped_elements = set()
        if not parsed or cst_link_version is None and found_some_old:
            Extracta(filename, last_extracta_version)
            this.running_extracta_from_mws = True
            parsed, found_some_old = this.parse_extracta_files(filenamebase, filename)
            if not parsed:
                raise DatabaseReadError('Unable to extract ASCII files from Cadence design file, extracta failed (see extract.log).')
        else:
            text = None
        if cst_link_version == None and extracta_version == None or extracta_version != None and extracta_version != last_extracta_version or cst_link_version != None and cst_link_version != last_extracta_version:
            text = 'The present ASCII files have been generated with a previous CST software version.'
            text += 'It is recommended to regenerate these files'
            text += '( delete *.txt files and re-import the design; for package layouts (APD/SiP) it is recommended to use the Cadence Plug-in).'
            what = 'Allegro'
            if this.design_type == 'sip':
                what = 'SiP'
            else:
                if this.design_type == 'mcm':
                    what = 'APD'
                print('WARNING: ' + text)
        if extracta_version != None:
            this.running_extracta_from_mws = True
        if found_some_old:
            print('WARNING: some ASCII files are older than the design')
        this.die_stacks = die_stacks = {}
        this.refdes2ds = {}
        this.refdes2layer = {}
        this.refdes2dielayer = {}
        this.refdes2attachtype = {}
        this.bumps_at = {}
        this.backdrilling = {}

    def parse_extracta_files(this, filenamebase, filename):
        files = [
         'pgeom', 'geom', 'layer', 'pad_def', 'component', 'connectivity', 'nonstandart_shape', 'nets', 'pad_connectivity', 'zone']
        if this.design_type in ('mcm', 'sip'):
            files.append('die_stack_def')
            files.append('settings')
        found_all_relevant_ascii = True
        found_some_older_ascii = False
        for name in files:
            fullname = filenamebase + '-' + name + '.txt'
            if os.path.exists(fullname):
                if os.path.getmtime(fullname) < os.path.getmtime(filename):
                    found_some_older_ascii = True
                if name != 'connectivity':
                    setattr(this, name, parse_file(fullname))
                else:
                    this.connectivity_filename = fullname
            else:
                if name not in ('settings', 'zone'):
                    if not (this.design_type == 'mcm' and name == 'die_stack_def'):
                        found_all_relevant_ascii = False
                        break

        return (
         found_all_relevant_ascii, found_some_older_ascii)

    def to_LayoutDB(this):
        from common.units import get_typical_manufacturing_tolerance
        design_name = os.path.basename(this.filename)
        design_name, ext = os.path.splitext(design_name)
        ext = ext.lower()
        if ext == '.brd':
            origin = 'CADENCE ALLEGRO'
        else:
            if ext == '.mcm':
                origin = 'CADENCE APD'
            else:
                if ext == '.sip':
                    origin = 'CADENCE SIP'
                else:
                    raise DatabaseReadError('Unknown Origin')
                if this.design_type in ('mcm', 'sip'):
                    this.PCBorPackage = 'package'
                else:
                    this.PCBorPackage = 'PCB'
                if this.progressbar is not None:
                    this.progressbar.reset('Processing layout data', 100)
                print('Grouping geometry data...')
                this.geom_classes = this.group_classes(this.geom)
                if this.progressbar is not None:
                    this.progressbar.set(5)
                print('Creating %s database...' % this.PCBorPackage)
                this.db_unit = this.geom.db_unit
                layoutdb = new_iLayoutDB()
                layoutdb.name = design_name
                layoutdb.description = 'CST CADENCE ALLEGRO IMPORT V1'
                layoutdb.origin = origin
                layoutdb.length_unit = this.db_unit
                layoutdb.tolerance = get_typical_manufacturing_tolerance(layoutdb.length_unit)
                if this.design_type != 'brd':
                    layoutdb.tolerance *= 0.25
                this.sp = ShapeProcessor(layoutdb.tolerance)
                layoutdb.is_x_mirror_mode = True
                try:
                    outline_shape = this.extract_outline()
                except:
                    outline_shape = None

                if outline_shape is not None:
                    outline_shape = this.sp(outline_shape, sense=1, info='board outline')
                if outline_shape is not None:
                    layoutdb.board_outline = outline_shape
                else:
                    print('WARNING: Unable to extract %s outline shape (taking bounding box instead)' % this.PCBorPackage)
                layoutdb.part_model_db = layoutdbPy.PartModelDB()
                this.extract_logical_nets(layoutdb)
                this.extract_stackup(layoutdb)
                this.no_die_info = False
                if this.design_type in ('mcm', 'sip'):
                    layoutdb.type = layoutdbPy.LayoutType.Package
                    this.extract_diestacks(layoutdb)
                check_layer_stackup(layoutdb, add_soldermasks=(this.design_type == 'brd'))
                if this.progressbar is not None:
                    this.progressbar.set(10)
                this.bgas = []
                this.extract_components(layoutdb)
                if this.progressbar is not None:
                    this.progressbar.set(15)
                this.lps_have_pins = {}
                nsshape = this.extract_lpadstacks(layoutdb)
                this.extract_non_standard_pads(layoutdb, nsshape)
                if this.progressbar is not None:
                    this.progressbar.set(20)
                P = Parser((this.connectivity_filename), is_connectivity=True)
                filesize = os.path.getsize(this.connectivity_filename)
                while 1:
                    connectivity = [d for d in P]
                    if len(connectivity) == 0:
                        break
                    this.connectivity_classes = this.group_connectivity(connectivity)
                    this.extract_etch_shapes(layoutdb)
                    this.extract_pad_shapes(layoutdb)
                    if this.design_type in ('mcm', 'sip'):
                        if not this.no_die_info:
                            this.extract_wirebonds(layoutdb)
                        if this.progressbar is not None and P.file.closed():
                            this.progressbar.set(90)

                if this.progressbar is not None:
                    this.progressbar.finished()
                if this.design_type in ('mcm', 'sip'):
                    if len(this.bgas) > 0:
                        this.add_bgas(layoutdb)
                this.compute_pin_layer(layoutdb)
                this.set_pad_connectivity(layoutdb)
                check_pin_names(layoutdb.components())
                if this.design_type in ('mcm', 'sip'):
                    if not this.no_die_info:
                        this.correct_die_stack_layers(layoutdb)
                        this.extract_wirebond_profiles(layoutdb)
                this.project_die_stacks_onto_visualization_layers(layoutdb)
                if layoutdb.board_outline is None:
                    layoutdb.board_outline = layoutdbPy.compute_board_outline(layoutdb, 0.05)
                if this.progressbar is not None:
                    this.progressbar.set(95)
            from common.layoutdb import set_read_elements
            print('Reading component values...')
            warnings = set_read_elements(layoutdb, (this.em_model_items), print_warnings=False)
            print()
            for w in warnings:
                print(w)

            if this.progressbar is None:
                print('Missing output filename for csv file')
            else:
                filename = os.path.splitext(this.progressbar.outputfile)[0] + '.csv'
                from common.layoutdb import export_lumped_elements_to_csv
                export_lumped_elements_to_csv(this.em_model_items, filename)
                print('INFO: Created CSV file (' + filename + ') with lumped-element values for review/re-import.')
        if this.progressbar is not None:
            this.progressbar.set(99)
        this.compute_min_trace_width(layoutdb)
        this.process_selection_options(layoutdb, this.selection_options)
        if this.design_type in ('mcm', 'sip'):
            this.set_package_options(layoutdb)
        this.set_terminals(layoutdb)
        if hasattr(this, 'zone'):
            this.set_stackupregions(layoutdb)
        this.set_bending_instructions(layoutdb)
        if this.progressbar is not None:
            this.progressbar.set(100)
        if this.progressbar is not None:
            this.progressbar.finished()
        if len(this.backdrilling):
            for token, number in this.backdrilling.items():
                print('Backdrilling from %s for %d drill(s)' % (token, number))

        if this.running_extracta_from_mws:
            if len(this.skipped_elements):
                import string
                s = ', '.join([i + 's' for i in this.skipped_elements])
                msg = 'WARNING: Some design elements are missing: %s. Please use the CST-Link plugin within Cadence to create the complete import data set (see CST online help).' % s
                print(msg)
        return layoutdb

    def extract_outline(this):

        def get_shape_from_max_bbox(seglist):
            bb = seglist[0].get_bounding_box()
            for i in range(1, len(seglist)):
                b = seglist[i].get_bounding_box()
                bb.extend(b)

            return Bbox2Rectangle(bb)

        from common.utils2d import Make_CClockwise
        if 'BOARD GEOMETRY' in this.geom_classes:
            if 'DESIGN_OUTLINE' in this.geom_classes['BOARD GEOMETRY']:
                subclass = this.geom_classes['BOARD GEOMETRY']['DESIGN_OUTLINE']
        elif 'BOARD GEOMETRY' in this.geom_classes:
            if 'OUTLINE' in this.geom_classes['BOARD GEOMETRY']:
                subclass = this.geom_classes['BOARD GEOMETRY']['OUTLINE']
        elif 'SUBSTRATE GEOMETRY' in this.geom_classes:
            if 'OUTLINE' in this.geom_classes['SUBSTRATE GEOMETRY']:
                subclass = this.geom_classes['SUBSTRATE GEOMETRY']['OUTLINE']
        else:
            return
        shapes = []
        problems = []
        for majorelem in list(subclass.values()):
            for minorelem in list(majorelem.values()):
                s = part_to_shapes(minorelem, is_outline=1)
                if type(s) == list:
                    if len(s) == 0:
                        pass
                    else:
                        problems.append(s)
                else:
                    shapes.append(s)

        if len(problems) != 0:
            for count in range(len(problems)):
                if len(problems) != 0:
                    resseg = problems.pop()
                    for ccount in range(count, len(problems)):
                        for prs in problems:
                            if resseg[(-1)].b == prs[0].a or resseg[(-1)].b == prs[(-1)].b:
                                if resseg[(-1)].b == prs[(-1)].b:
                                    prs.reverse()
                                    for s in prs:
                                        s.reverse()

                                for s in prs:
                                    resseg.append(s)

                                problems.remove(prs)

                        if resseg[0].a == resseg[(-1)].b:
                            break

                    try:
                        shapes.append(segs2shape(resseg))
                    except:
                        if len(resseg) == 1:
                            continue
                        shapes.append(get_shape_from_max_bbox(resseg))

        if len(problems):
            return
        shapes.sort(key=(lambda a: a.bbox.area()), reverse=True)
        if len(shapes) > 0:
            outline = shapes[0]
            if len(shapes) > 1:
                contain_all = True
                for i in range(1, len(shapes)):
                    if outline.contains(shapes[i]) != 1:
                        contain_all = False

                return contain_all or None
            else:
                Make_CClockwise(outline)
                return outline

    def extract_logical_nets(this, layoutdb):
        import re
        pattern = re.compile('([+-]?\\d+(\\.?\\d*)?)\\W*(mV|V)')
        for data in this.nets:
            netname = str(data.NET_NAME)
            if not netname == '':
                if not layoutdb.has_net(netname):
                    pass
                else:
                    typ = layoutdbPy.NetType.Signal
                    if hasattr(data, 'VOLTAGE'):
                        if data.VOLTAGE != '':
                            voltage = data.VOLTAGE
                            m = pattern.match(voltage)
                            if m is None:
                                print('WARNING: unable to deduce voltage %s for net %s' % (voltage, netname))
                            else:
                                try:
                                    v = float(m.groups()[0])
                                    if v == 0.0:
                                        typ = layoutdbPy.NetType.GND
                                    else:
                                        typ = layoutdbPy.NetType.Power
                                except:
                                    print('WARNING: unable to deduce voltage %s for net %s' % (voltage, netname))

                                print('INFO: net %s is of type' % netname, typ)
                    n = layoutdb.net(netname)
                    n.type = typ

    def extract_stackup(this, layoutdb):
        from common.units import length_unit_convert
        from layoutdbPy import new_iLayer, Color

        def standardize(s):
            return s

        layerdata = [d for d in this.layer]
        layerdata.sort(key=(lambda a: int(a.LAYER_SORT)))
        this.die_stack_layers = {}
        this.die_layers_are_used = {}
        materials = {}
        diel_count = 0
        for data in layerdata:
            if hasattr(data, 'LAYER_MATERIAL'):
                if data.LAYER_MATERIAL.upper() == 'AIR':
                    continue
                else:
                    layer = new_iLayer()
                    layername = data.LAYER_SUBCLASS
                    t = data.LAYER_TYPE.upper()
                    isc = t == 'CONDUCTOR' or data.LAYER_CONDUCTOR == 'YES'
                    if isc:
                        typ = 'conductor'
                    else:
                        typ = 'dielectric'
                    if t == 'CONDUCTOR':
                        layer.layer_type = LayerType.Signal
                    else:
                        if t == 'PLANE':
                            layer.layer_type = LayerType.Plane
                        else:
                            if t == 'DIELECTRIC':
                                layer.layer_type = LayerType.Dielectric
                            else:
                                if t == 'DIESTACK':
                                    layer.layer_type = LayerType.Visualization
                                    this.die_stack_layers[layername] = None
                                    this.die_layers_are_used[layername] = False
                                else:
                                    print("WARNING: Layer '%s' has unknown type '%s' (skipped)" % (layer.name, t))
                                    continue
                    if layername == '':
                        if typ == 'dielectric':
                            layername = 'dielectric_%d' % diel_count
                            diel_count += 1
                        else:
                            print('WARNING: Skipped layer:', data)
                            continue
                    a = data.LAYER_THICKNESS.split()
                    th = float(a[0])
                    if len(a) > 1:
                        th = length_unit_convert(standardize(a[1]), th, layoutdb.length_unit)
                    elif not 0:
                        raise AssertionError
            elif hasattr(data, 'LAYER_ARTWORK'):
                assert len(data.LAYER_ARTWORK) > 0 and data.LAYER_ARTWORK in ('POSITIVE',
                                                                              'NEGATIVE')
                positive = data.LAYER_ARTWORK == 'POSITIVE'
            else:
                positive = True
            if hasattr(data, 'LAYER_MATERIAL'):
                materialname = data.LAYER_MATERIAL
                material = Material()
                material.name = materialname
                material.eps = material.mu = 1
                if isc:
                    if hasattr(data, 'LAYER_ELECTRICAL_CONDUCTIVITY'):
                        a = data.LAYER_ELECTRICAL_CONDUCTIVITY.split()
                        if len(a) == 1:
                            material.condtan = float(a[0])
                        elif len(a) == 2:
                            material.condtan = float(a[0]) * cond_unit_to_SI(a[1])
                    material.type = layoutdbPy.MaterialType.Conductor
                else:
                    if hasattr(data, 'LAYER_DIELECTRIC_CONSTANT'):
                        material.eps = float(data.LAYER_DIELECTRIC_CONSTANT)
                    if hasattr(data, 'LAYER_LOSS_TANGENT'):
                        material.condtan = float(data.LAYER_LOSS_TANGENT)
                    material.type = layoutdbPy.MaterialType.Dielectric
                materials[materialname] = material
                layer.material = material
            layer.name, layer.thickness = layername, th
            layer.is_wireframe = False
            layoutdb.add_layer_below(layer, None)

        count_top = 0
        count_bottom = 0
        for i in range(layoutdb.n_layers()):
            if layoutdb.layer(i).name == 'TOP':
                count_top += 1
            if layoutdb.layer(i).name == 'BOTTOM':
                count_bottom += 1

        if count_top > 1 or count_bottom > 1:
            if this.design_type == 'brd':
                raise DatabaseReadError('Unable to import (found multiple layers with names TOP/BOTTOM).')
            else:
                raise DatabaseReadError('Unable to import. Please use the CST export option from within Cadence APD/SiP, see the CST online help for details.')
        layoutdb.update_elevations()

    def group_classes(this, orig):
        classes = {}
        for d in orig:
            if d.CLASS in classes:
                classes[d.CLASS].append(d)
            else:
                classes[d.CLASS] = [
                 d]

        new_classes = {}
        for klass, att in classes.items():
            subclasses = {}
            for d in att:
                if d.SUBCLASS in subclasses:
                    subclasses[d.SUBCLASS].append(d)
                else:
                    subclasses[d.SUBCLASS] = [
                     d]

            new_classes[klass] = subclasses

        classes = new_classes
        for klass, att0 in classes.items():
            for subclass, att in att0.items():
                groups0 = {}
                for d in att:
                    a = d.RECORD_TAG.split()
                    tag = int(a[0])
                    if tag in groups0:
                        groups0[tag].append(d)
                    else:
                        groups0[tag] = [
                         d]

                groups = {}
                for mtag, ds in groups0.items():
                    subgroups = {0: []}
                    for d in ds:
                        a = d.RECORD_TAG.split()
                        if len(a) > 2:
                            tag = int(a[2])
                        else:
                            tag = 0
                        if tag in subgroups:
                            subgroups[tag].append(d)
                        else:
                            subgroups[tag] = [
                             d]

                    groups[mtag] = subgroups

                att0[subclass] = groups

        return classes

    def group_connectivity(this, connorig):
        classes = {}
        for d in connorig:
            if d.NET_NAME == '':
                d.NET_NAME = 'NONE'
            if d.NET_NAME in classes:
                classes[d.NET_NAME].append(d)
            else:
                classes[d.NET_NAME] = [
                 d]

        new_classes = {}
        for klass, att in classes.items():
            subclasses = {}
            for d in att:
                if d.CLASS in subclasses:
                    subclasses[d.CLASS].append(d)
                else:
                    subclasses[d.CLASS] = [
                     d]

            new_classes[klass] = subclasses

        classes = new_classes
        for klass, att0 in classes.items():
            nodes = {}
            edges = {}
            for subclass, att in att0.items():
                groups0 = {}
                for d in att:
                    a = d.RECORD_TAG.split()
                    tag = int(a[0])
                    if tag in groups0:
                        groups0[tag].append(d)
                    else:
                        groups0[tag] = [
                         d]
                    if hasattr(d, 'NODE_1_NUMBER'):
                        if hasattr(d, 'NODE_2_NUMBER'):
                            n1, n2 = d.NODE_1_NUMBER.strip(), d.NODE_2_NUMBER.strip()
                            if n1 != '':
                                if n2 != '':
                                    n1, n2 = int(n1), int(n2)
                                    if n1 == n2:
                                        nodes[n1] = (
                                         subclass, tag)
                                    elif n1 > n2:
                                        n1, n2 = n2, n1
                        edges[(n1, n2)] = (
                         subclass, tag)

                groups = {}
                for mtag, ds in groups0.items():
                    subgroups = {0: []}
                    for d in ds:
                        a = d.RECORD_TAG.split()
                        if len(a) > 2:
                            tag = int(a[2])
                        else:
                            tag = 0
                        if tag in subgroups:
                            subgroups[tag].append(d)
                        else:
                            subgroups[tag] = [
                             d]

                    groups[mtag] = subgroups

                att0[subclass] = groups

            att0['NODES'] = nodes
            att0['EDGES'] = edges

        return classes

    def lname2layer(this, lname, layoutdb):
        for layer in layoutdb.layers():
            if layer.name == lname:
                return layer

        if not lname in this.die_stack_layers:
            if lname == 'WIRE':
                pass

    def extract_etch_shapes(this, layoutdb):
        for netname, netelem in this.connectivity_classes.items():
            elements = []
            if 'ETCH' in netelem:
                elements.extend(list(netelem['ETCH'].values()))
            if this.design_type in ('mcm', 'sip'):
                if 'CONDUCTOR' in netelem:
                    elements.extend(list(netelem['CONDUCTOR'].values()))
            for majorelem in elements:
                nets = set()
                layers = set()
                node1 = set()
                node2 = set()
                shapes = []
                slayer = set()
                elayer = set()
                for minorelem in list(majorelem.values()):
                    if minorelem[0].NET_NAME == '':
                        netname = 'NONE'
                    else:
                        netname = minorelem[0].NET_NAME
                    nets.add(netname)
                    layername = minorelem[0].SUBCLASS
                    layers.add(layername)
                    if hasattr(minorelem[0], 'NODE_1_NUMBER'):
                        if minorelem[0].NODE_1_NUMBER != '':
                            if hasattr(minorelem[0], 'NODE_2_NUMBER'):
                                if minorelem[0].NODE_2_NUMBER != '':
                                    node1.add(minorelem[0].NODE_1_NUMBER)
                                    node2.add(minorelem[0].NODE_2_NUMBER)
                    shapes.append((minorelem[0], part_to_shapes(minorelem)))
                    slayer.add(minorelem[0].START_LAYER_NAME)
                    elayer.add(minorelem[0].END_LAYER_NAME)

                assert len(nets) == 1
                netname = nets.pop()
                assert len(layers) == 1
                layername = layers.pop()
                layoutdb.add_net_dirty(netname)
                swh = ShapeWithHoles()
                has_pos_shape = False
                for minorelem, shape in shapes:
                    if minorelem.GRAPHIC_DATA_10 == 'VOID':
                        sense = -1
                    else:
                        sense = 1
                    layer = layoutdb.layer(layername)
                    if layer is None:
                        pass
                    else:
                        if layer.layer_type == LayerType.Visualization:
                            if hasattr(minorelem, 'REFDES'):
                                if minorelem.REFDES in this.refdes2layer:
                                    layer = this.refdes2layer[minorelem.REFDES]
                        for s in make_list(shape):
                            if isinstance(s, Trace):
                                s.net_index = layoutdb.net_index(netname)
                                layer.add_trace(s)
                            else:
                                if len(s.segments) == 0:
                                    pass
                                else:
                                    if sense > 0:
                                        Make_CClockwise(s)
                                        swh.shape = s
                                        has_pos_shape = True
                                    else:
                                        Make_Clockwise(s)
                                        swh.holes.push_back(s)

                layer = layoutdb.layer(layername)
                if not has_pos_shape:
                    pass
                else:
                    swh = this.sp(swh, sense=1, info='etch shape')
                    if swh is not None:
                        swh.net_index = layoutdb.net_index(netname)
                        layer.add_plane_shape(swh)

    def extract_components(this, layoutdb):
        from math import pi
        from common.helpers import float_with_unit, interpret_rlc_values
        import re
        this.comp_ps_mirror = {}
        this.em_model_items = []
        for d in this.component:
            new_comp = layoutdbPy.new_iComponent()
            comp_name = d.REFDES
            new_comp.name = comp_name
            if d.COMP_CLASS == 'IO':
                this.bgas.append(comp_name)
            try:
                new_comp.position = R2(float(d.SYM_X), float(d.SYM_Y))
                new_comp.rotation = float(d.SYM_ROTATE) * pi / 180.0
                this.comp_ps_mirror[comp_name] = mirr = d.SYM_MIRROR == 'YES'
                if mirr:
                    if this.design_type in ('mcm', 'sip'):
                        if d.COMP_CLASS == 'IO':
                            new_comp.side = layoutdbPy.WhereType.top
                    else:
                        new_comp.side = layoutdbPy.WhereType.bottom
                else:
                    if this.design_type in ('mcm', 'sip') and d.COMP_CLASS == 'IO':
                        new_comp.side = layoutdbPy.WhereType.bottom
                    else:
                        new_comp.side = layoutdbPy.WhereType.top
            except:
                print('WARNING: Incomplete component entry (skipped):\n', d)
                continue

            if hasattr(d, 'COMP_PLACEMENT_LAYER'):
                new_comp.layer = layoutdb.layer(d.COMP_PLACEMENT_LAYER)
            else:
                typ = comp_name[0]
                if this.design_type not in ('mcm', 'sip'):
                    if hasattr(d, 'PART_NUMBER'):
                        if d.PART_NUMBER != '':
                            partname = d.PART_NUMBER
                partname = d.COMP_DEVICE_TYPE
            if hasattr(d, 'COMP_VALUE'):
                value = d.COMP_VALUE
            else:
                value = ''
            this.em_model_items.append((comp_name, partname, typ, value))
            if new_comp.name in this.refdes2ds:
                ds = this.refdes2ds[new_comp.name]
                diestack = ds['diestack']
                ds_layer = this.refdes2layer[new_comp.name]
                print('Die %s is placed on layer' % new_comp.name, ds_layer.name)
                if new_comp.name not in this.refdes2attachtype:
                    print('WARNING: unknown attachment type of die', new_comp.name)
                else:
                    new_comp.mount_type = this.refdes2attachtype[new_comp.name]
                diestack.add_component(new_comp, ds_layer)
            layoutdb.add_component(new_comp)

        comp_outlines = this.group_classes(this.pgeom)
        for class_name in ('COMPONENT GEOMETRY', 'PACKAGE GEOMETRY'):
            if class_name in comp_outlines:
                for token in ('ASSEMBLY_BOTTOM', 'ASSEMBLY_TOP', 'PLACE_BOUND_TOP',
                              'PLACE_BOUND_BOTTOM'):
                    if token in comp_outlines[class_name]:
                        subclass = comp_outlines[class_name][token]
                        for majorelem in list(subclass.values()):
                            for minorelem in list(majorelem.values()):
                                refdes = minorelem[0].REFDES
                                s = part_to_shapes(minorelem, False, layoutdb.tolerance)
                                if len(s) == 0:
                                    print('WARNING: unable to import an outline shape of component %s' % refdes)
                                    continue
                                if layoutdb.has_component(refdes):
                                    comp = layoutdb.component(refdes)
                                    for shape in s:
                                        try:
                                            shape = this.sp(shape, sense=1, info='component outline')
                                            if shape is not None:
                                                comp.add_outline_shape(shape)
                                        except:
                                            print('WARNING: unable to extract outline shape for component %s' % comp.name)

                                    if comp.n_outline_shapes() == 1:
                                        if refdes in this.refdes2dielayer:
                                            dielayer = this.refdes2dielayer[refdes]
                                            dielayer.outline = comp.outline_shape(0)
                                    if comp.n_outline_shapes() == 0:
                                        print('WARNING: no outline could be extracted for component %s' % refdes)

    def extract_lpad_shapes(this, lpsname, layer, PADSHAPE1, PADWIDTH, PADHGHT, PADXOFF, PADYOFF, PADFLASH, PADSHAPENAME, PADPARAM, nsshape, pad_type):
        has_shape = True
        ox, oy = (0, 0)
        if len(PADXOFF):
            ox = float(PADXOFF)
        if len(PADYOFF):
            oy = float(PADYOFF)
        origin = R2(ox, oy)
        if PADSHAPE1 in ('ROUNDED_RECT', 'CHAMFERED_RECT', 'DONUT', 'NPOLY'):
            if PADPARAM == '':
                print('WARNING: The regular pad shape of library padstack %s will not be displayed %s %s. The ASCII files may be old or have been extracted with an old Cadence version. Try to export *.txt-files again using extracta of Cadence Version 17.2 or newer.' % (lpsname, PADSHAPE1, layer))
                return
        if PADSHAPE1 == 'CIRCLE':
            shape = CircleShape(R2(0, 0), float(PADWIDTH) * 0.5)
        else:
            if PADSHAPE1 in ('RECTANGLE', 'SQUARE'):
                shape = RectangleC(float(PADWIDTH), float(PADHGHT))
            else:
                if PADSHAPE1 in ('OBLONG_X', 'OBLONG_Y'):
                    w, h = float(PADWIDTH), float(PADHGHT)
                    assert w > 0 and h > 0
                    if w != h:
                        if w > h:
                            a = R2((w - h) * 0.5, 0)
                            w = h
                        else:
                            a = R2(0, (h - w) * 0.5)
                        b = -a
                        shape = PolyarcShape(straight_path_segment_to_XYR(a, b, w))
                    else:
                        shape = CircleShape(R2(0, 0), w * 0.5)
                else:
                    if PADSHAPE1 == 'OCTAGON':
                        w = float(PADWIDTH)
                        assert w > 0
                        w = w / 2.0
                        r = math.tan(22.5 * math.pi / 180.0) * w
                        xys = [R2(-w, r), R2(-r, w), R2(r, w), R2(w, r), R2(w, -r), R2(r, -w), R2(-r, -w), R2(-w, -r)]
                        shape = PolylineShape(xys)
                    else:
                        if PADSHAPE1 in ('ROUNDED_RECT', 'CHAMFERED_RECT'):
                            w, h = float(PADWIDTH), float(PADHGHT)
                            params = PADPARAM.split(',')
                            rad = float(params[0])
                            corners = ''
                            if 'UR' in params[1]:
                                corners += '1'
                            if 'UL' in params[1]:
                                corners += '2'
                            if 'LL' in params[1]:
                                corners += '3'
                            if 'LR' in params[1]:
                                corners += '4'
                            params = [
                             w, h, rad, corners]
                            if PADSHAPE1 == 'ROUNDED_RECT':
                                res = create_standart_shapes('RectRound', params)
                            else:
                                res = create_standart_shapes('RectCham', params)
                            assert len(res) == 1
                            shape = res[0]
                        else:
                            if PADSHAPE1 == 'DONUT':
                                od = float(PADWIDTH)
                                params = PADPARAM.split(',')
                                id = float(params[0])
                                params = [od, id]
                                res = create_standart_shapes('RoundDonut', params)
                                assert len(res) == 1
                                shape = res[0]
                            else:
                                if PADSHAPE1 == 'NPOLY':
                                    R = float(PADWIDTH)
                                    num = float(PADPARAM)
                                    params = [R, num]
                                    res = create_standart_shapes('NPolygon', params)
                                    assert len(res) == 1
                                    shape = res[0]
                                else:
                                    if PADSHAPE1 == 'FLASH':
                                        if PADFLASH in nsshape:
                                            nsshape[PADFLASH].append((lpsname, layer, pad_type, origin))
                                        else:
                                            nsshape[PADFLASH] = [
                                             (
                                              lpsname, layer, pad_type, origin)]
                                    else:
                                        if PADSHAPE1 == 'SHAPE':
                                            if PADSHAPENAME in nsshape:
                                                nsshape[PADSHAPENAME].append((lpsname, layer, pad_type, origin))
                                            else:
                                                nsshape[PADSHAPENAME] = [
                                                 (
                                                  lpsname, layer, pad_type, origin)]
                                        else:
                                            print('WARNING: Regular pad shape of library padstack %s will not be displayed' % lpsname, PADSHAPE1, layer)
                                    has_shape = False
                                    this.lps_have_pins[lpsname].append(layer.name)
        if has_shape:
            this.lps_have_pins[lpsname].append(layer.name)
            if origin.getNorm2() > 0:
                shape.translate(origin)
            cswh = this.sp(shape, sense=1, info='pad')
            if cswh is not None:
                pad = layoutdbPy.new_iLPad()
                pad.add_shape(cswh)
                return pad

    def extract_lpadstacks(this, layoutdb):
        lpadstacks = {}
        for d in this.pad_def:
            if d.PAD_NAME in lpadstacks:
                lpadstacks[d.PAD_NAME][d.LAYER] = d
            else:
                lpadstacks[d.PAD_NAME] = {d.LAYER: d}

        nsshape = {}
        this.lpadstacks = {}
        for lpsname, att in lpadstacks.items():
            lps = layoutdbPy.new_iLPadstack()
            lps.name = lpsname
            this.lps_have_pins[lpsname] = []
            has_visu_layer = False
            has_main_layer = False
            this.lpadstacks[lps.name] = lps
            pad_category = None
            for layername, lpsattr in att.items():
                layer = this.lname2layer(layername, layoutdb)
                if hasattr(lpsattr, 'PAD_STACK_CATEGORY'):
                    pad_category = lpsattr.PAD_STACK_CATEGORY
                if layer is not None:
                    if float(lpsattr.PADWIDTH) != 0 and float(lpsattr.PADHGHT) != 0:
                        if not hasattr(lpsattr, 'PADPARAM'):
                            lpsattr.PADPARAM = ''
                        pad_type = 'pad'
                        pad = this.extract_lpad_shapes(lpsname, layer, lpsattr.PADSHAPE1, lpsattr.PADWIDTH, lpsattr.PADHGHT, lpsattr.PADXOFF, lpsattr.PADYOFF, lpsattr.PADFLASH, lpsattr.PADSHAPENAME, lpsattr.PADPARAM, nsshape, pad_type)
                        if pad:
                            contype = layoutdbPy.ConnectType.connect
                            lps.pad(layer, contype, pad)
                    if float(lpsattr.APADWIDTH) != 0:
                        if float(lpsattr.APADHGHT) != 0:
                            if not hasattr(lpsattr, 'APADPARAM'):
                                lpsattr.APADPARAM = ''
                            pad_type = 'apad'
                            pad = this.extract_lpad_shapes(lpsname, layer, lpsattr.APADSHAPE1, lpsattr.APADWIDTH, lpsattr.APADHGHT, lpsattr.APADXOFF, lpsattr.APADYOFF, lpsattr.APADFLASH, lpsattr.APADSHAPENAME, lpsattr.APADPARAM, nsshape, pad_type)
                            if pad:
                                lps.pad(layer, layoutdbPy.ConnectType.clearance, pad)
                    if layername == '~DRILL' and float(lpsattr.PADSHAPE1) != 0:
                        Rdrill = float(lpsattr.PADSHAPE1) * 0.5
                        drillShape = CShape(CircleShape(R2(float(lpsattr.PADXOFF), float(lpsattr.PADYOFF)), Rdrill), 0)
                        lps.via_hole_shape = drillShape

            if pad_category and pad_category.upper() in ('SMD', 'SURFACE_PIN'):
                pad = None
                for l in layoutdb.layers():
                    if lps.pad(l, layoutdbPy.ConnectType.connect):
                        pad = lps.pad(l, layoutdbPy.ConnectType.connect)

                if pad:
                    for l in layoutdb.layers():
                        if l.is_etch():
                            lps.pad(l, layoutdbPy.ConnectType.connect, pad)

        return nsshape

    def extract_non_standard_pads(this, layoutdb, nsshape):
        flag4warning = False
        registered_shapes = {}
        if len(nsshape) > 0:
            nssgeom = {}
            for d in this.nonstandart_shape:
                padname = d.PAD_SHAPE_NAME
                tmp = re.split(' ', padname)
                if not len(tmp) == 2:
                    raise AssertionError
                else:
                    padname = tmp[1]
                    padstackname = d.PAD_STACK_NAME
                    if padname in nssgeom:
                        if padstackname == registered_shapes[padname]:
                            nssgeom[padname].append(d)
                    else:
                        nssgeom[padname] = [
                         d]
                    registered_shapes[padname] = padstackname

            new_classes = {}
            for klass, att in nssgeom.items():
                subclasses = {}
                for d in att:
                    if d.PAD_STACK_NAME in subclasses:
                        subclasses[d.PAD_STACK_NAME].append(d)
                    else:
                        subclasses[d.PAD_STACK_NAME] = [
                         d]

                new_classes[klass] = subclasses

            nssgeom = new_classes
            for klass, att0 in nssgeom.items():
                for subclass, att in att0.items():
                    groups0 = {}
                    for d in att:
                        a = d.RECORD_TAG.split()
                        tag = int(a[0])
                        if tag in groups0:
                            groups0[tag].append(d)
                        else:
                            groups0[tag] = [
                             d]

                    groups = {}
                    for mtag, ds in groups0.items():
                        subgroups = {0: []}
                        for d in ds:
                            a = d.RECORD_TAG.split()
                            if len(a) > 2:
                                tag = int(a[2])
                            else:
                                tag = 0
                            if tag in subgroups:
                                subgroups[tag].append(d)
                            else:
                                subgroups[tag] = [
                                 d]

                        groups[mtag] = subgroups

                    att0[subclass] = groups

            for shapename, pselem in nssgeom.items():
                for lpsname_here, psgeom in pselem.items():
                    if shapename in nsshape:
                        firstel = psgeom[list(psgeom.keys())[0]][0][0]
                        shapes = []
                        for sgeoms in list(psgeom.values()):
                            sgeomel = sgeoms[0][0]
                            if firstel.CLASS == sgeomel.CLASS:
                                if firstel.SUBCLASS == sgeomel.SUBCLASS:
                                    if firstel.CLASS == 'VIA CLASS':
                                        if firstel.VIA_X == sgeomel.VIA_X:
                                            if firstel.VIA_Y == sgeomel.VIA_Y:
                                                s = part_to_shapes(sgeoms[0])
                                                s.translate(R2(-float(firstel.VIA_X), -float(firstel.VIA_Y)))
                                                if hasattr(firstel, 'VIA_ROTATION'):
                                                    s.rotate(-float(firstel.VIA_ROTATION) * math.pi / 180.0, R2())
                                                else:
                                                    flag4warning = True
                                                shapes.append(s)
                                if firstel.CLASS == 'PIN':
                                    if firstel.PIN_X == sgeomel.PIN_X:
                                        if firstel.PIN_Y == sgeomel.PIN_Y:
                                            s = part_to_shapes(sgeoms[0])
                                            s.translate(R2(-float(firstel.PIN_X), -float(firstel.PIN_Y)))
                                            if hasattr(firstel, 'PIN_ROTATION_ABSOLUTE'):
                                                s.rotate(-float(firstel.PIN_ROTATION_ABSOLUTE) * math.pi / 180.0, R2())
                                                if firstel.SYM_MIRROR == 'YES':
                                                    s.x_mirror()
                                            else:
                                                flag4warning = True
                                                if firstel.SYM_MIRROR == 'YES':
                                                    s.rotate(float(firstel.SYM_ROTATE) * math.pi / 180.0, R2())
                                                else:
                                                    s.rotate(-float(firstel.SYM_ROTATE) * math.pi / 180.0, R2())
                                    shapes.append(s)

                        pslist = nsshape[shapename]
                        for ps in pslist:
                            if ps[0] == lpsname_here:
                                if ps[3].getNorm2() > 0:
                                    for shape in shapes:
                                        shape.translate(-ps[3])

                                break
                        else:
                            print("WARNING: incorrect usage of padstack '%s'" % lpsname_here)

                        for ps in pslist:
                            lpsname = ps[0]
                            if lpsname in this.lpadstacks:
                                lps = this.lpadstacks[ps[0]]
                                for shape in shapes:
                                    cswh = this.sp(shape, sense=1, info='pad')
                                    if cswh is not None:
                                        if ps[3].getNorm2() > 0:
                                            cswh.translate(ps[3])
                                        else:
                                            pad = layoutdbPy.new_iLPad()
                                            pad.add_shape(cswh)
                                            if ps[2] == 'pad':
                                                contype = layoutdbPy.ConnectType.connect
                                            else:
                                                if ps[2] == 'apad':
                                                    contype = layoutdbPy.ConnectType.clearance
                                                else:
                                                    contype = layoutdbPy.ConnectType.thermal
                                        layer = ps[1]
                                        lps.pad(layer, contype, pad)

        if flag4warning:
            print('WARNING: Due to old extracta version some pads may be wrong rotated.')

    def extract_pad_shapes(this, layoutdb):
        for netname, netelem in this.connectivity_classes.items():
            for token in ('PIN', 'VIA CLASS'):
                ispin = token == 'PIN'
                if token not in netelem:
                    pass
                else:
                    for classname, classelem in netelem[token].items():
                        for majorelem in list(classelem.values()):
                            if not len(majorelem) == 1:
                                raise AssertionError
                            else:
                                elem = majorelem[0]
                                pos = None
                                refdes = getattr(elem, 'REFDES', None)
                                lfrom = this.determine_physical_layer(layoutdb, elem.START_LAYER_NAME, pos, refdes)
                                lto = this.determine_physical_layer(layoutdb, elem.END_LAYER_NAME, pos, refdes)
                                if hasattr(elem, 'BACKDRILL_TOP_LAYER') and len(elem.BACKDRILL_TOP_LAYER) > 0:
                                    i = int(elem.BACKDRILL_TOP_LAYER)
                                    lfrom2 = layoutdb.etch_layer(i + 1)
                                    if lfrom is None or lfrom2 and lfrom2.number > lfrom.number:
                                        lfrom = lfrom2
                                        bd_token = 'TOP:' + lfrom.name
                                        if bd_token in this.backdrilling:
                                            this.backdrilling[bd_token] += 1
                                        else:
                                            this.backdrilling[bd_token] = 1
                                if hasattr(elem, 'BACKDRILL_BOTTOM_LAYER'):
                                    if len(elem.BACKDRILL_BOTTOM_LAYER) > 0:
                                        i = int(elem.BACKDRILL_BOTTOM_LAYER)
                                        lto2 = layoutdb.etch_layer(i - 1)
                                        if lto is None or lto2 and lto2.number < lto.number:
                                            lto = lto2
                                            bd_token = 'BOTTOM:' + lto.name
                                            if bd_token in this.backdrilling:
                                                this.backdrilling[bd_token] += 1
                                            else:
                                                this.backdrilling[bd_token] = 1
                                if lfrom == None:
                                    if lto == None:
                                        if this.running_extracta_from_mws:
                                            if this.design_type in ('mcm', 'sip'):
                                                this.skipped_elements.add('die-pad')
                                        print('WARNING: Start and end layers not specified in entry (skipped):\n', elem)
                                        continue
                                if lfrom is None:
                                    if layoutdb.layer(elem.START_LAYER_NAME) != None:
                                        if layoutdb.layer(elem.START_LAYER_NAME).layer_type == LayerType.Visualization:
                                            if lto.layer_type != LayerType.Visualization:
                                                lfrom = layoutdb.top_etch_layer()
                                        else:
                                            if this.running_extracta_from_mws:
                                                this.skipped_elements.add('die-pad')
                                            print('WARNING: Start layer not specified in entry (skipped):\n', elem)
                                            continue
                                if lto is None:
                                    if layoutdb.layer(elem.END_LAYER_NAME) != None:
                                        if layoutdb.layer(elem.END_LAYER_NAME).layer_type == LayerType.Visualization and lfrom.layer_type != LayerType.Visualization:
                                            lto = layoutdb.bottom_etch_layer()
                                        else:
                                            if this.running_extracta_from_mws:
                                                this.skipped_elements.add('die-pad')
                                            print('WARNING: End layer not specified in entry (skipped):\n', elem)
                                            continue
                            if lfrom is None or lto is None:
                                print('WARNING: One of start and end layer not specified in entry (skipped):\n', elem)
                                continue
                            lpsname = elem.PAD_STACK_NAME
                            if lpsname not in this.lpadstacks:
                                print('ERROR: Unable to extract padstack (skipped):\n', elem)
                            else:
                                lps = this.lpadstacks[lpsname].clone()
                                ps = layoutdbPy.new_iPadstack()
                                ps.library_padstack = lps
                                if ispin:
                                    pos = R2(float(elem.PIN_X), float(elem.PIN_Y))
                                    ps.rotation = float(elem.PIN_ROTATION_ABSOLUTE) * math.pi / 180
                                else:
                                    pos = R2(float(elem.VIA_X), float(elem.VIA_Y))
                                    is_mirrored = elem.VIA_MIRROR == 'YES'
                                    ps.rotation = float(elem.VIA_ROTATION) * math.pi / 180
                                ps.position = pos
                                ps.layer_from = lfrom
                                ps.layer_to = lto
                                on_diestack = layoutdb.layer(elem.START_LAYER_NAME).layer_type == LayerType.Visualization or layoutdb.layer(elem.END_LAYER_NAME).layer_type == LayerType.Visualization
                                if netname == '':
                                    netname = 'NONE'
                                if layoutdb.has_net(netname):
                                    ps.net = layoutdb.net(netname)
                                else:
                                    layoutdb.add_net_dirty(netname)
                                    ps.net = layoutdb.net(netname)
                                if ps.layer_from == ps.layer_to:
                                    ps.connect(ps.layer_from, layoutdbPy.ConnectType.connect)
                                assert elem.NODE_1_NUMBER == elem.NODE_2_NUMBER
                                if ispin:
                                    if layoutdb.has_component(elem.REFDES):
                                        comp = layoutdb.component(elem.REFDES)
                                        pin = new_Pin()
                                        pin.position = pos
                                        pin.name = elem.PIN_NUMBER
                                        pin.net = ps.net
                                        comp.add_pin(pin)
                                        if comp.layer != None:
                                            pin.layer = comp.layer
                                            ps.connect(comp.layer, layoutdbPy.ConnectType.connect)
                                        else:
                                            if comp.side == layoutdbPy.WhereType.bottom:
                                                ps.connect(layoutdb.bottom_etch_layer(), layoutdbPy.ConnectType.connect)
                                            else:
                                                if comp.side == layoutdbPy.WhereType.top:
                                                    ps.connect(layoutdb.top_etch_layer(), layoutdbPy.ConnectType.connect)
                                        ps.is_flipped = this.comp_ps_mirror[elem.REFDES]
                                        comp.add_padstack(ps)
                                    if elem.REFDES in this.bumps_at:
                                        bump_at_layer, bump_shape = this.bumps_at[elem.REFDES]
                                        bump_shape = CShapeWithHoles(bump_shape)
                                        bump_shape.translate(ps.position)
                                        bump_shape = this.sp(bump_shape, sense=1, info='bump')
                                        if bump_shape is not None:
                                            if ps.net is None:
                                                bump_shape.net_index = 0
                                            else:
                                                bump_shape.net_index = layoutdb.net_index(ps.net.name)
                                            bump_at_layer.add_plane_shape(bump_shape)
                                else:
                                    layoutdb.add_padstack(ps)
                                    if ps.layer_from != ps.layer_to:
                                        if ps.library_padstack.via_hole_shape == None:
                                            ps.library_padstack.intel_deduce_missing_drills = True
                                        if on_diestack:
                                            ds = this.refdes2ds[elem.REFDES]
                                            if 'pss' in ds:
                                                ds['pss'].append(ps)
                                            else:
                                                ds['pss'] = [
                                                 ps]

    def add_bgas(this, layoutdb):
        from common.units import length_unit_convert
        for cname in this.bgas:
            comp = layoutdb.component(cname)
            if comp is None:
                print('WARNING: unable to create BGA layer')
                continue
            comp.mount_type = layoutdbPy.MountType.bga
            bgalayer = new_iLayer()
            bgalayer.name = 'BGA'
            bgalayer.layer_type = LayerType.BGA
            if hasattr(this, 'settings'):
                for set in this.settings:
                    if set.REF == cname:
                        if set.NAME == 'BGA_BALL_RADIUS_TOP':
                            bgalayer.solder_ball_radius_top = float(set.VALUE)
                        else:
                            if set.NAME == 'BGA_BALL_RADIUS_CENTER':
                                bgalayer.solder_ball_radius_center = float(set.VALUE)
                            else:
                                if set.NAME == 'BGA_BALL_RADIUS_BOTTOM':
                                    bgalayer.solder_ball_radius_bottom = float(set.VALUE)
                                elif set.NAME == 'BGA_BALL_HEIGHT':
                                    bgalayer.thickness = float(set.VALUE)

            else:
                print('WARNING: BGA parameters missing, please define under (Stackup->Thickness) and (Preview->Specials->BGA/Bumps->Solder ball radii).')
            if comp.n_padstacks() == 0:
                print('WARNING: unable to create BGA layer (no pins)')
                continue
            ps = comp.padstack(0)
            if ps.layer_from == ps.layer_to:
                if ps.layer_from == layoutdb.top_etch_layer():
                    comp.side = layoutdbPy.WhereType.top
                else:
                    comp.side = layoutdbPy.WhereType.bottom
            else:
                comp.side = layoutdbPy.WhereType.bottom
            if comp.side == layoutdbPy.WhereType.bottom:
                layoutdb.add_layer_below(bgalayer, bgalayer)
            else:
                layoutdb.add_layer_above(bgalayer, bgalayer)
            bgaradius = length_unit_convert('um', 20, layoutdb.length_unit)
            if bgaradius > 0:
                circle = utils2dPy.make_circle_shape(R2(0, 0), bgaradius, True)
                circle = utils2dPy.CShapeWithHoles(circle)
                for i in range(comp.n_pins()):
                    pin = comp.pin(i)
                    bump_shape = CShapeWithHoles(circle)
                    bump_shape.translate(pin.position)
                    bump_shape = this.sp(bump_shape, sense=1, info='bump')
                    if bump_shape is not None:
                        netname = pin.net.name
                        bump_shape.net_index = layoutdb.net_index(netname)
                        bgalayer.add_plane_shape(bump_shape)

            else:
                print('WARNING: no solder balls created for BGA component %s' % comp.name)

        check_layer_stackup(layoutdb, add_soldermasks=False)

    def compute_pin_layer(this, layoutdb):
        for comp in layoutdb.components():
            if comp.mount_type == layoutdbPy.MountType.bga:
                pass
            else:
                for i in range(comp.n_pins()):
                    pin = comp.pin(i)
                    ps = comp.padstack(i)
                    lps = ps.library_padstack
                    if comp.side == layoutdbPy.WhereType.top:
                        if ps.connect(layoutdb.top_etch_layer()) == layoutdbPy.ConnectType.connect:
                            if layoutdb.top_etch_layer().name in this.lps_have_pins[lps.name]:
                                pin.layer = layoutdb.top_etch_layer()
                        if ps.connect(layoutdb.bottom_etch_layer()) == layoutdbPy.ConnectType.connect:
                            if layoutdb.bottom_etch_layer().name in this.lps_have_pins[lps.name]:
                                pin.layer = layoutdb.bottom_etch_layer()
                    else:
                        if comp.side == layoutdbPy.WhereType.bottom:
                            if ps.is_flipped:
                                if ps.connect(layoutdb.bottom_etch_layer()) == layoutdbPy.ConnectType.connect:
                                    if layoutdb.top_etch_layer().name in this.lps_have_pins[lps.name]:
                                        pin.layer = layoutdb.bottom_etch_layer()
                                if ps.connect(layoutdb.top_etch_layer()) == layoutdbPy.ConnectType.connect and layoutdb.bottom_etch_layer().name in this.lps_have_pins[lps.name]:
                                    pin.layer = layoutdb.top_etch_layer()
                            else:
                                if ps.connect(layoutdb.bottom_etch_layer()) == layoutdbPy.ConnectType.connect:
                                    if layoutdb.bottom_etch_layer().name in this.lps_have_pins[lps.name]:
                                        pin.layer = layoutdb.bottom_etch_layer()
                                if ps.connect(layoutdb.top_etch_layer()) == layoutdbPy.ConnectType.connect:
                                    if layoutdb.top_etch_layer().name in this.lps_have_pins[lps.name]:
                                        pin.layer = layoutdb.top_etch_layer()

    def extract_diestacks(this, layoutdb):
        from common.units import length_unit_convert
        if this.design_type == 'mcm':
            if not hasattr(this, 'die_stack_def'):
                print('ERROR: missing die infortation. Please re-generate the ASCII files with an up-to-date version of the CST-Link')
                this.no_die_info = True
                return
        last_ds = None
        die_stacks = this.die_stacks
        std_bond_pad_thickness = 0
        for d in this.die_stack_def:
            ds_name = d.DSA_DIE_STACK_NAME
            if ds_name == last_ds:
                ds['stack'].append(d)
            else:
                die_stacks[ds_name] = {}
                ds = die_stacks[ds_name]
                ds['common'] = d
                ds['stack'] = []
                ds['refdess'] = set()
                ds['layer2visu'] = {}
                ds['visu2layer'] = {}
                ds['extends'] = utils2dPy.BoundingBox(float(d.DSA_EXTENTS_X1), float(d.DSA_EXTENTS_X2), float(d.DSA_EXTENTS_Y1), float(d.DSA_EXTENTS_Y2))
                last_ds = ds_name

        for name in sorted((die_stacks.keys()), reverse=True):
            data = die_stacks[name]
            print('Extracting die stack', name)
            diestack = layoutdbPy.Diestack()
            diestack.name = name
            c = data['common']
            is_top = 'TOP' in c.DSA_SUBSTRATE_SURFACE
            diestack.is_top = is_top
            layoutdb.add_diestack(diestack)
            data['diestack'] = diestack
            stack = data['stack']
            stack.sort(key=(lambda a: int(a.DSA_STACK_POSITION)), reverse=True)
            single_die = len(stack) == 1
            for lyr in stack:
                a = R2(float(lyr.DSA_EXTENTS_X1), float(lyr.DSA_EXTENTS_Y1))
                b = R2(float(lyr.DSA_EXTENTS_X2), float(lyr.DSA_EXTENTS_Y2))
                outline = CShapeWithHoles(utils2dPy.make_rectangle_shape(a, b, True))
                hmin, hmax = float(lyr.DSA_STACK_HEIGHT_MIN), float(lyr.DSA_STACK_HEIGHT_MAX)
                thickness = hmax - hmin
                refdes = lyr.DSA_MEMBER_NAME
                t = lyr.DSA_MEMBER_TYPE.upper()
                m_layer = lyr.DSA_MEMBER_LAYER
                if not layoutdb.has_layer(m_layer):
                    raise DatabaseReadError('inconsistent layer data.  Please re-generate the ASCII files with an up-to-date version of the CST-Link')
                if m_layer in this.die_layers_are_used:
                    this.die_layers_are_used[m_layer] = True
                if t == 'DIE':
                    attach_type = lyr.DSA_DIE_ATTACH_TYPE.upper()
                    orientation = lyr.DSA_DIE_ORIENTATION.upper()
                    if orientation not in ('CHIP UP', 'CHIP DOWN'):
                        print("ERROR: orientation of die %s must be 'CHIP UP' or 'CHIP DOWN'." % refdes)
                    p = re.compile('FLIP[ _-]?CHIP')
                    if p.match(attach_type):
                        attach_type = 'FLIP-CHIP'
                    if single_die:
                        flip = False
                        cu = orientation == 'CHIP UP'
                        if attach_type == 'FLIP-CHIP':
                            if cu == diestack.is_top:
                                flip = True
                        else:
                            if cu != diestack.is_top:
                                flip = True
                            if flip:
                                if orientation == 'CHIP UP':
                                    new_ori = 'CHIP DOWN'
                                else:
                                    new_ori = 'CHIP UP'
                                print("WARNING: wrong orientation '%s' of die %s, corrected to '%s'" % (orientation, refdes, new_ori))
                                orientation = new_ori
                            layer = new_iLayer()
                            layer.layer_type = LayerType.Die
                            layer.name = diestack.name + '_' + lyr.DSA_MEMBER_NAME
                            layer.outline = outline
                            layer.thickness = thickness
                            diestack.layer_elevation(layer.name, hmin)
                            layer.display_name = m_layer
                            this.refdes2dielayer[refdes] = layer
                            diepadlayer = new_iLayer()
                            diepadlayer.layer_type = LayerType.DiePads
                            diepadlayer.name = layer.name + '-pads'
                            diepadlayer.thickness = std_bond_pad_thickness
                            diepadlayer.outline = outline
                            diestack.layer_elevation(diepadlayer.name, hmin + thickness)
                            data['layer2visu'][refdes] = {diepadlayer.name: m_layer}
                            data['visu2layer'][refdes] = {m_layer: diepadlayer.name}
                            this.refdes2layer[refdes] = diepadlayer
                            this.refdes2ds[refdes] = data
                            data['refdess'].add(refdes)
                            if attach_type == 'FLIP-CHIP':
                                this.refdes2attachtype[refdes] = layoutdbPy.MountType.flipchip
                                bumplayer = new_iLayer()
                                bumplayer.name = layer.name + '-bumps'
                                bumplayer.layer_type = LayerType.Bumps
                                bump_height = to_float(lyr.DSA_BUMP_HEIGHT, 0.0)
                                bumplayer.thickness = bump_height
                                if this.design_type == 'sip':
                                    layer.thickness -= bump_height
                                    if layer.thickness < 0:
                                        layer.thickness = 0
                                bump_die_rad = 0.5 * to_float(lyr.DSA_BUMP_DIE_DIAM, 0.0)
                                bump_max_rad = 0.5 * to_float(lyr.DSA_BUMP_MAX_DIAM, 0.0)
                                bump_package_rad = 0.5 * to_float(lyr.DSA_BUMP_PACKAGE_DIAM, 0.0)
                                if bump_die_rad > 0.0:
                                    if bump_max_rad == 0.0:
                                        if bump_package_rad == 0.0:
                                            bump_max_rad = bump_die_rad
                                            bump_package_rad = bump_die_rad
                                if is_top:
                                    bump_package_rad, bump_die_rad = bump_die_rad, bump_package_rad
                                bumplayer.solder_ball_radius_top = bump_package_rad
                                bumplayer.solder_ball_radius_center = bump_max_rad
                                bumplayer.solder_ball_radius_bottom = bump_die_rad
                                aux_rad = bump_max_rad
                                if aux_rad < layoutdb.tolerance * 10:
                                    aux_rad = layoutdb.tolerance * 10
                                circle = utils2dPy.make_circle_shape(R2(0, 0), aux_rad, True)
                                circle = utils2dPy.CShapeWithHoles(circle)
                                this.bumps_at[refdes] = (
                                 bumplayer, circle)
                            else:
                                this.refdes2attachtype[refdes] = layoutdbPy.MountType.wirebond
                        dstmp = []
                        if orientation == 'CHIP UP':
                            if attach_type == 'FLIP-CHIP':
                                dstmp.append(bumplayer)
                            dstmp.append(diepadlayer)
                            dstmp.append(layer)
                        else:
                            dstmp.append(layer)
                            dstmp.append(diepadlayer)
                            if attach_type == 'FLIP-CHIP':
                                dstmp.append(bumplayer)
                            if diestack.is_top:
                                for i in range(len(dstmp)):
                                    diestack.add_layer(dstmp[i])

                            else:
                                for i in range(len(dstmp) - 1, -1, -1):
                                    diestack.add_layer_above(dstmp[i])

                            if attach_type == 'FLIP-CHIP':
                                if orientation == 'CHIP UP' and diestack.is_top or orientation == 'CHIP DOWN' and diestack.is_top == False:
                                    diestack.layer_elevation(bumplayer.name, hmin + layer.thickness)
                                    diestack.layer_elevation(diepadlayer.name, hmin + layer.thickness)
                                    diestack.layer_elevation(layer.name, hmin)
                                else:
                                    diestack.layer_elevation(bumplayer.name, hmin)
                                    diestack.layer_elevation(diepadlayer.name, hmin + bumplayer.thickness)
                                    diestack.layer_elevation(layer.name, hmin + bumplayer.thickness)
                            else:
                                if orientation == 'CHIP UP' and diestack.is_top or orientation == 'CHIP DOWN' and diestack.is_top == False:
                                    diestack.layer_elevation(diepadlayer.name, hmax)
                                    diestack.layer_elevation(layer.name, hmin)
                                else:
                                    diestack.layer_elevation(diepadlayer.name, hmin)
                                    diestack.layer_elevation(layer.name, hmin)
                    else:
                        if t == 'INTERPOSER':
                            interposer = new_iLayer()
                            interposer.layer_type = LayerType.Interposer
                            interposer.name = diestack.name + '_' + lyr.DSA_MEMBER_NAME
                            interposer.outline = outline
                            interposer.thickness = thickness
                            diestack.layer_elevation(interposer.name, hmin)
                            interposer.display_name = m_layer
                            data['layer2visu'][refdes] = {interposer.name: m_layer}
                            data['visu2layer'][refdes] = {m_layer: interposer.name}
                            data['refdess'].add(refdes)
                            this.refdes2layer[refdes] = interposer
                            this.refdes2ds[refdes] = data
                            diestack.add_layer(interposer)
                        elif t == 'SPACER':
                            spacer = new_iLayer()
                            spacer.layer_type = LayerType.Spacer
                            spacer.name = diestack.name + '_' + lyr.DSA_MEMBER_NAME
                            spacer.outline = outline
                            spacer.thickness = thickness
                            diestack.layer_elevation(spacer.name, hmin)
                            spacer.display_name = m_layer
                            ldblayer = layoutdb.layer(m_layer)
                            if ldblayer is not None:
                                ldblayer.layer_type = layoutdbPy.LayerType.Visualization
                            data['layer2visu'][refdes] = {spacer.name: m_layer}
                            data['visu2layer'][refdes] = {m_layer: spacer.name}
                            diestack.add_layer(spacer)

            if diestack.is_top:
                for i in range(diestack.n_layers() - 1, -1, -1):
                    layoutdb.add_layer_above(diestack.layer(i), None)

            else:
                for i in range(diestack.n_layers()):
                    layoutdb.add_layer_below(diestack.layer(i), None)

        for layer, is_used in this.die_layers_are_used.items():
            if not is_used:
                print("WARNING:  Die layer '%s' is not associated to any die and cannot be imported." % layer)

    def determine_physical_layer(this, layoutdb, cdn_layername, position, refdes):
        layer = layoutdb.layer(cdn_layername)
        if layer is None:
            return
        if layer.layer_type != layoutdbPy.LayerType.Visualization:
            return layer
        ds_cands = []
        if refdes is not None:
            if refdes in this.refdes2ds:
                ds_cands.append(this.refdes2ds[refdes])
        if position is not None:
            for ds in list(this.die_stacks.values()):
                if ds['extends'].contains_p(position):
                    ds_cands.append(ds)

        for ds in ds_cands:
            if refdes:
                if layer.name in ds['visu2layer'][refdes]:
                    return layoutdb.layer(ds['visu2layer'][refdes][layer.name])
                else:
                    if position is None:
                        return
                    rd_cands = []
                    for refd in list(ds['visu2layer'].keys()):
                        if refd in this.refdes2layer and this.refdes2layer[refd].outline.bbox.contains_p(position):
                            rd_cands.append(refd)

                    lname = layer.name
                    visu2layer = {}
                    for refdestmp in rd_cands:
                        visu2layer.update(ds['visu2layer'][refdestmp])

                    if visu2layer is not None:
                        if lname in visu2layer:
                            return layoutdb.layer(visu2layer[lname])

    def correct_die_stack_layers(this, layoutdb):

        def copy_material(mat):
            new_mat = Material()
            new_mat.name = mat.name
            new_mat.condtan = mat.condtan
            new_mat.eps = mat.eps
            new_mat.mu = mat.mu
            new_mat.type = mat.type
            return new_mat

        print('Correcting die-stack layers...')
        from common.layoutdb import correct_die_pad_layers
        if this.running_extracta_from_mws:
            if this.design_type == 'mcm':
                if len(list(this.die_stacks.keys())) == 0:
                    this.skipped_elements.add('die-stack')
        for ds in list(this.die_stacks.values()):
            ds_name = ds['common'].DSA_DIE_STACK_NAME
            diestack = ds['diestack']
            for comp in diestack.components():
                if comp.name not in this.refdes2ds:
                    pass
                else:
                    lmap = ds['layer2visu'][comp.name]
                    oldL_newL = []
                    for i in range(diestack.n_layers()):
                        new_layer = diestack.layer(i)
                        if new_layer.name not in lmap:
                            pass
                        else:
                            if not layoutdb.has_layer(lmap[new_layer.name]):
                                raise DatabaseReadError('inconsistent layer data.  Please re-generate the ASCII files with an up-to-date version of the CST-Link')
                            else:
                                old_layer = layoutdb.layer(lmap[new_layer.name])
                        new_layer.material = copy_material(old_layer.material)
                        if old_layer.layer_type == layoutdbPy.LayerType.Visualization:
                            oldL_newL.append([old_layer, new_layer])

                    correct_die_pad_layers(layoutdb, comp.name, oldL_newL)

        for l in layoutdb.layers():
            if l.layer_type == layoutdbPy.LayerType.Visualization:
                layoutdb.delete_layer(l)

        check_layer_stackup(layoutdb, add_soldermasks=False)

    def project_die_stacks_onto_visualization_layers--- This code section failed: ---

 L.2020         0  LOAD_CONST               None
                2  RETURN_VALUE     

 L.2022         4  FOR_ITER             82  'to 82'
                6  STORE_FAST               'ids'

 L.2023         8  LOAD_FAST                'layoutdb'
               10  LOAD_ATTR                sublayout
               12  LOAD_FAST                'ids'
               14  CALL_FUNCTION_1       1  '1 positional argument'
               16  LOAD_ATTR                layout
               18  STORE_FAST               'sl'

 L.2024        20  LOAD_FAST                'layoutdb'
               22  LOAD_ATTR                layer
               24  LOAD_FAST                'this'
               26  LOAD_ATTR                die_stacks
               28  LOAD_FAST                'sl'
               30  LOAD_ATTR                name
               32  BINARY_SUBSCR    
               34  LOAD_STR                 'visualization_layer'
               36  BINARY_SUBSCR    
               38  CALL_FUNCTION_1       1  '1 positional argument'
               40  STORE_FAST               'player'

 L.2026        42  SETUP_LOOP           80  'to 80'
               44  LOAD_FAST                'sl'
               46  LOAD_ATTR                layers
               48  CALL_FUNCTION_0       0  '0 positional arguments'
               50  GET_ITER         
               52  FOR_ITER             78  'to 78'
               54  STORE_FAST               'layer'

 L.2027        56  LOAD_GLOBAL              print
               58  LOAD_STR                 'Project %s onto %s'
               60  LOAD_FAST                'layer'
               62  LOAD_ATTR                name
               64  LOAD_FAST                'player'
               66  LOAD_ATTR                name
               68  BUILD_TUPLE_2         2 
               70  BINARY_MODULO    
               72  CALL_FUNCTION_1       1  '1 positional argument'
               74  POP_TOP          
               76  JUMP_BACK            52  'to 52'
               78  POP_BLOCK        
             80_0  COME_FROM_LOOP       42  '42'
               80  JUMP_BACK             4  'to 4'
               82  POP_BLOCK        

Parse error at or near `FOR_ITER' instruction at offset 4

    def extract_wirebond_profiles(this, layoutdb):
        filename = os.path.abspath(os.path.join(os.path.dirname(this.filename), 'profiles.xml'))
        from common.units import length_unit_convert
        if os.path.exists(filename):
            try:
                this.profile_data = profile_parser.read_CDSX(filename)
            except:
                print('WARNING: Unable to read wirebond profiles.xml. Default profiles will be used instead.')
                this.create_default_wirebond_profile(layoutdb)
                return

        else:
            if layoutdb.n_wirebonds() > 0:
                print('WARNING: No wirebond profiles from original design are available. Default profiles will be used instead.')
            this.create_default_wirebond_profile(layoutdb)
            return
        if not (hasattr(this.profile_data, 'wire_profile_set') and hasattr(this.profile_data.wire_profile_set, 'wire_profile_def')):
            this.create_default_wirebond_profile(layoutdb)
            return
        prof_list = make_list(this.profile_data.wire_profile_set.wire_profile_def)
        for prof_data in prof_list:
            profile = layoutdbPy.vectorR2()
            prof_points = make_list(prof_data.profile_point)
            for point in prof_points:
                if point.horizontal_type.CHARDATA != 'Switch':
                    if not len(re.split(' ', point.horizontal_value.CHARDATA)) == 2:
                        raise AssertionError
                    else:
                        val, unit = re.split(' ', point.horizontal_value.CHARDATA)
                        val = float(val)
                        if point.horizontal_type.CHARDATA == 'Length':
                            p1 = utils2dPy.R2(1, length_unit_convert(unit, val, 'um'))
                        else:
                            if point.horizontal_type.CHARDATA == 'Percent':
                                if unit == '%':
                                    p1 = utils2dPy.R2(2, val / 100)
                                else:
                                    print('WARNING! Percent unit is unknown: ', unit)
                                    continue
                            else:
                                if point.horizontal_type.CHARDATA == 'Angle':
                                    if unit == 'deg':
                                        p1 = utils2dPy.R2(3, val * math.pi / 180)
                                    else:
                                        print('WARNING! Angle unit is unknown: ', unit)
                                        continue
                                else:
                                    print('WARNING! Horizontal_type is unknown: ', point.horizontal_type.CHARDATA)
                                    continue
                                assert len(re.split(' ', point.vertical_value.CHARDATA)) == 2
                                val, unit = re.split(' ', point.vertical_value.CHARDATA)
                                val = float(val)
                                if point.vertical_type.CHARDATA == 'Length':
                                    p2 = utils2dPy.R2(1, length_unit_convert(unit, val, 'um'))
                                else:
                                    if point.vertical_type.CHARDATA == 'Percent':
                                        if unit == '%':
                                            p2 = utils2dPy.R2(2, val / 100)
                                        else:
                                            print('WARNING! Percent unit is unknown: ', unit)
                                            continue
                                    else:
                                        if point.vertical_type.CHARDATA == 'Angle':
                                            if unit == 'deg':
                                                p2 = utils2dPy.R2(3, val * math.pi / 180)
                                            else:
                                                print('WARNING! Angle unit is unknown: ', unit)
                                                continue
                                        else:
                                            print('WARNING! Vertical_type is unknown: ', point.vertical_type.CHARDATA)
                                            continue
                else:
                    p1 = utils2dPy.R2(4, 0)
                    p2 = utils2dPy.R2(0, 0)
                if p1 and p2:
                    profile.append(p1)
                    profile.append(p2)

            wb = new_WirebondProfile_CADENCE(profile)
            wb.is_forward = prof_data.profile_direction.CHARDATA.upper() == 'FORWARD'
            wb.name = prof_data.profile_name.CHARDATA.upper()
            material = Material()
            material.name = prof_data.profile_material.CHARDATA
            material.eps = material.mu = 1
            wb.material = material
            assert len(re.split(' ', prof_data.profile_diameter.CHARDATA)) == 2
            val, unit = re.split(' ', prof_data.profile_diameter.CHARDATA)
            val2 = length_unit_convert(unit, float(val), 'um')
            wb.diameter = val2
            layoutdb.add_wirebond_profile(wb)

    def create_default_wirebond_profile(this, layoutdb):
        wb = new_WirebondProfile_JEDEC4(100)
        wb.diameter = 20
        wb.is_forward = True
        wb.name = 'JEDEC4'
        material = Material()
        material.name = 'GOLD'
        material.eps = material.mu = 1
        wb.material = material
        layoutdb.add_wirebond_profile(wb)
        for i in range(layoutdb.n_wirebonds()):
            w = layoutdb.wirebond(i)
            w.profile_name = 'JEDEC4'

    def extract_wirebonds(this, layoutdb):
        n_wirebonds = 0
        for netname, netelem in this.connectivity_classes.items():
            layoutdb.add_net_dirty(netname)
            wirebonds = []
            elements = []
            if 'ETCH' in netelem:
                elements.extend(list(netelem['ETCH'].values()))
            if this.design_type in ('mcm', 'sip'):
                if 'CONDUCTOR' in netelem:
                    elements.extend(list(netelem['CONDUCTOR'].values()))
            for majorelem in elements:
                for minorelem in majorelem[0]:
                    if minorelem.SUBCLASS != 'WIRE':
                        pass
                    else:
                        wirebonds.append(minorelem)

            n_wirebonds += len(wirebonds)
            for wbitem in wirebonds:
                if wbitem.GRAPHIC_DATA_NAME != 'LINE':
                    print('ERROR: Wirebond type "' + wbitem + '" not supported (skipped)')
                else:
                    a = R2(float(wbitem.GRAPHIC_DATA_1), float(wbitem.GRAPHIC_DATA_2))
                    b = R2(float(wbitem.GRAPHIC_DATA_3), float(wbitem.GRAPHIC_DATA_4))
                    w = float(wbitem.GRAPHIC_DATA_5)
                    seg = CurveSegment(a, b)
                    typ = wbitem.GRAPHIC_DATA_10
                    if hasattr(wbitem, 'REFDES'):
                        if wbitem.REFDES != '':
                            refdes = wbitem.REFDES
                    else:
                        refdes = None
                    wb = layoutdbPy.Wirebond()
                    wb.position_from = a
                    wb.position_to = b
                    if hasattr(wbitem, 'WIREBOND_PROFILE_NAME'):
                        wb.profile_name = wbitem.WIREBOND_PROFILE_NAME.upper()
                    lfrom = this.determine_physical_layer(layoutdb, wbitem.START_LAYER_NAME, wb.position_from, refdes)
                    if lfrom is None:
                        if this.running_extracta_from_mws:
                            this.skipped_elements.add('wirebond')
                        else:
                            print('ERROR: wirebond (%s->%s) cannot be considered because start layer %s cannot be mapped to diestack' % (a, b, wbitem.START_LAYER_NAME))
                    else:
                        lto = this.determine_physical_layer(layoutdb, wbitem.END_LAYER_NAME, wb.position_to, refdes)
                        if lto is None:
                            if this.running_extracta_from_mws:
                                this.skipped_elements.add('wirebond')
                            else:
                                print('ERROR: wirebond (%s->%s) cannot be considered because end layer %s cannot be mapped to diestack' % (a, b, wbitem.END_LAYER_NAME))
                        else:
                            wb.net_index = layoutdb.net_index(netname)
                            wb.layer_from = lfrom
                            wb.layer_to = lto
                            layoutdb.add_wirebond(wb)

    def compute_min_trace_width(this, layoutdb):
        mtw = 1e+100
        for l in layoutdb.layers():
            if not l.is_etch():
                pass
            else:
                for i in range(l.n_traces()):
                    t = l.trace(i)
                    for j in range(t.n_segments()):
                        w = t.width(j)
                        if w > 0 and w < mtw:
                            mtw = w

        layoutdb.simulation_settings.lateral_reference_length = mtw

    def set_package_options(this, layoutdb):
        ss = layoutdb.simulation_settings
        ss.use_pec_sheets = True
        ss.leads_to_soldermasks = False
        ss.leads_height_mm = 0.1
        ss.prefer_face_ports = True

    def process_selection_options(this, layoutdb, options):
        ss = layoutdb.simulation_settings
        if 'sel_nets' in options:
            selnets = layoutdbPy.vectorString()
            for netname in options['sel_nets']:
                selnets.append(netname)

            ss.selected_nets = selnets
            ss.is_net_selection_active = True
        this.simnets = None
        if 'sim_nets' in options:
            this.simnets = options['sim_nets']
        this.refnets = None
        if 'ref_nets' in options:
            this.refnets = options['ref_nets']
        this.sel_pins = None
        if 'sel_pins' in options:
            this.sel_pins = options['sel_pins']
        if 'fastmode' in options:
            if options['fastmode']:
                ss.etch_as_2D = True
                ss.number_of_via_segments = 4
        if 'minimize_substrate' in options:
            shapes = []
            for l in layoutdb.layers():
                if l.is_conductor():
                    for s in l.all_shapes(layoutdb):
                        net = layoutdb.net(s.net_index)
                        if net is not None and net.name in this.simnets:
                            shapes.append(s)

            if not len(shapes):
                return
            bbox = shapes[0].bbox
            for s in shapes:
                bbox.extend(s.bbox)

            dx, dy = bbox.xmax - bbox.xmin, bbox.ymax - bbox.ymin
            expand = options['minimize_substrate']
            dx *= 0.5 * expand
            dy *= 0.5 * expand
            bbox = BoundingBox(bbox.xmin - dx, bbox.xmax + dx, bbox.ymin - dy, bbox.ymax + dy)
            a = R2(bbox.xmin - dx, bbox.ymin - dy)
            b = R2(bbox.xmax + dx, bbox.ymax + dy)
            clipshape = make_rectangle_shape(a, b, True)
            ss.is_area_selection_active = True
            ss.add_selection_area_to_all_layers(layoutdb, clipshape)
        if 'set_leads_height' in options:
            ss = layoutdb.simulation_settings
            ss.leads_to_soldermasks = False
            ss.leads_height_mm = 0.1

    def set_terminals(this, layoutdb):
        if this.simnets != None:
            netlist = layoutdbPy.vectorString()
            for netname in this.refnets:
                netlist.append(netname)

            if this.sel_pins != None:
                for pin in this.sel_pins:
                    comp = layoutdb.component(pin[0])
                    if comp is None:
                        print('ERROR: port creation: pin %s of component %s not found' % (pin[1], pin[0]))
                    else:
                        if comp.has_pin(pin[1]):
                            tp = TestPoint(comp.name, pin[1])
                            portname = tp.decorated_name_dash()
                            port = DiscretePort(portname, tp, netlist)
                            layoutdb.simulation_settings.add_discrete_port(port)

            else:
                for comp in layoutdb.components():
                    for pi in range(comp.n_padstacks()):
                        for net in this.simnets:
                            ps = comp.padstack(pi)
                            if ps.net.name == net:
                                tp = TestPoint(comp.name, comp.pin(pi).name)
                                portname = tp.decorated_name_dash()
                                port = DiscretePort(portname, tp, netlist)
                                layoutdb.simulation_settings.add_discrete_port(port)

    def set_pad_connectivity(this, layoutdb):
        pad_conn = {'PIN':{},  'VIA CLASS':{}}
        for d in this.pad_connectivity:
            if d.CLASS not in pad_conn:
                pass
            else:
                is_pin = d.CLASS == 'PIN'
                if is_pin:
                    pos = (
                     float(d.PIN_X), float(d.PIN_Y), d.PAD_STACK_NAME)
                else:
                    pos = (
                     float(d.VIA_X), float(d.VIA_Y), d.PAD_STACK_NAME)
                if pos not in pad_conn[d.CLASS]:
                    pad_conn[d.CLASS][pos] = {}
                else:
                    pds_info = pad_conn[d.CLASS][pos]
                    if d.SUBCLASS in pds_info:
                        if pds_info[d.SUBCLASS] != d.PAD_TYPE:
                            print(('WARNING! Padstack %s on position ' % d.PAD_STACK_NAME), pos, end=' ')
                            print(' and layer %s has different connection: %s , %s' % (d.SUBCLASS, pds_info[d.SUBCLASS], d.PAD_TYPE))
                    else:
                        pds_info[d.SUBCLASS] = d.PAD_TYPE

        pss = [(pad_conn['VIA CLASS'], layoutdb.padstack(i), None) for i in range(layoutdb.n_padstacks())]
        pss += [(pad_conn['PIN'], comp.padstack(ips), comp.name) for comp in layoutdb.components() for ips in range(comp.n_padstacks())]
        for pc, ps, compname in pss:
            pos = ps.position
            key = (pos.x, pos.y, ps.library_padstack.name)
            if key in pc:
                con_info = pc[key]
                for layername, contype in con_info.items():
                    layer = this.determine_physical_layer(layoutdb, layername, None, compname)
                    if layer:
                        if layer.number >= ps.layer_from.number:
                            if layer.number <= ps.layer_to.number:
                                if contype == 'REGULAR':
                                    ps.connect(layer, layoutdbPy.ConnectType.connect)
                                elif contype == 'ANTI':
                                    ps.connect(layer, layoutdbPy.ConnectType.clearance)

    def set_stackupregions(this, layoutdb):
        shapes4zones = {}
        if 'RIGID FLEX' in this.geom_classes:
            if 'ZONE_OUTLINE' in this.geom_classes['RIGID FLEX']:
                subclass = this.geom_classes['RIGID FLEX']['ZONE_OUTLINE']
                for majorelem in list(subclass.values()):
                    for minorelem in list(majorelem.values()):
                        shape = part_to_shapes(minorelem, is_outline=1)
                        shape = this.sp(shape, sense=1, info='outline')
                        zone_name = minorelem[0].ZONE_NAME
                        if zone_name == '':
                            pass
                        else:
                            if zone_name in shapes4zones:
                                shapes4zones[zone_name].append(shape)
                            else:
                                shapes4zones[zone_name] = [
                                 shape]

        stackup_regions = {}
        for z in this.zone:
            if z.STACKUP_NAME not in stackup_regions:
                new_stackup_reg = layoutdbPy.StackupRegion()
                new_stackup_reg.name = z.STACKUP_NAME
                new_stackup_reg.bottom_layer = layoutdb.layer(z.BOTTOM_LAYER)
                new_stackup_reg.top_layer = layoutdb.layer(z.TOP_LAYER)
                areas = shapes4zones[z.ZONE_NAME]
                stackup_regions[z.STACKUP_NAME] = [new_stackup_reg, areas]
            else:
                stackup_reg = stackup_regions[z.STACKUP_NAME][0]
                if new_stackup_reg.bottom_layer.name != stackup_reg.bottom_layer.name or new_stackup_reg.top_layer.name != stackup_reg.top_layer.name:
                    print('WARNING!: Zones with the same stackup but different layer span defined.')
                stackup_regions[z.STACKUP_NAME][1].extend(shapes4zones[z.ZONE_NAME])

        res = stackup_regions.values()
        stackup_res = []
        for reg, areas in res:
            reg.areas_set(areas)
            stackup_res.append(reg)

        layoutdb.stackup_regions_set(stackup_res)

    def set_bending_instructions(this, layoutdb):
        bend_instr = []
        if 'RIGID FLEX' in this.geom_classes and 'BEND_LINE' in this.geom_classes['RIGID FLEX']:
            subclass = this.geom_classes['RIGID FLEX']['BEND_LINE']
            from common.units import length_unit_convert
            for majorelem in list(subclass.values()):
                for minorelem in list(majorelem.values()):
                    part = [d for d in minorelem if d.GRAPHIC_DATA_NAME != 'TEXT']
                    for d in part:
                        if d.GRAPHIC_DATA_NAME == 'LINE':
                            a = R2(float(d.GRAPHIC_DATA_1), float(d.GRAPHIC_DATA_2))
                            b = R2(float(d.GRAPHIC_DATA_3), float(d.GRAPHIC_DATA_4))
                        bend_inf = d.IDX_BEND_TYPE_INFO
                        res_list = bend_inf.split(',')
                        bi = BendingInstruction()
                        bi.pfrom = a
                        bi.pto = b
                        try:
                            for l in res_list:
                                a = l.strip().split('=')
                                if len(a) == 2:
                                    if a[0] == 'INNER_SIDE':
                                        bi.bending_towards_top = a[1] == 'TOP'
                                    else:
                                        if a[0] == 'INNER_ANGLE':
                                            bi.angle_degrees = float(a[1])
                                        else:
                                            if a[0] == 'INNER_RADIUS':
                                                tmp_res = a[1].split()
                                                if len(tmp_res) == 2:
                                                    r = float(tmp_res[0])
                                                    unit = tmp_res[1]
                                                    ufrom = {'microns':'um',  'millimeters':'mm',  'mils':'mil',  'meters':'m', 
                                                     'centimeters':'cm',  'inch':'in', 
                                                     'inches':'in'}[unit.lower()]
                                                    bi.radius = length_unit_convert(ufrom, r, layoutdb.length_unit)
                                                elif len(tmp_res) == 1:
                                                    bi.radius = float(tmp_res[0])
                                            elif a[0] == 'ORDER':
                                                bi.order = int(a[1])

                            bend_instr.append(bi)
                        except:
                            print('WARNING!: BEND_LINE can not be read due to invalid parameters.')

        if 'RIGID FLEX' in this.geom_classes:
            if 'BEND_AREA' in this.geom_classes['RIGID FLEX']:
                subclass = this.geom_classes['RIGID FLEX']['BEND_AREA']
                for majorelem in list(subclass.values()):
                    for minorelem in list(majorelem.values()):
                        shape = part_to_shapes(minorelem, is_outline=1)
                        b1 = shape.bbox
                        for bi in bend_instr:
                            b2 = BoundingBox(bi.pfrom, bi.pto)
                            if b1.intersects(b2):
                                s = CShape(shape, layoutdb.tolerance)
                                bi.bend_area = this.sp(s, sense=1, info='bend region')
                                break

        layoutdb.bending_instructions_set(bend_instr)


def Run(filename, importer, debug=False):
    print('=' * 60)
    print('Reading Cadence brd/mcm/sip extract database ...\n')
    e = BrdMcm(filename, progressbar=importer)
    layoutdb = e.to_LayoutDB()
    print('Finished reading Cadence database.')
    print('=' * 60)
    if layoutdb is not None:
        importer.db = layoutdb
    if debug:
        importer.e_debug = e
    return 0


if __name__ == '__main__':
    Run((pcbconverter.inputfile), pcbconverter, debug=True)
