# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\cdsbrdmcm\eparser.py
# Compiled at: 2019-03-29 17:58:22
# Size of source mod 2**32: 5306 bytes
import re, tempfile

class EntryLine:

    def __repr__(this):
        res = ''
        d = this.__dict__
        for key in sorted(d.keys()):
            value = d[key]
            if len(value):
                res += '\t%s\t:%s\n' % (str(key), str(value))

        return res


class Parser:
    __doc__ = '\n    A!CLASS!SUBCLASS!RECORD_TAG!REFDES!PIN_NUMBER!PAD_STACK_NAME!NET_NAME!PIN_X!PIN_Y!VIA_X!VIA_Y!TEST_POINT!GRAPHIC_DATA_NAME!GRAPHIC_DATA_1!GRAPHIC_DATA_2!GRAPHIC_DATA_3!GRAPHIC_DATA_4!GRAPHIC_DATA_5!GRAPHIC_DATA_6!GRAPHIC_DATA_7!GRAPHIC_DATA_8!GRAPHIC_DATA_9!GRAPHIC_DATA_10!NO_SHAPE_CONNECT!DRILL_FIGURE_CHAR!\n    J!d:/src/working-copy/MAIN/Source_Code/Projects/Tools/EDA/imports/cdsbrdmcm/tests/mcm_hatch/Fileformatproblem.mcm!Wed Jan 02 17:28:51 2008!-25000.0!-25000.0!25000.0!25000.0!0.1!microns!C:\\UserData\\APD_Design\\PM_3G_New_Coils\netlist_allgnd.txt!15.039370 mil!9!UP TO DATE!\n    '

    def __init__(this, filename, is_connectivity=False, progressbar=None):
        from common.helpers import FileWithPush, open_text_file
        openfile = open_text_file(filename)
        this.file = file = FileWithPush(openfile)
        this.filename = filename
        l = file.readline()
        a = l.strip().split('!')
        if a[0] != 'A':
            raise ImportError('ERROR: file %s can note be read due to unrecognized encoding.' % filename)
        else:
            this.fields = [i for i in a[1:-1]]
            l = file.readline()
            a = l.strip().split('!')
            assert a[0] == 'J'
        a = a[1:-1]
        if len(a) != 12:
            raise ImportError('ERROR: Second line in %s contains too many exclamation marks (!).' % filename)
        t = this
        t.design_name, t.edate, t.x0, t.x1, t.y0, t.y1, t.db_acc, t.db_unit, t.brd_schematic, t.brd_thickness, t.n_cls, t.drc_status = a
        this.db_unit = {'microns':'um', 
         'millimeters':'mm',  'mils':'mil',  'meters':'m', 
         'centimeters':'cm',  'inch':'in', 
         'inches':'in'}[t.db_unit.lower()]
        this.is_connectivity = is_connectivity
        this.current_net = None
        this.last_line = None

    def __iter__(this):
        return this

    def __next__(this):
        d = this.parse_line()
        if d is None:
            this.current_net = None
            raise StopIteration
        else:
            return d

    def parse_line(this):
        file = this.file
        if file.closed():
            return
        fields = this.fields
        nf = len(fields)
        while 1:
            if this.last_line is None:
                l = l_raw = file.readline()
            else:
                l = l_raw = this.last_line
                this.last_line = None
            if len(l) == 0:
                this.file.close()
                return
            l = l.strip()
            if len(l) == 0:
                pass
            else:
                a = l.split('!')
                assert a[0] == 'S'
                a = a[1:]
                if len(a[(-1)]) == 0:
                    a = a[:-1]
                if len(a) != nf and this.filename[-10:] == '-layer.txt':
                    l2 = file.readline()
                    l2 = l2.strip()
                    a = (l + l2).split('!')
                    a = a[1:]
                    if len(a[(-1)]) == 0:
                        a = a[:-1]
                if len(a) != nf:
                    print('ERROR(%s, line %d): unable to parse line:\n' % (this.filename, this.file.line_no), l)
                    if this.filename[-12:] == '-pad_def.txt':
                        if '~DRILL' in a:
                            print("Possible cause: 'Drill/Slot Symbol Characters' contains '!' or ';' ")
                            continue
                        d = EntryLine()
                        for i in range(nf):
                            setattr(d, fields[i], a[i])

                        if this.is_connectivity:
                            if this.current_net is None:
                                this.current_net = d.NET_NAME
                            elif d.NET_NAME != this.current_net:
                                this.last_line = l_raw
                                return
                return d


def parse_file(filename):
    parser = Parser(filename)
    return parser


if __name__ == '__main__':
    import sys
    p = parse_file(sys.argv[1])
    data = [d for d in p]
# okay decompiling eparser.pyc
