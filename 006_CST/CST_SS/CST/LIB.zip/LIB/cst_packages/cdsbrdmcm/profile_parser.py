# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\cdsbrdmcm\profile_parser.py
# Compiled at: 2018-08-27 21:46:15
# Size of source mod 2**32: 4846 bytes
import xml.parsers.expat, types, copy, os
from layoutdbPy import *
import layoutdbPy
from utils2dPy import *
import utils2dPy

class StringFile:

    def __init__(this):
        this.s = ''

    def write(this, s):
        this.s += s


def fPrint(this, file, level=0):
    if isinstance(this, CDSX):
        if len(this.__dict__) == 2:
            if set(this.__dict__.keys()) == set(['V', 'N']):
                if not isinstance(this.V, CDSX):
                    file.write('%s = %s\n' % (this.N, str(this.V)))
        else:
            file.write('\n')
            for key in sorted(this.__dict__.keys()):
                if key in ('prop_map', ):
                    pass
                else:
                    file.write('\t' * level + key + ': ')
                    val = this.__dict__[key]
                    fPrint(val, file, level=(level + 1))

    else:
        if type(this) == list:
            file.write('\n')
            for i in range(len(this)):
                val = this[i]
                file.write('\t' * level + '[%d]: ' % i)
                fPrint(val, file, level=(level + 1))

        else:
            file.write(str(this) + '\n')


class CDSX:

    def __init__(this):
        pass

    def __str__(this):
        file = StringFile()
        fPrint(this, file)
        return file.s

    def __repr__(this):
        return str(this)


class ProgressBarFile:

    def __init__(self, file, progressbar):
        self.file, self.progressbar, self.lastpos = file, progressbar, 0

    def read(this, s=-1):
        pos = 0
        if pos > this.lastpos + 1000:
            if this.progressbar is not None:
                this.progressbar.set(pos)
                this.lastpos = pos
        return this.file.read(s)


datastack = []
globalcounter = 0

def start_element(name, attrs):
    global datastack
    data = datastack[(-1)]
    newdata = CDSX()
    datastack.append(newdata)
    if hasattr(data, name):
        val = getattr(data, name)
        if type(val) == list:
            val.append(newdata)
        else:
            setattr(data, name, [val, newdata])
    else:
        setattr(data, name, newdata)
    newdata.__dict__.update(attrs)


def end_element(name):
    data = datastack.pop()
    newattr = {}
    delattr = []
    for key in delattr:
        del data.__dict__[key]

    data.__dict__.update(newattr)


def char_data(data):
    ds = datastack[(-1)]
    if hasattr(ds, 'CHARDATA'):
        ds.CHARDATA = ds.CHARDATA + str(data)
    else:
        ds.CHARDATA = str(data)


def read_CDSX(filename, progressbar=None):
    global datastack
    global globalcounter
    globalcounter = 0
    datastack = [CDSX()]
    p = xml.parsers.expat.ParserCreate(encoding='UTF-8')
    p.StartElementHandler = start_element
    p.EndElementHandler = end_element
    p.CharacterDataHandler = char_data
    if os.path.splitext(filename)[(-1)] == 'gz':
        import gzip
        file = gzip.open(filename, 'rb')
        p.progressbar = None
    else:
        file = ProgressBarFile(open(filename, 'rb'), progressbar)
        if progressbar is not None:
            progressbar.reset('Reading Wirebond Profiles', os.path.getsize(filename))
        p.ParseFile(file)
        assert len(datastack) == 1
    return datastack.pop()


if __name__ == '__main__':
    import sys
    D = read_CDSX(sys.argv[1])
# okay decompiling profile_parser.pyc
