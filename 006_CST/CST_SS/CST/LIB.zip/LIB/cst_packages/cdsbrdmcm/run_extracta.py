# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\cdsbrdmcm\run_extracta.py
# Compiled at: 2020-05-12 16:17:03
# Size of source mod 2**32: 12537 bytes
import sys, os, subprocess
from common.layoutdb import DatabaseReadError
IS_LINUX = sys.platform.startswith('linux')

def execute_extracta(cmd, extracta_env):
    is_ok = False
    output = ''
    try:
        res = subprocess.Popen(cmd, env=extracta_env, stdout=(subprocess.PIPE), stderr=(subprocess.STDOUT))
        stdout, stderr = res.communicate()
        output = stdout.decode('utf-8', 'ignore')
        if res.returncode == 0:
            is_ok = True
    except:
        pass

    return (
     is_ok, output)


def get_extracta_exe_from_cdsroot():
    message = ''
    if os.environ.get('CDSROOT') is None:
        message = "Environment variable 'CDSROOT' not found. "
        if IS_LINUX:
            return (
             None, None, message)
        message += 'Try to find Cadence installation. '
        found_install = False
        if os.path.exists('C:\\Cadence'):
            for vers in ('\\SPB_17.4', '\\SPB_17.2', '\\SPB_16.6'):
                if os.path.exists('C:\\Cadence' + vers):
                    os.environ['CDSROOT'] = 'C:\\Cadence' + vers
                    found_install = True
                    break

        found_install or message += 'Cadence Installation not found.'
        return (
         None, None, message)
    else:
        cds_sub_paths = [
         'tools/bin',
         '',
         'tools/pcb/bin']

        def get_cdsroot_fullpath(p):
            cds_root_env_var = '${CDSROOT}'
            fp = os.path.join(cds_root_env_var, os.path.normpath(p))
            expanded = os.path.expandvars(fp)
            return expanded

        cds_paths = []
        for p in cds_sub_paths:
            cds_paths.append(get_cdsroot_fullpath(p))

        cds_path = os.pathsep.join(cds_paths)
        extracta_path = os.environ.copy()
        extracta_path['PATH'] = cds_path + os.pathsep + extracta_path['PATH']
        roots = [
         get_cdsroot_fullpath('tools/bin/extracta'), get_cdsroot_fullpath('tools/pcb/bin/extracta')]
        extracta_root = None
        found_extracta = False
        for i in roots:
            i = os.path.expandvars(i)
            if not (os.path.isfile(i + '.exe') or os.path.isfile(i)):
                pass
            else:
                found_extracta = True
                is_ok, stdout = execute_extracta([i, '-version'], extracta_path)
                if not is_ok:
                    message += 'Found extracta in ' + i + ' but it cannot be called. '
                else:
                    extracta_root = i
                    break

        if not found_extracta:
            message = +"Executable 'extracta' not found in Cadence installation."
        return (
         extracta_root, extracta_path, message)


def Extracta(brdmcm, version, nets=None):
    extracta_exe = None
    extracta_env = os.environ.copy()
    is_ok, stdout = execute_extracta(['extracta', '-version'], extracta_env)
    if is_ok:
        extracta_exe = 'extracta'
    else:
        extracta_exe, extracta_env, message = get_extracta_exe_from_cdsroot()
    if extracta_exe == None:
        raise DatabaseReadError("Unable to call 'extracta' executable: " + message + ' Please check whether Cadence software is installed correctly.\nDetails can be found in the CST online help.\n')
    if not os.path.exists(brdmcm):
        raise DatabaseReadError('Running extracta: The Cadence input file "%s" does not exist.' % str(brdmcm))
    name, ext = os.path.splitext(os.path.basename(brdmcm))
    basename = os.path.join(os.path.dirname(brdmcm), name)
    if ' ' in name:
        msg = "Executing Cadence extract with design names containing 'space' characters is not supported."
        print('ERROR: ' + msg)
        raise DatabaseReadError(msg)
    else:
        if nets != None:
            if len(nets) >= 1:
                netnames = '  NET_NAME=' + nets[0] + '  \n'
                for i in range(1, len(nets)):
                    netnames += '  OR  \n  NET_NAME=' + nets[i] + '  \n'

            else:
                netnames = ''
        else:
            netnames = ''
        is_ok, stdout = execute_extracta([extracta_exe, '-version'], extracta_env)
        if not is_ok:
            raise DatabaseReadError('Error while running extracta\n')
        import re
        if re.search('tool:\\s*extracta\\s*16', stdout.lower()) or re.search('.*allegro_batch.*v16-2', stdout.lower()):
            is_vers_17 = False
        else:
            is_vers_17 = True
        add_flex1 = ''
        add_flex2 = ''
        new_comp = ''
        if is_vers_17:
            pad_def = 'PAD_DEF2'
            if ext == '.brd':
                add_flex1 = "OR \n    CLASS='RIGID FLEX' "
                add_flex2 = 'IDX_BEND_TYPE_INFO\n    ZONE_NAME'
                new_comp = 'COMP_PLACEMENT_LAYER\n    COMP_ZONE_NAME\n    EMBEDDED_ATTACH\n    EMBEDDED_STATUS'
        else:
            pad_def = 'PAD_DEF'
        backdrilling = 'BACKDRILL_TOP_LAYER\n    BACKDRILL_BOTTOM_LAYER'
        view1 = "GEOMETRY\n    CLASS = 'PACKAGE GEOMETRY'\n    SUBCLASS = ASSEMBLY_TOP  \n    OR \n    CLASS = 'PACKAGE GEOMETRY'\n    SUBCLASS = ASSEMBLY_BOTTOM\n    OR\n    CLASS = 'PACKAGE GEOMETRY'\n    SUBCLASS = PLACE_BOUND_TOP \n    OR \n    CLASS = 'PACKAGE GEOMETRY'\n    SUBCLASS = PLACE_BOUND_BOTTOM\n    OR\n    CLASS = 'COMPONENT GEOMETRY'\n    SUBCLASS = ASSEMBLY_TOP  \n    OR \n    CLASS = 'COMPONENT GEOMETRY'\n    SUBCLASS = ASSEMBLY_BOTTOM\n    OR\n    CLASS = 'COMPONENT GEOMETRY'\n    SUBCLASS = PLACE_BOUND_TOP  \n    OR \n    CLASS = 'COMPONENT GEOMETRY'\n    SUBCLASS = PLACE_BOUND_BOTTOM\n    OR\n    CLASS='REF DES'\n    SUBCLASS = ASSEMBLY_TOP  \n    OR \n    CLASS = 'REF DES'\n    SUBCLASS = ASSEMBLY_BOTTOM\n    CLASS\n    SUBCLASS\n    RECORD_TAG\n    REFDES\n    GRAPHIC_DATA_NAME\n    GRAPHIC_DATA_1\n    GRAPHIC_DATA_2\n    GRAPHIC_DATA_3\n    GRAPHIC_DATA_4\n    GRAPHIC_DATA_5\n    GRAPHIC_DATA_6\n    GRAPHIC_DATA_7\n    GRAPHIC_DATA_8\n    GRAPHIC_DATA_9\n    GRAPHIC_DATA_10\n    END\n\nFULL_GEOMETRY\n\n    CLASS='BOARD GEOMETRY'\n    OR\n    CLASS='SUBSTRATE GEOMETRY'\n    SUBCLASS='OUTLINE'\n    %s\n    CLASS\n    SUBCLASS\n    RECORD_TAG\n    GRAPHIC_DATA_NAME\n    GRAPHIC_DATA_1\n    GRAPHIC_DATA_2\n    GRAPHIC_DATA_3\n    GRAPHIC_DATA_4\n    GRAPHIC_DATA_5\n    GRAPHIC_DATA_6\n    GRAPHIC_DATA_7\n    GRAPHIC_DATA_8\n    GRAPHIC_DATA_9\n    GRAPHIC_DATA_10\n    %s\nEND\n\nLAYER\n   LAYER_SORT\n   LAYER_SUBCLASS\n   LAYER_TYPE\n   LAYER_ARTWORK\n   LAYER_USE\n   LAYER_CONDUCTOR\n   LAYER_DIELECTRIC_CONSTANT\n   LAYER_LOSS_TANGENT\n   LAYER_ELECTRICAL_CONDUCTIVITY\n   LAYER_MATERIAL\n   LAYER_SHIELD_LAYER\n   LAYER_THERMAL_CONDUCTIVITY\n   LAYER_THICKNESS\nEND\n    \n%s\nEND\n\nCOMPONENT\n    REFDES_SORT\n    REFDES\n    PART_NUMBER\n    COMP_CLASS\n    COMP_PACKAGE\n    COMP_DEVICE_TYPE\n    COMP_VALUE\n    COMP_TOL      \n    SYM_NAME\n    SYM_X\n    SYM_Y\n    SYM_ROTATE\n    SYM_MIRROR\n    COMP_WIRE_BOND\n    %s\nEND\n\nCONNECTIVITY\n    %s\n    NET_NAME_SORT\n    NODE_SORT\n    NODE_1_NUMBER\n    NODE_2_NUMBER\n    RECORD_TAG\n    CLASS\n    SUBCLASS\n    NET_NAME\n    GRAPHIC_DATA_NAME\n    GRAPHIC_DATA_NUMBER\n    GRAPHIC_DATA_1\n    GRAPHIC_DATA_2\n    GRAPHIC_DATA_3\n    GRAPHIC_DATA_4\n    GRAPHIC_DATA_5\n    GRAPHIC_DATA_6\n    GRAPHIC_DATA_7\n    GRAPHIC_DATA_8\n    GRAPHIC_DATA_9\n    GRAPHIC_DATA_10\n    NODE_CONNECTS\n    REFDES\n    PIN_NUMBER\n    PIN_TYPE\n    PIN_X\n    PIN_Y\n    PIN_ROTATION_ABSOLUTE\n    PIN_NAME\n    VIA_X\n    VIA_Y\n    VIA_MIRROR\n    VIA_ROTATION\n    PAD_STACK_NAME\n    START_LAYER_NAME\n    END_LAYER_NAME\n    RAT_CONNECTED\n    COMP_DEVICE_TYPE\n    COMP_TERMINATOR_PACK\n    COMP_VALUE\n    WIREBOND_PROFILE_NAME\n    VOLTAGE\n    DRILL_HOLE_PLATING\n    FILLET\n    %s\nEND\n\nFULL_GEOMETRY\n    \n    CLASS = 'VIA CLASS'\n    GRAPHIC_DATA_10='SHAPE'\n    OR\n    CLASS = 'PIN'\n    GRAPHIC_DATA_10='SHAPE'\n       \n    CLASS\n    SUBCLASS\n    RECORD_TAG\n    REFDES\n    PAD_STACK_NAME\n    PAD_SHAPE_NAME\n    PAD_TYPE\n    SYM_MIRROR\n    SYM_ROTATE\n    PIN_X\n    PIN_Y\n    PIN_ROTATION_ABSOLUTE\n    VIA_X\n    VIA_Y\n    VIA_ROTATION\n    GRAPHIC_DATA_NAME\n    GRAPHIC_DATA_1\n    GRAPHIC_DATA_2\n    GRAPHIC_DATA_3\n    GRAPHIC_DATA_4\n    GRAPHIC_DATA_5\n    GRAPHIC_DATA_6\n    GRAPHIC_DATA_7\n    GRAPHIC_DATA_8\n    GRAPHIC_DATA_9\n    GRAPHIC_DATA_10\nEND\n\nNET\n    CLASS\n    SUBCLASS\n    NET_NAME\n    NET_DIFFERENTIAL_PAIR\n    VOLTAGE\nEND\n\nFULL_GEOMETRY\n    \n    CLASS = 'VIA CLASS'\n    OR\n    CLASS = 'PIN'\n       \n    CLASS\n    SUBCLASS\n    PAD_STACK_NAME\n    PAD_TYPE\n    PIN_X\n    PIN_Y\n    VIA_X\n    VIA_Y\nEND\n" % (add_flex1, add_flex2, pad_def, new_comp, netnames, backdrilling)
        if is_vers_17:
            if ext == '.brd':
                view1 += '\nZONE\n   ZONE_NAME\n   TOP_LAYER\n   BOTTOM_LAYER\n   CONSTRAINT_REGION\n   STACKUP_NAME\nEND\n\n'
        if ext in ('.mcm', '.sip'):
            view1 += '\n\nDIE_STACK_DEF\nEND\n'
        filename = basename + '-cst_view.txt'
        file = open(filename, 'w')
        file.write(view1)
        file.close()
        filename = basename + '-version.txt'
        file = open(filename, 'w')
        text = 'extracta_version ="' + version + '"'
        file.write(text)
        file.close()
        if ext in ('.mcm', '.sip'):
            mcmflag = '-m'
        else:
            mcmflag = ''
    if basename.find('!') != -1:
        raise DatabaseReadError('Import file and/or path may not contain exclamation marks (!).')

    def quoted(s):
        return '"' + s + '"'

    cmd = [
     extracta_exe,
     '-c']
    if ext in ('.mcm', '.sip'):
        cmd.append(mcmflag)
    cmd.extend([quoted(brdmcm),
     quoted(basename + '-cst_view.txt'),
     quoted(basename + '-pgeom.txt'),
     quoted(basename + '-geom.txt'),
     quoted(basename + '-layer.txt'),
     quoted(basename + '-pad_def.txt'),
     quoted(basename + '-component.txt'),
     quoted(basename + '-connectivity.txt'),
     quoted(basename + '-nonstandart_shape.txt'),
     quoted(basename + '-nets.txt'),
     quoted(basename + '-pad_connectivity.txt')])
    if is_vers_17:
        if ext == '.brd':
            cmd.append(quoted(basename + '-zone.txt'))
    if ext in ('.mcm', '.sip'):
        cmd.append(quoted(basename + '-die_stack_def.txt'))
    if ext in ('.mcm', '.sip'):
        os.environ['ALLEGRO_MCM'] = 'ALLEGRO_MCM'
    is_ok, err_mesage = execute_extracta(cmd, extracta_env)
    if not is_ok:
        raise DatabaseReadError('Error while running extracta \n%s \n' % err_mesage)


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('usage:\n\tpython %s brd-or-mcm-file' % sys.argv[0])
        sys.exit(0)
    brdmcm = sys.argv[1]
    Extracta(brdmcm, '3.3')
# okay decompiling run_extracta.pyc
