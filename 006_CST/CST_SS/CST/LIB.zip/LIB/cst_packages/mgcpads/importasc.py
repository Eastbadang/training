# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\mgcpads\importasc.py
# Compiled at: 2019-03-13 21:58:21
# Size of source mod 2**32: 123949 bytes
import string, types
from odbpp.odbppparser import FileWithPush
from common.utils2d import R2, CircleShape, RectangleC, Make_CClockwise, Make_Clockwise, CirclePath, vectorShapeWithHoles, BoundingBox, Planeprocessor
from common.utils2d import PolyarcShape, PolylineShape, Xyrs2Segments, segment2shape, rectangular_shape_from_straight_path, thicken_curvesegment, polyarc_path_to_polyarc_shapes, remove_identical_points
from common.utils2d import ShapeProcessor
from common import utils2d
from common.layoutdb import DatabaseReadError, check_pin_names
from common.units import length_unit_convert
import utils2dPy, layoutdbPy
from utils2dPy import CShapeWithHoles, CShape, Shape, ShapeWithHoles, CurveSegment
import math

def version_string_to_version(s):
    import re
    s = s.strip()
    supported_formats = re.compile('V(\\d+\\.\\d+)')
    m = supported_formats.match(s)
    if m is None or len(m.groups()) != 1:
        return
    v = float(m.groups()[0])
    if v < 9:
        return
    else:
        if v < 1000:
            v *= 1000
        return v


class FileWithPush_Here(FileWithPush):

    def readline(this):
        l = FileWithPush.readline(this)
        while l.strip().startswith('.REUSE'):
            l = FileWithPush.readline(this)

        return l

    def skiplines_starting_with_remark_or_empty(this):
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            if l[:8] == '*REMARK*':
                continue
            if len(l.strip()):
                this.push(l)
                return True

    def parse_brackets(this):
        file = this
        res = {}
        while True:
            if not this.skiplines_starting_with_remark_or_empty():
                return res
            else:
                l = file.readline()
                this.push(l)
                if l[0] == '*':
                    return res
                if l[0] == '}':
                    l = file.readline()
                    return res
                key, data = this.parse_one_bracket()
                if key is None:
                    return res
            if key in res:
                if type(res[key]) == list:
                    res[key].append(data)
                else:
                    res[key] = [
                     res[key], data]
            else:
                res[key] = data

    def parse_one_bracket(this):
        l = this.readline()
        a = l.strip().split()
        key = a[0]
        parent_value = ' '.join(a[1:])
        value = None
        l = this.readline()
        if l[0] == '{':
            value = this.parse_brackets()
            value['parent_value'] = parent_value
        else:
            this.push(l)
            value = parent_value
        return (
         key, value)


class PartDummy:
    pass


class AscImport:
    __doc__ = ' asc parser class '

    def __init__(this, layoutfilename, progressbar=None):
        this.layoutfilename = layoutfilename
        encoding = 'iso-8859-1'
        from common.helpers import open_text_file
        this.file = file = FileWithPush_Here(open_text_file((this.layoutfilename), default_encoding=encoding))
        this.progressbar = progressbar
        this.PARTMAP = {}
        this.PARTLIST = {}

    def parse_asc(this):
        import os.path
        from common.units import get_typical_manufacturing_tolerance
        print('Parsing ASCII file...')
        this.design_name = 'unknown'
        this.MISC = {}
        this.POUR = {}
        this.LINES = {}
        this.route_signals = []
        this.iamin = None
        this.min_radius = 0
        file = this.file
        totalsize = os.path.getsize(this.layoutfilename)
        l = file.readline()
        a = l.strip().split('!')
        assert len(a) >= 2 and len(a[0]) == 0
        a = a[1].split('-')
        if not (len(a) >= 4 and a[0] == 'PADS'):
            raise AssertionError
        else:
            product, version, units = a[1:4]
            print('PADS version:', version)
            this.version = version_string_to_version(version)
            if this.version is None:
                raise DatabaseReadError('PADS ASCII format %s is not supported' % version)
            elif this.version > 9300:
                raise DatabaseReadError('PADS ASCII format %s is not supported, please use ODB++ interface for PADS designs.' % version)
            else:
                this.scale = 1.0
                this.scal_basic = False
                if units == 'MILS':
                    this.db_unit = 'mil'
                else:
                    if units == 'INCHES':
                        this.db_unit = 'in'
                    else:
                        if units == 'METRIC':
                            this.db_unit = 'mm'
                        else:
                            if units == 'BASIC':
                                this.db_unit = 'mm'
                                this.scale = 6.666666666666666e-07
                                this.scal_basic = True
                            else:
                                raise ImportError('invalid length units : %s' % units)
        this.tolerance = get_typical_manufacturing_tolerance(this.db_unit)
        this.min_radius = 5 * this.tolerance
        if this.progressbar is not None:
            this.progressbar.reset('Reading ASCII file', totalsize)
        while 1:
            if not file.skiplines_starting_with_remark_or_empty():
                break
            l = file.readline()
            a = l.strip().split('*')
            if len(a) < 2:
                pass
            else:
                func = 'parse_' + a[1]
                if not hasattr(this, func):
                    pass
                else:
                    file.push(l)
                    func = getattr(this, func)
                    func()
            if this.progressbar is not None:
                this.progressbar.set(file.my_approx_pos)

        if this.progressbar is not None:
            this.progressbar.finished()

    def parse_PCB(this):
        file = this.file
        file.readline()
        this.PCB = {}
        while True:
            if not file.skiplines_starting_with_remark_or_empty():
                return
            l = file.readline()
            if l[0] == '*':
                file.push(l)
                return
            l = l.strip()
            if len(l) == 0:
                continue
            a = l.split()
            token = a[0]
            this.PCB[token] = ' '.join(a[1:])

    def parse_LINES(this):
        file = this.file
        file.readline()
        this.LINES = {}
        while True:
            if not file.skiplines_starting_with_remark_or_empty():
                return
            l = file.readline()
            if l[0] == '*':
                file.push(l)
                return
            a = l.strip().split()
            name, linetype, x, y, pieces = (
             a[0], a[1], float(a[2]), float(a[3]), int(a[4]))
            xy = R2(x, y)
            xy *= this.scale
            ntxtlines = 0
            if this.version >= 2007.0:
                assert len(a) >= 6
                if len(a) > 6:
                    if linetype == 'COPPER':
                        sigstr = a[6]
                        if len(a) > 7:
                            print('NOT USED: ', a)
                    else:
                        ntxtlines = int(a[6])
                        if len(a) > 7:
                            sigstr = a[7]
                        else:
                            sigstr = None
                else:
                    ntxtlines, sigstr = (0, None)
            else:
                if len(a) > 5:
                    if linetype == 'COPPER':
                        sigstr = a[5]
                        if len(a) > 6:
                            print('NOT USED: ', a)
                    else:
                        ntxtlines = int(a[5])
                        if len(a) > 6:
                            sigstr = a[6]
                        else:
                            sigstr = None
                else:
                    ntxtlines, sigstr = (0, None)
                l = file.readline()
                a = l.strip().split()
                if a[0] != '.REUSE.':
                    file.push(l)
                pieces = [this.parse_LINES_PIECE() for i in range(pieces)]
                for i in range(ntxtlines):
                    this.parse_TEXT()

                this.LINES[name] = {'linetype':linetype, 
                 'pos':xy,  'net':sigstr,  'pieces':pieces}

    def parse_LINES_PIECE(this, lscale=1):
        file = this.file
        l = file.readline()
        a = l.strip().split()
        assert len(a) >= 4
        typ, numcoord, widthhght, level = (a[0], int(a[1]), float(a[2]), int(a[3]))
        widthhght *= this.scale * lscale
        xyrs = []
        for i in range(numcoord):
            l = file.readline().strip()
            a = l.split()
            if len(a) == 2:
                x, y = float(a[0]), float(a[1])
                xyrs.append((R2(x, y) * this.scale * lscale, 0))
            else:
                assert len(a) == 8
                x1, y1, ab, aa, ax1, ay1, ax2, ay2 = [float(ia) for ia in a]
                R = 0.5 * (ay2 - ay1) * this.scale * lscale
                c = R2((ax1 + ax2) / 2, (ay1 + ay2) / 2)
                c *= this.scale * lscale
                a = R2(x1, y1)
                a *= this.scale * lscale
                xyrs.append((a, 0))
                if aa < 0:
                    xyrs.append((c, R))
                else:
                    xyrs.append((c, -R))

        return {'typ':typ, 
         'widthhght':widthhght,  'xyrs':xyrs,  'level':level}

    def parse_PARTDECAL(this):
        """
        A part decal consists of the following: 
            Header line
        *REMARK* NAME UNITS ORIX ORIY PIECES TERMINALS STACKS TEXT LABELS
            Piece definitions
        *REMARK* PIECETYPE CORNERS WIDTHHGHT LEVEL RESTRICTIONS
        *REMARK* PIECETYPE CORNERS WIDTH LEVEL PINNUM
            Text definitions
            Label definitions
            Pad definitions
            Pad stack definitions
            Note: All coordinates are relative.
        
        *REMARK* XLOC YLOC BEGINANGLE DELTAANGLE
        *REMARK* XLOC YLOC ORI LEVEL HEIGHT WIDTH MIRRORED HJUST VJUST
        *REMARK* VISIBLE XLOC YLOC ORI LEVEL HEIGTH WIDTH MIRRORED HJUST VJUST RIGHTREADING
        *REMARK* FONTSTYLE FONTFACE
        *REMARK* T XLOC YLOC NMXLOC NMYLOC
        *REMARK* PAD PIN STACKLINES
        *REMARK* LEVEL SIZE SHAPE IDIA DRILL [PLATED]
        *REMARK* LEVEL SIZE SHAPE FINORI FINLENGTH FINOFFSET DRILL [PLATED]
        """
        from common.units import length_unit_convert
        file = this.file
        file.readline()
        this.PARTDECALS = {}
        while True:
            if not file.skiplines_starting_with_remark_or_empty():
                break
            else:
                l = file.readline().strip()
                if l[0] == '*':
                    file.push(l)
                    break
                a = l.split()
                assert len(a) >= 7 and len(a) <= 9
                name, units, part_origin, n_pieces, n_terminals, n_padstacks, n_text, n_labels = (a[0], a[1].upper(), R2(float(a[2]), float(a[3])), int(a[4]), int(a[5]), int(a[6]), 0, 0)
                if len(a) > 7:
                    n_text = int(a[7])
                if len(a) > 8:
                    n_labels = int(a[8])
                assert units in 'MI'
                if units == 'I':
                    units = 'mil'
                else:
                    units = 'mm'
                if this.scal_basic:
                    lscale = 1.0
                else:
                    lscale = length_unit_convert(units, 1.0, this.db_unit)
            pieces = [this.parse_LINES_PIECE(lscale) for i in range(n_pieces)]
            texts = [this.parse_TEXT() for i in range(n_text)]
            labels = [this.parse_TEXT() for i in range(n_labels)]
            pads = []
            alpinm = {}
            alpinname = {}
            pincount = 0
            while True:
                l = file.readline()
                if len(l) == 0:
                    raise ImportError('failure reading part decal (%s)' % str(file))
                if l[0] != 'T':
                    file.push(l)
                    break
                a = l[1:].split()
                assert len(a) >= 4
                x, y, nmx, nmy = a[:4]
                if this.version >= 2007:
                    pinnumber = a[4]
                    alpinm[pinnumber] = pincount
                    alpinname[pincount] = pinnumber
                else:
                    alpinm[str(pincount + 1)] = pincount
                    alpinname[pincount] = str(pincount + 1)
                pincount += 1
                xv, yv = float(x) * this.scale * lscale, float(y) * this.scale * lscale
                pads.append(R2(xv, yv))

            padstacks = {}
            for i in range(n_padstacks):
                p = this.parse_padstack(lscale)
                p['name'] = '%s-%s' % (name, str(p['pinno']))
                padstacks[int(p['pinno'])] = p

            padstackmap = []
            for i in range(len(pads)):
                if i + 1 in padstacks:
                    padstackmap.append(padstacks[(i + 1)])
                else:
                    assert 0 in padstacks
                    padstackmap.append(padstacks[0])

            this.PARTDECALS[name] = {'name':name, 
             'scale':lscale,  'part_origin':part_origin,  'pieces':pieces,  'padstacks':padstacks, 
             'padstackmap':padstackmap,  'pads':pads,  'alpinm':alpinm,  'alpinname':alpinname}

    def parse_PART(this):
        import re
        file = this.file
        file.readline()
        this.PARTLIST = {}
        this.PARTMAP = {}
        has_alt_name = {}
        while True:
            if not file.skiplines_starting_with_remark_or_empty():
                break
            else:
                l = file.readline().strip()
                if l[0] == '*':
                    file.push(l)
                    break
                a = l.split()
                assert len(a) > 7
                refnm, ptypenm, xy, ori, glued, mirrored, alt = (a[0], a[1], R2(float(a[2]) * this.scale, float(a[3]) * this.scale), float(a[4]), a[5] == 'G', a[6] == 'M', int(a[7]))
                clstid, clsattr, brotherid, labels = (None, None, None, 0)
                if len(a) > 8:
                    assert len(a) == 12
                    clstid, clsattr, brotherid, labels = (a[8], int(a[9]), a[10], int(a[11]))
                ll = file.readline()
                lls = ll.split()
                if len(lls) > 0:
                    if lls[0] != '.REUSE.':
                        file.push(ll)
                else:
                    file.push(ll)
                for i in range(labels):
                    this.parse_TEXT()

                this.PARTLIST[refnm] = {'refnm':refnm,  'ptypenm':ptypenm,  'xy':xy,  'ori':ori,  'glued':glued,  'mirrored':mirrored,  'alt':alt,  'clstid':clstid, 
                 'clsattr':clsattr,  'brotherid':brotherid}
                ptnm = ptypenm.split('@')
                if ptnm[0] not in list(has_alt_name.keys()):
                    has_alt_name[ptnm[0]] = {'alt':[],  'sep':[]}
                if len(ptnm) == 2:
                    pdnm = ptnm[0] + '@' + ptnm[1]
                    if ptnm[1] not in has_alt_name[ptnm[0]]['sep']:
                        has_alt_name[ptnm[0]]['sep'].append(ptnm[1])
                else:
                    pdnm = ptnm[0] + '@' + str(alt)
                if alt not in has_alt_name[ptnm[0]]['alt']:
                    has_alt_name[ptnm[0]]['alt'].append(alt)
                if re.match('[RCL][0-9]{1,}', refnm):
                    comp_art = refnm[0]
                else:
                    comp_art = 'other'
            if pdnm not in list(this.PARTMAP.keys()):
                this.PARTMAP[pdnm] = {comp_art: 1}
            else:
                if comp_art not in list(this.PARTMAP[pdnm].keys()):
                    this.PARTMAP[pdnm][comp_art] = 1
                else:
                    this.PARTMAP[pdnm][comp_art] += 1

        this.PARTMAP['has_alt_name'] = has_alt_name

    def parse_PARTTYPE(this):
        import math
        file = this.file
        file.readline()
        this.PARTTYPE = {}
        while True:
            if not file.skiplines_starting_with_remark_or_empty():
                break
            else:
                l = file.readline().strip()
                if l[0] == '*':
                    file.push(l)
                    break
                a = l.split()
                if this.version >= 2007.0:
                    assert len(a) > 6
                    ptypenm, dcalnm, units, typ, n_gates, n_signals, n_alpinm, flag, eco = (a[0], a[1], None, a[2], int(a[3]), int(a[4]), int(a[5]), int(a[6]), False)
                else:
                    assert len(a) > 7
                    ptypenm, dcalnm, units, typ, n_gates, n_signals, n_alpinm, flag, eco = (a[0], a[1], a[2], a[3], int(a[4]), int(a[5]), int(a[6]), int(a[7]), False)
                dcalnm = dcalnm.split(':')
                for i in range(n_gates):
                    l = file.readline().strip()
                    assert len(l.split()) == 3
                    pins = int(l.split()[2])
                    pinnr = 0
                    while True:
                        if pinnr >= pins:
                            break
                        l = file.readline().strip()
                        pinnr += len(l.split())

                for i in range(n_signals):
                    l = file.readline()

                alpinm = {}
                alpinname = {}
                pincount = 0
                while pincount < n_alpinm:
                    l = file.readline().strip()
                    a = l.split()
                    for i in range(len(a)):
                        alpinm[a[i]] = pincount
                        alpinname[pincount] = a[i]
                        pincount += 1

                assert pincount == n_alpinm
            this.PARTTYPE[ptypenm] = {'ptypenm':ptypenm,  'dcalnm':dcalnm,  'units':units,  'type':typ,  'flag':flag,  'eco':eco,  'alpinm':alpinm,  'alpinname':alpinname}

    def parse_padstack(this, lscale=1):
        """
        p. 37 (v2005):
        The pad stack definition section contains one entry for each unique pad stack within the part decal.
        Each pad should have a pad stack assigned either explicitly or implicitly. The format for each pad stack entry
        is defined as follows:
                        PAD pinno stacklines
                        level size shape idia finori finlength finoffset drill [plated] [slotori slotlength slotoffset]
                        level size shape idia drill [plated]
                        
                        name drill stacklines [drill_start] [drill_end]
                        level size shape [inner_diameter]

        """
        file = this.file
        l = file.readline().strip()
        a = l.split()
        if not len(a) >= 3:
            raise AssertionError
        else:
            is_pin = a[0] == 'PAD'
            padstack = {'is_pin': is_pin}
            if is_pin:
                padstack['pinno'] = int(a[1])
            else:
                padstack['name'] = a[0]
                padstack['drill'] = float(a[1]) * this.scale * lscale
                if len(a) > 3:
                    assert len(a) == 5
                    von, bis = a[3:5]
                    padstack['fromto'] = [int(von), int(bis)]
                else:
                    padstack['fromto'] = [
                     -2, 0]
        stacklines = []
        n_stacklines = int(a[2])
        for i in range(n_stacklines):
            l = file.readline().strip()
            a = l.split()
            assert len(a) >= 3
            level, size, shape = int(a[0]), float(a[1]), a[2].upper()
            size *= this.scale * lscale
            a = a[3:]
            if shape in ('R', 'S', 'A', 'O', 'OF', 'RF', 'RA', 'SA'):
                idia, finori, finlength, finoffset, corner, drill, plated, slotori, slotlength, slotoffset = (None,
                                                                                                              None,
                                                                                                              None,
                                                                                                              None,
                                                                                                              None,
                                                                                                              None,
                                                                                                              None,
                                                                                                              None,
                                                                                                              None,
                                                                                                              None)
                if shape == 'A':
                    idia = float(a[0]) * this.scale * lscale
                    a = a[1:]
                if shape in ('RF', 'OF'):
                    finori, finlength, finoffset = float(a[0]), float(a[1]), float(a[2])
                    finlength *= this.scale * lscale
                    finoffset *= this.scale * lscale
                    a = a[3:]
                if len(a) > 3:
                    slotori, slotlength, slotoffset = float(a[(-3)]), float(a[(-2)]), float(a[(-1)])
                    slotlength *= this.scale * lscale
                    slotoffset *= this.scale * lscale
                    a = a[:-3]
                if this.version >= 9000:
                    if shape in ('S', 'RF'):
                        if len(a) > 0:
                            corner = float(a[0]) * this.scale * lscale
                            a = a[1:]
                if level == -2:
                    if is_pin:
                        drill = float(a[0]) * this.scale * lscale
                        a = a[1:]
                    else:
                        if len(a) > 0:
                            if a[0] in 'NP':
                                plated = a[0] != 'N'
                                a = a[1:]
                            if this.version >= 9000:
                                if len(a) > 0:
                                    if a[0] == '0':
                                        a = a[1:]
                        if len(a) != 0:
                            print('WARNING: unable to interpret complete line:\n', l)
                    stacklines.append({'level':level, 
                     'size':size,  'shape':shape,  'idia':idia,  'finori':finori, 
                     'finlength':finlength,  'finoffset':finoffset,  'corner':corner,  'drill':drill,  'plated':plated,  'slotori':slotori, 
                     'slotlength':slotlength,  'slotoffset':slotoffset})
                else:
                    assert shape in ('RT', 'ST') and len(a) >= 4
                    if len(a) > 4:
                        print('WARNING: Ignoring undocumented argument(s) for thermal pads in line: ', l)
                    spokeori, outsize, spokewidth, spokenum = (
                     float(a[0]), float(a[1]), float(a[2]), int(a[3]))
                    outsize *= this.scale * lscale
                    spokewidth *= this.scale * lscale
                    stacklines.append({'level':level, 
                     'size':size,  'shape':shape,  'spokeori':spokeori,  'outsize':outsize, 
                     'spokewidth':spokewidth,  'spokenum':spokenum,  'drill':None})
            else:
                print('WARNING: Unknown padstack line found (%s):' % str(file), l)
                continue

        padstack['stacklines'] = stacklines
        return padstack

    def parse_POUR(this):
        file = this.file
        file.readline()
        this.POUR = {}
        while True:
            if not file.skiplines_starting_with_remark_or_empty():
                break
            else:
                l = file.readline().strip()
                if l[0] == '*':
                    file.push(l)
                    break
                a = l.split()
                assert len(a) >= 6
                name, typ, xloc, yloc, pieces, flags = (a[0], a[1], float(a[2]), float(a[3]), int(a[4]), int(a[5]))
                assert typ in ('HATOUT', 'PADTHERM', 'POUROUT', 'VIATHERM', 'VOIDOUT')
                pos = R2(xloc, yloc) * this.scale
                ownername = None
                signame = None
                assert typ in ('PADTHERM', 'VIATHERM') and len(a) == 9
                ownername, int1, int2 = a[6], int(a[7]), int(a[8])
                if ownername in this.POUR:
                    if this.POUR[ownername]['net'] != None:
                        signame = this.POUR[ownername]['net']
                    elif len(a) > 6:
                        ownername = a[6]
                        if len(a) > 7:
                            signame = a[7]
                        elif ownername in this.POUR:
                            if this.POUR[ownername]['net'] != None:
                                signame = this.POUR[ownername]['net']
            pieces = [this.parse_POUR_PIECE() for i in range(pieces)]
            this.POUR[name] = {'type':typ, 
             'pos':pos,  'net':signame,  'pieces':pieces,  'owner':ownername}

    def parse_POUR_PIECE(this):
        file = this.file
        l = file.readline()
        a = l.strip().split()
        if not len(a) == 5:
            raise AssertionError
        else:
            typ, corners, arcs, width, level = (
             a[0], int(a[1]), int(a[2]), float(a[3]) * this.scale, int(a[4]))
            assert typ in ('POLY', 'CIRCLE', 'SEG', 'CUTOUT', 'CIRCUT')
        xyrs = []
        numcoord = corners + arcs
        lastp = None
        for i in range(numcoord):
            l = file.readline().strip()
            a = l.split()
            if len(a) == 2:
                x, y = float(a[0]), float(a[1])
                lastp = R2(x, y) * this.scale
                xyrs.append((lastp, 0))
            elif not len(a) == 4:
                raise AssertionError
            else:
                x1, y1, ab, aa = [float(ia) for ia in a]
                c = R2(x1, y1)
                c *= this.scale
                assert lastp is not None
                R = (c - lastp).getNorm()
                if not aa == 0:
                    if R < this.min_radius:
                        continue
                    if aa > 0:
                        R = -R
                    xyrs.append((c, R))

        return {'type':typ, 
         'width':width,  'xyrs':xyrs,  'level':level}

    def parse_MISC(this):
        file = this.file
        file.readline()
        while True:
            if not file.skiplines_starting_with_remark_or_empty():
                return
            misc = file.parse_brackets()
            if len(misc) == 0:
                break
            this.MISC.update(misc)

    def parse_ROUTE(this):
        file = this.file
        file.readline()
        if not file.skiplines_starting_with_remark_or_empty():
            return
        this.iamin = 'ROUTE'

    def parse_SIGNAL(this):
        """
        Each signal is separately identified, and consists of the signal header line and the pin pair line,
        followed by the coordinates that make up the route. As in the Connection List section, each connection
        pin pair in a signal entry must include one pin previously entered in the signal entry. The signal net must be
        listed in its entirety. All width statements in the format are modal, and will affect the global width, and
        subsequent route widths. It is necessary to reset to the correct width with a width statement in the next signal.
        """
        file = this.file
        l = file.readline().strip()
        a = l.split()
        if not len(a) >= 2:
            raise AssertionError
        else:
            if not a[0] in ('*SIG*', '*SIGNAL*'):
                raise AssertionError
            else:
                signame = a[1]
                if len(a) > 2:
                    sigflag = int(a[2])
                else:
                    sigflag = 0
            if len(a) > 3:
                color = int(a[3])
            else:
                color = -2
        pps = []
        while 1:
            l = file.readline()
            if l.strip() == '':
                break
            pin1, pin2 = l.split()
            conns = []
            while True:
                l = file.readline()
                if len(l) == 0:
                    file.push(l)
                    break
                l2 = l.strip()
                if len(l2) == 0 or l2[0] == '*' or l2[0].isalpha() or len(l2.split()) == 2:
                    file.push(l)
                    break
                conns.append(l2)

            pps.append(((pin1, pin2), conns))
            l = l.strip()
            if len(l) == 0 or not l[0].isalpha():
                break

        if this.iamin == 'ROUTE':
            this.route_signals.append((signame, pps))
        elif not 0:
            raise AssertionError

    def parse_TEXT(this):
        file = this.file
        text = {}
        file.readline()
        file.readline()
        file.readline()

    def parse_VIA(this):
        from common.utils2d import CircleShape, RectangleC
        file = this.file
        this.vias = {}
        file.readline()
        while True:
            if not file.skiplines_starting_with_remark_or_empty():
                return
            l = file.readline().strip()
            file.push(l)
            if l[0] == '*':
                return
            via = this.parse_padstack()
            this.vias[via['name']] = via

    def to_LayoutDB(this):
        from common.units import get_typical_manufacturing_tolerance
        from common.layoutdb import check_layer_stackup
        print('Creating PCB database...')
        db = layoutdbPy.new_iLayoutDB()
        db.length_unit = this.db_unit
        db.tolerance = this.tolerance
        this.sp = ShapeProcessor(db.tolerance)
        try:
            outline_shape = this.find_board_outline(db.tolerance)
        except:
            outline_shape = None

        if outline_shape is None:
            print('WARNING: Unable to extract outline shape (taking bounding box instead)')
        else:
            db.board_outline = outline_shape
        db.origin = 'CST MENTOR GRAPHICS PADS IMPORT V1'
        db.part_model_db = layoutdbPy.PartModelDB()
        db.is_x_mirror_mode = False
        if this.progressbar is not None:
            this.progressbar.reset('Processing layout data', 100)
        this.set_stackup(db)
        check_layer_stackup(db)
        if this.progressbar is not None:
            this.progressbar.set(10)
        this.set_padstacks(db)
        if this.progressbar is not None:
            this.progressbar.set(25)
        this.set_parts(db)
        if this.progressbar is not None:
            this.progressbar.set(40)
        this.viapadstacks = {}
        this.thermrelief = {}
        this.set_components(db)
        check_pin_names(db.components())
        this.set_signals(db)
        if this.progressbar is not None:
            this.progressbar.set(55)
        if this.progressbar is not None:
            this.progressbar.set(70)
        this.set_copper_pours(db)
        if this.progressbar is not None:
            this.progressbar.set(85)
        this.set_lines_copper(db)
        if this.progressbar is not None:
            this.progressbar.set(95)
        if db.board_outline is None:
            db.board_outline = layoutdbPy.compute_board_outline(db, 0.05)
        if this.progressbar is not None:
            this.progressbar.set(100)
        if this.progressbar is not None:
            this.progressbar.finished()
        else:
            if this.progressbar is not None:
                this.progressbar.reset('Processing pad connections', len(db.layers()))
            this.set_pads_connect(db)
            ss = db.simulation_settings
            if ss is not None:
                ss.use_ipp = True
            else:
                print('WARNING: unable to set the default geometry engine')
        if this.progressbar is not None:
            this.progressbar.finished()
        return db

    def find_board_outline(this, tolerance):
        from common.utils2d import PolyarcShape
        boards = [i for i in list(this.LINES.values()) if i['linetype'] == 'BOARD']
        if len(boards) == 0:
            return
        else:
            assert len(boards) == 1
            board = boards[0]
            pieces = [piece for piece in board['pieces'] if piece['typ'] in ('CLOSED',
                                                                             'BRDCLS')]
            shapes = []
            for piece in pieces:
                shape = PolyarcShape(piece['xyrs'])
                if shape is not None:
                    shapes.append(shape)

            cswh = utils2dPy.ShapeWithHoles()
            have_outline = False
            for shape in shapes:
                if have_outline:
                    cswh.holes.append(shape)
                else:
                    cswh.shape = shape
                    have_outline = True

            cswh.translate(board['pos'])
            res = this.sp(cswh, sense=1, info='board outline')
            return res

    def set_stackup(this, layoutdb):
        this.n_cl_layer = n_substraten_layers = 0
        this.num2layername, this.layername2num, this.islayermixed = {}, {}, {}
        associated_soldermask, solder_mask = {}, {}
        for l in this.MISC['LAYER']['LAYER']:
            cl_name = l['parent_value']
            if cl_name == '0':
                if 'LAYER_THICKNESS' in l:
                    th = float(l['LAYER_THICKNESS'])
                    th *= this.scale
                    layer = layoutdbPy.new_iLayer()
                    layer.thickness = th
                    layer.name = 'substrate-%d' % n_substraten_layers
                    n_substraten_layers += 1
                    layer.layer_type = layoutdbPy.LayerType.Dielectric
                    layoutdb.add_layer_below(layer, layer)
                    if 'DIELECTRIC' in l:
                        mat = layoutdbPy.Material()
                        mat.name = 'FR4'
                        mat.type = layoutdbPy.MaterialType.Dielectric
                        mat.eps = float(l['DIELECTRIC'])
                        layer.material = mat
            else:
                cl_name, typ, name = l['parent_value'], l['LAYER_TYPE'], l['LAYER_NAME']
                name, cl_name = name.upper(), cl_name.upper()
                this.num2layername[int(cl_name)] = name
                this.layername2num[name] = int(cl_name)
                if 'ASSOCIATED_SOLDER_MASK' in l:
                    sm_name = l['ASSOCIATED_SOLDER_MASK']
                    associated_soldermask[name] = sm_name.upper()
                if l['LAYER_TYPE'] in ('ROUTING', 'COMPONENT', 'SOLDER_MASK'):
                    th = float(l['COPPER_THICKNESS'])
                    th *= this.scale
                    layer = layoutdbPy.new_iLayer()
                    layer.thickness = th
                    layer.name = name
                    layer.layer_type = layoutdbPy.LayerType.Signal
                    if l['LAYER_TYPE'] == 'SOLDER_MASK':
                        layer.layer_type = layoutdbPy.LayerType.Soldermask
                        solder_mask[layer.name] = layer
                    else:
                        layoutdb.add_layer_below(layer, layer)
                    layer.is_split_mixed = l['PLANE'] == 'MIXED'
                    this.n_cl_layer += 1
                    if 'LAYER_THICKNESS' in l and l['LAYER_TYPE'] != 'SOLDER_MASK':
                        th = float(l['LAYER_THICKNESS'])
                        th *= this.scale
                        layer = layoutdbPy.new_iLayer()
                        layer.thickness = th
                        layer.name = 'substrate-%d' % n_substraten_layers
                        n_substraten_layers += 1
                        layer.layer_type = layoutdbPy.LayerType.Dielectric
                        layoutdb.add_layer_below(layer, layer)
                        if 'DIELECTRIC' in l:
                            mat = layoutdbPy.Material()
                            mat.name = 'FR4'
                            mat.type = layoutdbPy.MaterialType.Dielectric
                            mat.eps = float(l['DIELECTRIC'])
                            layer.material = mat

        l_top = layoutdb.top_etch_layer()
        if l_top.name in list(associated_soldermask.keys()):
            if associated_soldermask[l_top.name] in solder_mask:
                if l_top.number == 1 and layoutdb.layer(0).layer_type == layoutdbPy.LayerType.Dielectric:
                    smtl = layoutdb.layer(0)
                    smtl.layer_type = layoutdbPy.LayerType.Soldermask
                    smtl.name = solder_mask[associated_soldermask[l_top.name]].name
                elif l_top.number == 0:
                    layoutdb.add_layer_above(solder_mask[associated_soldermask[l_top.name]], l_top)
        l_bottom = layoutdb.bottom_etch_layer()
        if l_bottom.name in list(associated_soldermask.keys()):
            if associated_soldermask[l_bottom.name] in solder_mask:
                if l_bottom.number == layoutdb.n_layers() - 2 and layoutdb.layer(layoutdb.n_layers() - 1).layer_type == layoutdbPy.LayerType.Dielectric:
                    smbl = layoutdb.layer(layoutdb.n_layers() - 1)
                    smbl.layer_type = layoutdbPy.LayerType.Soldermask
                    smbl.name = solder_mask[associated_soldermask[l_bottom.name]].name
                elif l_top.number == layoutdb.n_layers() - 1:
                    layoutdb.add_layer_below(solder_mask[associated_soldermask[l_bottom.name]], l_bottom)

    def num2layer(this, layoutdb, num):
        if num in this.num2layername:
            return layoutdb.layer(this.num2layername[num])

    def set_padstacks(this, layoutdb):
        this.connect2layers = {}
        for pname, partdecal in this.PARTDECALS.items():
            for padstack in list(partdecal['padstacks'].values()):
                this.set_library_padstack(layoutdb, padstack)

        for via in list(this.vias.values()):
            this.set_library_padstack(layoutdb, via)

        if 'DRLOVERSIZE' in this.PCB:
            a = this.PCB['DRLOVERSIZE'].split()
            print(a)
            lscale = length_unit_convert(this.db_unit, 1.0, 'um')
            layoutdb.simulation_settings.plating_thickness_um = float(a[0]) * lscale / 2.0 * this.scale

    def set_library_padstack(this, layoutdb, padstack):
        lpsname = padstack['name']
        if not not layoutdb.has_lpadstack(lpsname):
            raise AssertionError
        else:
            lps = layoutdbPy.new_iLPadstack()
            lps.name = lpsname
            layoutdb.add_lpadstack(lps)
            if not padstack['is_pin']:
                dd = padstack['drill']
                dsrc = padstack
            elif padstack['is_pin']:
                if padstack['stacklines'][0]['drill'] != None:
                    dd = padstack['stacklines'][0]['drill']
                    dsrc = padstack['stacklines'][0]
            else:
                dd = 0
        if dd > 0:
            sl = 0
            if 'slotlength' in dsrc:
                if dsrc['slotlength'] is not None:
                    sl = dsrc['slotlength']
                    sl -= dd
                    if sl < 0:
                        print('WARNING: slotlength smaller than drill, using round drill figure:\n\t', padstack)
            if sl > 0:
                soff = 0
                if 'slotoffset' in dsrc:
                    soff = dsrc['slotoffset']
                a = utils2dPy.R2(-sl * 0.5 - soff, 0)
                b = utils2dPy.R2(sl * 0.5 - soff, 0)
                if 'slotori' in dsrc:
                    sori = dsrc['slotori'] * math.pi / 180.0
                    a.turn(sori)
                    b.turn(sori)
                seg = utils2dPy.CurveSegment(a, b)
                vhs = utils2dPy.thicken_curvesegment(seg, dd, True, layoutdb.tolerance, True)
                if vhs is not None:
                    lps.via_hole_shape = vhs.shape
            else:
                lps.via_hole_shape = CShape(CircleShape(R2(0, 0), dd * 0.5), layoutdb.tolerance)
            if padstack['stacklines'][0]['plated']:
                lps.is_plated = True
        lastlevel = None
        for stackline in padstack['stacklines']:
            level, s, size = stackline['level'], stackline['shape'], stackline['size']
            if size == 0:
                if lpsname not in this.connect2layers:
                    this.connect2layers[lpsname] = {}
                lastlevel = level
                continue
            shapes = []
            if s == 'R':
                shape = CircleShape(R2(0, 0), size * 0.5)
                Make_CClockwise(shape)
                shapes.append(shape)
            else:
                if s == 'S':
                    if stackline['corner'] in (None, 0):
                        shape = RectangleC(size, size)
                    else:
                        h = size * 0.5
                        r = stackline['corner']
                        assert h > 0
                        if stackline['corner'] < 0:
                            r = -r
                            assert r <= h
                            if r == h:
                                shape = CircleShape(R2(0, 0), h)
                            else:
                                xys = [
                                 R2(-h, h - r), R2(-h + r, h), R2(h - r, h), R2(h, h - r), R2(h, -h + r), R2(h - r, -h), R2(-h + r, -h), R2(-h, -h + r)]
                                xys.reverse()
                                shape = PolylineShape(xys)
                        else:
                            assert r <= h
                            xys = [(R2(-h, h - r), 0), (R2(-h + r, h - r), r), (R2(-h + r, h), 0), (R2(h - r, h), 0), (R2(h - r, h - r), r), (R2(h, h - r), 0), (R2(h, -h + r), 0), (R2(h - r, -h + r), r), (R2(h - r, -h), 0), (R2(-h + r, -h), 0), (R2(-h + r, -h + r), r), (R2(-h, -h + r), 0)]
                            shape = PolyarcShape(xys)
                    Make_CClockwise(shape)
                    shapes.append(shape)
                else:
                    if s == 'RF':
                        if stackline['corner'] == None or stackline['corner'] == 0:
                            shape = RectangleC(stackline['finlength'], size)
                        else:
                            h = size * 0.5
                            w = stackline['finlength'] * 0.5
                            r = stackline['corner']
                            assert w > 0 and h > 0
                            if stackline['corner'] < 0:
                                r = -r
                                assert r <= h and r <= w
                                xys = [R2(-w, h - r), R2(-w + r, h), R2(w - r, h), R2(w, h - r), R2(w, -h + r), R2(w - r, -h), R2(-w + r, -h), R2(-w, -h + r)]
                                xys.reverse()
                                shape = PolylineShape(xys)
                            else:
                                assert r <= h and r <= w
                                xys = [(R2(-w, h - r), 0), (R2(-w + r, h - r), r), (R2(-w + r, h), 0), (R2(w - r, h), 0), (R2(w - r, h - r), r), (R2(w, h - r), 0), (R2(w, -h + r), 0), (R2(w - r, -h + r), r), (R2(w - r, -h), 0), (R2(-w + r, -h), 0), (R2(-w + r, -h + r), r), (R2(-w, -h + r), 0)]
                                shape = PolyarcShape(xys)
                        Make_CClockwise(shape)
                        shape.translate(R2(stackline['finoffset'], 0))
                        shape.rotate(stackline['finori'] * math.pi / 180, R2(0, 0))
                        shapes.append(shape)
                    else:
                        if s == 'OF':
                            h, w = size, stackline['finlength']
                            assert w > 0 and h > 0
                            if w != h:
                                if w > h:
                                    a = R2((w - h) * 0.5, 0)
                                    w = h
                                else:
                                    a = R2(0, (h - w) * 0.5)
                                b = -a
                                shape = utils2d.PolyarcShape(utils2d.straight_path_segment_to_XYR(a, b, w))
                            else:
                                shape = utils2d.CircleShape(R2(0, 0), w * 0.5)
                            Make_CClockwise(shape)
                            shape.translate(R2(stackline['finoffset'], 0))
                            shape.rotate(stackline['finori'] * math.pi / 180, R2(0, 0))
                            shapes.append(shape)
                        else:
                            if s in ('RA', 'SA'):
                                if lastlevel == level:
                                    continue
                                else:
                                    print('WARNING: Pad stack has only antipad  on the level', lpsname, level)
                                if s == 'RA':
                                    shape = CircleShape(R2(0, 0), size * 0.5)
                                    Make_Clockwise(shape)
                                    shapes.append(shape)
                                else:
                                    if s == 'SA':
                                        shape = RectangleC(size, size)
                                        Make_Clockwise(shape)
                                        shapes.append(shape)
                            else:
                                if s == 'A':
                                    shape = CircleShape(R2(0, 0), size * 0.5)
                                    Make_CClockwise(shape)
                                    swh = ShapeWithHoles()
                                    swh.shape = shape
                                    hole = CircleShape(R2(0, 0), stackline['idia'] * 0.5)
                                    Make_Clockwise(hole)
                                    swh.holes.append(hole)
                                    shapes.append(swh)
                                else:
                                    if s in ('ST', 'RT'):
                                        if lastlevel == level:
                                            continue
                                        else:
                                            print('WARNING: Pad stack %s has only  termal pad  on the level ', lpsname, level)
                                        os, id, angle, num_sp, gap = (
                                         stackline['outsize'], size, stackline['spokeori'], stackline['spokenum'], stackline['spokewidth'])
                                        assert os > 0 and id >= 0 and os > id
                                        if num_sp > 0:
                                            angle_sp = 2 * math.pi / num_sp
                                        else:
                                            angle_sp = 0
                                        if s == 'ST':
                                            symb = RectangleC(os, os)
                                            Make_CClockwise(symb)
                                            symb_hole = RectangleC(id, id)
                                        else:
                                            symb = CircleShape(R2(0, 0), os * 0.5)
                                            Make_CClockwise(symb)
                                            symb_hole = CircleShape(R2(0, 0), id * 0.5)
                                        shapemap = this.get_Planeprocessor_WithShapes(os, symb, symb_hole, gap, angle, angle_sp, num_sp)
                                        for shape in shapemap:
                                            shapes.append(shape)

                                    else:
                                        print('WARNING: Ignored pad shape %s' % s)
            if len(shapes):
                pad = layoutdbPy.new_iLPad()
                for shape in shapes:
                    if isinstance(shape, Shape):
                        cswh = CShapeWithHoles(CShape(shape, layoutdb.tolerance))
                    else:
                        cswh = CShapeWithHoles(shape, layoutdb.tolerance)
                    pad.add_shape(cswh)

                if s in ('SA', 'RA'):
                    contype = layoutdbPy.ConnectType.clearance
                else:
                    if s in ('ST', 'RT'):
                        contype = layoutdbPy.ConnectType.thermal
                    else:
                        contype = layoutdbPy.ConnectType.connect
                    if lpsname in list(this.connect2layers.keys()):
                        if level in list(this.connect2layers[lpsname].keys()):
                            if this.connect2layers[lpsname][level] != contype:
                                print('WARNING: In LPadstack %s several pads on layer %i with various ConnectType' % (lpsname, level))
                        else:
                            this.connect2layers[lpsname][level] = contype
                    else:
                        this.connect2layers[lpsname] = {level: contype}
                    if not padstack['is_pin']:
                        von, bis = int(padstack['fromto'][0]), int(padstack['fromto'][1])
                    if level <= 0:
                        if level == -2:
                            if padstack['is_pin']:
                                lps.pad(layoutdbPy.WhereType.top, contype, pad)
                            else:
                                if von == -2:
                                    lps.pad(layoutdbPy.WhereType.top, contype, pad)
                                else:
                                    layer = this.num2layer(layoutdb, von)
                                    if layer is not None:
                                        lps.pad(layer, contype, pad)
                        else:
                            if level == -1:
                                w = layoutdbPy.WhereType.inner
                                lps.pad(w, contype, pad)
                            else:
                                if padstack['is_pin']:
                                    lps.pad(layoutdbPy.WhereType.bottom, contype, pad)
                                else:
                                    if bis == 0:
                                        lps.pad(layoutdbPy.WhereType.bottom, contype, pad)
                                    else:
                                        layer = this.num2layer(layoutdb, bis)
                                        if layer is not None:
                                            lps.pad(layer, contype, pad)
                    else:
                        layer = this.num2layer(layoutdb, level)
                        if layer is not None:
                            lps.pad(layer, contype, pad)
            lastlevel = level

    def get_Planeprocessor_WithShapes(this, os, symb, symb_hole, gap, angle, angle_sp, num_sp):
        hs = [
         symb_hole]
        h0 = utils2d.Rectangle(gap, os * math.sqrt(2) + os / 10)
        h0.translate(R2(-gap / 2.0, 0))
        Make_Clockwise(h0)
        h0.rotate(-2 * math.pi / 4 + 2 * math.pi * angle / 360, R2())
        for i in range(num_sp):
            h0.rotate(angle_sp, R2())
            hs.append(h0.clone())

        vhs = vectorShapeWithHoles()
        vhs.append(CShapeWithHoles(symb))
        for h in hs:
            vhs.append(CShapeWithHoles(h))

        pp = Planeprocessor(BoundingBox(-(os * math.sqrt(2) + os / 8), os * math.sqrt(2) + os / 8, -(os * math.sqrt(2) + os / 8), os * math.sqrt(2) + os / 8), 0.0001)
        pp.add_shapes(vhs)
        res = pp.boolean_add2()
        return [r.to_ShapeWithHoles() for r in res]

    def set_parts_old(this, layoutdb):
        for ptype in list(this.PARTTYPE.keys()):
            parttype = this.PARTTYPE[ptype]
            for altpdecalname in parttype['dcalnm']:
                this.set_part(layoutdb, altpdecalname)

    def set_parts(this, layoutdb):
        this.partdummies = {}
        this.not_displayed_pieces = {}
        this.partname2decalname = {}
        if 'has_alt_name' in this.PARTMAP:
            for ptype in this.PARTMAP['has_alt_name']:
                parttype = this.PARTTYPE[ptype]
                for alt in this.PARTMAP['has_alt_name'][ptype]['alt']:
                    for ctype in list(this.PARTMAP[(ptype + '@' + str(alt))].keys()):
                        if not alt <= len(parttype['dcalnm']):
                            raise AssertionError
                        else:
                            decalname = parttype['dcalnm'][alt]
                            if ctype in ('R', 'C', 'L'):
                                partname = decalname + '-' + ctype
                                this.set_part(layoutdb, decalname, partname)
                            else:
                                partname = decalname
                                this.set_part(layoutdb, decalname, partname)
                        this.partname2decalname[partname] = decalname

                for sep in this.PARTMAP['has_alt_name'][ptype]['sep']:
                    for ctype in list(this.PARTMAP[(ptype + '@' + sep)].keys()):
                        decalname = sep
                        if ctype in ('R', 'C', 'L'):
                            partname = decalname + '-' + ctype
                            this.set_part(layoutdb, decalname, partname)
                        else:
                            partname = decalname
                            this.set_part(layoutdb, decalname, partname)
                        this.partname2decalname[partname] = decalname

        if len(list(this.not_displayed_pieces.keys())) > 0:
            print('WARNING:  The following piece types in Partdecal will not be displayed:')
            for piece_type in this.not_displayed_pieces:
                print('\t%s (%i)' % (piece_type, this.not_displayed_pieces[piece_type]))

    def set_part(this, layoutdb, altpdecalname, partname):
        if altpdecalname not in this.PARTDECALS:
            print('ERROR: No part decal found for  %s' % refnm)
        else:
            new_part = PartDummy()
            new_part.padstacks = []
            new_part.pins = []
            new_part.outlines = []
            new_part.copshape = []
            new_part.copcuts = []
            new_part.name = partname
            new_part.mount_type = layoutdbPy.MountType.unknown
            new_part.mount_side = 'unknown'
            partdecal = this.PARTDECALS[altpdecalname]
            pm = partdecal['padstackmap']
            pinpos = partdecal['pads']
            assert len(pm) == len(pinpos)
            for i in range(len(pm)):
                ps = this.set_pin(layoutdb, pm[i], pinpos[i])
                new_part.padstacks.append(ps)
                new_part.pins.append(ps.position)

            ps = partdecal['padstacks']
            n_pads_top = 0
            n_pads_inner = 0
            n_pads_bottom = 0
            n_drill = 0
            for i in ps:
                if ps[i]['stacklines'][0]['size'] != 0:
                    n_pads_top += 1
                if ps[i]['stacklines'][1]['size'] != 0:
                    n_pads_inner += 1
                if len(ps[i]['stacklines']) > 2:
                    if ps[i]['stacklines'][2]['size'] != 0:
                        n_pads_bottom += 1
                    if ps[i]['stacklines'][0]['drill'] != 0:
                        n_drill += 1

            if n_pads_top == len(ps) and n_pads_inner == 0 and n_pads_bottom == 0 and n_drill == 0 or n_pads_top == 0 and n_pads_inner == 0 and n_pads_bottom == len(ps) and n_drill == 0:
                new_part.mount_type = layoutdbPy.MountType.surface
                if n_pads_top == len(ps):
                    new_part.mount_side = 'top'
                else:
                    new_part.mount_side = 'bottom'
            elif n_pads_top != 0 and n_pads_inner != 0 or n_pads_inner != 0 and n_pads_bottom != 0 or n_pads_top != 0 and n_pads_bottom != 0:
                if n_drill == len(ps):
                    new_part.mount_type = layoutdbPy.MountType.through
            else:
                new_part.mount_type = layoutdbPy.MountType.unknown
            pieces = partdecal['pieces']
            shapes = []
            for piece in pieces:
                if piece['typ'] in ('CLOSED', 'COPCLS'):
                    shape = PolyarcShape(piece['xyrs'])
                    if piece['typ'] == 'CLOSED':
                        shapes.append(shape)
                    else:
                        cswh = this.sp(shape, sense=1, info='closed')
                        if cswh is not None:
                            new_part.copshape.append((cswh, piece['level']))
                elif piece['typ'] in ('OPEN', ):
                    xyrs = piece['xyrs']
                    if len(xyrs) >= 2:
                        a = xyrs[0][0]
                        for i in range(1, len(xyrs)):
                            b = xyrs[i][0]
                            if xyrs[i][1] == 0:
                                w = piece['widthhght']
                                if a != b:
                                    if w > 0:
                                        shape = rectangular_shape_from_straight_path(a, b, w, True)
                                        shape = shape.to_Shape()
                                        shapes.append(shape)
                                a = b

                elif piece['typ'] in ('COPOPN', ):
                    xyrs = piece['xyrs']
                    w = piece['widthhght']
                    res = polyarc_path_to_polyarc_shapes(xyrs, float(w))
                    for shape in res:
                        cswh = this.sp(shape, sense=1, info='copopn')
                        if cswh is not None:
                            new_part.copshape.append((cswh, piece['level']))

                elif piece['typ'] in ('CIRCLE', 'COPCIR'):
                    assert len(piece['xyrs']) == 2
                    xy1, xy2 = piece['xyrs'][0][0], piece['xyrs'][1][0]
                    c = (xy2 + xy1) / 2
                    R = ((xy2 - xy1) / 2).getNorm()
                    shape = CircleShape(c, R)
                    if piece['typ'] == 'CIRCLE':
                        shapes.append(shape)
                    else:
                        cswh = this.sp(shape, sense=1)
                        if cswh is not None:
                            pass
                    new_part.copshape.append((cswh, piece['level']))
                else:
                    if piece['typ'] in ('COPCUT', ):
                        shape = PolyarcShape(piece['xyrs'])
                        utils2d.Make_Clockwise(shape)
                        new_part.copcuts.append((shape, piece['level']))
                    else:
                        if piece['typ'] not in this.not_displayed_pieces:
                            this.not_displayed_pieces[piece['typ']] = 1
                        else:
                            this.not_displayed_pieces[piece['typ']] += 1

            for shape in shapes:
                cswh = this.sp(shape, sense=1)
                if cswh is not None:
                    new_part.outlines.append(cswh)

            this.partdummies[new_part.name] = new_part

    def set_pin(this, layoutdb, padstack, pinpos):
        lpsname = padstack['name']
        assert layoutdb.has_lpadstack(lpsname)
        lps = layoutdb.lpadstack(lpsname)
        ps = layoutdbPy.new_iPadstack()
        ps.library_padstack = lps
        cl_layer = [l.name for l in layoutdb.layers() if l.is_etch()]
        con_inf = this.connect2layers[lpsname]
        for lev in con_inf:
            if lev <= 0:
                if lev == -2:
                    ps.connect(layoutdb.layer(layoutdb.top_etch_layer().name), con_inf[lev])
                else:
                    if lev == -1:
                        for l in cl_layer:
                            if l != layoutdb.top_etch_layer().name and l != layoutdb.bottom_etch_layer().name:
                                ps.connect(layoutdb.layer(l), con_inf[lev])

                    else:
                        ps.connect(layoutdb.layer(layoutdb.bottom_etch_layer().name), con_inf[lev])
            else:
                layer = this.num2layer(layoutdb, lev)
                if layer is not None:
                    ps.connect(layer, con_inf[lev])

        ps.connect(layoutdb.top_etch_layer(), layoutdbPy.ConnectType.connect)
        ps.connect(layoutdb.bottom_etch_layer(), layoutdbPy.ConnectType.connect)
        for l in [layoutdb.top_soldermask(), layoutdb.bottom_soldermask()]:
            if l is not None and l.layer_type == layoutdbPy.LayerType.Soldermask:
                ps.connect(l, layoutdbPy.ConnectType.connect)

        ps.position = pinpos
        return ps

    def set_components(this, layoutdb):
        from math import pi
        import re, types
        this.alpinm4com = {}
        this.em_model_items = []
        parttypes = {}
        if 'ATTRIBUTE' in this.MISC:
            if 'PARTTYPE' in this.MISC['ATTRIBUTE']:
                if type(this.MISC['ATTRIBUTE']['PARTTYPE']) == list:
                    for p in this.MISC['ATTRIBUTE']['PARTTYPE']:
                        if 'Value' in p:
                            parttypes[p['parent_value']] = p

                elif type(this.MISC['ATTRIBUTE']['PARTTYPE']) == dict:
                    if 'parent_value' in this.MISC['ATTRIBUTE']['PARTTYPE']:
                        if 'Value' in this.MISC['ATTRIBUTE']['PARTTYPE']:
                            parttypes[this.MISC['ATTRIBUTE']['PARTTYPE']['parent_value']] = this.MISC['ATTRIBUTE']['PARTTYPE']
        parts = {}
        if 'ATTRIBUTE' in this.MISC and 'PART' in this.MISC['ATTRIBUTE']:
            if type(this.MISC['ATTRIBUTE']['PART']) == list:
                for p in this.MISC['ATTRIBUTE']['PART']:
                    if 'Value' in p:
                        parts[p['parent_value']] = p

            elif type(this.MISC['ATTRIBUTE']['PART']) == dict:
                if 'parent_value' in this.MISC['ATTRIBUTE']['PART']:
                    if 'Value' in this.MISC['ATTRIBUTE']['PART']:
                        parts[this.MISC['ATTRIBUTE']['PART']['parent_value']] = this.MISC['ATTRIBUTE']['PART']
        for comp_name in list(this.PARTLIST.keys()):
            comp = this.PARTLIST[comp_name]
            new_comp = layoutdbPy.new_iComponent()
            new_comp.name = comp_name
            new_comp.position = comp['xy']
            new_comp.rotation = comp['ori'] * pi / 180.0
            if comp['mirrored']:
                new_comp.side = layoutdbPy.WhereType.bottom
            else:
                new_comp.side = layoutdbPy.WhereType.top
            if re.match('[RCL][0-9]{1,}', comp_name):
                comp_art = comp_name[0]
            else:
                comp_art = 'other'
            ptnm = comp['ptypenm']
            ptnm = ptnm.split('@')
            if len(ptnm) == 1:
                if ptnm[0] in list(this.PARTTYPE.keys()):
                    part_type = this.PARTTYPE[ptnm[0]]
                    if comp['alt'] <= len(part_type['dcalnm']):
                        if comp_art in 'RCL':
                            part_name = part_type['dcalnm'][comp['alt']] + '-' + comp_art
                        else:
                            part_name = part_type['dcalnm'][comp['alt']]
                    else:
                        print('ERROR: No part decal found for component %s' % comp_name)
                        continue
                else:
                    print('ERROR: No part decal found for component %s' % comp_name)
                    continue
            else:
                if len(ptnm) == 2:
                    part_name = ptnm[1]
                    if comp_art in 'RCL':
                        part_name = ptnm[1] + '-' + comp_art
                    else:
                        part_name = ptnm[1]
                else:
                    print('ERROR: No part decal found for component %s' % comp_name)
                    continue
                if comp_art in 'RCL':
                    typ = comp_art
                else:
                    typ = ''
                value = ''
                em_model = ptnm[0]
                if em_model in parttypes:
                    if 'Value' in parttypes[em_model]:
                        value = parttypes[em_model]['Value']
                if comp_name in parts:
                    if 'Value' in parts[comp_name]:
                        value = parts[comp_name]['Value']
                this.em_model_items.append((new_comp.name, em_model, typ, value))
                if part_name in this.partdummies:
                    part = this.partdummies[part_name]
                    zero = R2(0, 0)
                    rot = new_comp.rotation
                    pos = new_comp.position
                    new_comp.mount_type = part.mount_type
                    istop = new_comp.side == layoutdbPy.WhereType.top
                    pinnames = []
                    if part_name in this.partname2decalname:
                        pdname = this.partname2decalname[part_name]
                        pinnames = this.PARTDECALS[pdname]['alpinname']
                    if len(this.PARTTYPE[ptnm[0]]['alpinm']) > 0:
                        pinnames = this.PARTTYPE[ptnm[0]]['alpinname']
                    assert len(pinnames) == len(part.pins)
                    for o in part.outlines:
                        swh = o.to_ShapeWithHoles()
                        if istop:
                            swh.rotate(rot, zero)
                        else:
                            swh.y_mirror()
                            swh.reverse()
                            swh.rotate(-rot - pi, zero)
                        swh.translate(pos)
                        cswh = this.sp(swh, sense=1, info='component outline')
                        if cswh is not None:
                            new_comp.add_outline_shape(cswh)

                    for i in range(len(part.pins)):
                        p = part.pins[i]
                        pnt = p * 1
                        if istop:
                            pnt.turn(rot)
                        else:
                            pnt.x = -pnt.x
                            pnt.turn(-rot)
                        pnt += pos
                        pin = layoutdbPy.new_Pin()
                        pin.position = pnt
                        if part.mount_side == 'top':
                            if istop:
                                pin.layer = layoutdb.top_etch_layer()
                            else:
                                pin.layer = layoutdb.bottom_etch_layer()
                        else:
                            if part.mount_side == 'bottom':
                                if istop:
                                    pin.layer = layoutdb.bottom_etch_layer()
                                else:
                                    pin.layer = layoutdb.top_etch_layer()
                            pin.name = pinnames[i]
                            new_comp.add_pin(pin)

                    for ps in part.padstacks:
                        ps = ps.clone()
                        p = ps.position
                        if istop:
                            p.turn(rot)
                            ps.rotation += rot
                        else:
                            p.x = -p.x
                            p.turn(-rot)
                            ps.rotation -= rot + pi
                            lps = ps.library_padstack.clone()
                            for contype in [layoutdbPy.ConnectType.clearance, layoutdbPy.ConnectType.thermal, layoutdbPy.ConnectType.connect]:
                                for l_from, l_to in [(layoutdbPy.WhereType.bottom, layoutdbPy.WhereType.top), (layoutdbPy.WhereType.top, layoutdbPy.WhereType.bottom),
                                 (
                                  layoutdb.top_etch_layer(), layoutdb.bottom_etch_layer()), (layoutdb.bottom_etch_layer(), layoutdb.top_etch_layer()),
                                 (
                                  layoutdb.top_soldermask(), layoutdb.bottom_soldermask()), (layoutdb.bottom_soldermask(), layoutdb.top_soldermask())]:
                                    pad = ps.library_padstack.pad(l_from, contype)
                                    newpad = None
                                    if pad:
                                        for i in range(pad.n_shapes()):
                                            newpad = layoutdbPy.new_iLPad()
                                            s1 = pad.shape(i).to_ShapeWithHoles()
                                            if layoutdb.is_x_mirror_mode:
                                                s1.x_mirror()
                                            else:
                                                s1.y_mirror()
                                            s1.reverse()
                                            newpad.add_shape(CShapeWithHoles(s1, layoutdb.tolerance))

                                    lps.pad(l_to, contype, newpad)

                            ps.library_padstack = lps
                            ps.is_flipped = False
                        ps.position = p + pos
                        ps.net = layoutdb.net('NONE')
                        if ps.library_padstack.via_hole_shape:
                            ps.layer_from = layoutdb.layer(layoutdb.top_etch_layer().name)
                            ps.layer_to = layoutdb.layer(layoutdb.bottom_etch_layer().name)
                            ok = this.set_ps_array(ps, ps.position, -2, 0, False)
                        new_comp.add_padstack(ps)

                    for swh, level in part.copshape:
                        if level >= 0:
                            layer = this.num2layer(layoutdb, level)
                        else:
                            if level == -1:
                                if istop:
                                    layer = layoutdb.bottom_etch_layer()
                                else:
                                    layer = layoutdb.top_etch_layer()
                            else:
                                print('WARNING: Invalid level=%d in part copper fill (skipped)' % level)
                                continue
                            if layer is None:
                                pass
                            else:
                                for cut, l in part.copcuts:
                                    if l == level and swh.shape.to_Shape().contains(cut):
                                        swh.add_hole(CShape(cut, layoutdb.tolerance))

                                swh = swh.to_ShapeWithHoles()
                                if istop:
                                    swh.rotate(rot, zero)
                                    swh.translate(pos)
                                else:
                                    swh.y_mirror()
                                    swh.reverse()
                                    swh.rotate(-rot - pi, zero)
                                    swh.translate(pos)
                                    if layer.number <= layoutdb.top_etch_layer().number or layer.number >= layoutdb.bottom_etch_layer().number:
                                        nlnum = layoutdb.n_layers() - 1 - layer.number
                                        layer = layoutdb.layer(nlnum)
                        cswh = this.sp(swh, sense=1)
                        if cswh is not None:
                            layer.add_plane_shape(cswh)

                    if part_name in this.partname2decalname:
                        pdname = this.partname2decalname[part_name]
                        this.alpinm4com[comp_name] = this.PARTDECALS[pdname]['alpinm']
                    if len(this.PARTTYPE[ptnm[0]]['alpinm']) > 0:
                        this.alpinm4com[comp_name] = this.PARTTYPE[ptnm[0]]['alpinm']
                else:
                    print('ERROR: No part found for component %s' % comp_name, part_name)
                layoutdb.add_component(new_comp)

        from common.layoutdb import set_read_elements
        import os
        print('Reading component values...')
        warnings = set_read_elements(layoutdb, (this.em_model_items), print_warnings=False)
        print()
        for w in warnings:
            print(w)

        if len(this.em_model_items):
            filename = os.path.splitext(this.layoutfilename)[0] + '.csv'
            from common.layoutdb import export_lumped_elements_to_csv
            export_lumped_elements_to_csv(this.em_model_items, filename)
            print('INFO: Created CSV file (' + filename + ') with lumped-element values for review/re-import.')

    def set_signals(this, layoutdb):
        from common.utils2d import PolyarcShape, Make_CClockwise, Make_Clockwise, straight_path_segment_to_XYR
        import re

        def get_psnet(comn1, pinn1, signame):
            com1 = layoutdb.component(comn1)
            if com1:
                if comn1 in this.alpinm4com:
                    if pinn1 in this.alpinm4com[comn1]:
                        ps = com1.padstack(this.alpinm4com[comn1][pinn1])
                        ps.net = layoutdb.net(signame)
                        pin = com1.pin(this.alpinm4com[comn1][pinn1])
                        pin.net = ps.net
                if len(re.findall('\\D', pinn1)) == 0:
                    if com1.n_padstacks() >= int(pinn1) - 1:
                        ps = com1.padstack(int(pinn1) - 1)
                        ps.net = layoutdb.net(signame)
                        pin = com1.pin(int(pinn1) - 1)
                        pin.net = ps.net

        flags_used = set()
        this.min_trace_width = 1e+100
        cl_layer_nums = [this.layername2num[l.name] for l in layoutdb.layers() if l.is_etch()]
        segments = []
        arccenter = None
        for signame, pinpairs in this.route_signals:
            for (pin1, pin2), conns in pinpairs:
                lastp, lastlayer = (None, None)
                vias, pins = [], []
                layoutdb.add_net_dirty(signame)
                comn1, pinn1 = re.split('\\.', pin1)
                comn2, pinn2 = re.split('\\.', pin2)
                get_psnet(comn1, pinn1, signame)
                get_psnet(comn2, pinn2, signame)
                for l in conns:
                    a = l.split()
                    assert len(a) >= 5
                    option_kws = ('THERMAL', 'TEARDROP', 'JUMPER', 'REUSE')
                    options = {}
                    ilast = -1
                    for kw, i in sorted([(kw, a.index(kw)) for kw in option_kws if kw in a],
                      key=(lambda x: x[1])):
                        options[kw] = a[i + 1:ilast]
                        ilast = i

                    if ilast >= 0:
                        a = a[:ilast]
                    x, y, layer, segwidth, flag = (
                     float(a[0]), float(a[1]), a[2], float(a[3]) * this.scale, int(a[4]))
                    pos = R2(x, y)
                    pos *= this.scale
                    teardrop_proh_left = flag & 512 != 0
                    teardrop_proh_right = flag & 1024 != 0
                    isarccenter = flag & 4096 != 0
                    flags_used.add(flag)
                    if isarccenter:
                        assert a[5] in ('CW', 'CCW')
                        isccw = a[5] == 'CCW'
                        arccenter = (
                         pos, isccw)
                    else:
                        if len(a) > 5:
                            vianame = a[5]
                            if vianame not in this.vias:
                                print('WARNING: Via with name %s not found (pos=%s)' % (vianame, str(pos)))
                            else:
                                via = this.vias[vianame]
                                von, bis = via['fromto']
                                ps, isnew = this.get_ps(pos, von, bis)
                                if isnew:
                                    if not layoutdb.has_lpadstack(vianame):
                                        raise AssertionError
                                    else:
                                        lps = layoutdb.lpadstack(vianame)
                                        ps.library_padstack = lps
                                        ps.net = layoutdb.net(signame)
                                        ps.position = pos
                                        ps.rotation = 0
                                        cl_layer = [l.name for l in layoutdb.layers() if l.is_etch()]
                                        con_inf = this.connect2layers[vianame]
                                        for lev in con_inf:
                                            if lev <= 0:
                                                if lev == -2:
                                                    ps.connect(layoutdb.layer(layoutdb.top_etch_layer().name), con_inf[lev])
                                                else:
                                                    if lev == -1:
                                                        for l in cl_layer:
                                                            if l != layoutdb.top_etch_layer().name and l != layoutdb.bottom_etch_layer().name:
                                                                ps.connect(layoutdb.layer(l), con_inf[lev])

                                                    else:
                                                        ps.connect(layoutdb.layer(layoutdb.bottom_etch_layer().name), con_inf[lev])
                                            else:
                                                lp = this.num2layer(layoutdb, lev)
                                                if lp is not None:
                                                    ps.connect(lp, con_inf[lev])

                                        if bis == 0:
                                            ps.layer_from = layoutdb.layer(layoutdb.top_etch_layer().name)
                                            ps.layer_to = layoutdb.layer(layoutdb.bottom_etch_layer().name)
                                        else:
                                            ps.layer_from = this.num2layer(layoutdb, von)
                                        ps.layer_to = this.num2layer(layoutdb, bis)
                                    ps.connect(ps.layer_from, layoutdbPy.ConnectType.connect)
                                    ps.connect(ps.layer_to, layoutdbPy.ConnectType.connect)
                                elif ps.library_padstack.name != vianame or ps.net.name != signame:
                                    print('WARNING: Two vias on the same position with diferent lps or nets  (pos=%s)' % str(pos))
                        if lastp is not None:
                            if lastlayer != '0':
                                if arccenter != None:
                                    segments.append([lastp, pos, lastsegwidth, lastlayer, signame, arccenter[0], arccenter[1]])
                                    arccenter = None
                                else:
                                    segments.append([lastp, pos, lastsegwidth, lastlayer, signame])
                        lastp, lastsegwidth = pos, segwidth
                        lastlayer = layer

        def seg_sort(x, y):
            if x[3] != y[3]:
                return 2 * (x[3] < y[3]) - 1
            else:
                if x[4] != y[4]:
                    return 2 * (x[4] < y[4]) - 1
                else:
                    xmin = x[0]
                    if x[1].x < xmin.x:
                        xmin = x[1]
                    ymin = y[0]
                    if y[1].x < ymin.x:
                        ymin = y[1]
                    if xmin.x != ymin.x:
                        return 2 * (xmin.x < ymin.x) - 1
                return 2 * (xmin.y < ymin.y) - 1

        class KeyWrap:

            def __init__(self, obj):
                self.obj = obj

            def __lt__(self, other):
                return seg_sort(self.obj, other.obj) < 0

            def __gt__(self, other):
                return seg_sort(self.obj, other.obj) > 0

            def __eq__(self, other):
                return seg_sort(self.obj, other.obj) == 0

            def __le__(self, other):
                return seg_sort(self.obj, other.obj) <= 0

            def __ge__(self, other):
                return seg_sort(self.obj, other.obj) >= 0

            def __ne__(self, other):
                return seg_sort(self.obj, other.obj) != 0

        if len(segments) > 1:
            segments.sort(key=KeyWrap)
            new_segs = []
            last_seg = segments[0]
            for seg in segments:
                a, b, w, lyr, net = seg[:5]
                last_a, last_b, last_w, last_lyr, last_net = last_seg[:5]
                if net == last_net:
                    if lyr == last_lyr:
                        if a == last_a and b == last_b or a == last_b and b == last_a:
                            last_seg[2] = max(w, last_w)
                            continue
                else:
                    new_segs.append(last_seg)
                last_seg = seg

            new_segs.append(last_seg)
            print('Deleted %d redundant trace segments.' % (len(segments) - len(new_segs)))
            segments = new_segs
        for seg in segments:
            p1, p2, width, lyr, signame = seg[:5]
            if not lyr == '0':
                if lyr == 0:
                    pass
                else:
                    if this.min_trace_width > width:
                        this.min_trace_width = width
                    layer = this.num2layer(layoutdb, int(lyr))
                    if layer is not None:
                        trace = layoutdbPy.Trace()
                        roundcaps = True
                        if len(seg) > 5:
                            assert len(seg) == 7
                            c = seg[5]
                            R = (p1 - c).getNorm()
                            if not seg[6]:
                                R *= -1
                            segm = CurveSegment(p1, p2, c, R)
                        else:
                            segm = CurveSegment(p1, p2)
                        trace.add_segment(segm, width)
                        trace.net_index = layoutdb.net_index(signame)
                        layer.add_trace(trace)

        layoutdb.simulation_settings.lateral_reference_length = this.min_trace_width
        for padst_x in this.viapadstacks.values():
            for padst in padst_x.values():
                if padst[1] == True:
                    layoutdb.add_padstack(padst[0])

    def get_ps(this, pos, von, bis):
        if (
         pos.x, pos.y) in this.viapadstacks:
            if (von, bis) in this.viapadstacks[(pos.x, pos.y)]:
                return (
                 this.viapadstacks[(pos.x, pos.y)][(von, bis)][0], False)
        ps = layoutdbPy.new_iPadstack()
        ok = this.set_ps_array(ps, pos, von, bis, True)
        if ok:
            return (
             this.viapadstacks[(pos.x, pos.y)][(von, bis)][0], True)

    def set_ps_array(this, ps, pos, von, bis, is_via):
        if (
         pos.x, pos.y) in this.viapadstacks:
            if (
             von, bis) in this.viapadstacks[(pos.x, pos.y)]:
                return 0
            this.viapadstacks[(pos.x, pos.y)][(von, bis)] = (ps, is_via)
        else:
            this.viapadstacks[(pos.x, pos.y)] = {(
 von, bis): (ps, is_via)}
        return 1

    def get_ps2layer(this, pos, layer):
        for x, y in list(this.viapadstacks.keys()):
            if pos.x - this.tolerance <= x <= pos.x + this.tolerance and pos.y - this.tolerance <= y <= pos.y + this.tolerance:
                for fromto, ps in this.viapadstacks[(x, y)].items():
                    if fromto[0] <= layer and layer <= fromto[1] or fromto[1] == 0:
                        return ps[0]
                    else:
                        return

    def set_pads_connect(this, layoutdb):
        if 'PLANEFLAGS' in this.PCB:
            a = this.PCB['PLANEFLAGS'].split()
            if len(a) < 14:
                print("Error! Incorrect PLANEFLAGS in export file, ignore 'Remove unused pads' flag")
                return
            kept_start_end = False
            if len(a) >= 20:
                if a[19] == 'Y':
                    kept_start_end = True
            a = a[:14]
            save_mode, display_mode, remove_isolated_copper, remove_stub_viol, show_tp, lock_tp, hide_tack, auto_thermal_update, auto_link_update, flood_confirm, relative_size, show_protection, hatch_reverse, remove_unused_pads = a
            try:
                if not save_mode in ('ALL', 'OUTLINE'):
                    raise AssertionError
                else:
                    if not display_mode in ('ALL', 'OUTLINE', 'THERMALS'):
                        raise AssertionError
                    else:
                        if not remove_isolated_copper in 'YN':
                            raise AssertionError
                        else:
                            if not remove_stub_viol in 'YN':
                                raise AssertionError
                            else:
                                if not show_tp in 'YN':
                                    raise AssertionError
                                else:
                                    if not lock_tp in 'YN':
                                        raise AssertionError
                                    else:
                                        if not hide_tack in 'YN':
                                            raise AssertionError
                                        elif not auto_thermal_update in 'YN':
                                            raise AssertionError
                                        assert auto_link_update in 'YN'
                                    assert flood_confirm in 'YN'
                                assert relative_size in 'YN'
                            assert show_protection in 'YN'
                        assert hatch_reverse in 'YN'
                    assert remove_unused_pads in 'YN'
            except:
                print("Error! Incorrect PLANEFLAGS in export file, ignore 'Remove unused pads' flag")
                return
            else:
                if remove_unused_pads != 'Y':
                    return
            layoutdb.simulation_settings.is_suppress_unconnected_pads_active = True
            if kept_start_end:
                layoutdb.simulation_settings.unconnected_pads_check_type = layoutdbPy.UnconnectedPadsCheckType.pads_keep_se
            else:
                layoutdb.simulation_settings.unconnected_pads_check_type = layoutdbPy.UnconnectedPadsCheckType.pads

    def set_pads_connect_old(this, layoutdb):
        if this.progressbar is not None:
            this.progressbar.reset('Processing pad connections', len(layoutdb.layers()) + len(this.thermrelief))
        count = 0
        for layer in layoutdb.layers():
            for i in range(layer.n_traces()):
                trace = layer.trace(i)
                for j in range(trace.n_segments()):
                    seg = trace.segment(j)
                    pss = (this.get_ps2layer(seg.a, this.layername2num[layer.name]),
                     this.get_ps2layer(seg.b, this.layername2num[layer.name]))
                    for ps in pss:
                        if ps is not None:
                            ps.connect(layer, layoutdbPy.ConnectType.connect)

            if this.progressbar is not None:
                count += 1
                this.progressbar.set(count)

        for level, therm_array in this.thermrelief.items():
            layer = this.num2layer(layoutdb, level)
            for thermrel in therm_array:
                for xy in list(this.viapadstacks.keys()):
                    for fromto, ps in this.viapadstacks[xy].items():
                        if fromto[0] <= level and level <= fromto[1] or fromto[1] == 0:
                            lpad = ps[0].library_padstack.pad(layer, layoutdbPy.ConnectType.connect)
                            if not lpad:
                                lpad = ps[0].library_padstack.pad(layoutdbPy.WhereType.inner, layoutdbPy.ConnectType.connect)
                            if lpad and lpad.n_shapes() >= 1:
                                ss = lpad.shape(0).shape.to_Shape()
                                ss.rotate(ps[0].rotation, R2())
                                ss.translate(ps[0].position)
                                padsbb = ss.bbox
                                if padsbb.intersects(thermrel[0].bbox):
                                    ps[0].connect(layer, layoutdbPy.ConnectType.connect)

            if this.progressbar is not None:
                count += 1
                this.progressbar.set(count)

        if this.progressbar is not None:
            this.progressbar.finished()

    def set_copper_pours(this, layoutdb):
        deleted = []
        for key, val in this.POUR.items():
            if val['type'] == 'POUROUT':
                deleted.append(key)

        for key in deleted:
            del this.POUR[key]

        deleted = []
        for key, val in this.POUR.items():
            if val['owner'] is not None:
                if val['owner'] != key:
                    if val['owner'] not in this.POUR:
                        val['owner'] = key
                        continue
                    owner = this.POUR[val['owner']]
                    if 'childs' not in owner:
                        owner['childs'] = {}
                owner['childs'][key] = val
                deleted.append(key)

        for key in deleted:
            del this.POUR[key]

        for key, pour in this.POUR.items():
            assert key == pour['owner']

        def create_shapes(pours, parent_netname=None):
            res = []
            for pour in pours:
                netname = pour['net']
                if not parent_netname is None:
                    if not netname is None:
                        assert netname == parent_netname
                    else:
                        if netname is None:
                            netname = parent_netname
                        if pour['type'] not in ('POUROUT', ):
                            pos = pour['pos']
                            pour_neg = False
                            for piece in pour['pieces']:
                                if piece['type'] == 'SEG':
                                    w = piece['width']
                                    xy1, xy2 = piece['xyrs'][0][0], piece['xyrs'][1][0]
                                    delta = (xy2 - xy1) / (xy2 - xy1).getNorm() * (w / 2)
                                    a = xy1 - delta
                                    b = xy2 + delta
                                    if w > 0:
                                        shape = rectangular_shape_from_straight_path(a, b, w, True)
                                        shape = shape.to_Shape()
                                    else:
                                        continue
                                else:
                                    if piece['type'] == 'CIRCLE':
                                        assert len(piece['xyrs']) == 2
                                        xy1, xy2 = piece['xyrs'][0][0], piece['xyrs'][1][0]
                                        c = (xy2 + xy1) / 2
                                        R = ((xy2 - xy1) / 2).getNorm()
                                        shape = CircleShape(c, R)
                                        if piece['width'] > 0:
                                            conturshapes = CirclePath(c, R, piece['width'])
                                            for conshape in conturshapes:
                                                conshape.translate(pos)
                                                if conshape is not None:
                                                    res.append((conshape, piece['level'], netname, 1))

                                    else:
                                        if piece['type'] == 'POLY':
                                            remove_identical_points(piece['xyrs'])
                                            if len(piece['xyrs']) < 2:
                                                pass
                                            else:
                                                shape = PolyarcShape(piece['xyrs'])
                                                cswh = this.sp(shape, sense=1, info='coppper pour')
                                                if cswh is None:
                                                    pass
                                                elif piece['width'] > 0:
                                                    conturshapes = polyarc_path_to_polyarc_shapes(piece['xyrs'], piece['width'])
                                                    for conshape in conturshapes:
                                                        conshape.translate(pos)
                                                        if conshape is not None:
                                                            res.append((conshape, piece['level'], netname, 1))

                                        else:
                                            print('WARNING: Unknow piece type:', piece['type'])
                                            continue
                                if shape.empty():
                                    print('WARNING: Empty shape after healing (skipped)', piece)
                                else:
                                    shape.translate(pos)
                                    if shape != None:
                                        if pour['type'] == 'VOIDOUT':
                                            sense = -1
                                            if shape is not None:
                                                res.append((shape, piece['level'], netname, sense))
                                        else:
                                            sense = 1
                                            swh = ShapeWithHoles()
                                            swh.shape = shape
                                            res.append((swh, piece['level'], netname, sense))
                                        if pour['type'] in ('PADTHERM', 'VIATHERM'):
                                            if piece['level'] in list(this.thermrelief.keys()):
                                                this.thermrelief[piece['level']].append((shape, netname))
                                            else:
                                                this.thermrelief[piece['level']] = [
                                                 (
                                                  shape, netname)]

                    if 'childs' in pour:
                        childs = create_shapes((list(pour['childs'].values())), parent_netname=netname)
                        if len(res) < 1:
                            print('WARNING: Found hole without contour (SKIPPED)')
                            continue
                        parenst = res.pop()
                        assert parenst[3] == 1
                        for child in childs:
                            if not len(child) == 4:
                                raise AssertionError
                            else:
                                if child[3] == 1:
                                    res.append(child)
                                else:
                                    if child[0] is not None:
                                        parenst[0].holes.append(child[0])
                                    else:
                                        print('WARNING: found broken hole shape (SKIPPED)')

                        res.append(parenst)

            return res

        shapes = create_shapes(list(this.POUR.values()))
        debug_counter = 0
        for shape, level, netname, sense in shapes:
            layer = this.num2layer(layoutdb, level)
            shape = this.sp(shape, sense=sense, info='POUR')
            debug_counter += 1
            if shape is not None:
                if layer is None:
                    shape = shape.to_ShapeWithHoles().shape
                    if not shape.empty():
                        pos = shape.segments[0].a
                    else:
                        pos = 'unknown position'
                    print('WARNING: skipped unplaced copper pour piece near point ', pos)
                else:
                    if netname is None:
                        netname = 'NONE'
                    layoutdb.add_net_dirty(netname)
                    shape.net_index = layoutdb.net_index(netname)
                    layer.add_plane_shape(shape)

    def set_lines_copper(this, layoutdb):
        coppers = []
        copcuts = []
        for key, val in this.LINES.items():
            if val['linetype'] in ('COPPER', 'LINES'):
                pieces = val['pieces']
                tmp_coppers = []
                tmp_copcuts = []
                netname = val['net']
                if netname is None:
                    netname = 'NONE'
                layoutdb.add_net_dirty(netname)
                for piece in pieces:
                    layer = this.num2layer(layoutdb, piece['level'])
                    if layer is not None:
                        if val['linetype'] == 'COPPER':
                            if piece['typ'] in ('COPCLS', 'COPCUT'):
                                shape = PolyarcShape(piece['xyrs'])
                                if piece['typ'] == 'COPCLS':
                                    utils2d.Make_CClockwise(shape)
                                    tmp_coppers.append((shape, layer))
                                else:
                                    utils2d.Make_Clockwise(shape)
                                    tmp_copcuts.append((shape, layer))
                            else:
                                if piece['typ'] in ('COPOPN', ):
                                    xyrs = piece['xyrs']
                                    w = piece['widthhght']
                                    shapes = polyarc_path_to_polyarc_shapes(xyrs, float(w))
                                    for shape in shapes:
                                        Make_CClockwise(shape)
                                        tmp_coppers.append((shape, layer))

                                else:
                                    assert piece['typ'] in ('COPCCO', 'CIRCUR', 'COPCIR') and len(piece['xyrs']) == 2
                                    xy1, xy2 = piece['xyrs'][0][0], piece['xyrs'][1][0]
                                    c = (xy2 + xy1) / 2
                                    R = ((xy2 - xy1) / 2).getNorm()
                                    if piece['typ'] in ('COPCIR', ):
                                        shape = CircleShape(c, R)
                                        Make_CClockwise(shape)
                                        tmp_coppers.append((shape, layer))
                                    else:
                                        shape = CircleShape(c, R)
                                        Make_Clockwise(shape)
                                        tmp_copcuts.append((shape, layer))
                        else:
                            if piece['typ'] in ('OPEN', 'CLOSED'):
                                res = Xyrs2Segments(piece['xyrs'])
                                if len(res):
                                    trace = layoutdbPy.Trace()
                                    for segm in res:
                                        segm.translate(val['pos'])
                                        trace.add_segment(segm, piece['widthhght'])

                                    trace.net_index = layoutdb.net_index(netname)
                                    layer.add_trace(trace)
                            elif piece['typ'] == 'CIRCLE':
                                assert len(piece['xyrs']) == 2
                                trace = layoutdbPy.Trace()
                                xy1, xy2 = piece['xyrs'][0][0], piece['xyrs'][1][0]
                                c = (xy2 + xy1) / 2
                                R = ((xy2 - xy1) / 2).getNorm()
                                seg1 = CurveSegment(xy1, xy2, c, R)
                                seg1.translate(val['pos'])
                                seg2 = CurveSegment(xy2, xy1, c, R)
                                seg2.translate(val['pos'])
                                trace.add_segment(seg1, piece['widthhght'])
                                trace.add_segment(seg2, piece['widthhght'])
                                trace.net_index = layoutdb.net_index(netname)
                                layer.add_trace(trace)

                if val['linetype'] == 'COPPER':
                    for copshape in tmp_coppers:
                        if type(copshape[0]) == utils2dPy.ShapeWithHoles:
                            swh = copshape[0]
                        else:
                            swh = ShapeWithHoles()
                            swh.shape = copshape[0]
                        if len(tmp_copcuts) > 0:
                            if len(tmp_coppers) == 1:
                                for cutshape in tmp_copcuts:
                                    swh.holes.append(cutshape[0])

                            else:
                                print('WARNING: Unknown parents of holes in LINES copper ', key)
                            swh.translate(val['pos'])
                            cswh = this.sp(swh, sense=1, info='copper')
                            if cswh is not None:
                                cswh.net_index = layoutdb.net_index(netname)
                                layer.add_plane_shape(cswh)

    def remove_dupl_viapadstaks(this, layoutdb):
        padstmap = {}
        map = []
        for padst in this.viapadstacks:
            if padst not in map:
                map.append(padst)
            if padst.position.x not in padstmap:
                padstmap[padst.position.x] = {padst.position.y: [padst]}
            else:
                if padst.position.y not in padstmap[padst.position.x]:
                    padstmap[padst.position.x][padst.position.y] = [
                     padst]
                else:
                    padstmap[padst.position.x][padst.position.y].append(padst)

        count = 0
        deletelist = []
        for i in list(padstmap.values()):
            count += len(i)
            for j in list(i.values()):
                if len(j) > 1:
                    for padst1 in range(len(j) - 1):
                        for padst2 in range(padst1 + 1, len(j)):
                            if j[padst1].layer_from == j[padst2].layer_from:
                                if j[padst1].layer_to == j[padst2].layer_to:
                                    if j[padst1].library_padstack == j[padst2].library_padstack:
                                        if j[padst2] in this.viapadstacks:
                                            this.viapadstacks.remove(j[padst2])
                                    else:
                                        print('WARNING: These padstacks have same coordinates and layers but various lpadstacks:', j[padst1], j[padst2])

        for padst in this.viapadstacks:
            layoutdb.add_padstack(padst)


def Run(filename, importer):
    print('=' * 60)
    print('Reading MGC PADs  database ...\n')
    e = AscImport(filename, progressbar=importer)
    e.parse_asc()
    layoutdb = e.to_LayoutDB()
    print('Finished reading MGC PADs database.')
    print('=' * 60)
    if layoutdb is not None:
        importer.db = layoutdb
    return 0


def sortR2(x, y):
    if x.position.x > y.position.x:
        return 1
    else:
        if x.position.x == y.position.x:
            return 0
        return -1


if __name__ == '__main__':
    import sys
    e = AscImport(sys.argv[1])
    e.parse_asc()
    db = e.to_LayoutDB()
# okay decompiling importasc.pyc
