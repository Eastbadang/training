# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\common\utils2d.py
# Compiled at: 2018-08-27 21:46:15
# Size of source mod 2**32: 50913 bytes
import types, copy
from math import cos, sin, tan, acos, asin, atan2, pi
from utils2dPy import *
from layoutdbPy import *
from .helpers import Warnings
ACISabstol = 1e-05
angletol = 1e-09
calculationtol = 1e-10
geotol = calculationtol
modeltol = 0.001
warnings_here = Warnings()

def check_shape(shape, sense, tolerance, shape_type=''):
    try:
        if shape.empty():
            warnings_here.warn('WARNING: empty %s shape (skipped)' % shape_type)
            return
        else:
            shape.heal(tolerance)
            if shape.empty():
                warnings_here.warn('WARNING: empty %s shape after healing (skipped)' % shape_type)
                return
            tmp = shape.sense()
            if tmp == 0:
                shape.heal(tolerance)
                tmp = shape.sense()
            if tmp == 0:
                warnings_here.warn('WARNING: skipped %s because it is not orientable' % shape_type)
                return
            if tmp != sense:
                shape.reverse()
            if isinstance(shape, ShapeWithHoles):
                for i in range(len(shape.holes)):
                    h = shape.holes[i]
                    s = h.sense()
                    if s != 0 and s == sense:
                        h.reverse()

        return shape
    except:
        warnings_here.warn('WARNING: skipped %s  shape' % shape_type)
        return


def R2str(r2):
    return '(%1.16e %1.16e)' % (r2.x, r2.y)


def PolyarcShape(xyrs):
    ensure_closed_xyr(xyrs)
    segs = Xyrs2Segments(xyrs)
    return Shape(segs)


def Xyrs2Segments(xyrs):
    remove_identical_points(xyrs)
    assert xyrs[0][1] == 0
    segs = ArrayCurveSegment(0)
    for i in range(len(xyrs) - 1):
        x0, R0 = xyrs[i]
        if R0 != 0:
            continue
        x1, R1 = xyrs[(i + 1)]
        if R1 == 0:
            segs.push_back(CurveSegment(x0, x1))
        else:
            x2, R2 = xyrs[(i + 2)]
            a, b, c = x0, x2, x1
            assert R2 == 0
            R = -R1
            if a != b:
                seg = CurveSegment(a, b, c, R)
                if abs(seg.phi) > 3.1:
                    m = seg.point(0.5)
                    c = seg.c
                    seg = CurveSegment(a, m, c, R)
                    segs.push_back(seg)
                    assert abs(seg.phi) < 3.15
                    seg = CurveSegment(m, b, c, R)
                    segs.push_back(seg)
                    assert abs(seg.phi) < 3.15
                else:
                    segs.push_back(seg)
            else:
                m = c - a + c
                seg = CurveSegment(a, m, c, R)
                segs.push_back(seg)
                seg = CurveSegment(m, a, c, R)
                segs.push_back(seg)

    return segs


def PolylineShape(xys):
    ensure_closed_xy(xys)
    remove_identical_points2(xys)
    segs = ArrayCurveSegment(0)
    last_xy = None
    for xy in xys:
        if last_xy is not None:
            segs.push_back(CurveSegment(last_xy, xy))
        last_xy = xy

    return Shape(segs)


def CirclePath(c, R, w):
    if w == 0:
        return [CircleShape(c, R)]
    else:
        w2 = w * 0.5
        R = abs(R)
        if w2 > R - ACISabstol:
            return [
             CircleShape(c, R + w2)]
        n0, n1 = R2(R - w2, 0), R2(R + w2, 0)
        n2, n3 = R2(0, R - w2), R2(0, R + w2)
        xyrs = [
         (
          c + n0, 0), (c, R - w2), (c + n2, 0), (c + n3, 0), (c, -(R + w2)), (c + n1, 0), (c + n0, 0)]
        res = [PolyarcShape(xyrs)]
        xyrs = [
         (
          c - n0, 0), (c - n1, 0), (c, R + w2), (c - n3, 0), (c - n2, 0), (c, -(R - w2)), (c - n0, 0)]
        res.append(PolyarcShape(xyrs))
        return res


def CircleShape(c, R):
    assert R != 0
    n = R2(R, 0)
    xyrs = [(c + n, 0), (c, R), (c - n, 0), (c, R), (c + n, 0)]
    return PolyarcShape(xyrs)


def Rectangle(w, h, origin=None):
    w = R2(w, 0)
    h = R2(0, h)
    o = R2(0, 0)
    xys = [o, w, w + h, h]
    res = PolylineShape(xys)
    if origin is not None:
        res.translate(origin)
    return res


def RectangleC(w, h, origin=None):
    w = R2(w * 0.5, 0)
    h = R2(0, h * 0.5)
    xys = [w + h, w - h, -w - h, -w + h]
    res = PolylineShape(xys)
    if origin is not None:
        res.translate(origin)
    return res


def Bbox2Rectangle(bbox):
    return RectangleC((bbox.xmax - bbox.xmin), (bbox.ymax - bbox.ymin), origin=(R2(0.5 * (bbox.xmax + bbox.xmin), 0.5 * (bbox.ymax + bbox.ymin))))


def RectPathC(width, height, w):
    w2 = w * 0.5
    dx, dX = R2(width * 0.5 - w2, 0), R2(width * 0.5 + w2, 0)
    dy, dY = R2(0, height * 0.5 - w2), R2(0, height * 0.5 + w2)
    return [PolylineShape([-dx + dy, dX + dy, dX + dY, -dX + dY, -dX - dY, dX - dY, dX - dy, -dx - dy]),
     PolylineShape([dx - dy, dX - dy, dX + dy, dx + dy])]


def RectPath(a, b, w):
    xmin, xmax = min(a.x, b.x), max(a.x, b.x)
    ymin, ymax = min(a.y, b.y), max(a.y, b.y)
    if w == 0:
        return [
         Rectangle((xmax - xmin), (ymax - ymin), origin=(R2(xmin, ymin)))]
    else:
        res = RectPathC(xmax - xmin, ymax - ymin, w)
        dx = R2(xmax + xmin, ymax + ymin)
        dx *= 0.5
        for r in res:
            r.translate(dx)

        return res


def Make_CClockwise(shape):
    s = shape.sense()
    if s == -1:
        shape.reverse()
    elif s == 0:
        return False
    return True


make_pos_sense = Make_CClockwise

def Make_Clockwise(shape):
    s = shape.sense()
    if s == 1:
        shape.reverse()
    elif s == 0:
        return False
    return True


make_neg_sense = Make_Clockwise

def segment2shape(seg, w, tol=0, roundcaps=True):
    assert w > 0
    return thicken_curvesegment(seg, w, True, tol, roundcaps)


from math import pi, cos, sin
phis = [
 0, 0.2, 0.4, 0.6, 0.8, 1, 1.2, 1.4, 1.6, 1.8, 2, 2.2, 2.4, 2.6, 2.8, 3, 3.2, 3.4, 3.6, 3.8, 4, 4.2, 4.4, 4.6, 4.8, 5, 5.2, 5.4, 5.6, 5.8, 6, 6.2]
unitcircle = [(cos(phi), sin(phi)) for phi in phis]
unitcircleR2 = [R2(x, y) for x, y in unitcircle]

def get_XYR_single_segment2(p0, p1, w, rounded=True):
    from math import sin, tan, asin
    w *= 0.5
    t = p1 - p0
    assert t.getNorm() > 1e-11
    t /= t.getNorm()
    n = R2(t.y, -t.x)
    n *= w
    if rounded:
        return [(p0 + n, 0), (p0, w), (p0 - n, 0), (p1 - n, 0), (p1, w), (p1 + n, 0)]
    else:
        return [
         (
          p0 + n, 0), (p0 - n, 0), (p1 - n, 0), (p1 + n, 0)]


def straight_path_segment_to_XYR(p0, p1, w, roundcaps=True):
    from math import sin, tan, asin
    w *= 0.5
    t = p1 - p0
    if t.getNorm2() == 0:
        assert w != 0
        R = w / 2
        n = R2(R, 0)
        c = p0
        return [
         (
          c + n, 0), (c, R), (c - n, 0), (c, R), (c + n, 0)]
    else:
        t /= t.getNorm()
        n = R2(t.y, -t.x)
        n *= w
        if roundcaps:
            res = [
             (
              p0 + n, 0), (p0, w), (p0 - n, 0), (p1 - n, 0), (p1, w), (p1 + n, 0), (p0 + n, 0)]
        else:
            res = [
             (
              p0 + n, 0), (p0 - n, 0), (p1 - n, 0), (p1 + n, 0), (p0 + n, 0)]
        return res


def curved_path_segment_to_XYR(a, b, c, R, w, tol):
    from math import atan2, sqrt, pi
    assert R != 0
    w2 = w * 0.5
    sector = abs(abs(R) - w2) < tol
    iscircle = is_circle(a, b, c, R)
    if not iscircle:
        if a == b:
            return
    if w2 > abs(R) + tol * abs(R):
        if iscircle:
            n = a - c
            n /= n.getNorm()
            a2 = c + n * (abs(R) + w2)
            a3 = c - n * (abs(R) + w2)
            if R > 0:
                Rb = R + w2
            else:
                Rb = R - w2
            return [(a2, 0), (c, Rb), (a3, 0), (c, Rb), (a2, 0)]
        else:
            ab = b - a
            ab2 = ab.getNorm()
            ab /= ab2
            ab2 /= 2
            y = sqrt(w2 * w2 - ab2 * ab2)
            n = ab * 1
            n.turn_right()
            if R > 0:
                z = a + ab * ab2 + n * y
            else:
                z = a + ab * ab2 - n * y
            ca = a - c
            ca /= ca.getNorm()
            cb = b - c
            cb /= cb.getNorm()
            if R > 0:
                return [(z, 0), (a, w2), (a + ca * w2, 0), (c, R + w2), (b + cb * w2, 0), (b, w2), (z, 0)]
            return [
             (
              z, 0), (b, w2), (b + cb * w2, 0), (c, -R + w2), (a + ca * w2, 0), (a, w2), (z, 0)]
    dab = (b - a).getNorm()
    if dab < 0.001 * abs(R):
        if not sector:
            c = a + b
            c *= 0.5
            R = w * 0.5
            n = R2(R, 0)
            return [
             (
              c + n, 0), (c, R), (c - n, 0), (c, R), (c + n, 0)]
    na = a - c
    na /= na.getNorm()
    nb = b - c
    nb /= nb.getNorm()
    phi = atan2(na.cross(nb), na.dot(nb))
    if phi < 0:
        phi += 2 * pi
    else:
        if R > 0:
            phi -= 2 * pi
        if abs(phi) > pi:
            if dab <= w:
                if sector:
                    y = yy = sqrt(4 * R * R - dab * dab)
                    tmp = b - a
                    n = R2(tmp.y, -tmp.x)
                    n /= n.getNorm()
                    if R < 0:
                        n *= -1
                    y = c + n * y
                    na *= w2
                    nb *= w2
                    if R < 0:
                        return [(y, 0), (a, -w2), (a + na, 0), (c, R - w2), (b + nb, 0), (b, -w2), (y, 0)]
                    else:
                        return [
                         (
                          y, 0), (a, w2), (a + na, 0), (c, R + w2), (b + nb, 0), (b, w2), (y, 0)]
                else:
                    tmp = CurveSegment(a, b, c, -R)
                    m = tmp.point(0.5)
                    c = tmp.c
                    return [
                     curved_path_segment_to_XYR(a, m, c, R, w, tol), curved_path_segment_to_XYR(m, b, c, R, w, tol)]
        na *= w2
        nb *= w2
        Rmin = abs(R) - w2
        if R < 0:
            if sector or Rmin < tol:
                return [(a + na, 0), (a, w2), (a - na, 0), (b, w2), (b + nb, 0), (c, -R + w2), (a + na, 0)]
            else:
                return [
                 (
                  a + na, 0), (a, w2), (a - na, 0), (c, -Rmin), (b - nb, 0), (b, w2), (b + nb, 0), (c, -R + w2), (a + na, 0)]
        else:
            if sector or Rmin < tol:
                return [(a - na, 0), (a, w2), (a + na, 0), (c, R + w2), (b + nb, 0), (b, w2), (a - na, 0)]
            else:
                return [
                 (
                  a - na, 0), (a, w2), (a + na, 0), (c, R + w2), (b + nb, 0), (b, w2), (b - nb, 0), (c, -Rmin), (a - na, 0)]


def contains_arcs(xyrs):
    for xy, r in xyrs:
        if r != 0:
            return True

    return False


def polyline_path_to_shapes(xys, w, roundcaps=True, separate_segments=True):
    """ Convert a Mentor polylinepath to a shapes"""
    if separate_segments:
        xyrss = [straight_path_segment_to_XYR((xys[i]), (xys[(i + 1)]), w, roundcaps=roundcaps) for i in range(len(xys) - 1)]
    else:
        xyrss = polyline_path_to_xyrs2(xys, w, roundcaps=roundcaps)
    shapes = []
    for xyrs in xyrss:
        if contains_arcs(xyrs):
            shapes.append(PolyarcShape(xyrs))
        else:
            shapes.append(PolylineShape([xy for xy, r in xyrs]))

    return shapes


def polyline_path_to_xyrs(xys, w, roundcaps=True, separate_segments=True):
    """ Convert a Mentor polylinepath to a closed XYR representation."""
    if separate_segments:
        return [straight_path_segment_to_XYR((xys[i]), (xys[(i + 1)]), w, roundcaps=roundcaps) for i in range(len(xys) - 1)]
    else:
        return polyline_path_to_xyrs2(xys, w, roundcaps=roundcaps)


def polyline_path_to_xyrs2(xys, w, roundcaps=True):
    """ Convert a Mentor polylinepath to a closed XYR representation."""
    w2 = w * 0.5
    if xys[0] == xys[(-1)]:
        return [
         polyline_path_to_xyrs((xys[:-1]), w, roundcaps=roundcaps),
         polyline_path_to_xyrs((xys[-2:]), w, roundcaps=roundcaps)]
    else:
        if not type(xys) == types.ListType:
            raise AssertionError
        else:
            if not len(xys) >= 2:
                raise AssertionError
            else:
                segs = [(xys[i], xys[(i + 1)], tandnl(xys[i], xys[(i + 1)])) for i in range(0, len(xys) - 1)]
                p0, p1, (t, n, l) = segs[0]
                if roundcaps:
                    res = [
                     (
                      p0 + n * w2, 0), (p0, w2), (p0 - n * w2, 0)]
                else:
                    res = [
                     (
                      p0 + n * w2, 0), (p0 - n * w2, 0)]
            lastpoint = res[(-1)][0]
            for i in range(0, len(segs) - 1):
                p0, p1, (t0, n0, l0) = segs[i]
                p1, p2, (t1, n1, l1) = segs[(i + 1)]
                sinphi = t0.cross(t1)
                if sinphi > 0:
                    d = w2 * tan(asin(sinphi) / 2)
                    assert d >= 0
                    pnew = p1 - n0 * w2 - t0 * d
                    if d > l0:
                        print('WARNING: Strange segment in Polylinepath', xys, w)
                        lastpoint.x, lastpoint.y = pnew.x, pnew.y
                        return []
                    res.append((pnew, 0))
                else:
                    res.extend([(p1 - n0 * w2, 0), (p1, w2), (p1 - n1 * w2, 0)])
                lastpoint = res[(-1)][0]

            p0, p1, (t, n, l) = segs[(-1)]
            if roundcaps:
                res.extend([(p1 - n * w2, 0), (p1, w2), (p1 + n * w2, 0)])
            else:
                res.extend([(p1 - n * w2, 0), (p1 + n * w2, 0)])
        lastpoint = res[(-1)][0]
        for i in range(len(segs) - 1, 0, -1):
            p1, p0, (t0, n0, l0) = segs[i]
            p2, p1, (t1, n1, l1) = segs[(i - 1)]
            sinphi = t0.cross(t1)
            if sinphi > 0:
                d = w2 * tan(asin(sinphi) / 2)
                assert d >= 0
                pnew = p1 + n0 * w2 + t0 * d
                if d > l0:
                    print('WARNING: Strange segment in Polylinepath', xys, w)
                    lastpoint.x, lastpoint.y = pnew.x, pnew.y
                    return []
                res.append((pnew, 0))
            else:
                res.extend([(p1 + n0 * w2, 0), (p1, w2), (p1 + n1 * w2, 0)])
            lastpoint = res[(-1)][0]

        res.append(res[0])
        return [res]


def correct_arc_centers(xyrs):
    from math import sqrt
    for i in range(1, len(xyrs) - 1):
        c, R = xyrs[i]
        if R == 0:
            continue
        a, Ra = xyrs[(i - 1)]
        b, Rb = xyrs[(i + 1)]
        assert Ra == 0 and Rb == 0
        Ra = (a - c).getNorm()
        Rb = (b - c).getNorm()
        dRa = Ra - abs(R)
        dRb = Rb - abs(R)
        if abs(dRa) < calculationtol * abs(R):
            if abs(dRb) < calculationtol * abs(R):
                continue
        if a == b:
            b = a * 1
            d = c - a
            d *= abs(R) / Ra
            cnew = a + d
            xyrs[i] = (cnew, R)
            assert (cnew - c).getNorm() < 0.01 * abs(R)
            xyrs[i + 1] = (b, 0)
        else:
            ab = b - a
            ababs = ab.getNorm()
            y = sqrt(abs(R * R - ababs * ababs * 0.25))
            n = R2(-ab.y, ab.x)
            n *= y / ababs
            c1 = a + ab * 0.5 + n
            c2 = a + ab * 0.5 - n
            dc1 = (c1 - c).getNorm()
            dc2 = (c2 - c).getNorm()
            if dc1 < dc2:
                cnew = c1
            else:
                cnew = c2
            xyrs[i] = (
             cnew, R)


def correct_arc_center(a, b, c, R):
    from math import sqrt
    if R == 0:
        return c
    else:
        absR = abs(R)
        Ra = (a - c).getNorm()
        Rb = (b - c).getNorm()
        dRa = Ra - absR
        dRb = Rb - absR
        if abs(dRa) < calculationtol * abs(R):
            if abs(dRb) < calculationtol * abs(R):
                return c
        if (b - a).getNorm() < calculationtol:
            d = c - a
            d *= absR / Ra
            cnew = a + d
            return cnew
        ab = b - a
        ababs = ab.getNorm()
        y = sqrt(abs(R * R - ababs * ababs * 0.25))
        n = R2(-ab.y, ab.x)
        n *= y / ababs
        c1 = a + ab * 0.5 + n
        c2 = a + ab * 0.5 - n
        dc1 = (c1 - c).getNorm()
        dc2 = (c2 - c).getNorm()
        if dc1 < dc2:
            cnew = c1
        else:
            cnew = c2
        return cnew


def remove_col_edges(xyrs):
    rem = []
    for i in range(1, len(xyrs) - 1):
        pa, ra = xyrs[(i - 1)]
        p, r = xyrs[i]
        pb, rb = xyrs[(i + 1)]
        if not ra != 0:
            if r != 0 or rb != 0:
                pass
            else:
                t0 = p - pa
                t0 /= t0.getNorm()
                t1 = pb - p
                t1 /= t1.getNorm()
                if abs(t0.cross(t1)) < 0.001:
                    rem.append(i)

    rem.reverse()
    for r in rem:
        del xyrs[r]


def remove_identical_points(xyrs, tol=0):
    rem = []
    for i in range(0, len(xyrs) - 1):
        pa, ra = xyrs[i]
        pb, rb = xyrs[(i + 1)]
        if not ra != 0:
            if rb != 0:
                pass
            elif (pa - pb).getNorm() <= tol:
                rem.append(i)

    rem.reverse()
    for i in rem:
        del xyrs[i]


def remove_identical_points2(xys, tol=0):
    rem = []
    for i in range(0, len(xys) - 1):
        pa = xys[i]
        pb = xys[(i + 1)]
        if (pa - pb).getNorm() <= tol:
            rem.append(i)

    rem.reverse()
    for i in rem:
        del xys[i]


def ensure_closed_shape(key, val):
    if key == 'POLYARC_SHAPE':
        xyrs = val.XYR
        xyrs.append(xyrs[0])
    elif key == 'POLYLINE_SHAPE':
        xys = val.XY
        xys.append(xys[0])


def ensure_closed_xyr(xyrs):
    remove_identical_points(xyrs)
    xyrs.append((xyrs[0][0] * 1, xyrs[0][1]))


def ensure_closed_xy(xys):
    remove_identical_points2(xys)
    if (xys[0] - xys[(-1)]).getNorm2() == 0:
        return
    xys.append(xys[0] * 1)


def write_xyr(file, xyrs):
    remove_col_edges(xyrs)
    correct_arc_centers(xyrs)
    file.write('%d (' % len(xyrs))
    for i in range(0, len(xyrs) - 1):
        p, r = xyrs[i]
        file.write('(%1.16e %1.16e %1.16e) ' % (p.x, p.y, r))

    p, r = xyrs[(-1)]
    file.write('(%1.16e %1.16e %1.16e))\n' % (p.x, p.y, r))


def xyr_2_xyb(xyrs):
    from math import atan2, tan
    remove_col_edges(xyrs)
    correct_arc_centers(xyrs)
    res = []
    if not (xyrs[0][0] - xyrs[(-1)][0]).getNorm() < ACISabstol:
        raise AssertionError
    elif not (xyrs[0][1] == 0 and xyrs[(-1)][1] == 0):
        raise AssertionError
    xyrs[-1] = xyrs[0]
    for i in range(0, len(xyrs) - 1):
        a, r = xyrs[i]
        if r != 0:
            continue
        b, r = xyrs[(i + 1)]
        if r == 0:
            res.append((a, 0))
        else:
            c, R = b, r
            b = xyrs[(i + 2)][0]
            if (a - b).getNorm() < ACISabstol:
                print('xyr_2_xyb: full circle encountered!')
                b2 = a + (c - a) * 2
                phi = arcphi(a, b2, c, R)
                bulge = tan(phi / 4)
                assert abs(bulge) < 100000.0
                res.append((a, bulge))
                a = b2
            phi = arcphi(a, b, c, R)
            bulge = tan(phi / 4)
            assert abs(bulge) < 100000.0
            res.append((a, bulge))

    return res


def xyb_2_xyr(xybs):
    from math import atan, tan, pi
    xybs.append(xybs[0])
    segs = []
    for i in range(0, len(xybs) - 1):
        x, y, bulge = xybs[i]
        a = R2(x, y)
        x, y, tmp = xybs[(i + 1)]
        b = R2(x, y)
        if bulge == 0:
            segs.append(((a, 0), (b, 0)))
        else:
            phi = 4 * atan(bulge)
            assert phi > -2 * pi and phi < 2 * pi
            h = b - a
            h *= 0.5
            h2 = h.getNorm()
            y = h2 / tan(phi / 2)
            yy = R2(-h.y, h.x)
            yy /= yy.getNorm()
            c = a + h + yy * y
            R = (a - c).getNorm()
            assert abs((b - c).getNorm() - R) < R * 1e-05
            if phi > 0:
                R *= -1
            segs.append(((a, 0), (c, R), (b, 0)))

    res = []
    for seg in segs:
        res.append(seg[0])
        if len(seg) > 2:
            res.append(seg[1])

    res.append((res[0][0], 0))
    return res


def write_xyb(file, xybs):
    file.write('%d (' % len(xybs))
    for p, b in xybs[:-1]:
        file.write('(%1.16e %1.16e %1.16e) ' % (p.x, p.y, b))

    p, b = xybs[(-1)]
    file.write('(%1.16e %1.16e %1.16e))\n' % (p.x, p.y, b))


def convert_to_circle_shape(key, val):
    if key != 'POLYARC_SHAPE':
        return (
         key, val)
    else:
        if not is_circle_shape(val.XYR):
            return (
             key, val)
        elif not 0:
            raise AssertionError
        C = Dummy3()
        C.SHAPE_OPTIONS = val.SHAPE_OPTIONS
        c, R = val.XYR[1]
        C.RADIUS = abs(R)
        C.XY = c
        return ('CIRCLE_SHAPE', C)


def is_circle_shape(xyrs):
    if len(xyrs) != 3:
        return False
    else:
        a, ra = xyrs[0]
        c, r = xyrs[1]
        b, rb = xyrs[2]
        return is_circle(a, b, c, r)


def is_circle(a, b, c, r, tol=calculationtol * 10):
    if r == 0:
        return False
    else:
        if b != a:
            return False
        else:
            if (b - a).getNorm2() == 0:
                return True
            ca, cb = a - c, b - c
            angle = atan2(ca.cross(cb), ca.dot(cb))
            if r > 0:
                return angle >= angletol
        return angle <= -angletol


def write_shape(file, key, val, material, name, elevation, thickness):
    if key == 'POLYARC_SHAPE':
        file.write('308!%s!%s!%1.16e!%1.16e!' % (material, name, thickness, elevation))
        write_xyb(file, xyr_2_xyb(val.XYR))
    else:
        if key == 'POLYLINE_SHAPE':
            ensure_closed_shape(key, val)
            xyrs = [(p, 0) for p in val.XY]
            file.write('308!%s!%s!%1.16e!%1.16e!' % (material, name, thickness, elevation))
            write_xyb(file, xyr_2_xyb(xyrs))
        else:
            if key == 'POLYLINE_PATH':
                CHECK.ME
                xyrs = polyline_path_to_xyrs(val.XY, val.WIDTH)
                file.write('308!%s!%s!%1.16e!%1.16e!' % (material, name, thickness, elevation))
                write_xyb(file, xyr_2_xyb(xyrs))
            else:
                if key == 'CIRCLE_SHAPE':
                    file.write('112!%s!%s!%1.16e!%1.16e!%1.16e!%1.16e %s\n' % (material, name, elevation, thickness + elevation,
                     val.RADIUS, 0.0, R2str(val.XY)))
                else:
                    print('write_shape: not covered:', key, material, name)
                    return False
    return True


def polyarc_path_to_polyarc_shapes(xyrs, w, roundcaps=True):
    if 0 and xyrs[0][0] == xyrs[(-1)][0]:
        print('Ignoring closed polyarc path:', xyrs)
        return []
    else:
        correct_arc_centers(xyrs)
        res = []
        for i in range(0, len(xyrs) - 1):
            p0, r0 = xyrs[i]
            if r0 != 0:
                continue
            p1, R = xyrs[(i + 1)]
            if R == 0:
                xyrs1 = straight_path_segment_to_XYR(p0, p1, w)
                if xyrs1 is not None:
                    res.append(PolyarcShape(xyrs=xyrs1))
                    res[(-1)].info = (p0, p1, w)
            else:
                p2, r2 = xyrs[(i + 2)]
                assert r2 == 0
                if is_circle(p0, p2, p1, R):
                    res.extend(CirclePath(p1, R, w))
                else:
                    seg = CurveSegment(p0, p2, p1, -R)
                    csh = thicken_curvesegment(seg, w, True, 0.001, roundcaps)
                    res.append(csh.to_ShapeWithHoles())

        return res


def separate_inner_circles(xyrs):
    res = []
    cutouts = []
    for i in range(0, len(xyrs) - 1):
        c, R = xyrs[i]
        if R == 0:
            continue
        a, b = xyrs[(i - 1)][0], xyrs[(i + 1)][0]
        if is_circle(a, b, c, R):
            res.append(Circle(c * 1, abs(R), R < 0))
            cutouts.append(i)

    cutouts.reverse()
    for i in cutouts:
        del xyrs[i:i + 2]

    return res


def compress_shape(shape, tol=0.0):
    if isinstance(shape, Shape):
        shape.make_arcs_less_than_pi()
        return CShape(shape, tol)
    else:
        if isinstance(shape, ShapeWithHoles):
            shape.make_arcs_less_than_pi()
            return CShapeWithHoles(shape, tol)
        return shape


def make_compressed_swh(shape, tol=0.0):
    shape = compress_shape(shape, tol)
    if isinstance(shape, CShape):
        shape = CShapeWithHoles(shape)
    return shape


class ShapeProcessor:

    def __init__(this, tol):
        this.tolerance = tol
        this.bad_shapes = []

    def check_shape(this, shape, sense, shape_type=''):
        if shape.empty():
            warnings_here.warn('empty %s shape (skipped)' % shape_type)
            return
        else:
            heal_success, heal_errors = shape.heal_and_report_errors(this.tolerance)
            if len(heal_errors) > 0:
                warnings_here.warn(heal_errors)
            if shape.empty():
                warnings_here.warn('empty %s shape after healing (skipped)' % shape_type)
                return
            tmp = shape.sense()
            if tmp == 0:
                shape.heal(this.tolerance)
                tmp = shape.sense()
            if tmp == 0:
                warnings_here.warn('skipped %s because it is not orientable' % shape_type)
                return
            if tmp != sense:
                shape.reverse()
            if isinstance(shape, ShapeWithHoles):
                for i in range(len(shape.holes)):
                    h = shape.holes[i]
                    s = h.sense()
                    if s != 0 and s == sense:
                        h.reverse()

            return shape

    def __call__(this, shape, sense=None, info=None, layer=None):
        if isinstance(shape, Shape):
            try:
                shape = aps2swh(shape, this.tolerance)
            except:
                try:
                    heal_success, heal_errors = shape.heal_and_report_errors(this.tolerance)
                    if len(heal_errors) > 0:
                        warnings_here.warn(heal_errors)
                    s = CShapeWithHoles()
                    s.shape = CShape(shape, this.tolerance)
                    if not a_good_shape(s, this.tolerance):
                        return
                    shape = s.to_ShapeWithHoles()
                except:
                    return

        else:
            if isinstance(shape, ShapeWithHoles):
                try:
                    s = aps2swh(shape.shape, this.tolerance)
                    for i in range(len(shape.holes)):
                        h = shape.holes[i]
                        s.holes.push_back(h)

                    shape = s
                except:
                    try:
                        heal_success, heal_errors = shape.heal_and_report_errors(this.tolerance)
                        if len(heal_errors) > 0:
                            warnings_here.warn(heal_errors)
                        s = CShapeWithHoles(shape, this.tolerance)
                        if not a_good_shape(s, this.tolerance):
                            return
                        shape = s.to_ShapeWithHoles()
                    except:
                        return

            if isinstance(shape, ShapeWithHoles):
                if sense is None:
                    sense = 1
                shape = this.check_shape(shape, sense, info)
                if shape is None:
                    return
            shape = compress_shape(shape, this.tolerance)
            if isinstance(shape, CShape):
                shape = CShapeWithHoles(shape)
            return shape


def decompress_shape(shape):
    if isinstance(shape, CShape):
        return shape.to_Shape()
    else:
        if isinstance(shape, CShapeWithHoles):
            return shape.to_ShapeWithHoles()
        return shape


def shape_write(shape, file, material, name, thickness, elevation, ok=1):
    if not (shape.segments[0].a - shape.segments[(len(shape.segments) - 1)].b).getNorm2() == 0:
        raise AssertionError
    else:
        if shape.contains_arcs():
            if shape.aux_int:
                tmp1, tmp2 = R2(), R2()
                assert shape.is_circle(1000000.0, tmp1, tmp2)
                pos, r, o = tmp1, tmp2.x, tmp2.y
                cylinder_write(file, material, name, pos, r, 0.0, thickness, elevation)
                return True
            else:
                file.write('308!%s!%s!%1.16e!%1.16e!' % (material, name, thickness, elevation))
                xybs = [(seg.a, seg.compute_bulge()) for seg in shape.segments]
                write_xyb(file, xybs)
                return True
        else:
            xys = [seg.a for seg in shape.segments]
            ensure_closed_xy(xys)
            file.write('107!%s!%s!%1.16e!%1.16e!' % (material, name, thickness, elevation))
            file.write('%d (' % len(xys))
            for xy in xys[:-1]:
                file.write('%s ' % R2str(xy))

            file.write('%s)\n' % R2str(xys[(-1)]))
            return True


def plane_wire_write(shape, file, layer, planename):
    if shape.aux_int:
        tmp1, tmp2 = R2(), R2()
        assert shape.is_circle(1000000.0, tmp1, tmp2)
        pos, r, o = tmp1, tmp2.x, tmp2.y
        file.write('402!%s!%s!%1.16e!%1.16e!%1.16e!%d\n' % (layer, planename, pos.x, pos.y, r, int(o)))
    else:
        file.write('401!%s!%s!' % (layer, planename))
        shape.make_arcs_less_than(5.5)
        write_xyb(file, [(seg.a, seg.compute_bulge()) for seg in shape.segments])


def plane_finish(file, layer, planename, thickness, elevation):
    file.write('408!%s!%s!%1.16e!%1.16e\n' % (layer, planename, thickness, elevation))


def shape_with_holes_write(swh, file, layer, planename, thickness, elevation, finish_plane=True, only_finish_plane=False):
    if swh.empty():
        return
    if len(swh.holes) == 0:
        shape_write(swh.shape, file, layer, planename, thickness, elevation)
    else:
        if not only_finish_plane:
            plane_wire_write(swh.shape, file, layer, planename)
            for hole in swh.holes:
                if hole.is_via_hole:
                    pass
                else:
                    plane_wire_write(hole, file, layer, planename)

    if finish_plane or only_finish_plane:
        plane_finish(file, layer, planename, thickness, elevation)


def shape_with_holes_write_single(shape, file, layer, name, thickness, elevation):
    assert shape.sense() == 1
    plane_wire_write(shape, file, layer, name)
    file.write('408!%s!%s!%1.16e!%1.16e\n' % (layer, name, thickness, elevation))


def shape_with_holes_write_with_boolean(swh, file, layer, planename, thickness, elevation):
    counter = 0
    shape_with_holes_write_single(swh.shape, file, layer, planename, thickness, elevation)
    for hole in swh.holes:
        name = '%s:%d' % (planename, counter)
        counter += 1
        assert hole.sense() == -1
        hole.reverse()
        shape_with_holes_write_single(hole, file, layer, name, thickness, elevation)
        file.write('109!%s!%s!%s\n' % (layer, planename, name))


def cylinder_write(file, layername, bodyname, pos, r_max, r_min, thickness, elevation):
    file.write('112!%s!%s!%1.16e!%1.16e!%1.16e!%1.16e %s\n' % (layername, bodyname,
     elevation, elevation + thickness, r_max, r_min, R2str(pos)))


def rect_cylinder_write(file, layername, bodyname, pos, r_max, r_min, thickness, elevation):
    file.write('112!%s!%s!%1.16e!%1.16e!%1.16e!%1.16e %s\n' % (layername, bodyname,
     elevation, elevation + thickness, r_max, r_min, R2str(pos)))
    if r_min != 0:
        print("WARNING: 'r_min' ignored in writing rect cylinder")
    shape = RectangleC((2 * r_max), (2 * r_max), origin=pos)
    shape_write(shape, file, layername, bodyname, thickness, elevation)
# okay decompiling utils2d.pyc
