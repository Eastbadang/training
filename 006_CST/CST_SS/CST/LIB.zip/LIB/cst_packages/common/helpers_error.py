# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\common\helpers.py
# Compiled at: 2019-03-29 17:58:27
# Size of source mod 2**32: 10799 bytes
Instruction context:
-> 
 L. 103         4  DUP_TOP          
                   6  LOAD_GLOBAL              UnicodeDecodeError
                   8  COMPARE_OP               exception-match
                  10  POP_JUMP_IF_FALSE    22  'to 22'
                  12  POP_TOP          
                  14  POP_TOP          
                  16  POP_TOP          
import types, os, sys, re, math

def splitfull(path):
    res = []
    while True:
        xpath


class FileFromStringList:

    def __init__(this, ss):
        this.ss = ss
        this.i = 0
        this.n = len(ss)

    def readline(this):
        if this.i >= len(this.ss):
            return ''
        else:
            l = this.ss[this.i]
            this.i += 1
            return l + '\n'


def get_cst_install_path(version):
    if sys.platform.startswith('win'):
        from winreg import OpenKey, EnumValue, ConnectRegistry, HKEY_LOCAL_MACHINE
        version = str(version)
        if version not in ('2008', '2009', '2010', '2011'):
            return ''
        is_ag = version not in ('2008', '2009')
        aReg = ConnectRegistry(None, HKEY_LOCAL_MACHINE)
        if is_ag:
            aKey = OpenKey(aReg, 'SOFTWARE\\CST AG\\CST DESIGN ENVIRONMENT' + '\\' + str(version))
        else:
            aKey = OpenKey(aReg, 'SOFTWARE\\CST GmbH\\CST DESIGN ENVIRONMENT' + '\\' + str(version))
        tmp = {}
        for i in range(10000):
            try:
                x = EnumValue(aKey, i)
                if x[0] == 'INSTALLPATH':
                    return str(x[1])
            except:
                break

    else:
        if len(sys.argv) == 0:
            return ''
        exepath = sys.argv[0]
        path, exe = os.path.split(exepath)
        if 'pcbimport' not in exe:
            return ''
        path, pcb = os.path.split(path)
    if pcb != 'pcb':
        return ''
    else:
        path, imports = os.path.split(path)
        if imports != 'Imports':
            return ''
        else:
            return path
        return ''


def mwsname(name):
    if name is None:
        return 'None'
    else:
        translate = {'$':'S', 
         '[':'(',  ']':')',  ':':'.',  ',':';',  '|':';',  '*':'x',  '/':'-',  '\\':'-',  '~':'-',  '"':"'",  '^':'-',  '#':'+'}
        for old, new in translate.items():
            name = name.replace(old, new)

        return name


def mwsunit(unit):
    if unit == 'inch':
        return 'in'
    else:
        return unit.lower()


mu = (b'\xc2\xb5').decode('utf-8')
magtrans = {'f': 1e-15, 'F': 1e-15, 
 'p': 1e-12, 'P': 1e-12, 
 'n': 1e-09, 'N': 1e-09, 
 'u': 1e-06, 'U': 1e-06, mu: 1e-06, 
 'm': 0.001, 
 'k': 1000.0, 'K': 1000.0, 
 'M': 1000000.0, 
 'G': 1000000000.0}

def float_with_unit(s):
    if s[(-1)] in magtrans:
        return float(s[:-1]) * magtrans[s[(-1)]]
    else:
        return float(s)


def is_ascii--- This code section failed: ---

 L.  97         0  LOAD_CONST               True
                2  RETURN_VALUE     

 L. 103         4  DUP_TOP          
                6  LOAD_GLOBAL              UnicodeDecodeError
                8  COMPARE_OP               exception-match
               10  POP_JUMP_IF_FALSE    22  'to 22'
               12  POP_TOP          
               14  POP_TOP          
               16  POP_TOP          

 L. 105        18  LOAD_CONST               False
               20  RETURN_VALUE     
             22_0  COME_FROM            10  '10'
               22  END_FINALLY      
               24  POP_BLOCK        
               26  JUMP_FORWARD         56  'to 56'

 L. 106        28  DUP_TOP          
               30  LOAD_GLOBAL              LookupError
               32  COMPARE_OP               exception-match
               34  POP_JUMP_IF_FALSE    54  'to 54'
               36  POP_TOP          
               38  POP_TOP          
               40  POP_TOP          

 L. 107        42  LOAD_GLOBAL              print
               44  LOAD_STR                 'WARNING: Lookup error'
               46  CALL_FUNCTION_1       1  '1 positional argument'
               48  POP_TOP          

 L. 108        50  LOAD_GLOBAL              false
               52  RETURN_VALUE     
             54_0  COME_FROM            34  '34'
               54  END_FINALLY      
             56_0  COME_FROM            26  '26'

Parse error at or near `DUP_TOP' instruction at offset 4


s = '(\\d+\\.?\\d*)\\s*(.*)'
split_trailiing_number = re.compile(s)
s = '(\\d+)([fFpPnNuUmkKMGR])(\\d*)'
rlc_notation = re.compile(s)
s = '[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?'
is_just_float_full = re.compile('^' + s + '$')
is_just_float_full_with_trailing_SI_unit = re.compile('^' + s + '\\s*(Ohm|Ohms|OHM|OHMS|ohm|ohms|F|H)$')

def to_float(val, default=None):
    try:
        f = float(val)
        if math.isinf(f):
            raise ValueError()
    except ValueError:
        val2print = val
        if len(val2print) == 0:
            val2print = '[EMPTY STRING]'
        if default is not None:
            print('WARNING: Could not convert: ', val2print, ' to float.')
        else:
            print('WARNING: Could not convert: ', val2print, ' to float. Using default value.')
        f = default

    return f


def interpret_rlc_values(s, typ):
    if not is_ascii(s):
        return
    else:
        typ = typ.upper()
        if len(s) == 0:
            return
        s = s.strip()
        s = s.replace(',', '.')
        if s[0] == '.':
            s = '0' + s
        m = is_just_float_full_with_trailing_SI_unit.match(s)
        if m is not None and len(m.groups()) == 2:
            e, u = m.groups()
            if typ == 'R' and u.upper().startswith('OHM') or typ == 'L' and u == 'H' or typ == 'C' and u == 'F':
                try:
                    e = int(e[1:])
                    if abs(e) < 30:
                        value = float(s.strip(u))
                        if math.isinf(value):
                            raise ValueError()
                        return value
                except:
                    pass

        m = is_just_float_full.search(s)
        if m is not None:
            val = to_float(s)
            scale = 1.0
        else:
            m = rlc_notation.match(s)
            if m is not None:
                if len(m.groups()) == 3:
                    g = m.groups()
                    value = to_float(g[0])
                    if len(g[2]):
                        value += to_float(g[2]) / 10.0 ** len(g[2])
                    mag = g[1]
                    if typ in ('L', 'C'):
                        if mag == 'M':
                            mag = 'm'
                    if mag != 'R':
                        value *= magtrans[mag]
                    return value
                else:
                    return
            m = split_trailiing_number.match(s)
            if m is None:
                return
            else:
                val, magu = m.groups()
                val = to_float(val)
                if len(magu):
                    if magu[0] in magtrans:
                        mag = magu[0]
                        if typ in ('L', 'C'):
                            if mag == 'M':
                                mag = 'm'
                        scale = magtrans[mag]
                scale = 1
        if typ == 'R':
            return val * scale
        if typ == 'L':
            if val > 1:
                if scale == 1:
                    scale = 1e-09
            return val * scale
        if typ == 'C':
            if val > 0.001:
                if scale == 1:
                    scale = 1e-12
            return val * scale


norm_netname_re = re.compile('(.+)[\\(\\{\\[](\\d+)[\\}\\]\\)]')

def norm_netname(net):
    net = net.upper()
    m = norm_netname_re.match(net)
    if m is not None:
        net = '%s(%s)' % m.groups()
    return net


def make_list(o):
    if type(o) == list:
        return o
    else:
        return [
         o]


def hexstr(i, length=2):
    res = '%x' % i
    if len(res) < length:
        res = '0' * (length - len(res)) + res
    return res


def hexstr2(i):
    res = '%x' % i
    if len(res) < 2:
        res = '0' + res
    return res


def randhex():
    from random import randint
    return hexstr2(randint(0, 255))


def random_color():
    return '#%s%s%s' % (randhex(), randhex(), randhex())


class FileWithPush:

    def __init__(this, file, progress_start=0, progressbar=None):
        this.progressbar, this.progress_start = progressbar, progress_start
        this.file = file
        this.pushed = []
        this.eof = False
        this.line_no = 0
        this.my_approx_pos = 0

    def readline(this):
        if len(this.pushed) > 0:
            return this.pushed.pop()
        else:
            l = this.file.readline()
            this.my_approx_pos += len(l)
            if this.line_no % 1000 == 0:
                if this.progressbar is not None:
                    this.progressbar.set(this.progress_start + this.my_approx_pos)
            this.line_no += 1
            if len(l) == 0:
                this.eof = True
            return l.strip()

    def push(this, line):
        if len(this.pushed) > 0:
            raise Exception('already pushed:%s' % this.pushed)
        this.pushed.append(line)

    def nextline(this):
        l = this.readline()
        while (len(l) == 0 or l[0:1] == ';') and not this.eof:
            l = this.readline()

        return l

    def closed(this):
        return this.file.closed

    def close(this):
        this.file.close()

    def tell(this):
        return this.my_approx_pos


class DatabaseReadError(Exception):

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


class Warnings:

    def __init__(this):
        this.warnings = {}

    def warn(this, s):
        if s not in this.warnings:
            this.warnings[s] = 0
        this.warnings[s] += 1


def open_text_file(filename, default_encoding=None):
    try:
        if open(filename, encoding=default_encoding).read():
            return open(filename, encoding=default_encoding)
    except:
        import encodings
        encoding_list = list(set([v for k, v in encodings.aliases.aliases.items()]))
        encoding_list.insert(0, 'utf_8')
        for ce in encoding_list:
            try:
                file = open(filename, encoding=ce)
                s = file.read()
                print('For the file ', filename, ', the encoding', ce, ' was used.')
                file.close()
                return open(filename, encoding=ce)
            except:
                pass

        raise ImportError('ERROR: cannot read file ', filename, ' because of unknown encoding.')
