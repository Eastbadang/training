# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\common\utils2dPyFake.py
# Compiled at: 2008-07-11 20:59:36
# Size of source mod 2**32: 57 bytes
from utils2dPy import *
from layoutdbPy import *
# okay decompiling utils2dPyFake.pyc
