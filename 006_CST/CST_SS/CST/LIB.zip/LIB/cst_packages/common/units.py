# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\common\units.py
# Compiled at: 2018-08-27 21:46:15
# Size of source mod 2**32: 3641 bytes
import types
def_inch = 0.0254
def_th = def_inch * 0.001
def_inch_mm = def_inch * 1000.0
def_th_mm = def_th * 1000.0
def_inch_mu = def_inch * 1000000.0
def_th_mu = def_th * 1000000.0

def units_th2si(s):
    return s * 2.54e-05


def units_mm2si(s):
    return s * 0.001


def units_in2si(s):
    return s * 0.0254


def get_length_unit_conversion_factor_mu(name):
    """conversion to micrometer"""
    name = name.lower()
    if name in ('th', 'mil'):
        return def_th_mu
    if name == 'in':
        return def_inch_mu
    if name == 'cm':
        return 10000.0
    if name == 'mm':
        return 1000.0
    if name == 'm':
        return 1000000.0
    if name in ('mu', 'um'):
        return 1.0
    if name == 'nm':
        return 0.001
    if name == '10nm':
        return 0.01
    if name == 'bu':
        print("WARNING: unit 'BU' not understood (set to um)")
        return 1.0
    raise NameError('WRONG UNIT GIVEN: ' + name)


get_length_unit_conversion_factor_um = get_length_unit_conversion_factor_mu

def get_length_unit_conversion_factor_mm(name):
    """conversion to millimeter"""
    return get_length_unit_conversion_factor_mu(name) * 0.001


def get_length_unit_conversion_factor_m(name):
    """conversion to millimeter"""
    return get_length_unit_conversion_factor_mu(name) * 1e-06


def get_length_unit_conversion_factor_th(name):
    """conversion to thousands of an inch"""
    name = name.lower()
    if name in ('th', 'mil'):
        return 1.0
    if name == 'in':
        return 1000.0
    if name == 'mm':
        return 1.0 / def_th_mm
    if name == 'cm':
        return 10.0 / def_th_mm
    if name == 'm':
        return 1000.0 / def_th_mm
    if name in ('mu', 'um'):
        return 1.0 / def_th_mu
    if name == 'nm':
        return 0.001 / def_th_mu
    if name == '10nm':
        return 0.01 / def_th_mu
    raise NameError('WRONG UNIT GIVEN: ' + name)


get_length_unit_conversion_factor_mil = get_length_unit_conversion_factor_th

def get_length_unit_conversion_factor_in(name):
    """conversion to inch"""
    return get_length_unit_conversion_factor_th(name) * 0.001


def get_length_unit_conversion_factor_nm(name):
    """conversion to nm"""
    return get_length_unit_conversion_factor_mu(name) * 1000.0


def get_length_unit_conversion_factor_10nm(name):
    """conversion to nm"""
    return get_length_unit_conversion_factor_mu(name) * 100.0


def get_length_unit_conversion_factor_getter(name):
    try:
        name = name.lower()
        return eval('get_length_unit_conversion_factor_' + name)
    except:
        raise NameError('WRONG UNIT GIVEN: ' + name)


def get_typical_manufacturing_tolerance(name, tolmu=1.0):
    return tolmu / get_length_unit_conversion_factor_mu(name)


def length_unit_convert(ufrom, val, uto):
    getter = get_length_unit_conversion_factor_getter(uto)
    return val * getter(ufrom)


def standardize(unit):
    unit = unit.lower()
    if unit == 'th':
        unit = 'mil'
    if unit in ('inch', ):
        return 'in'
    else:
        if unit in ('meter', ):
            return 'm'
        elif not unit in ('m', 'cm', 'mm', 'um', 'nm', 'in', 'mil'):
            raise AssertionError
        return unit


tt = {'f':1e-15, 
 'p':1e-12,  'n':1e-09,  'u':1e-06,  'm':0.001,  'k':1000.0,  'M':1000000.0,  'G':1000000000.0}

def floatmag(s):
    global tt
    if type(s) != types.StringType:
        return s
    else:
        s = s.strip()
        if s[(-1)] in tt:
            return float(s[:-1]) * tt[s[(-1)]]
        return float(s)


logitt = {-15: 'f', -12: 'p', -9: 'n', -6: 'u', -3: 'm', 0: '', 3: 'k', 6: 'M', 9: 'G', 12: 'T'}

def find_best_display_scaling(value):
    for ex in range(12, -16, -3):
        mag = logitt[ex]
        factor = 10.0 ** ex
        if value >= factor:
            return (
             value / factor, mag)

    return (
     value, '')
# okay decompiling units.pyc
