# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\common\parsexml.py
# Compiled at: 2018-08-27 21:46:15
# Size of source mod 2**32: 3932 bytes
"""
Parse PCBMod xml design file and build hierarchical dataset.  
"""
import types, copy, os

class StringFile:

    def __init__(this):
        this.s = ''

    def write(this, s):
        this.s += s


def fPrint(this, file, level=0):
    if isinstance(this, PCBModXML):
        if len(this.__dict__) == 2:
            if set(this.__dict__.keys()) == set(['V', 'N']):
                if not isinstance(this.V, PCBModXML):
                    file.write('%s = %s\n' % (this.N, str(this.V)))
        else:
            file.write('\n')
            for key in sorted(this.__dict__.keys()):
                file.write('\t' * level + key + ': ')
                val = this.__dict__[key]
                fPrint(val, file, level=(level + 1))

    else:
        if type(this) == list:
            file.write('\n')
            for i in range(len(this)):
                val = this[i]
                file.write('\t' * level + '[%d]: ' % i)
                fPrint(val, file, level=(level + 1))

        else:
            file.write(str(this) + '\n')


class PCBModXML:

    def __init__(this):
        pass

    def __str__(this):
        file = StringFile()
        fPrint(this, file)
        return file.s

    def __repr__(this):
        return str(this)


class ProgressBarFile:

    def __init__(self, file, progressbar):
        self.file, self.progressbar, self.lastpos, self.pos = (
         file, progressbar, 0, 0)

    def read(self, s=-1):
        res = self.file.read(s)
        self.pos += len(res)
        if self.pos > self.lastpos + 10000:
            if self.progressbar is not None:
                self.progressbar.set(self.pos)
                self.lastpos = self.pos
        return res


datastack = []
globalcounter = 0

def start_element(name, attrs):
    global datastack
    name = str(name)
    for key in attrs:
        if key in ('x', 'y', 'centerX', 'centerY'):
            attrs[key] = float(attrs[key])

    if name in ('PolyStepSegment', 'PolyStepCurve'):
        name = 'PolySteps'
    else:
        data = datastack[(-1)]
        newdata = PCBModXML()
        datastack.append(newdata)
        if hasattr(data, name):
            val = getattr(data, name)
            if type(val) == list:
                val.append(newdata)
            else:
                setattr(data, name, [val, newdata])
        else:
            setattr(data, name, newdata)
    for key, val in attrs.items():
        setattr(newdata, str(key), val)


def end_element(name):
    data = datastack.pop()
    newattr = {}
    delattr = []
    for key, val in data.__dict__.items():
        if key[-5:] == '_LIST':
            l0 = getattr(data, key)
            keys = list(l0.__dict__.keys())
            keys.remove('cadset')
            keys.remove('lastcadset')
            assert len(keys) == 1
            l = getattr(l0, keys[0])
            if type(l) != list:
                l = [
                 l]
            newattr[key[:-5]] = l
            delattr.append(key)

    for key in delattr:
        del data.__dict__[key]

    data.__dict__.update(newattr)


def char_data(data):
    pass


def read_XML(filename, progressbar=None):
    global datastack
    global globalcounter
    import xml.parsers.expat
    globalcounter = 0
    datastack = [PCBModXML()]
    p = xml.parsers.expat.ParserCreate(encoding='UTF-8')
    p.StartElementHandler = start_element
    p.EndElementHandler = end_element
    p.CharacterDataHandler = char_data
    file = ProgressBarFile(open(filename, 'rb'), progressbar)
    if progressbar is not None:
        progressbar.reset('Reading IPC2581 file', os.path.getsize(filename))
    else:
        p.ParseFile(file)
        if progressbar is not None:
            progressbar.finished()
        assert len(datastack) == 1
    return datastack.pop()


if __name__ == '__main__':
    import sys
    D = read_PCBModXML(sys.argv[1])
# okay decompiling parsexml.pyc
