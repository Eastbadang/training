# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\common\layoutdb.py
# Compiled at: 2019-07-30 18:09:30
# Size of source mod 2**32: 39667 bytes
import os, sys, types, layoutdbPy

class DatabaseReadError(Exception):

    def __init__(self, value):
        self.value = value

    def __str__(self):
        return repr(self.value)


def set_fraction_filled_from_below(db, layer, fraction):
    if db.fraction_filled_from_below(layer) == 0.5:
        db.fraction_filled_from_below(layer, fraction)


def add_soldermask(db, on_top):
    if (db.top_soldermask() if on_top else db.bottom_soldermask()) is not None:
        return
    else:
        l_etch = db.top_etch_layer() if on_top else db.bottom_etch_layer()
        assert l_etch is not None
        if l_etch is not None:
            new_layer = layoutdbPy.new_iLayer()
            new_layer.name = 'Solder_Mask_' + ('TOP' if on_top else 'BOTTOM')
            new_layer.layer_type = layoutdbPy.LayerType.Dielectric
            mat = layoutdbPy.Material()
            mat.name = 'FR4'
            mat.condtan = 0.02
            mat.eps = 4.3
            mat.mu = 1.0
            mat.type = layoutdbPy.MaterialType.Dielectric
            new_layer.material = mat
            if on_top:
                db.add_layer_above(new_layer, l_etch)
            else:
                db.add_layer_below(new_layer, l_etch)
            print('Added layer %s %s etch layer %s' % (new_layer.name, 'above' if on_top else 'below', l_etch.name))


def check_layer_stackup(layoutdb, add_soldermasks=True):
    need_substrate_below = []
    last = None
    for l in layoutdb.layers():
        if last is not None:
            if l.is_etch():
                if last.is_etch():
                    if l.layer_type != layoutdbPy.LayerType.Visualization:
                        if last.layer_type != layoutdbPy.LayerType.Visualization:
                            if l.layer_type != layoutdbPy.LayerType.BGA:
                                if last.layer_type != layoutdbPy.LayerType.BGA:
                                    need_substrate_below.append(last)
        last = l

    count = 1
    for l in need_substrate_below:
        new_layer = layoutdbPy.new_iLayer()
        new_layer.name = 'Substrate-%d' % count
        count += 1
        new_layer.layer_type = layoutdbPy.LayerType.Dielectric
        mat = layoutdbPy.Material()
        mat.name = 'FR4'
        mat.condtan = 0.02
        mat.eps = 4.3
        mat.mu = 1.0
        mat.type = layoutdbPy.MaterialType.Dielectric
        new_layer.material = mat
        layoutdb.add_layer_below(new_layer, l)
        print('Added substrate layer %s below etch layer %s' % (new_layer.name, l.name))

    if add_soldermasks:
        add_soldermask(layoutdb, on_top=False)
    l_top = layoutdb.top_etch_layer()
    if l_top is not None:
        set_fraction_filled_from_below(layoutdb, l_top, 0)
    l_bottom = layoutdb.bottom_etch_layer()
    if l_bottom is not None:
        set_fraction_filled_from_below(layoutdb, l_bottom, 1)
    count = 1
    if l_top is not None:
        if l_bottom is not None:
            for i in range(l_top.number, l_bottom.number):
                l = layoutdb.layer(i)
                if l.is_etch():
                    if count % 2 == 0:
                        set_fraction_filled_from_below(layoutdb, l, 1)
                    else:
                        set_fraction_filled_from_below(layoutdb, l, 0)
                    count += 1

    if add_soldermasks:
        add_soldermask(layoutdb, on_top=True)
    layoutdb.update_elevations()
    for l in layoutdb.layers():
        if l.material is not None:
            pass
        else:
            mat = layoutdbPy.Material()
            if l.is_etch() or l.layer_type == layoutdbPy.LayerType.Bumps or l.layer_type == layoutdbPy.LayerType.BGA:
                mat.name = 'Copper'
                mat.condtan = 58000000.0
                mat.eps = 1
                mat.mu = 1
                mat.type = layoutdbPy.MaterialType.Conductor
            else:
                if l.layer_type == layoutdbPy.LayerType.DiePads:
                    mat.name = 'Gold'
                    mat.condtan = 45610000.0
                    mat.eps = 1
                    mat.mu = 1
                    mat.type = layoutdbPy.MaterialType.Conductor
                else:
                    if l.layer_type == layoutdbPy.LayerType.Visualization:
                        mat.name = 'Visualization'
                        mat.condtan = mat.eps = mat.mu = 0.0
                        mat.type = layoutdbPy.MaterialType.Dielectric
                    else:
                        mat.name = 'FR4'
                        mat.condtan = 0.02
                        mat.eps = 4.3
                        mat.mu = 1.0
                        mat.type = layoutdbPy.MaterialType.Dielectric
            l.material = mat

    for l in layoutdb.layers():
        mat = l.material
        if mat.type == layoutdbPy.MaterialType.unknown:
            if l.is_etch():
                mat.type = layoutdbPy.MaterialType.Conductor
            else:
                mat.type = layoutdbPy.MaterialType.Dielectric

    i = 0
    for l in layoutdb.layers():
        if l.is_etch():
            l.color = layoutdbPy.Color(i)
            i += 1
        else:
            if l.layer_type == layoutdbPy.LayerType.Die:
                l.color = layoutdbPy.Color(0.666, 0, 0)
            else:
                if l.layer_type == layoutdbPy.LayerType.Spacer:
                    l.color = layoutdbPy.Color(0.9372549019607843, 0.06274509803921569, 0.9372549019607843)
                else:
                    if l.layer_type in (layoutdbPy.LayerType.Visualization, layoutdbPy.LayerType.DiePads):
                        l.color = layoutdbPy.Color(0.9098039215686274, 0.8431372549019608, 0.39215686274509803)
                    else:
                        l.color = layoutdbPy.Color(0, 0.333, 0)


def loadtechfile2008(filename, db):
    from common.Tools import loaddata
    try:
        tech = loaddata(filename)
    except:
        return 1
    else:
        tnew = tech['table']
        ioffset = 0
        if len(tnew) != db.n_layers():
            if len(tnew) > 0:
                if len(tnew) + 2 == db.n_layers():
                    if 'metal' in tnew[0]['material_type'].lower():
                        if 'metal' in tnew[(-1)]['material_type'].lower():
                            if not db.layer(0).is_etch():
                                if not db.layer(db.n_layers() - 1).is_etch():
                                    ioffset = 1
            else:
                print('ERROR: xunequal number of layers')
                return 2
        for i in range(len(tnew)):
            l = db.layer(i + ioffset)
            if ('metal' in tnew[i]['material_type'].lower()) != l.is_etch():
                print('ERROR: incompatible stackup')
                return 3

        su = tech
        from common.units import length_unit_convert
        unit = su['unit'].lower()
        factor = length_unit_convert(unit, 1.0, db.length_unit)
        il = ioffset
        for i in su['table']:
            l = db.layer(il)
            il += 1
            l.thickness = i['thickness'] * factor
            l.material.eps = i['permittivity']
            l.material.condtan = i['condtan']
            l.is_selected = i['export'] != 0

        db.update_elevations()
        return 0


def type_name_to_RLC_type(typename):
    import layoutdbPy
    typename = typename.lower()
    if typename.startswith('r'):
        return layoutdbPy.LEModelType.R_HF
    else:
        if typename.startswith('l') or typename.startswith('i'):
            return layoutdbPy.LEModelType.L_HF
        return layoutdbPy.LEModelType.C_HF


def import_lumped_elements(filename, filetype, errors_as_warnings=False):
    if filetype == 'csv':
        func = import_lumped_elements_from_csv
    else:
        if filetype == 'csv-parasitics':
            func = import_lumped_elements_from_csv_With_Parasitics
        else:
            if filetype == 'zcr5000':
                func = import_lumped_elements_from_zcr5000_txt
            else:
                if filetype == 'cadence':
                    func = load_cadence_partsfile
                else:
                    if filetype == 'cstmws':
                        func = load_cst_part_model_db
                    else:
                        print('ERROR: unrecognized file extension (%s)' % ext)
                        return (10, list(), list())
    status, les, assignments, warnings = func(filename)
    for w in warnings:
        if errors_as_warnings:
            w = w.replace('ERROR:', 'WARNING:')
        print(w)

    return (
     status, les, assignments, warnings)


def create_lumped_element_table(items0, print_warnings=True):
    from common.helpers import interpret_rlc_values
    from common.helpers import is_ascii
    import string, re
    lumped_element_list = []
    refdes_to_lumped_element = []
    warnings = []

    def issue_warning(w):
        w = 'WARNING: ' + w
        warnings.append(w)
        if print_warnings:
            print(w)

    items = []
    unknown_types = {}
    for refdes, partname, typ, value in items0:
        if refdes == '':
            issue_warning('ignored empty refdes')
        else:
            if typ == '':
                if len(refdes) >= 2:
                    if refdes[:2].upper() == 'IC':
                        typ = 'IC'
                else:
                    typ = refdes[:1]
            typ = typ.upper()
            if typ not in ('R', 'RES', 'RESISTOR', 'C', 'CAP', 'CAPACITOR', 'L', 'I',
                           'IND', 'INDUCTOR'):
                unknown_types[refdes] = typ
            else:
                typ = typ[0]
            if typ == 'I':
                typ = 'L'
            items.append((refdes, partname, typ, value.strip()))

    parts0 = {}
    for refdes, partname, typ, value in items:
        id = (
         partname, typ, value)
        if id not in parts0:
            parts0[id] = []
        parts0[id].append(refdes)

    parts1 = {}
    for (partname, typ, value), refdess in parts0.items():
        if partname not in parts1:
            parts1[partname] = {}
        else:
            p = parts1[partname]
            if typ not in p:
                p[typ] = {}
            t = p[typ]
            if value not in t:
                t[value] = []
        v = t[value]
        v.extend(refdess)

    for name in parts1:
        for typ in parts1[name]:
            t = parts1[name][typ]
            if len(t) == 2 and '' in t:
                rr = t.pop('')
                t[list(t.keys())[0]].extend(rr)

    parts2 = {}
    for partname, p in parts1.items():
        for typ, t in p.items():
            name_t = partname
            if len(p) > 1:
                name_t += '-%s' % typ
            for value, refdess in t.items():
                name_v = name_t
                if len(t) > 1:
                    name_v += '-%s' % value
                if partname == '':
                    for refdes in refdess:
                        parts2[refdes] = (
                         typ, value, [refdes])

                else:
                    parts2[name_v] = (
                     typ, value, refdess)

    values = {}
    unable_to_interpret = {}
    for name, (typ, value_string, refdess) in parts2.items():
        typ = typ.upper()
        if typ in ('R', 'L', 'C'):
            try:
                value = interpret_rlc_values(value_string, typ)
            except:
                value = None

            if value is None:
                unable_to_interpret[value_string] = name
            else:
                values[name] = (
                 typ, value_string, value)
            le = layoutdbPy.LumpedElementModel()
            if typ == 'R':
                le.type = layoutdbPy.LEModelType.R_HF
            else:
                if typ == 'L':
                    le.type = layoutdbPy.LEModelType.L_HF
                else:
                    le.type = layoutdbPy.LEModelType.C_HF
                le.name = name
                setattr(le, typ, value)
                if value == 0:
                    if typ == 'R':
                        le.type = layoutdbPy.LEModelType.short
                lumped_element_list.append(le)
        for refdes in refdess:
            refdes_to_lumped_element.append((refdes, name))

    unit_string = {'R':'Ohms',  'L':'Henries',  'C':'Farads'}
    lower_limit = {'R':1e-06,  'L':1e-15,  'C':1e-18}
    upper_limit = {'R':1000000000000.0,  'L':0.001,  'C':0.999}
    translations = {}
    for name, (typ, value_string, value) in values.items():
        if typ in ('R', 'L', 'C'):
            translations[(value_string, typ)] = value

    from common.units import find_best_display_scaling
    translation_factor = {'R':1, 
     'L':1000000000000.0,  'C':1000000000000.0}
    translation_mag = {'R':'',  'L':'p',  'C':'p'}
    unit_string = {'R':'Ohm',  'L':'H',  'C':'F'}
    report = []
    if len(translations):
        print('Value-string translations:')
        for (value_string, typ), value in translations.items():
            dval, mag = find_best_display_scaling(value)
            report.append('\t%s ->  %s %s%s (%s)' % (value_string, dval, mag, unit_string[typ], typ.upper()))
            if value <= lower_limit[typ] or value >= upper_limit[typ]:
                if value == 0:
                    if typ == 'R':
                        issue_warning('interpreted as short: %s %s' % (value, unit_string[typ]))
                else:
                    issue_warning('unphysical value: %s %s' % (value, unit_string[typ]))

    report.sort()
    if len(unable_to_interpret):
        for val in list(unable_to_interpret.keys()):
            msg = ''
            if not is_ascii(val):
                msg = 'unable to interpret: %s (non-ascii)' % val
            else:
                if len(val) == 0:
                    msg = 'unable to interpret: [empty string]'
                else:
                    msg = 'unable to interpret: %s' % val
            issue_warning(msg)

    for r in report:
        print(r)

    return (lumped_element_list, refdes_to_lumped_element, warnings)


def set_read_elements(layoutdb, items0, print_warnings=True):
    pdb = layoutdb.part_model_db
    if pdb is None:
        layoutdb.part_model_db = pdb = layoutdbPy.PartModelDB()
    items = items0[:]
    les, asss, warnings = create_lumped_element_table(items, print_warnings=print_warnings)
    for le in les:
        pdb.add_lumped_element(le)

    for refdes, model in asss:
        comp = layoutdb.component(refdes)
        if comp is not None:
            comp.em_model = model

    return warnings


def export_lumped_elements_to_csv(items, filename):
    import os, csv
    cfile = csv.writer(open(filename, 'w', encoding='utf-8', newline=''), delimiter=';')
    cfile.writerow(['refdes', 'partname', 'type', 'value'])
    for item in items:
        csvline = []
        for sval in list(item):
            sval = sval.replace(';', ' ')
            sval = sval.strip("'")
            sval = ' ' + sval
            csvline.append(sval)

        cfile.writerow(csvline)


def import_lumped_elements_from_csv(filename):
    from common.helpers import float_with_unit
    import csv, string
    print('=' * 40)
    print('Lumped-element import (%s)...' % filename)
    status, les, ass, text_warnings = (
     0, [], [], [])
    warnings = 0
    f = open(filename, encoding='utf-8')
    header_line = f.readline().strip()
    sep_list = [
     ';', ',', ':', '\t']
    n = []
    for sep in sep_list:
        n.append(header_line.count(sep))

    splitchar = sep_list[n.index(max(n))]
    print("Detected '", splitchar, "' as separator.\n")
    if splitchar not in header_line:
        text_warnings.append("ERROR: Expecting '%s' as a separator, but none were found in the first line " % splitchar)
    col2key = header_line.split(splitchar)
    col2key = [c.strip().strip('"').strip() for c in col2key]
    for i in range(len(col2key)):
        s = col2key[i].lower()
        if s in ('ref', 'reference'):
            s = 'refdes'
        if s in ('part name', 'part_name'):
            s = 'partname'
        if s in ('val', 'wert'):
            s = 'value'
        col2key[i] = s

    key2col = {}
    duplicate_headers = set()
    for i in range(len(col2key)):
        key = col2key[i]
        count = 0
        while key in key2col:
            key = '%s_%d' % (col2key[i], count)
            count += 1

        if key != col2key[i]:
            duplicate_headers.add(col2key[i])
            col2key[i] = key
        key2col[key] = i

    if len(duplicate_headers):
        s = ', '.join(["'" + d + "'" for d in duplicate_headers])
        text_warnings.append('WARNING: column header(s) %s found multiple times (taking the first one)' % s)
    for key in ('refdes', 'partname', 'value'):
        if key not in key2col:
            status = 10
            text_warnings.append('ERROR: missing column header in the .csv file: %s. The following headers are required: refdes, partname, value.' % key)

    reader = csv.reader(f, delimiter=splitchar)
    if status == 0:
        has_type = 'type' in key2col
        read = []
        not_read = set()
        warnings = 0
        try:
            for a in reader:
                if len(a) != len(key2col):
                    text_warnings.append('ERROR: In .csv file (line %d): #columns!=#headers:\n\t' % reader.line_num)
                else:
                    partnumber = a[key2col['partname']]
                    partnumber.strip()
                    partnumber = partnumber.strip('"').strip("'")
                    partnumber.strip()
                    value = a[key2col['value']]
                    value = value.strip()
                    value = value.strip('"').strip("'")
                    value = value.strip()
                    for refdes in a[key2col['refdes']].strip('"').split(splitchar):
                        refdes = refdes.strip('"')
                        refdes = refdes.strip()
                        if len(refdes) == 0:
                            pass
                        else:
                            typ = ''
                            if has_type:
                                typ = a[key2col['type']]
                                typ = typ.strip()
                            read.append((refdes, partnumber, typ, value))

            les, ass, text_warnings2 = create_lumped_element_table(read, print_warnings=False)
            text_warnings += text_warnings2
        except csv.Error as e:
            text_warnings.append('line %d: %s' % (reader.line_num, e))

    f.close()
    warnings += len(text_warnings)
    if status < 2:
        if warnings > 0:
            status = 1
    return (
     status, les, ass, text_warnings)


def import_lumped_elements_from_csv_With_Parasitics(filename):
    f = open(filename)
    header_line = f.readline().strip()
    req_columns = [
     'partname', 'type', 'R', 'L', 'C']
    splitchar = None
    for sep in (';', ',', ':', '\t'):
        if header_line == sep.join(req_columns):
            splitchar = sep
            break

    if splitchar is None:
        return
    else:
        from common.helpers import float_with_unit
        import csv
        reader = csv.reader(f, delimiter=splitchar)
        status = 0
        les = []
        ass = []
        text_warnings = []
        typemap = {'R':layoutdbPy.LEModelType.R_HF,  'L':layoutdbPy.LEModelType.L_HF, 
         'C':layoutdbPy.LEModelType.C_HF}
        if status == 0:
            try:
                for a in reader:
                    error_start = 'ERROR: In .csv file (line %d): ' % reader.line_num
                    error_end = '\n\t'
                    if len(a) != len(req_columns):
                        text_warnings.append(error_start + 'incorrect #columns' + error_end)
                    else:
                        a = [s.strip().strip("'").strip('"') for s in a]
                        partname, typ, R, L, C = a
                        if len(partname) == 0:
                            text_warnings.append(error_start + 'empty part name' + error_end)
                        else:
                            typ = typ.upper()
                            if typ not in ('R', 'L', 'C'):
                                text_warnings.append(error_start + 'part type must be one of R,L, or C' + error_end)
                            else:
                                try:
                                    R = float_with_unit(R)
                                    L = float_with_unit(L)
                                    C = float_with_unit(C)
                                except:
                                    text_warnings.append(error_start + 'unable to read one the R,L,C values' + error_end)
                                    continue

                                model = layoutdbPy.LumpedElementModel()
                                model.type = typemap[typ]
                                model.name = partname
                                model.R = R
                                model.L = L
                                model.C = C
                                les.append(model)

            except csv.Error as e:
                text_warnings.append('line %d: %s' % (reader.line_num, e))

        f.close()
        return (
         status, les, ass, text_warnings)


def import_ports_from_csv_ELTA(filename):
    import layoutdbPy
    print('=' * 40)
    print('Port import (%s)...' % filename)
    status, text_warnings, ports, data_entries = (
     0, [], [], [])
    warnings = 0
    splitchar = ';'
    f = open(filename)
    col2key = f.readline().strip().split(splitchar)
    col2key = [c.strip().strip('"').strip() for c in col2key]
    for i in range(len(col2key)):
        s = col2key[i].lower()
        col2key[i] = s

    key2col = {}
    for i in range(len(col2key)):
        if col2key[i] in key2col:
            if col2key[i] in ('refdes', 'refpins', 'spar', 'sparpins', 'gndpins'):
                text_warnings.append("ERROR: column header '%s' found multiple times" % col2key[i])
                status = 10
        key2col[col2key[i]] = i

    for key in ('refdes', 'refpins', 'spar', 'sparpins', 'gndpins'):
        if key not in key2col:
            status = 10
            text_warnings.append('ERROR: missing column header in the .csv file: %s' % key)
            text_warnings.append('The following header strings are required: refdes, partname, value')

    if status == 0:
        read = []
        not_read = set()
        lineno = 1
        for l in f:
            lineno += 1
            l = l.strip()
            a = l.strip().split(splitchar)
            if len(a) != len(key2col):
                text_warnings.append('ERROR in .csv file (line %d): #columns!=#headers:\n\t' % lineno)
                text_warnings.append(l)
                continue
            refdess = []
            for refdes in a[key2col['refdes']].strip('"').split(splitchar):
                refdes = refdes.strip('"')
                refdes = refdes.strip()
                if len(refdes) > 0:
                    refdess.append(refdes)

            pins = a[key2col['refpins']].strip('"').strip("'").split(',')
            pins = [pinname.strip() for pinname in pins]
            pins = [pinname for pinname in pins if len(pinname) > 0]
            refpins = pins
            pins = a[key2col['gndpins']].strip('"').strip("'").split(',')
            pins = [pinname.strip() for pinname in pins]
            pins = [pinname for pinname in pins if len(pinname) > 0]
            gndpins = pins
            pins = a[key2col['sparpins']].strip('"').strip("'").split(',')
            pins = [pinname.strip() for pinname in pins]
            pins = [pinname for pinname in pins if len(pinname) > 0]
            sparpins = pins
            netlist = layoutdbPy.vectorString()
            data_entries.append({'refdess':refdess,  'refpins':refpins,  'gndpins':gndpins,  'spar':a[key2col['spar']],  'sparpins':sparpins})
            if 'partname' in key2col:
                data_entries[(-1)]['partname'] = a[key2col['partname']]
            for refdes in refdess:
                for pinname in refpins:
                    tp = layoutdbPy.TestPoint(refdes, pinname)
                    portname = tp.decorated_name()
                    port = layoutdbPy.DiscretePort(portname, tp, netlist)
                    ports.append(port)

    warnings += len(text_warnings)
    if status < 2:
        if warnings > 0:
            status = 1
    return (
     status, text_warnings, ports, data_entries)


def import_parts_from_csv_ELTA(filename, db, datapaths=[]):
    import layoutdbPy
    status, text_warnings, ports, data_entries = import_ports_from_csv_ELTA(filename)
    if status != 0:
        return (
         status, text_warnings)
    if len(datapaths) == 0:
        datapaths = [
         os.path.dirname(filename)]
    ss = db.simulation_settings
    pdb = ss.part_models
    count = 0
    for d in data_entries:
        modelfilename = spar = d['spar']
        for p in datapaths:
            path = os.path.join(p, modelfilename)
            if os.path.exists(path):
                modelfilename = path
                break
        else:
            continue

        if 'partname' in d:
            modelname = d['partname']
        else:
            modelname = os.path.basename(modelfilename)
        try:
            model = layoutdbPy.FileBasedModel(modelname, modelfilename, layoutdbPy.FileBasedModelType.touchstone)
        except:
            print('unable to read ', modelname, modelfilename)

        if not spar == '':
            if spar is None:
                pass
            else:
                refpins, sparpins = d['refpins'], d['sparpins']
                if len(refpins) != len(sparpins):
                    print('ERROR: unequal ref/spar pins: ', refpins, sparpins)
                    continue
                for p, s in zip(refpins, sparpins):
                    model.pin_mappings.add(layoutdbPy.PinNode('outer', '', p), layoutdbPy.PinNode('model', '', s))

                pdb.add_file_based_model(model)
                for refdes in d['refdess']:
                    comp = db.component(refdes)
                    if comp is not None:
                        comp.em_model = model.name

                count += 1

    print('added %d file-based models' % count)
    for w in text_warnings:
        print('WARNING: ' + w)


def load_cst_part_model_db(filename):
    status, les, ass, text_warnings = loadpartsfile2008(filename)
    if status == 1:
        status = 0
        pdb = layoutdbPy.PartModelDB()
        pdb.load(filename)
        for name in pdb.lumped_elements():
            print(name)
            les.append(pdb.lumped_element(name))

    return (status, les, ass, text_warnings)


def loadpartsfile2008(filename):
    import layoutdbPy
    from common.Tools import loaddata
    status, les, ass, text_warnings = (
     0, [], [], [])
    try:
        parts = loaddata(filename)
    except:
        return (
         1, [], [], [])
    else:
        for part in list(parts.values()):
            if not isinstance(part, layoutdbPy.RLC):
                pass
            else:
                model = layoutdbPy.LumpedElementModel()
                model.type = layoutdbPy.LEModelType.RLC_serial if part.is_serial else layoutdbPy.LEModelType.RLC_parallel
                model.name = part.number
                model.R = part.R
                model.L = part.L
                model.C = part.C
                les.append(model)

        return (
         status, les, ass, text_warnings)


def load_cadence_partsfile(filename):
    import layoutdbPy
    from common.helpers import interpret_rlc_values
    print('*' * 40)
    print('Reading Cadence component report...')
    status, les, ass, text_warnings = (
     0, [], [], [])
    warnings = 0
    file = open(filename)
    l = file.readline()
    assert 'Component Report' in l
    file.readline()
    file.readline()
    file.readline()
    keys = file.readline().strip().split(',')
    if 'REFDES' not in keys or 'COMP_DEVICE_TYPE' not in keys or 'COMP_VALUE' not in keys:
        status = 2
        text_warnings.append('ERROR: input file has wrong format (see online help)')
    else:
        read_items = []
        problems = []
        for l in file:
            a = l.strip().split(',')
            if len(a) != len(keys):
                problems.append(l.strip())
            else:
                data = dict(list(zip(keys, a)))
                refdes, model, value = data['REFDES'], data['COMP_DEVICE_TYPE'], data['COMP_VALUE']
                if refdes in read_items:
                    text_warnings.append("WARNING: found refdes '%s' for the second time in line:" % str(refdes))
                    text_warnings.append(l.strip())
                else:
                    read_items.append((refdes, model, refdes[:1].upper(), value))

        if len(problems):
            text_warnings.append('WARNING: the following lines could not be interpreted (problem: #commas):')
            for l in problems:
                text_warnings.append('->' + l.strip())

        les, ass, wtmp = create_lumped_element_table(read_items)
        text_warnings += wtmp
    warnings += len(text_warnings)
    if status < 2:
        if warnings > 0:
            status = 1
    return (
     status, les, ass, text_warnings)


def import_lumped_elements_from_zcr5000_txt(filename):
    from common.helpers import float_with_unit
    status, les, ass, text_warnings = (
     0, [], [], [])
    warnings = 0
    f = open(str(filename))
    l = f.readline().strip()
    a = l.split()
    if not (len(a) == 4 and a[0].lower().strip('"') in ('reference', 'ref', 'refdes') and a[1].lower().strip('"') in ('partname',
                                                                                                                      'part name',
                                                                                                                      'part') and a[2].lower().strip('"') in ('value',
                                                                                                                                                              'val') and a[3].lower().strip('"') in ('nomount', )):
        text_warnings.append('ERROR: Wrong file header:')
        text_warnings.append('\t' + l)
        text_warnings.append('The correct first line should read:\n\t"reference"  "partname" "value" "nomount"')
    read = []
    for l in f:
        a = l.strip().split()
        refdes = a[0].strip('"\'')
        partnumber = a[1].strip('"\'')
        value = a[2].strip('"\'')
        if not len(refdes) == 0:
            if refdes[0].lower() not in 'rlc':
                continue
            try:
                read.append((refdes, partnumber, '', value))
            except:
                text_warnings.append('ERROR: Failed to read value of part %s' % partnumber)

    les, ass, wtmp = create_lumped_element_table(read)
    text_warnings += wtmp
    warnings += len(text_warnings)
    print('=' * 40)
    if status == 0:
        if warnings > 0:
            status = 1
    return (
     status, les, ass, text_warnings)


def load_cadence_techfile(filename, layoutdb):
    pass


def correct_die_pad_layers(layoutdb, comp_name, oldL_newL):
    comp = layoutdb.component(comp_name)
    pss = []
    for ips in range(comp.n_padstacks()):
        ps = comp.padstack(ips)
        pss.append(ps)

    lps4clone = {}
    for ps in pss:
        if ps.library_padstack.name not in lps4clone:
            lps = ps.library_padstack.clone()
            lps4clone[lps.name] = lps

    for old_layer, new_layer in oldL_newL:
        for lps in list(lps4clone.values()):
            layoutdbPy.replace_layers(lps, old_layer, new_layer)

        for ps in pss:
            lname = ps.library_padstack.name
            ps.library_padstack = lps4clone[lname]
            if ps.layer_from == ps.layer_to and ps.library_padstack.pad(new_layer, layoutdbPy.ConnectType.connect):
                ps.layer_to = ps.layer_from = new_layer
                ps.connect(new_layer, layoutdbPy.ConnectType.connect)

        for i in range(comp.n_pins()):
            pin = comp.pin(i)
            if pin.layer == old_layer:
                pin.layer = new_layer


def check_pin_names(components):
    for c in components:
        pin_names = {}
        for i in range(c.n_pins()):
            p = c.pin(i)
            if p.name in pin_names:
                pin_names[p.name].append(p)
            else:
                pin_names[p.name] = [
                 p]

        for name, pins in pin_names.items():
            if len(pins) > 1:
                msg = []
                num = 1
                for i in range(1, len(pins)):
                    p = pins[i]
                    new_name = name + '(%i)' % num
                    while new_name in pin_names:
                        num += 1
                        new_name = name + '(%i)' % num

                    p.name = new_name
                    num += 1
                    msg.append(p.name)

                msg = ', '.join(msg)
                print('WARNING: renamed pins with the same name for component %s from %s to %s' % (c.name, name, msg))


def read_IRDrop_result(file_name, sim_set):
    from common.parsexml import read_XML
    data = read_XML(file_name, progressbar=None)
    data1 = getattr(data, 'IRDropResults')
    l1 = data1.resulttype
    status = 1
    for i in l1:
        if i.name == 'Power Losses':
            for j in i.resultname:
                if j.name == 'Components':
                    for result in j.result:
                        if hasattr(result, 'param'):
                            comp = None
                            power = None
                            for param in result.param:
                                if hasattr(param, 'name') and hasattr(param, 'value'):
                                    if param.name == 'Component':
                                        comp = param.value.upper()
                                    elif param.name == 'Power loss[W]':
                                        power = float(param.value)

                            if comp and power:
                                h = layoutdbPy.HeatSource(comp, power, 0)
                                sim_set.add_heat_source(h)

    return status


def read_content_from_csv(file_name):
    status = 1
    csv_content = []
    f = open(file_name)
    header_line = f.readline().strip()
    sep_list = [
     ';', ',', ':', '\t']
    n = []
    for sep in sep_list:
        n.append(header_line.count(sep))

    splitchar = sep_list[n.index(max(n))]
    print("Detected '", splitchar, "' as separator.\n")
    if splitchar not in header_line:
        text_warnings.append("ERROR: Expecting '%s' as a separator, but none were found in the first line " % splitchar)
    row1 = header_line.split(splitchar)
    csv_content.append([i.strip() for i in row1])
    import csv
    text_warnings = []
    reader = csv.reader(f, delimiter=splitchar)
    if status == 1:
        read = []
        warnings = 0
        try:
            for a in reader:
                read = [i.strip() for i in a]
                csv_content.append(read)

        except csv.Error as e:
            text_warnings.append('line %d: %s' % (reader.line_num, e))

    f.close()
    warnings += len(text_warnings)
    if status < 2:
        if warnings > 0:
            status = 2
    return (
     status, csv_content)
# okay decompiling layoutdb.pyc
