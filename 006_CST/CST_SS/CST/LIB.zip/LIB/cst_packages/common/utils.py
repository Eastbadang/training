# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\common\utils.py
# Compiled at: 2018-08-27 21:46:15
# Size of source mod 2**32: 18842 bytes
verbose = False

def dd_real(x):
    return x


from utils2dPy import *
from layoutdbPy import *
from functools import reduce
segsperrad = 12

def segs_from_string(s):
    segs = ArrayCurveSegment(0)
    for l in s.split('\n'):
        if len(l) == 0:
            pass
        else:
            a = l.split(':')
            seg = eval(a[1])
            segs.push_back(seg)

    return segs


def segs_from_string2(s):
    segs = ArrayCurveSegment(0)
    s = s.replace('\n', '')
    ss = s.split(':')
    for i in range(1, len(ss)):
        l = ss[i]
        print(l)
        if len(l) == 0:
            pass
        else:
            seg = eval(l)
            segs.push_back(seg)

    return segs


def rectange(a, b, c, d):
    segs = ArrayCurveSegment(0)
    segs.push_back(CurveSegment(a * 1, b * 1))
    segs.push_back(CurveSegment(b * 1, c * 1))
    segs.push_back(CurveSegment(c * 1, d * 1))
    segs.push_back(CurveSegment(d * 1, a * 1))
    res = Shape(segs)
    if res.sense() < 0:
        res.reverse()
    elif not res.sense() > 0:
        raise AssertionError
    return res


rectangle = rectange

def random_rect(staux=0.1, stauy=1, rotate=True):
    from random import random
    from math import pi
    geotol = 0
    a = R2(random(), random(), geotol)
    dx, dy = random(), random()
    dx, dy = R2(dx, 0, geotol) * staux, R2(0, dy, geotol) * stauy
    res = rectange(a * 1, a + dx, a + dx + dy, a + dy)
    if rotate:
        angle = 2 * pi * random()
        res.rotate(dd_real(angle), (a + a + dx + dy) * 0.5)
    return res


def circle(c, R):
    segs = ArrayCurveSegment(0)
    a = c + R2(abs(R), 0)
    b = c - R2(abs(R), 0)
    R = dd_real(R)
    segs.push_back(CurveSegment(a, b, c, R))
    segs.push_back(CurveSegment(b, a, c, R))
    res = Shape(segs)
    if res.sense() < 0:
        res.reverse()
    elif not res.sense() > 0:
        raise AssertionError
    return res


def random_circle(rad=1):
    from random import random
    from math import pi
    geotol = 0
    c = R2(random(), random(), geotol)
    if random() > 0.5:
        R = random()
    else:
        R = -random()
    R *= rad
    return circle(c, R)


def get_xs_ys_segment(seg):
    global segsperrad
    if seg.is_arc:
        ns = int(segsperrad * abs(float(seg.phi)))
        if ns:
            dphi = float(seg.phi) / ns
        dx = seg.ca * 1
        xs = [dx + seg.c]
        for i in range(ns):
            dx.turn(dd_real(dphi))
            xs.append(dx + seg.c)

        xs.append(seg.b)
    else:
        xs = [
         seg.a, seg.b]
    ys = [float(x.y) for x in xs]
    xs = [float(x.x) for x in xs]
    return (xs, ys)


def convert_R2(p):
    return R2(p.x, p.y)


def convert_seg(seg, segs):
    a, b = convert_R2(seg.a), convert_R2(seg.b)
    if seg.is_arc:
        c, R = convert_R2(seg.c), dd_real(seg.R)
        if abs(seg.phi) > 3.1:
            m0 = seg.point(0.5)
            m = convert_R2(m0)
            cc = CurveSegment(a, m, c, R)
            segs.push_back(cc)
            assert abs(float(cc.phi)) < 3.15
        else:
            cc = CurveSegment(m, b, c, R)
            segs.push_back(cc)
            if not abs(float(cc.phi)) < 3.15:
                raise AssertionError
            else:
                segs.push_back(CurveSegment(a, b, c, R))
    else:
        segs.push_back(CurveSegment(a, b))


def convert_shape(shape):
    segs = ArrayCurveSegment(0)
    try:
        for seg in shape.segments:
            convert_seg(seg, segs)

    except:
        print('Shape: failed conversion!!')
        return
    else:
        res = Shape(segs)
        sense = res.sense()
        if sense == -1:
            res.reverse()
        else:
            if sense == 0:
                return
            assert res.sense() == 1
        return res


def filter_shapes(shapes, xmin, xmax, ymin, ymax):
    res = []
    for shape in shapes:
        bb = shape.boundingbox
        if not bb.xmin < xmin:
            if bb.xmax > xmax or bb.ymin < ymin or bb.ymax > ymax:
                pass
            else:
                res.append(shape)

    return res


def contains_straight_lines(shape):
    for s in shape.segments:
        if not s.is_arc:
            return True

    return False


def analyze_criticality(shapes):
    res = []
    p1, p2 = R2(), R2()
    for i in range(len(shapes)):
        for j in range(i + 1, len(shapes)):
            for e1 in shapes[i].segments:
                for e2 in shapes[j].segments:
                    x = intersection_curve_segments(e1, e2, p1, p2)
                    if x != 0:
                        res.append((e1, e2, x))
                        print(e1)
                        print(e2)
                        print(repr(e1))
                        print(repr(e2))
                        print('res = ', x)
                        plot_segment(e1)
                        plot_segment(e2, show=1)

    return res


def analyze(swhs):
    from math import log10
    lengths_lin = [
     0] * 40
    lengths_arc = [0] * 40
    lengths_circles = [0] * 40

    def ana_shape(shape):
        if len(shape.segments) > 1:
            for i in range(len(shape.segments)):
                seg = shape.segments[i]
                assert seg.length > 0
                ll = int(log10(seg.length)) + 20
                if seg.is_arc:
                    lengths_arc[ll] += 1
                else:
                    lengths_lin[ll] += 1

        else:
            if not len(shape.segments) == 1:
                raise AssertionError
            else:
                seg = shape.segments[0]
                assert seg.is_arc
            l = abs(seg.R) * 6.283186
            ll = int(log10(l)) + 20
            lengths_circles[ll] += 1

    for swh in swhs:
        ana_shape(swh.shape)
        for hole in swh.holes:
            ana_shape(hole)

    n_arcs = n_lins = n_circles = 0
    for i in range(len(lengths_arc)):
        n = lengths_arc[i] + lengths_lin[i] + lengths_circles[i]
        if n > 0:
            n_lins += lengths_lin[i]
            n_arcs += lengths_arc[i]
            n_circles += lengths_circles[i]

    n_segs = n_arcs + n_lins + n_circles
    return n_segs


def shapes_from_swhs(swhs):
    shapes = []
    for swh in swhs:
        if swh.empty():
            pass
        else:
            shapes.append(swh.shape)
            for hole in swh.holes:
                shapes.append(hole)

    return shapes


def shapes_from_swhs_or_shapes(swhs):
    shapes = []
    for swh in swhs:
        if isinstance(swh, Shape):
            shapes.append(swh)
        else:
            if swh.empty():
                pass
            else:
                shapes.append(swh.shape)
                for hole in swh.holes:
                    shapes.append(hole)

    return shapes


def shape_from_segm_list():
    from common.utils2d import R2, CurveSegment, ArrayCurveSegment
    import re
    flag = False
    s = '{'
    print('get segment list: ')
    while flag == False:
        a = input()
        if len(a) == 0:
            flag = True
        else:
            s += a + '\n'

    s += '}'
    ss = re.sub('#.*\\n', ' ', s)
    segl = eval(ss)
    segs = ArrayCurveSegment(0)
    for seg in list(segl.values()):
        segs.push_back(seg)

    res = Shape(segs)
    return res


def boolean_add(shapes, bbox=None, healing_tol=1.0, check_arcs=1, use_boolean_add=0, clipping=None, n=None):
    for i in range(5):
        try:
            res = boolean_add__(shapes, bbox=bbox, healing_tol=healing_tol, check_arcs=1, use_boolean_add=use_boolean_add,
              clipping=clipping,
              n=n)
            break
        except Exception as inst:
            print(inst)
            res = (None, None, None)
            print('WARNING: Planeprocessor failed once.')
            continue

    if res[0] == None:
        print('ERROR: Planeprocessor failed.')
    return res


def boolean_add__(shapes, bbox=None, healing_tol=1.0, check_arcs=1, use_boolean_add=0, clipping=None, n=None):
    import time
    from common.utils2d import decompress_shape, compress_shape
    tstart = time.clock()
    if not isinstance(shapes, vectorShapeWithHoles):
        tmp = vectorShapeWithHoles()
        for s in shapes:
            if not isinstance(s, CShapeWithHoles):
                s = CShapeWithHoles(s)
            tmp.append(s)

        shapes = tmp
    if len(shapes) == 0:
        return (vectorShapeWithHoles(), vectorShapeWithHoles(), None)
    else:
        planeproc = Planeprocessor(bbox, healing_tol)
        if clipping is not None:
            planeproc.clip_mode(clipping)
        tadd = time.clock()
        planeproc.add_shapes(shapes)
        swhs = planeproc.boolean_add()
        print('Result: %d shape(s) with %d hole(s).' % (len(swhs), reduce(lambda a, b: a + b.n_holes, swhs, 0)))
        theal = time.clock()
        erroneous_swhs = []
        if len(planeproc.via_intersections) > 0:
            print('WARNING: some via holes have been cut,  at positions:')
            for p in planeproc.via_intersections:
                print('\t', p)

        if verbose:
            if planeproc:
                print('PP DIAGNOSTICS:\n', planeproc.diagnostics())
        print('[Time for boolean add(%d): %g s]' % (planeproc.used_boolean_add, time.clock() - tstart))
        return (
         swhs, erroneous_swhs, planeproc)


def clip(swhs, clipping_shape, bbox=None, healing_tol=1.0, check_arcs=1, clip_index=999999999):
    """
    Clip collection of swhs to area defined by clipping_shape.
    Return new collection of swhs.
    """
    print('[Clipping.]')
    if 0:
        if len(shapes) > 1:
            for shape in shapes:
                print('SHAPE=========')
                for i0 in range(len(shape.segments) - 1):
                    if i0 == 0:
                        i = len(shape.segments) - 1
                        j = 0
                    else:
                        i = i0
                        j = i + 1
                    si, sj = shape.segments[i], shape.segments[j]
                    print('TANGENT %d-%d' % (i, j), '= ', si.tangent(1).cross(sj.tangent(0)))

                plot_Shape(shape, filled=0, show=0)

            plot_Shape(shape, filled=0, show=1)
    swhs_clipped, erroneous_swhs, planeproc = boolean_add(swhs, bbox=bbox,
      check_arcs=1,
      use_boolean_add=2,
      healing_tol=healing_tol,
      clipping=clipping_shape)
    return (
     swhs_clipped, erroneous_swhs, planeproc)


def write_erroneous_shape(filename, shapes):
    """
    Write pp debug info to file.
    """
    file = open(filename, 'w')
    for cshape in shapes:
        swh = cshape.to_ShapeWithHoles()
        print('Shape:\n', (swh.shape), file=file)
        for hole in swh.holes:
            print('Hole:\n', hole, file=file)

    file.close()
    from common import Tools
    Tools.savedata([cswh for cswh in shapes], filename + '.bin')


def report_united_nets(planeproc, layoutdb):
    if planeproc is None:
        return
    unauxs = planeproc.report_united_nets()
    if len(unauxs) == 0:
        return
    print('United the following nets:')
    for unaux in unauxs:
        print('\t%s <- %s at position %s' % (
         layoutdb.index2net(unaux.netnow), layoutdb.index2net(unaux.netold), str(unaux.pref)))
# okay decompiling utils.pyc
