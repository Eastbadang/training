# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\common\shapemanager.py
# Compiled at: 2018-09-10 18:20:28
# Size of source mod 2**32: 48078 bytes
"""
Provides basic functionality for building shapes from different kinds of
origins.
"""
geom_tol = 0

def create_standart_shapes(name, params):
    import math
    from common.utils2d import R2, CurveSegment, ArrayCurveSegment, Shape, ShapeWithHoles, CircleShape, Make_CClockwise, Make_Clockwise, vectorShapeWithHoles, CShapeWithHoles, BoundingBox, Planeprocessor, segment2shape
    from common import utils2d

    def get_Planeprocessor_WithShapes(os, symb, symb_hole, gap, angle, angle_sp):
        hs = [
         symb_hole]
        h0 = utils2d.Rectangle(gap, os * math.sqrt(2) + os / 10)
        h0.translate(R2(-gap / 2.0, 0))
        Make_Clockwise(h0)
        h0.rotate(-2 * math.pi / 4 + 2 * math.pi * angle / 360, R2())
        for i in range(num_sp):
            h0.rotate(angle_sp, R2())
            hs.append(h0.clone())

        vhs = vectorShapeWithHoles()
        vhs.append(CShapeWithHoles(symb))
        for h in hs:
            vhs.append(CShapeWithHoles(h))

        pp = Planeprocessor(BoundingBox(-(os * math.sqrt(2) + os / 8), os * math.sqrt(2) + os / 8, -(os * math.sqrt(2) + os / 8), os * math.sqrt(2) + os / 8), 0.0001)
        pp.add_shapes(vhs)
        res = pp.boolean_add2()
        return [r.to_ShapeWithHoles() for r in res]

    def compute_round_off(a, b, c, r):
        if r == 0:
            return [(c, 0)]
        else:
            acrossb = (a - c).cross(b - c)
            if acrossb == 0:
                return [
                 (
                  c, 0)]
            if (a - c).getNorm() < r or (b - c).getNorm() < r:
                return [
                 (
                  c, 0)]
            ua = (a - c) / (a - c).getNorm()
            ub = (b - c) / (b - c).getNorm()
            cosphi = ua.dot(ub)
            phi = math.acos(cosphi)
            l = r / math.tan(phi / 2)
            a1 = c + ua * l
            b1 = c + ub * l
            if acrossb > 0:
                ua.turn_left()
                ub.turn_right()
            else:
                ua.turn_right()
                ub.turn_left()
            m1 = a1 + ua * r
            m2 = b1 + ub * r
            m = (m1 + m2) / 2.0
            if acrossb > 0:
                t = 1.0
            else:
                t = -1.0
            return [
             (
              a1, 0), (m, r * t), (b1, 0)]

    def seg2swh(seg, w):
        cshape = segment2shape(seg, w, 0, True)
        return cshape.to_ShapeWithHoles()

    def computeXY4gap(R, gap, angle):
        phi = math.asin(gap * 0.5 / R)
        x = R * math.cos(phi + angle)
        y = R * math.sin(phi + angle)
        return (x, y)

    def get_R2_from_R_angle(R, phi, angle):
        x = R * math.cos(phi + angle)
        y = R * math.sin(phi + angle)
        return R2(x, y)

    def replaceXY(p):
        return R2(p.y, p.x)

    def get_gap_end(Ri, Ro, hgap, angle, round_endind):
        angle_1 = math.pi * angle / 180
        if round_endind:
            Rc = (Ri + Ro) / 2.0
            phi = math.asin(hgap / Rc)
            po = get_R2_from_R_angle(Ro, phi, angle_1)
            pc = get_R2_from_R_angle(Rc, phi, angle_1)
            pi = get_R2_from_R_angle(Ri, phi, angle_1)
            res = [pi, pc, po]
            return res
        else:
            phii = math.asin(hgap / Ri)
            pi = get_R2_from_R_angle(Ri, phii, angle_1)
            phio = math.asin(hgap / Ro)
            po = get_R2_from_R_angle(Ro, phio, angle_1)
            res = [pi, po]
            return res

    def compute_gap_end(Ri, Ro, gap, angle, round_endind):
        if not round_corners:
            pi, po = get_gap_end(Ri, Ro, gap, angle, round_endind)
            pc = R2(0, 0)
        else:
            gap = gap + hw
            pi, pc, po = get_gap_end(Ri, Ro, gap, angle, round_endind)
        return (
         pi, pc, po, gap)

    def add_xmirror_xycr(xycr):
        res = []
        res.extend(xycr)
        xycr.reverse()
        for p, R in xycr:
            res.append((R2(p.x * -1.0, p.y), R))

        return res

    try:
        if name == 'Circle':
            R = params[0] * 0.5
            if R > 0:
                return [utils2d.CircleShape(R2(0, 0), R)]
            else:
                return []
        else:
            if name == 'Square':
                wh = params[0]
                assert wh > 0
                return [utils2d.RectangleC(wh, wh)]
            else:
                if name == 'Rect':
                    w, h = params
                    assert w > 0 and h > 0
                    return [utils2d.RectangleC(w, h)]
                if name == 'RectCorner':
                    llx, lly, urx, ury = params
                    w = urx - llx
                    h = ury - lly
                    ur = R2(urx, ury)
                    ll = R2(llx, lly)
                    c = (ur + ll) / 2
                    return [utils2d.RectangleC(w, h, c)]
                if name == 'Oval':
                    w, h = params
                    assert w > 0 and h > 0
                    if w != h:
                        if w > h:
                            a = R2((w - h) * 0.5, 0)
                            w = h
                        else:
                            a = R2(0, (h - w) * 0.5)
                        b = -a
                        return [
                         utils2d.PolyarcShape(utils2d.straight_path_segment_to_XYR(a, b, w))]
                    else:
                        return [
                         utils2d.CircleShape(R2(0, 0), w * 0.5)]
                else:
                    if name == 'Octagon':
                        w, h, r = params
                        assert w > 0 and h > 0 and r <= w / 2 and r <= h / 2
                        w *= 0.5
                        h *= 0.5
                        xys = [R2(-w, h - r), R2(-w + r, h), R2(w - r, h), R2(w, h - r), R2(w, -h + r), R2(w - r, -h), R2(-w + r, -h), R2(-w, -h + r)]
                        xys.reverse()
                        return [utils2d.PolylineShape(xys)]
                    else:
                        if name == 'Octagon_l':
                            l = params[0]
                            assert l > 0
                            size_lenght = math.cos(67.5 * math.pi / 180.0) * l
                            r = math.sin(67.5 * math.pi / 180.0) * size_lenght
                            l = l / 2.0
                            xys = [R2(0, -l), R2(r, -r), R2(l, 0), R2(r, r), R2(0, l), R2(-r, r), R2(-l, 0), R2(-r, -r)]
                            return [utils2d.PolylineShape(xys)]
                        else:
                            if name == 'Hexagon':
                                l = params[0]
                                assert l > 0
                                w = math.cos(30.0 * math.pi / 180.0) * 5
                                l = l / 2.0
                                xys = [R2(0, l), R2(w, l / 2.0), R2(w, -l / 2.0), R2(0, -l), R2(-w, -l / 2.0), R2(-w, l / 2.0)]
                                return [utils2d.PolylineShape(xys)]
                            else:
                                if name == 'Hexagon_l':
                                    w, h, r = params
                                    assert w > 0 and h > 0 and r <= w / 2 and r <= h / 2
                                    w *= 0.5
                                    h *= 0.5
                                    xys = [R2(-w, 0), R2(-w + r, h), R2(w - r, h), R2(w, 0), R2(w - r, -h), R2(-w + r, -h)]
                                    xys.reverse()
                                    return [utils2d.PolylineShape(xys)]
                                else:
                                    if name == 'Hexagon_s':
                                        w, h, r = params
                                        assert w > 0 and h > 0 and r <= w / 2 and r <= h / 2
                                        w *= 0.5
                                        h *= 0.5
                                        xys = [R2(-w, -h + r), R2(-w, h - r), R2(0, h), R2(w, h - r), R2(w, -h + r), R2(0, -h)]
                                        xys.reverse()
                                        return [utils2d.PolylineShape(xys)]
                                    if name == 'HalfOval':
                                        w, h = params
                                        assert w > 0 and h > 0
                                        w2, h2 = w * 0.5, h * 0.5
                                        xyrs = [(R2(-w2, -h2), 0), (R2(w2 - h2, -h2), 0), (R2(w2 - h2, 0), -h2), (R2(w2 - h2, h2), 0), (R2(-w2, h2), 0), (R2(-w2, -h2), 0)]
                                        return [utils2d.PolyarcShape(xyrs)]
                                    if name == 'Triangle':
                                        b, h = params
                                        assert b > 0 and h > 0
                                        b *= 0.5
                                        h *= 0.5
                                        xys = [R2(-b, -h), R2(0, h), R2(b, -h)]
                                        xys.reverse()
                                        return [utils2d.PolylineShape(xys)]
                                if name == 'RoundButterfly':
                                    s = params[0]
                                    assert s > 0
                                    s *= 0.5
                                    xysr1 = [(R2(0, s), 0), (R2(0, 0), -s), (R2(-s, 0), 0), (R2(0, 0), 0)]
                                    xysr2 = [(R2(0, 0), 0), (R2(0, -s), 0), (R2(0, 0), -s), (R2(s, 0), 0)]
                                    return [utils2d.PolyarcShape(xysr1), utils2d.PolyarcShape(xysr2)]
                            if name == 'SquareButterfly':
                                s = params[0]
                                assert s > 0
                                s *= 0.5
                                xys1 = [R2(0, 0), R2(0, s), R2(-s, s), R2(-s, 0)]
                                xys2 = [R2(0, -s), R2(s, -s), R2(s, 0), R2(0, 0)]
                                return [utils2d.PolylineShape(xys1), utils2d.PolylineShape(xys2)]
                        if name == 'Diamond':
                            w, h = params
                            assert w > 0 and h > 0
                            w *= 0.5
                            h *= 0.5
                            xys = [R2(w, 0), R2(0, h), R2(-w, 0), R2(0, -h)]
                            return [utils2d.PolylineShape(xys)]
                    if name == 'NPolygon':
                        R, n = params
                        dphi = 2.0 * math.pi / n
                        p1 = R2(R, 0)
                        p1.turn(dphi / 2)
                        xys = []
                        for i in range(int(n)):
                            xys.append(p1 * 1)
                            p1.turn(dphi)

                        return [utils2d.PolylineShape(xys)]
            if name in ('RectCham', 'RectRound'):
                w, h, rad, corners = params
                assert w > 0 and h > 0
                w2, h2 = w * 0.5, h * 0.5
                rounded = name == 'RectRound'
                if rad == 0:
                    return [
                     utils2d.RectangleC(w, h)]
                if rad > w2 or rad > h2:
                    print('WARNING: rounded/chamfered rectangle %s with wrong syntax[2] (assuming regular rectangle)' % name)
                    print(w, h, rad, corners)
                    return [
                     utils2d.RectangleC(w, h)]
                else:
                    xyrs = []
                    if '1' in corners:
                        xyrs.append(R2(w2, h2 - rad))
                        if rounded:
                            xyrs.append((R2(w2 - rad, h2 - rad), -rad))
                        xyrs.append(R2(w2 - rad, h2))
                    else:
                        xyrs.append(R2(w2, h2))
                    if '2' in corners:
                        xyrs.append(R2(-w2 + rad, h2))
                        if rounded:
                            xyrs.append((R2(-w2 + rad, h2 - rad), -rad))
                        xyrs.append(R2(-w2, h2 - rad))
                    else:
                        xyrs.append(R2(-w2, h2))
                    if '3' in corners:
                        xyrs.append(R2(-w2, -h2 + rad))
                        if rounded:
                            xyrs.append((R2(-w2 + rad, -h2 + rad), -rad))
                        xyrs.append(R2(-w2 + rad, -h2))
                    else:
                        xyrs.append(R2(-w2, -h2))
                    if '4' in corners:
                        xyrs.append(R2(w2 - rad, -h2))
                        if rounded:
                            xyrs.append((R2(w2 - rad, -h2 + rad), -rad))
                        xyrs.append(R2(w2, -h2 + rad))
                    else:
                        xyrs.append(R2(w2, -h2))
                    if rounded:
                        tmp = []
                        for xyr in xyrs:
                            if type(xyr) == tuple:
                                tmp.append(xyr)
                            else:
                                tmp.append((xyr, 0))

                        return [
                         utils2d.PolyarcShape(tmp)]
                    return [utils2d.PolylineShape(xyrs)]
            else:
                if name == 'RoundDonut':
                    od, id = params
                    assert od > 0 and id >= 0
                    res = ShapeWithHoles()
                    res.shape = create_standart_shapes('Circle', [od])[0]
                    res.holes.append(create_standart_shapes('Circle', [id])[0])
                    return [res]
                else:
                    if name == 'SquareDonut':
                        od, id = params
                        assert od > 0 and id >= 0
                        res = ShapeWithHoles()
                        res.shape = create_standart_shapes('Square', [od])[0]
                        res.holes.append(create_standart_shapes('Square', [id])[0])
                        return [res]
                    else:
                        if name == 'RectangleDonut':
                            ow, oh, lw = params
                            assert ow > 0 and oh > 0 and lw > 0 and lw < ow / 2 and lw < oh / 2
                            res = ShapeWithHoles()
                            res.shape = create_standart_shapes('Rect', [ow, oh])[0]
                            res.holes.append(create_standart_shapes('Rect', [ow - 2.0 * lw, oh - 2.0 * lw])[0])
                            return [res]
                        else:
                            if name == 'SquareRoundDonut':
                                od, id = params
                                assert od > 0 and id >= 0 and od > id
                                res = ShapeWithHoles()
                                res.shape = create_standart_shapes('Square', [od])[0]
                                res.holes.append(create_standart_shapes('Circle', [id])[0])
                                return [res]
                            else:
                                if name == 'RoundedSquareDonut':
                                    od, id, rad, corners = params
                                    res = ShapeWithHoles()
                                    res.shape = create_standart_shapes('RectRound', [od, od, rad, corners])[0]
                                    res.holes.append(create_standart_shapes('RectRound', [id, id, rad, corners])[0])
                                    return [res]
                                else:
                                    if name == 'RoundedRectangleDonut':
                                        ow, oh, lw, rad, corners = params
                                        res = ShapeWithHoles()
                                        res.shape = create_standart_shapes('RectRound', [ow, oh, rad, corners])[0]
                                        res.holes.append(create_standart_shapes('RectRound', [ow - 2.0 * lw, oh - 2.0 * lw, rad, corners])[0])
                                        return [res]
                                    else:
                                        if name == 'OvalDonut':
                                            ow, oh, lw = params
                                            assert ow > 0 and oh > 0 and lw > 0 and lw < ow / 2 and lw < oh / 2
                                            res = ShapeWithHoles()
                                            res.shape = create_standart_shapes('Oval', [ow, oh])[0]
                                            res.holes.append(create_standart_shapes('Oval', [ow - 2.0 * lw, oh - 2.0 * lw])[0])
                                            return [res]
                                        else:
                                            if name == 'HexagonDonut':
                                                od, id = params
                                                assert od > 0 and id >= 0
                                                res = ShapeWithHoles()
                                                res.shape = create_standart_shapes('Hexagon', [od])[0]
                                                res.holes.append(create_standart_shapes('Hexagon', [id])[0])
                                                return [res]
                                            else:
                                                if name == 'OctagonDonut':
                                                    od, id = params
                                                    assert od > 0 and id >= 0
                                                    res = ShapeWithHoles()
                                                    res.shape = create_standart_shapes('Octagon_l', [od])[0]
                                                    res.holes.append(create_standart_shapes('Octagon_l', [id])[0])
                                                    return [res]
                                                if name == 'RoundThermal':
                                                    od, id, angle, num_spokes, gap = params
                                                    assert od > id and id > 0 and num_spokes > 0 and gap > 0
                                                    rmin, rmax, g2 = id * 0.5, od * 0.5, gap * 0.5
                                                    dphi = 2.0 * math.pi / num_spokes
                                                    x0 = R2(math.sqrt(rmin * rmin - g2 * g2), g2)
                                                    x1 = R2(math.sqrt(rmax * rmax - g2 * g2), g2)
                                                    x2, x3 = R2(x1.x, -x1.y), R2(x0.x, -x0.y)
                                                    x2.turn(dphi)
                                                    x3.turn(dphi)
                                                    xyrs = [(x0, 0), (x1, 0), (R2(0, 0), -rmax), (x2, 0), (x3, 0), (R2(0, 0), rmin), (R2(x0), 0)]
                                                    spoke = utils2d.PolyarcShape(xyrs)
                                                    res = [spoke]
                                                    for i in range(1, num_spokes):
                                                        res.append(spoke.clone())

                                                    for i in range(num_spokes):
                                                        res[i].rotate(i * dphi + angle, R2(0, 0))

                                                    return res
                                                if name == 'RoundThermalRoundet':
                                                    od, id, angle, num_spokes, gap = params
                                                    assert od > id and id > 0 and num_spokes > 0 and gap > 0
                                                    dphi = 2.0 * math.pi / num_spokes
                                                    R = (od + id) / 4.0
                                                    w = (od - id) / 2.0
                                                    phi = math.asin((w + gap) * 0.5 / R)
                                                    x1 = R * math.cos(phi)
                                                    y1 = R * math.sin(phi)
                                                    x2 = R * math.cos(dphi - phi)
                                                    y2 = R * math.sin(dphi - phi)
                                                    seg = CurveSegment(R2(x1, y1), R2(x2, y2), R2(0, 0), R)
                                                    spoke = seg2swh(seg, w)
                                                    res = [spoke]
                                                    for i in range(1, num_spokes):
                                                        res.append(spoke.clone())

                                                    for i in range(num_spokes):
                                                        res[i].rotate(i * dphi + angle, R2(0, 0))

                                                    return res
                                            if name == 'SquareThermal':
                                                od, id, angle, num_sp, gap = params
                                                assert od > 0 and id >= 0 and od > id
                                                if num_sp > 0:
                                                    angle_sp = 2 * math.pi / num_sp
                                                else:
                                                    angle_sp = 0
                                                symb = create_standart_shapes('Square', [od])[0]
                                                Make_CClockwise(symb)
                                                symb_hole = create_standart_shapes('Square', [id])[0]
                                                return get_Planeprocessor_WithShapes(od, symb, symb_hole, gap, angle, angle_sp)
                                        if name == 'HexagonThermal':
                                            od, id, angle, num_sp, gap = params
                                            assert od > 0 and id >= 0 and od > id
                                            if num_sp > 0:
                                                angle_sp = 2 * math.pi / num_sp
                                            else:
                                                angle_sp = 0
                                            symb = create_standart_shapes('Hexagon', [od])[0]
                                            Make_CClockwise(symb)
                                            symb_hole = create_standart_shapes('Hexagon', [id])[0]
                                            return get_Planeprocessor_WithShapes(od, symb, symb_hole, gap, angle, angle_sp)
                                    if name == 'OctagonThermal':
                                        od, id, angle, num_sp, gap = params
                                        assert od > 0 and id >= 0 and od > id
                                        if num_sp > 0:
                                            angle_sp = 2 * math.pi / num_sp
                                        else:
                                            angle_sp = 0
                                        symb = create_standart_shapes('Octagon_l', [od])[0]
                                        Make_CClockwise(symb)
                                        symb_hole = create_standart_shapes('Octagon_l', [id])[0]
                                        return get_Planeprocessor_WithShapes(od, symb, symb_hole, gap, angle, angle_sp)
                                if name == 'SquareRoundThermal':
                                    os, id, angle, num_sp, gap = params
                                    assert os > 0 and id >= 0 and os > id
                                    if num_sp > 0:
                                        angle_sp = 2 * math.pi / num_sp
                                    else:
                                        angle_sp = 0
                                    symb = create_standart_shapes('Square', [os])[0]
                                    Make_CClockwise(symb)
                                    symb_hole = create_standart_shapes('Circle', [id])[0]
                                    return get_Planeprocessor_WithShapes(os, symb, symb_hole, gap, angle, angle_sp)
                            if name == 'RoundedSquareThermal':
                                os, id, angle, num_sp, gap, rad, corners = params
                                assert os > 0 and id >= 0 and os > id
                                if num_sp > 0:
                                    angle_sp = 2 * math.pi / num_sp
                                else:
                                    angle_sp = 0
                                if rad != 0:
                                    symb = create_standart_shapes('RectRound', [os, os, rad, corners])[0]
                                else:
                                    symb = create_standart_shapes('Square', [os])[0]
                                Make_CClockwise(symb)
                                symb_hole = create_standart_shapes('Square', [id])[0]
                                return get_Planeprocessor_WithShapes(os, symb, symb_hole, gap, angle, angle_sp)
                        if name == 'RectangularThermalOpenCorners':
                            w, h, angle, num_sp, gap, lw = params
                            w *= 0.5
                            h *= 0.5
                            gap *= 0.5
                            assert w > 0 and h >= 0 and lw < min(w, h)
                            if num_sp == 0:
                                return create_standart_shapes('RectangleDonut', [w * 2, h * 2, lw * 2])
                            if num_sp == 1:
                                if angle == 0 or angle % 180 == 0:
                                    xys = [
                                     R2(w, gap), R2(w, h), R2(-w, h), R2(-w, -h), R2(w, -h), R2(w, -gap), R2(w - lw, -gap), R2(w - lw, -h + lw), R2(-w + lw, -h + lw), R2(-w + lw, h - lw), R2(w - lw, h - lw), R2(w - lw, gap)]
                                    res = utils2d.PolylineShape(xys)
                                    if angle % 360 == 180:
                                        res.x_mirror()
                                        Make_CClockwise(res)
                                    return [res]
                                else:
                                    if angle % 90 == 0:
                                        xys = [
                                         R2(-gap, h), R2(-w, h), R2(-w, -h), R2(w, -h), R2(w, h), R2(gap, h), R2(gap, h - lw), R2(w - lw, h - lw), R2(w - lw, -h + lw), R2(-w + lw, -h + lw), R2(-w + lw, h - lw), R2(-gap, h - lw)]
                                        res = utils2d.PolylineShape(xys)
                                        if angle % 360 == 270:
                                            res.y_mirror()
                                            Make_CClockwise(res)
                                        return [
                                         res]
                                    if angle % 45 == 0:
                                        xys = [
                                         R2(w - (lw + gap * math.sqrt(2)), h - lw), R2(w - (lw + gap * math.sqrt(2)), h), R2(-w, h), R2(-w, -h), R2(w, -h), R2(w, h - (lw + gap * math.sqrt(2))), R2(w - lw, h - (lw + gap * math.sqrt(2))), R2(w - lw, -h + lw), R2(-w + lw, -h + lw), R2(-w + lw, +h - lw)]
                                        res = utils2d.PolylineShape(xys)
                                        if angle % 360 == 135:
                                            res.x_mirror()
                                        else:
                                            if angle % 360 == 225:
                                                res.x_mirror()
                                                res.y_mirror()
                                            else:
                                                if angle % 360 == 315:
                                                    res.y_mirror()
                                        Make_CClockwise(res)
                                        return [res]
                                    print('angle %f is for  this shapes not allowed' % angle)
                                    return []
                            else:
                                if num_sp == 2:
                                    if angle == 0 or angle % 180 == 0:
                                        xys = [
                                         R2(w, gap), R2(w, h), R2(-w, h), R2(-w, gap), R2(-w + lw, gap), R2(-w + lw, h - lw), R2(w - lw, h - lw), R2(w - lw, gap)]
                                        res = utils2d.PolylineShape(xys)
                                        res2 = res.clone()
                                        res2.y_mirror()
                                        Make_CClockwise(res2)
                                        return [
                                         res, res2]
                                    else:
                                        if angle % 90 == 0:
                                            xys = [
                                             R2(-gap, h), R2(-w, h), R2(-w, -h), R2(-gap, -h), R2(-gap, -h + lw), R2(-w + lw, -h + lw), R2(-w + lw, h - lw), R2(-gap, h - lw)]
                                            res = utils2d.PolylineShape(xys)
                                            res2 = res.clone()
                                            res2.x_mirror()
                                            Make_CClockwise(res2)
                                            return [res, res2]
                                        if angle % 45 == 0:
                                            xys = [
                                             R2(w - (lw + gap * math.sqrt(2)), h - lw), R2(w - (lw + gap * math.sqrt(2)), h), R2(-w, h), R2(-w, -h + (lw + gap * math.sqrt(2))), R2(-w + lw, -h + (lw + gap * math.sqrt(2))), R2(-w + lw, h - lw)]
                                            res = utils2d.PolylineShape(xys)
                                            res = utils2d.PolylineShape(xys)
                                            res2 = res.clone()
                                            res2.x_mirror()
                                            res2.y_mirror()
                                            if angle % 180 == 135:
                                                res.y_mirror()
                                                Make_CClockwise(res)
                                                res2.y_mirror()
                                                Make_CClockwise(res2)
                                            return [
                                             res, res2]
                                        print('angle %f is for  this shapes not allowed' % angle)
                                        return []
                                else:
                                    if num_sp == 4:
                                        if angle == 0 or angle % 90 == 0:
                                            xys = [
                                             R2(-gap, h), R2(-w, h), R2(-w, gap), R2(-w + lw, gap), R2(-w + lw, h - lw), R2(-gap, h - lw)]
                                            res1 = utils2d.PolylineShape(xys)
                                            res2 = res1.clone()
                                            res2.x_mirror()
                                            Make_CClockwise(res2)
                                            res3 = res1.clone()
                                            res3.y_mirror()
                                            Make_CClockwise(res3)
                                            res4 = res2.clone()
                                            res4.y_mirror()
                                            Make_CClockwise(res4)
                                            return [
                                             res1, res2, res3, res4]
                                        else:
                                            if angle % 45 == 0:
                                                xys1 = [
                                                 R2(w - (lw + gap * math.sqrt(2)), h - lw), R2(w - (lw + gap * math.sqrt(2)), h), R2(-w + (lw + gap * math.sqrt(2)), h), R2(-w + (lw + gap * math.sqrt(2)), h - lw)]
                                                xys2 = [R2(-w + lw, -h + (lw + gap * math.sqrt(2))), R2(-w + lw, h - (lw + gap * math.sqrt(2))), R2(-w, h - (lw + gap * math.sqrt(2))), R2(-w, -h + (lw + gap * math.sqrt(2)))]
                                                res1 = utils2d.PolylineShape(xys1)
                                                res2 = utils2d.PolylineShape(xys2)
                                                res3 = res1.clone()
                                                res3.y_mirror()
                                                Make_CClockwise(res3)
                                                res4 = res2.clone()
                                                res4.x_mirror()
                                                Make_CClockwise(res4)
                                                return [res1, res2, res3, res4]
                                            print('angle %f is for  this shapes not allowed' % angle)
                                            return []
                                    else:
                                        print('num_spokes %f is for  this shapes not allowed' % num_sp)
                                        return []
                        else:
                            if name == 'OvalThermal':
                                ow, oh, angle, num_sp, gap, lw = params
                                assert ow > 0 and oh >= 0 and lw < min(ow, oh) / 2
                                if num_sp > 0:
                                    angle_sp = 2 * math.pi / num_sp
                                else:
                                    angle_sp = 0
                                symb = create_standart_shapes('Oval', [ow, oh])[0]
                                Make_CClockwise(symb)
                                symb_hole = create_standart_shapes('Oval', [ow - 2 * lw, oh - 2 * lw])[0]
                                Make_Clockwise(symb_hole)
                                return get_Planeprocessor_WithShapes(max(ow, oh), symb, symb_hole, gap, angle, angle_sp)
                            if name == 'RoundedRectangleThermal':
                                ow, oh, angle, num_sp, gap, lw, rad, corners = params
                                assert ow > 0 and oh >= 0 and lw < min(ow, oh) / 2
                                if num_sp > 0:
                                    angle_sp = 2 * math.pi / num_sp
                                else:
                                    angle_sp = 0
                                symb = create_standart_shapes('RectRound', [ow, oh, rad, corners])[0]
                                Make_CClockwise(symb)
                                symb_hole = create_standart_shapes('RectRound', [ow - 2 * lw, oh - 2 * lw, rad, corners])[0]
                                Make_Clockwise(symb_hole)
                                return get_Planeprocessor_WithShapes(max(ow, oh), symb, symb_hole, gap, angle, angle_sp)
                    if name == 'RectangularThermal':
                        w, h, angle, num_sp, gap, lw = params
                        assert w > 0 and h >= 0 and lw < min(w, h)
                        if num_sp == 0:
                            return create_standart_shapes('RectangleDonut', [w, h, lw])
                        if num_sp == 1:
                            if angle == 0 or angle % 90 == 0:
                                return create_standart_shapes('RectangularThermalOpenCorners', [w, h, angle, num_sp, gap, lw])
                            else:
                                if angle % 45 == 0:
                                    w *= 0.5
                                    h *= 0.5
                                    gap *= 0.5
                                    assert w > 0 and h >= 0 and lw < min(w, h)
                                    xys = [R2(w - (lw + gap * math.sqrt(2)), h - lw), R2(w - gap * math.sqrt(2), h), R2(-w, h), R2(-w, -h), R2(w, -h), R2(w, h - gap * math.sqrt(2)), R2(w - lw, h - (lw + gap * math.sqrt(2))), R2(w - lw, -h + lw), R2(-w + lw, -h + lw), R2(-w + lw, h - lw)]
                                    res = utils2d.PolylineShape(xys)
                                    if angle % 360 == 135:
                                        res.x_mirror()
                                    else:
                                        if angle % 360 == 225:
                                            res.x_mirror()
                                            res.y_mirror()
                                        else:
                                            if angle % 360 == 315:
                                                res.y_mirror()
                                    Make_CClockwise(res)
                                    return [res]
                                print('angle %f is for  this shapes not allowed' % angle)
                                return []
                        else:
                            if num_sp == 2:
                                if angle == 0 or angle % 90 == 0:
                                    return create_standart_shapes('RectangularThermalOpenCorners', [w, h, angle, num_sp, gap, lw])
                                else:
                                    if angle % 45 == 0:
                                        w *= 0.5
                                        h *= 0.5
                                        gap *= 0.5
                                        assert w > 0 and h >= 0 and lw < min(w, h)
                                        xys = [R2(w - (lw + gap * math.sqrt(2)), h - lw), R2(w - gap * math.sqrt(2), h), R2(-w, h), R2(-w, -h + gap * math.sqrt(2)), R2(-w + lw, -h + (lw + gap * math.sqrt(2))), R2(-w + lw, h - lw)]
                                        res = utils2d.PolylineShape(xys)
                                        res = utils2d.PolylineShape(xys)
                                        res2 = res.clone()
                                        res2.x_mirror()
                                        res2.y_mirror()
                                        if angle % 180 == 135:
                                            res.y_mirror()
                                            Make_CClockwise(res)
                                            res2.y_mirror()
                                            Make_CClockwise(res2)
                                        return [
                                         res, res2]
                                    print('angle %f is for  this shapes not allowed' % angle)
                                    return []
                            else:
                                if num_sp == 4:
                                    if angle == 0 or angle % 90 == 0:
                                        return create_standart_shapes('RectangularThermalOpenCorners', [w, h, angle, num_sp, gap, lw])
                                    else:
                                        if angle % 45 == 0:
                                            w *= 0.5
                                            h *= 0.5
                                            gap *= 0.5
                                            assert w > 0 and h >= 0 and lw < min(w, h)
                                            xys1 = [R2(w - (lw + gap * math.sqrt(2)), h - lw), R2(w - gap * math.sqrt(2), h), R2(-w + gap * math.sqrt(2), h), R2(-w + (lw + gap * math.sqrt(2)), h - lw)]
                                            xys2 = [R2(-w + lw, -h + (lw + gap * math.sqrt(2))), R2(-w + lw, h - (lw + gap * math.sqrt(2))), R2(-w, h - gap * math.sqrt(2)), R2(-w, -h + gap * math.sqrt(2))]
                                            res1 = utils2d.PolylineShape(xys1)
                                            res2 = utils2d.PolylineShape(xys2)
                                            res3 = res1.clone()
                                            res3.y_mirror()
                                            Make_CClockwise(res3)
                                            res4 = res2.clone()
                                            res4.x_mirror()
                                            Make_CClockwise(res4)
                                            return [res1, res2, res3, res4]
                                        print('angle %f is for  this shapes not allowed' % angle)
                                        return []
                                else:
                                    print('num_spokes %f is for  this shapes not allowed' % num_sp)
                                    return []
                    else:
                        if name == 'Moire':
                            rw, rg, nr, lw, ll, la = params
                            vhs = vectorShapeWithHoles()
                            for i in range(1, nr + 1):
                                so = CircleShape(R2(0, 0), i * (rg + rw))
                                Make_CClockwise(so)
                                vhs.append(CShapeWithHoles(so))
                                si = CircleShape(R2(0, 0), i * rg + (i - 1) * rw)
                                Make_Clockwise(si)
                                vhs.append(CShapeWithHoles(si))

                            ov1 = create_standart_shapes('Oval', [ll, lw])[0]
                            ov1.rotate(-2 * math.pi / 4 + 2 * math.pi * la / 360, R2())
                            Make_CClockwise(ov1)
                            vhs.append(CShapeWithHoles(ov1))
                            ov2 = ov1.clone()
                            ov2.rotate(2 * math.pi / 4, R2())
                            Make_CClockwise(ov2)
                            vhs.append(CShapeWithHoles(ov2))
                            bbs = max(nr * (rw + rg), ll / 2)
                            bbs += bbs * 0.1
                            pp = Planeprocessor(BoundingBox(-bbs, bbs, -bbs, bbs), 0.0001)
                            pp.add_shapes(vhs)
                            res = pp.boolean_add2()
                            res2 = [r.to_ShapeWithHoles() for r in res]
                            return res2
                        else:
                            if name == 'HomePlate':
                                w, h, c, ra, ro = params
                                if c > w:
                                    print('Symbol with violated limitations in definition', name, w, h, c, ra, ro)
                                    return []
                                else:
                                    w *= 0.5
                                    h *= 0.5
                                    p1, p2, p3, p4, p5 = (R2(-w, h), R2(w - c, h), R2(w, 0), R2(w - c, -h), R2(-w, -h))
                                    xysr = []
                                    xysr.extend(compute_round_off(p1, p3, p2, ro))
                                    xysr.extend(compute_round_off(p2, p4, p3, ra))
                                    xysr.extend(compute_round_off(p3, p5, p4, ro))
                                    xysr.extend(compute_round_off(p4, p1, p5, ra))
                                    xysr.extend(compute_round_off(p5, p2, p1, ra))
                                    return [
                                     utils2d.PolyarcShape(xysr)]
                            else:
                                if name == 'InvertedHomePlate':
                                    w, h, c, ra, ro = params
                                    if c >= w:
                                        print('Symbol with violated limitations in definition', name, w, h, c, ra, ro)
                                        return []
                                    else:
                                        w *= 0.5
                                        h *= 0.5
                                        p1, p2, p3, p4, p5 = (R2(-w, h), R2(w, h), R2(w - c, 0), R2(w, -h), R2(-w, -h))
                                        xysr = []
                                        xysr.extend(compute_round_off(p1, p3, p2, ra))
                                        xysr.extend(compute_round_off(p2, p4, p3, ro))
                                        xysr.extend(compute_round_off(p3, p5, p4, ra))
                                        xysr.extend(compute_round_off(p4, p1, p5, ra))
                                        xysr.extend(compute_round_off(p5, p2, p1, ra))
                                        return [
                                         utils2d.PolyarcShape(xysr)]
                                if name == 'FlatHomePlate':
                                    w, h, hc, vc, ra, ro = params
                                    if hc >= w or vc >= h / 2.0:
                                        print('Symbol with violated limitations in definition', name, w, h, hc, vc, ra, ro)
                                        return []
                                    else:
                                        w *= 0.5
                                        h *= 0.5
                                        p1, p2, p3, p4, p5, p6 = (R2(-w, h), R2(w - hc, h), R2(w, vc / 2.0), R2(w, -vc / 2.0), R2(w - hc, -h), R2(-w, -h))
                                        xysr = []
                                        xysr.append((p2, 0))
                                        xysr.extend(compute_round_off(p2, p4, p3, ro))
                                        xysr.extend(compute_round_off(p3, p5, p4, ro))
                                        xysr.append((p5, 0))
                                        xysr.extend(compute_round_off(p5, p1, p6, ra))
                                        xysr.extend(compute_round_off(p6, p2, p1, ra))
                                        return [
                                         utils2d.PolyarcShape(xysr)]
                            if name == 'RadiusedInvertedHomePlate':
                                w, h, ms, ra = params
                                if ms >= w or ms > h or ra > (h - ms) / 0.5 or ra > ms:
                                    print('Symbol with violated limitations in definition', name, w, h, ms, ra)
                                    return []
                                else:
                                    p1, p2, p3, p4, p5 = (R2(-w, -h), R2(-w, h), R2(w, h), R2(w, ms), R2(w - ms, ms))
                                    p6, p7, p8, p9 = (R2(w - ms, 0), R2(w - ms, -ms), R2(w, -ms), R2(w, -h))
                                    xysr = []
                                    xysr.extend(compute_round_off(p9, p2, p1, ra))
                                    xysr.extend(compute_round_off(p1, p3, p2, ra))
                                    xysr.extend(compute_round_off(p2, p4, p3, ra))
                                    xysr.extend(compute_round_off(p3, p5, p4, ra))
                                    xysr.append((p5, 0))
                                    xysr.append((p6, -ms))
                                    xysr.append((p7, 0))
                                    xysr.extend(compute_round_off(p7, p9, p8, ra))
                                    xysr.extend(compute_round_off(p8, p1, p9, ra))
                                    return [
                                     utils2d.PolyarcShape(xysr)]
                        if name == 'RadiusedHomePlate':
                            w, h, r, ra = params
                            if r > w or r > h / 2.0:
                                print('Symbol with violated limitations in definition', name, w, h, r, ra)
                                return []
                            else:
                                w *= 0.5
                                h *= 0.5
                                p1, p2, p3, p4 = (R2(-w, h), R2(w, h), R2(w, -h), R2(-w, -h))
                                xysr = []
                                xysr.extend(compute_round_off(p1, p3, p2, r))
                                xysr.extend(compute_round_off(p2, p4, p3, r))
                                xysr.extend(compute_round_off(p3, p1, p4, ra))
                                xysr.extend(compute_round_off(p4, p2, p1, ra))
                                return [
                                 utils2d.PolyarcShape(xysr)]
                if name == 'Cross':
                    w, h, hs, vs, hc, vc, sr, ra = params
                    if hs >= h or vs >= w or ra >= min(hs, vs):
                        print('Symbol with violated limitations in definition', name, w, h, hs, vs, hc, vc, sr, ra)
                        return []
                    w *= 0.5
                    h *= 0.5
                    hc = -w + hc
                    vc = -h + vc
                    hs *= 0.5
                    vs *= 0.5
                    p1, p2, p3, p4, p5, p6 = (R2(-w, vc - hs), R2(-w, vc + hs), R2(hc - vs, vc + hs), R2(hc - vs, h), R2(hc + vs, h), R2(hc + vs, vc + hs))
                    p7, p8, p9, p10, p11, p12 = (R2(w, vc + hs), R2(w, vc - hs), R2(hc + vs, vc - hs), R2(hc + vs, -h), R2(hc - vs, -h), R2(hc - vs, vc - hs))
                    xysr = []
                    pass_next = False
                    xr = R2(ra, 0)
                    yr = R2(0, ra)
                    if vc - hs <= -h:
                        pass_next = True
                    if hc - vs <= -w:
                        if pass_next:
                            xysr.extend([(R2(-w, h), 0)])
                        else:
                            xysr.extend([(R2(-w, -h), 0), (R2(-w, h), 0)])
                        pass_next = True
                    else:
                        if pass_next:
                            pass_next = False
                        else:
                            xysr.extend(compute_round_off(R2(w, -h), p12 - yr, p11, ra))
                            xysr.extend(compute_round_off(p11, p1, p12, ra))
                            xysr.extend(compute_round_off(p12 - xr, R2(-w, h), p1, ra))
                        if vc + hs >= h:
                            if pass_next:
                                xysr.extend([(R2(w, h), 0)])
                            else:
                                xysr.extend([(R2(-w, h), 0), (R2(w, h), 0)])
                            pass_next = True
                        else:
                            if pass_next:
                                pass_next = False
                            else:
                                xysr.extend(compute_round_off(R2(-w, -h), p3 - xr, p2, ra))
                                xysr.extend(compute_round_off(p2, p4, p3, ra))
                                xysr.extend(compute_round_off(p3 + yr, R2(w, h), p4, ra))
                            if hc + vs >= w:
                                if pass_next:
                                    xysr.extend([(R2(w, -h), 0)])
                                else:
                                    xysr.extend([(R2(w, h), 0), (R2(w, -h), 0)])
                                pass_next = True
                            else:
                                if pass_next:
                                    pass_next = False
                                else:
                                    xysr.extend(compute_round_off(R2(-w, h), p6 + yr, p5, ra))
                                    xysr.extend(compute_round_off(p5, p7, p6, ra))
                                    xysr.extend(compute_round_off(p6 + xr, R2(w, -h), p7, ra))
                        if vc - hs <= -h:
                            if pass_next:
                                xysr.extend([(R2(-w, -h), 0)])
                            else:
                                xysr.extend([(R2(w, -h), 0), (R2(-w, -h), 0)])
                        else:
                            if pass_next:
                                pass_next = False
                            else:
                                xysr.extend(compute_round_off(R2(w, h), p9 + xr, p8, ra))
                                xysr.extend(compute_round_off(p8, p10, p9, ra))
                                xysr.extend(compute_round_off(p9 - yr, R2(-w, -h), p10, ra))
                            return [
                             utils2d.PolyarcShape(xysr)]
                    if name == 'Dogbone':
                        w, h, hs, vs, hc, sr, ra = params
                        if hs >= h / 2.0 or vs >= w or ra > min(hs, vs):
                            print('Symbol with violated limitations in definition', name, w, h, hs, vs, hc, sr, ra)
                            return []
                        else:
                            w *= 0.5
                            h *= 0.5
                            hc = -w + hc
                            vs *= 0.5
                            p1, p2, p3, p4, p5, p6 = (R2(-w, -h + hs), R2(hc - vs, -h + hs), R2(hc - vs, h - hs), R2(-w, h - hs), R2(-w, h), R2(w, h))
                            p7, p8, p9, p10, p11, p12 = (R2(w, h - hs), R2(hc + vs, h - hs), R2(hc + vs, -h + hs), R2(w, -h + hs), R2(w, -h), R2(-w, -h))
                            xysr = []
                            rx = R2(ra, 0)
                            xysr.extend(compute_round_off(p11, p1, p12, ra))
                            if hc - vs > -w:
                                xysr.extend(compute_round_off(p12, p2 - rx, p1, ra))
                                xysr.extend(compute_round_off(p1, p3, p2, ra))
                                xysr.extend(compute_round_off(p2, p4, p3, ra))
                                xysr.extend(compute_round_off(p3 - rx, p5, p4, ra))
                            xysr.extend(compute_round_off(p4, p6, p5, ra))
                            xysr.extend(compute_round_off(p5, p7, p6, ra))
                            if hc + vs < w:
                                xysr.extend(compute_round_off(p6, p8 + rx, p7, ra))
                                xysr.extend(compute_round_off(p7, p9, p8, ra))
                                xysr.extend(compute_round_off(p8, p10, p9, ra))
                                xysr.extend(compute_round_off(p9 + rx, p11, p10, ra))
                            xysr.extend(compute_round_off(p10, p12, p11, ra))
                            return [
                             utils2d.PolyarcShape(xysr)]
                    if name == 'D-Pack':
                        w, h, hg, vg, vn, hn, ra = params
                        hs = (w - hg * (hn - 1)) / hn
                        vs = (h - vg * (vn - 1)) / vn
                        if not (hg < h and vg < w and hs > 0 and vs > 0) or ra > min(hs * 0.5, vs * 0.2):
                            print('Symbol with violated limitations in definition', name, w, h, hg, vg, vn, hn, ra)
                            return []
                        else:
                            shape = create_standart_shapes('RectRound', [hs, vs, ra, '1234'])[0]
                            points = []
                            res = []
                            xstart = -w / 2.0 + hs / 2.0
                            y = -h / 2.0 + vs / 2.0
                            for i in range(hn):
                                x = xstart
                                for j in range(vn):
                                    points.append(R2(x, y))
                                    x += hg + hs

                                y += vs + vg

                            for p in points:
                                s = shape.clone()
                                s.translate(p)
                                res.append(s)

                            return res
                    if name == 'LineThermal':
                        os, id, angle, num_spokes, gap = params
                        if id >= os or num_spokes != 4 or angle != 45:
                            print('Symbol with violated limitations in definition', name, os, id, angle, num_spokes, gap)
                            return []
                        else:
                            w = (os - id) / 2.0
                            hw = (os + id) / 4
                            gap_xy = (w + gap) * math.sqrt(0.5)
                            hl = hw - gap_xy
                            s1 = CurveSegment(R2(-hl, -hw), R2(hl, -hw))
                            s2 = CurveSegment(R2(-hl, hw), R2(hl, hw))
                            s3 = CurveSegment(R2(-hw, -hl), R2(-hw, hl))
                            s4 = CurveSegment(R2(hw, -hl), R2(hw, hl))
                            res = [seg2swh(s1, w), seg2swh(s2, w), seg2swh(s3, w), seg2swh(s4, w)]
                            return res
                    if name == 'OblongThermal':
                        ow, oh, angle, num_spokes, gap, lw, rs = params
                        (num_spokes == 2 and angle in (0, 90) or num_spokes == 4 and angle in (0,
                                                                                               45,
                                                                                               90)) and rs in ('s',
                                                                                                               'r') or print('Symbol with violated limitations in definition', name, os, id, angle, num_spokes, gap)
                        return []
                    else:
                        if ow < oh:
                            if angle == 0:
                                new_angle = 90
                            else:
                                if angle == 90:
                                    new_angle = 0
                                else:
                                    new_angle = 45
                                res = create_standart_shapes('OblongThermal', [oh, ow, new_angle, num_spokes, gap, lw, rs])
                                for s in res:
                                    s.rotate(math.pi / 2.0, R2(0, 0))

                                return res
                            h = oh / 2.0
                            w = ow / 2.0
                            res = []
                            xysr = []
                            hm = w - h
                            Ri = h - lw
                            Ro = h
                            gap1 = gap * 0.5
                            round_corners = rs == 'r'
                            hw = lw * 0.5
                            pm1 = R2(hm, 0)
                            if angle == 0 or num_spokes == 4 and angle == 90:
                                pi, pc, po, gap1 = compute_gap_end(Ri, Ro, gap1, 0, round_corners)
                                need_gap2 = False
                                if num_spokes == 4:
                                    if hm < gap / 2.0:
                                        need_gap2 = True
                                        gap2 = gap * 0.5 - hm
                                        pi2, pc2, po2, gap2 = compute_gap_end(Ri, Ro, gap2, 0, round_corners)
                                        pi2 = replaceXY(pi2)
                                        po2 = replaceXY(po2)
                                        if round_corners:
                                            pc2 = replaceXY(pc2)
                                if need_gap2:
                                    xysr.append((pi2, 0))
                                else:
                                    xysr.append((R2(hm, Ri), 0))
                                xysr.append((pm1, Ri))
                                xysr.append((pi + pm1, 0))
                                if round_corners:
                                    xysr.append((pc + pm1, -hw))
                                xysr.append((po + pm1, 0))
                                xysr.append((pm1, -Ro))
                                if need_gap2:
                                    xysr.append((po2, 0))
                                    if round_corners:
                                        xysr.append((pc2, -hw))
                                    xysr.append((pi2, 0))
                                else:
                                    xysr.append((R2(hm, Ro), 0))
                                    if num_spokes == 4:
                                        xysr.append((R2(gap1, Ro), 0))
                                        if round_corners:
                                            xysr.append((R2(gap1, Ro - hw), -hw))
                                        xysr.append((R2(gap1, Ri), 0))
                                    if num_spokes == 2:
                                        new_xysr = []
                                        new_xysr.extend(xysr)
                                        xysr = add_xmirror_xycr(xysr)
                                    shape = utils2d.PolyarcShape(xysr)
                                    if num_spokes == 2:
                                        res.append(shape)
                                        s2 = shape.clone()
                                        s2.y_mirror()
                                        s2.reverse()
                                        res.append(s2)
                                    else:
                                        res.append(shape.clone())
                                        shape.x_mirror()
                                        shape.reverse()
                                        res.append(shape.clone())
                                        shape.y_mirror()
                                        shape.reverse()
                                        res.append(shape.clone())
                                        shape.x_mirror()
                                        shape.reverse()
                                        res.append(shape.clone())
                                return res
                            if num_spokes == 2:
                                if round_corners:
                                    gap1 = gap1 + hw
                                else:
                                    pi2 = R2(gap1, Ri)
                                    po2 = R2(gap1, Ro)
                                    pc2 = R2(gap1, Ro - hw)
                                    need_gap2 = False
                                    if hm < gap / 2.0:
                                        need_gap2 = True
                                        gap2 = gap * 0.5 - hm
                                        pi2, pc2, po2, gap2 = compute_gap_end(Ri, Ro, gap2, 0, round_corners)
                                        pi2 = replaceXY(pi2)
                                        po2 = replaceXY(po2)
                                        if round_corners:
                                            pc2 = replaceXY(pc2)
                                    if need_gap2:
                                        xysr.append((pi2, 0))
                                    else:
                                        xysr.append((R2(hm, Ri), 0))
                                    xysr.append((pm1, Ri))
                                    if not need_gap2:
                                        xysr.append((R2(hm, -Ri), 0))
                                    xysr.append((R2(pi2.x, pi2.y * -1.0), 0))
                                    if round_corners:
                                        xysr.append((R2(pc2.x, pc2.y * -1.0), -hw))
                                    xysr.append((R2(po2.x, po2.y * -1.0), 0))
                                    if not need_gap2:
                                        xysr.append((R2(hm, -Ro), 0))
                                    xysr.append((pm1, -Ro))
                                    if not need_gap2:
                                        xysr.append((R2(hm, Ro), 0))
                                    xysr.append((po2, 0))
                                    if round_corners:
                                        xysr.append((pc2, -hw))
                                xysr.append((pi2, 0))
                                shape = utils2d.PolyarcShape(xysr)
                                res.append(shape)
                                s2 = shape.clone()
                                s2.x_mirror()
                                s2.reverse()
                                res.append(s2)
                                return res
                            pi, pc, po, gap1 = compute_gap_end(Ri, Ro, gap1, angle, round_corners)
                            pi2 = replaceXY(pi) + pm1
                            po2 = replaceXY(po) + pm1
                            if round_corners:
                                pc2 = replaceXY(pc) + pm1
                                pc = pc + pm1
                            pi, po = pi + pm1, po + pm1
                            xysr1 = []
                            xysr1.append((pi2, 0))
                            xysr1.append((pm1, Ri))
                            xysr1.append((R2(pi2.x, pi2.y * -1.0), 0))
                            if round_corners:
                                xysr1.append((R2(pc2.x, pc2.y * -1.0), -hw))
                        else:
                            xysr1.append((R2(po2.x, po2.y * -1.0), 0))
                            xysr1.append((pm1, -Ro))
                            xysr1.append((po2, 0))
                            if round_corners:
                                xysr1.append((pc2, -hw))
                            shape = utils2d.PolyarcShape(xysr1)
                            res.append(shape)
                            s2 = shape.clone()
                            s2.x_mirror()
                            s2.reverse()
                            res.append(s2)
                            xysr2 = []
                            xysr2.append((R2(hm, Ri), 0))
                            xysr2.append((pm1, Ri))
                            xysr2.append((pi, 0))
                            if round_corners:
                                xysr2.append((pc, -hw))
                        xysr2.append((po, 0))
                        xysr2.append((pm1, -Ro))
                        xysr2.append((R2(hm, Ro), 0))
                        xysr2 = add_xmirror_xycr(xysr2)
                        shape = utils2d.PolyarcShape(xysr2)
                        res.append(shape)
                        s2 = shape.clone()
                        s2.y_mirror()
                        s2.reverse()
                        res.append(s2)
                        return res
                else:
                    return []
    except:
        print('WARNING: shape %s cannot be created because of wrong parameters' % name)
        return []
# okay decompiling shapemanager.pyc
