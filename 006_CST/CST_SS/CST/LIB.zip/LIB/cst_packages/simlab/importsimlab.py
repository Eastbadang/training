# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\simlab\importsimlab.py
# Compiled at: 2019-07-02 16:58:06
# Size of source mod 2**32: 3382 bytes


def Run_dar2(filename, pcbimporter):
    import layoutdbPy
    from common.layoutdb import check_layer_stackup, DatabaseReadError
    from common.units import length_unit_convert
    from os.path import dirname, join, basename, normpath, exists
    from common.layoutdb import read_IRDrop_result
    filename = normpath(filename)
    try:
        res, msg, db = layoutdbPy.import_dar_and_plb(filename)
    except Exception as e:
        raise DatabaseReadError(str(e))
    except:
        raise DatabaseReadError('Unable to read dar file')

    if res < 0:
        raise DatabaseReadError(msg)
    else:
        if res > 0:
            print('WARNING: ' + msg)
    pcbimporter.db = db
    check_layer_stackup(db, add_soldermasks=False)
    ctrfile = None
    s = dirname(filename)
    if basename(s) == 'Design':
        s = dirname(s)
        if basename(s) == 'PCBS':
            s = dirname(s)
            if basename(s) == 'Model':
                s = dirname(s)
                ctrfile = join(s, 'Temp', 'PCBS', 'control.ctr')
                try:
                    therm_los = join(s, 'Result', 'IRDROPRESULTS', 'thermallosses.tlz')
                    if exists(therm_los):
                        proj_name = basename(s)
                        proj_dir = dirname(s)
                        proj_file = join(proj_dir, proj_name + '.cst')
                        if exists(proj_file):
                            db.simulation_settings.subproject_name4thermal_losses_import = proj_file
                            db.simulation_settings.import_thermal_losses_from_subproject = True
                except Exception as e:
                    print('WARNING: cannot read thermal losses ', str(e))

                try:
                    ir_drop_res = join(s, 'Result', 'IRDROPRESULTS', 'irdrop_0Dresults.xml')
                    if exists(ir_drop_res):
                        read_IRDrop_result(ir_drop_res, db.simulation_settings)
                        comp_height = length_unit_convert('mm', 1.0, db.length_unit)
                        hss = db.simulation_settings.heat_sources
                        for i in range(len(hss)):
                            hs = hss[i]
                            hs.height = comp_height
                            hss[i] = hs

                        print('WARNING: No component height are given, set heat sources height default value 1mm.')
                except Exception as e:
                    print('WARNING: cannot read heat souces ', str(e))

    if ctrfile is not None:
        if exists(ctrfile):
            print('Reading PCBS controlfile = ', ctrfile)
            try:
                layoutdbPy.process_simulation_control_file(ctrfile, db)
            except Exception as e:
                print('WARNING:', str(e), ': PCBS simulation settings have been ignored. Please specify manually in the EDA Import Dialog. ')

    return res
# okay decompiling importsimlab.pyc
