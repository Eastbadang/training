# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\altium_plugin\pidc.py
# Compiled at: 2019-03-13 22:01:20
# Size of source mod 2**32: 50975 bytes
import os, sys
from os.path import *
import types, layoutdbPy
RPIN_DEFAULT = 0.0001

def warning(s):
    print('<<warning>>')
    print(s)
    print('<<end>>')


def error(s):
    raise AltiumPluginException(s)


class AltiumPluginException(BaseException):
    pass


def Assert(x):
    if not x:
        import inspect
        s = inspect.currentframe().f_back.f_lineno
        raise AltiumPluginException('internal condition violation in %s' % s)


class Elem:

    def __init__(self, myname):
        self.my_special_name = myname

    def myname(self):
        if hasattr(self, 'my_special_name'):
            return self.my_special_name
        else:
            return self.__class__.__name__


class Param(Elem):

    def __init__(self, name, value):
        self.ID = name
        self.value = value
        self.si_value = value


class StandardModel(Elem):

    def __init__(self, le):
        self.ModelName = 'StandardModel'
        self.Param = []
        self.Param.append(Param('R', le.R))
        self.Param.append(Param('L', le.L))
        self.Param.append(Param('C', le.C))


class Models(Elem):

    def __init__(self, models):
        self.Models = models


class ComponentPart(Elem):

    def __init__(self, name, data):
        if isinstance(data, layoutdbPy.LumpedElementModel):
            le = data
            self.ID = le.name
            self.Name = le.name
            if le.type == layoutdbPy.LEModelType.R_HF:
                self.ElementType = 'Resistor'
                self.PartType = 'SPT_RHF'
            else:
                if le.type == layoutdbPy.LEModelType.C_HF:
                    self.ElementType = 'Capacitor'
                    self.PartType = 'SPT_CHF'
                else:
                    if le.type == layoutdbPy.LEModelType.L_HF:
                        self.ElementType = 'Inductor'
                        self.PartType = 'SPT_LHF'
            self.UsePartReferenceModel = 'no'
            self.LibPartReferenceID = 'Dummy-%s' % le.name
            self.DefaultModelName = 'StandardModel'
            self.NumPins = '2'
            self.Models = Models([StandardModel(le)])
        else:
            model = data
            Assert(hasattr(model, 'pins'))
            pins = model.pins
            del model.pins
            if isinstance(model, IntegratedCircuit):
                self.PartType = 'IntegratedCircuit'
                self.DefaultModelName = 'IntegratedCircuit'
                model.pin = pins
                self.NumPins = len(pins)
            else:
                if isinstance(model, NPin):
                    self.PartType = 'N-PIN'
                    self.DefaultModelName = 'N-Pin'
                    model.Pins = Elem('Pins')
                    model.Pins.Pins = pins
                    self.NumPins = len(pins)
                else:
                    raise AltiumPluginException('The component model could not be processed: %s' % model)
                self.UsePartReferenceModel = 'no'
                self.ElementType = 'Discrete'
                self.Name = name
                self.ID = name
                self.Models = Models([model])


class PCBComponentParts(Elem):

    def __init__(self, lumped_elements, shorts, ics):
        self.format = 'PCBSPartLibrary'
        self.version = '1.0.5'
        self.SIZE = 90
        self.ComponentPart = []
        for le in lumped_elements:
            self.ComponentPart.append(ComponentPart(le.name, le))

        for name, short in shorts:
            self.ComponentPart.append(ComponentPart(name, short))

        for name, ic in ics:
            self.ComponentPart.append(ComponentPart(name, ic))


def build_elem(elem):
    import xml.etree.cElementTree as ET, types
    root = ET.Element(elem.myname())
    for k, v in elem.__dict__.items():
        if type(v) is list:
            for vi in v:
                root.append(build_elem(vi))

        elif isinstance(v, Elem):
            root.append(build_elem(v))
        elif k == 'text':
            root.text = str(v)
        else:
            if k == 'my_special_name':
                pass
            else:
                root.set(k, str(v))

    return root


def write_elem(elem, dest, encoding='UTF-8'):
    import xml.etree.cElementTree as ET
    tree = ET.ElementTree(elem)
    tree.write(dest, encoding, xml_declaration=True)


class Groups(Elem):

    def __init__(self, grs):
        self.Group = grs


class Element(Elem):

    def __init__(self, refdes, pinname, index):
        self.TermName = refdes + '-' + pinname
        self.TermIndex = index


def make_group_name(netname, refdes, something):
    return netname + '-' + refdes + '-' + something


class Group(Elem):

    def __init__(self, refdes, grpname, pins):
        self.Id = grpname
        self.Element = []
        for index in pins:
            self.Element.append(Element(refdes, str(index), index))


class GroupInfo(Elem):

    def __init__(self, grid, ground_id=None):
        self.OwnGroupId = grid
        if ground_id is not None:
            self.GroundGroupId = ground_id


class SignalModel(Elem):

    def __init__(self):
        self.Type = 'PulseSignalModel'


class DoubleValue(Elem):

    def __init__(self, name, val):
        self.Double = val
        self.SIExt = '(none)'
        self.SIValue = val
        self.my_special_name = name


class StringValue(Elem):

    def __init__(self, name, val):
        self.text = val
        self.my_special_name = name


class StupidValue(Elem):

    def __init__(self, name, val):
        self.Value = val
        self.my_special_name = name


class BoolValue(Elem):

    def __init__(self, name, val):
        if val:
            self.text = 'true'
        else:
            self.text = 'false'
        self.my_special_name = name


class PowerModel(Elem):

    def __init__(self, V_supply=None, I_DC=None, resistance=None, Rpin=RPIN_DEFAULT):
        if V_supply is not None:
            self.Type = 'VoltageSourceModel'
            self.VSource = DoubleValue('VSource', V_supply)
            if resistance is None:
                resistance = 0.001
            self.RSource = DoubleValue('RSource', resistance)
            self.RPin = DoubleValue('RPin', Rpin)
            self.LPin = DoubleValue('LPin', 0)
        else:
            if I_DC == 0:
                I_DC = None
            else:
                if (I_DC is None) == (resistance is None):
                    raise AltiumPluginException('Invalid excitation: either current or resistance need to be specified')
                if I_DC is None:
                    I_DC = 0
                    DefinedBy = 'RInternal'
                if resistance is None:
                    resistance = 0.1
                    DefinedBy = 'IDC'
            self.Type = 'CurrentDrainModel'
            self.DefinedBy = StupidValue('DefinedBy', DefinedBy)
            self.IDC = DoubleValue('IDC', float(I_DC))
            self.RInternal = DoubleValue('RInternal', float(resistance))
            self.RPin = DoubleValue('RPin', Rpin)
            self.LPin = DoubleValue('LPin', 0)


class Pin(Elem):

    def __init__(self, refdes, index, typ):
        import layoutdbPy
        self.my_special_name = 'pin'
        self.Name = '%s-%s' % (refdes, index)
        self.Type = typ
        if typ == 'signal':
            self.SignalModel = SignalModel()
        self.Index = index


class ComponentHelper:

    def __init__(self, db, refdes):
        comp = db.component(refdes)
        if comp is None:
            raise AltiumPluginException("component '%s' specified in settings file does not exist in the design" % refdes)
        net2pins = {}
        pin2net = {}
        pinname2pin_and_index = {}
        for i in range(comp.n_pins()):
            pin = comp.pin(i)
            netname = pin.net.name
            pin2net[pin.name] = netname
            if netname not in net2pins:
                net2pins[netname] = []
            net2pins[netname].append(pin.name)
            pinname2pin_and_index[pin.name] = (pin, i)

        self.comp = comp
        self.refdes = refdes
        self.net2pins = net2pins
        self.pin2net = pin2net
        self.pinname2pin_and_index = pinname2pin_and_index


n_vomp = 0

class VirtualComp:

    def __init__(self, id):
        global n_vomp
        self.id = id
        self.name = 'VCOMP%d' % n_vomp
        n_vomp += 1
        self.pin_count = 0
        self.v2o_pin = {}
        self.o2v_pin = {}
        self.v2g = {}

    def add_orig_pin(self, opin, group=None):
        if opin in self.o2v_pin:
            return self.o2v_pin[opin]
        else:
            vpin = self.pin_count
            self.o2v_pin[opin] = vpin
            self.v2o_pin[vpin] = opin
            self.v2g[vpin] = group
            self.pin_count += 1
            return vpin

    def pin2group(self):
        return self.v2g

    def groups(self):
        res = {}
        for v, g in self.v2g.items():
            if g not in res:
                res[g] = []
            res[g].append(v)

        return res

    def n_pins(self):
        return len(self.v2o_pin)


class IntegratedCircuit(Elem):

    def __init__(self, db, vcomp, excitation, voltage_regulator):
        vrm = voltage_regulator
        refdes = vcomp.name
        self.ModelName = 'IntegratedCircuit'
        self.pins = []
        if excitation is not None:
            x = excitation
            Assert(x['type'] in ('source', 'load'))
            power_group_id = 'P-' + vcomp.name
            ground_group_id = 'G-' + vcomp.name
            for opin in x['power_pins']:
                vcomp.add_orig_pin(opin, power_group_id)

            for opin in x['ground_pins']:
                vcomp.add_orig_pin(opin, ground_group_id)

        if voltage_regulator is not None:
            vrm = voltage_regulator
            pingroups = [
             'in', 'out']
            for pg in pingroups:
                gid = 'P-' + pg + vcomp.name
                pins = vrm[pg]
                Assert(len(pins) > 0)
                for opin in pins:
                    vcomp.add_orig_pin(opin, gid)

                vrm['groupname_' + pg] = gid

        self.PinCount = len(vcomp.v2g)
        groups = []
        for grpname, pins in vcomp.groups().items():
            groups.append(Group(vcomp.name, grpname, pins))

        self.Groups = Groups(groups)
        if excitation is not None:
            x = excitation
            voltage_source = None
            if x['type'] == 'source':
                voltage_source = float(x['voltage'])
            resistance = None
            try:
                resistance = float(x['resistance'])
            except:
                pass

            current_drain = None
            if x['type'] == 'load':
                nload_pins = len(x['power_pins'])
                if 'current' in x:
                    current_drain = float(x['current'])
            Rpin = RPIN_DEFAULT
            try:
                Rpin = float(x['Rpin'])
            except:
                pass

            first = True
            for index, grpname in vcomp.v2g.items():
                Assert(grpname[0:2] in ('P-', 'G-'))
                typ = 'power' if grpname.startswith('P') else 'ground'
                p = Pin(vcomp.name, index, typ)
                p.GroupInfo = GroupInfo(grpname, ground_group_id)
                if typ == 'power':
                    if first:
                        p.PowerModel = PowerModel(V_supply=voltage_source, I_DC=current_drain, resistance=resistance, Rpin=Rpin)
                        first = False
                self.pins.append(p)

        if voltage_regulator is not None:
            vrm = voltage_regulator
            Rpin = RPIN_DEFAULT
            try:
                Rpin = float(vrm['Rpin'])
            except:
                pass

            if vrm['type'] == 'linear':
                v2 = float(vrm['v2'])
                Ro = float(vrm['Ro'])
                in_group_id = vrm['groupname_in']
                Vin = 10.0
                Vout = Vin + v2
                for what in ('in', 'out'):
                    for o_refdes, pinname in vrm[what]:
                        index = vcomp.o2v_pin[(o_refdes, pinname)]
                        p = Pin(refdes, index, 'power')
                        p.GroupInfo = GroupInfo(vrm[('groupname_' + what)])
                        p.PowerModel = model = Elem('PowerModel')
                        if what == 'in':
                            model.Type = 'RegulatorSupplyModel'
                            model.VSource = DoubleValue('VSource', Vin)
                        else:
                            model.Type = 'VoltageRegulatorModel'
                            model.VSource = DoubleValue('VSource', v2)
                            model.RSource = DoubleValue('RSource', Ro)
                            model.V_PIN = DoubleValue('V_PIN', Vout)
                            model.SupplyPowerGroupID = spgID = Elem('SupplyPowerGroupID')
                            spgID.ID = in_group_id
                            model.RegulatorType = regT = Elem('RegulatorType')
                            regT.ID = 'ConstantVoltageDrop'
                        model.RPin = DoubleValue('RPin', Rpin)
                        model.LPin = DoubleValue('LPin', 0)
                        self.pins.append(p)

            else:
                raise AltiumPluginException('unsupported VRM type')


class NPin(Elem):

    def __init__(self, vcomp, pinpairs):
        refdes = vcomp.name
        self.PinCount = vcomp.n_pins()
        self.ModelName = 'N-Pin'
        self.ModelInstances = mis = Elem('ModelInstances')
        mis.ModelInstances = []
        pinname2instance_name_pin = {}
        for p1, p2 in pinpairs:
            iname = 'inst_%s-%s-%s' % (refdes, p1, p2)
            le = layoutdbPy.LumpedElementModel()
            le.name = iname
            le.R = 1e-06
            sm = StandardModel(le)
            sm.my_special_name = 'ModelInstance'
            sm.InstanceName = iname
            sm.CirType = 'SPT_RHF'
            sm.isLibrary = 'false'
            sm.Pin = [Elem('Pin'), Elem('Pin')]
            sm.Pin[0].Name = '1'
            sm.Pin[1].Name = '2'
            mis.ModelInstances.append(sm)
            pinname2instance_name_pin[p1] = (iname, '1')
            pinname2instance_name_pin[p2] = (iname, '2')

        pins = []
        groups = []
        for index in list(vcomp.v2o_pin.keys()):
            grouppins = [index]
            groupname = 'G' + refdes + '-%d' % index
            group = Group(refdes, groupname, grouppins)
            if index in pinname2instance_name_pin:
                iname, ipin = pinname2instance_name_pin[index]
                for e in group.Element:
                    e.InstanceName = iname
                    e.InstancePin = ipin

            groups.append(group)
            thepin = Pin(refdes, index, 'signal')
            thepin.GroupInfo = GroupInfo(groupname)
            pins.append(thepin)

        self.Groups = Groups(groups)
        self.pins = pins


class SpecialSettingsParam(Elem):

    def __init__(self, name, value):
        Elem.__init__(self, 'param')
        self.ID = name
        self.Value = value


class PIDC_Manager(object):

    def __init__(self, db, **args):
        self.db = db
        self.args = args
        self.virtual_components = {}
        self.set_net_types(args['powerNets'], args['groundNets'])
        Assert('excitation' in args)
        self.excitation = self.preprocess_excitation(args['excitation'])
        self.apply_tech(args['tech'])
        if 'explicit_pin_layers' in args:
            self.set_explicit_pin_layers(args['explicit_pin_layers'])
        passives = args['passives'] if 'passives' in args else []
        if type(passives) == dict:
            passives = self.preprocss_passives(passives)
        self.create_passives(passives)
        self.create_shorts(args['shorts'] if 'shorts' in args else [])
        vrms = args['voltage_regulators'] if 'voltage_regulators' in args else []
        self.create_ICs(self.excitation, vrms)
        self.switch_to_virtual_comps()

    def set_net_types(self, powernets, groundnets):
        import layoutdbPy
        db = self.db
        for p in powernets:
            net = db.net(p)
            net.type = layoutdbPy.NetType.Power

        for p in groundnets:
            net = db.net(p)
            net.type = layoutdbPy.NetType.GND

        self.simulated_nets = powernets + groundnets

    def preprocess_excitation(self, excitation):
        xs = []
        for x in excitation:
            if type(x) == dict:
                xs.append(x)
            else:
                Assert(type(x) == list)
                y = dict()
                powerNet, refdes, pins, groundNet, supplied_voltage, I_DC = x[:6]
                if len(x) > 6:
                    y['resistance'] = x[6]
                if pins == 'All':
                    y['power_pins'] = [
                     (
                      refdes, 'All', powerNet)]
                else:
                    if type(pins) in (tuple, list):
                        pins = list(pins)
                    else:
                        if type(pins) == str:
                            pins = [
                             pins]
                        else:
                            raise AltiumPluginException('Processing excitation of component %s failed' % refdes)
                        y['power_pins'] = [(refdes, pin) for pin in pins]
                y['ground_pins'] = [
                 (
                  refdes, 'All', groundNet)]
                if len(supplied_voltage) > 0:
                    y['type'] = 'source'
                    y['voltage'] = float(supplied_voltage)
                else:
                    y['type'] = 'load'
                if len(I_DC) > 0:
                    y['current'] = I_DC
                xs.append(y)

        for x in xs:
            self.expand_pin_list(x['power_pins'], layoutdbPy.NetType.Power)
            self.expand_pin_list(x['ground_pins'], layoutdbPy.NetType.GND)

        return xs

    def expand_pin_list(self, list_of_pintuples, net_type):
        Assert(type(list_of_pintuples) == list)
        to_expand = []
        for tup in list_of_pintuples[:]:
            if len(tup) != 2:
                list_of_pintuples.remove(tup)
                to_expand.append(tup)
            else:
                Assert(len(tup) == 2)

        for tup in to_expand:
            list_of_pintuples += self.expand_pin_tuple(tup, net_type=net_type)

    def expand_pin_tuple(self, pintuple, net_type=None):
        list_of_pintuples = []
        Assert(type(pintuple) == tuple)
        tup = pintuple
        refdes = tup[0]
        refdes = refdes.upper()
        comp = self.db.component(refdes)
        if comp is None:
            raise AltiumPluginException("component '%s' specified in the solver input does not exist in the design" % refdes)
        else:
            if len(tup) == 2:
                pinname = tup[1]
                pin = comp.pin(pinname)
                if pin is None:
                    raise AltiumPluginException("component pin '%s-%s' specified in the solver input does not exist in the design" % (
                     refdes, pinname))
                list_of_pintuples = [tup]
            else:
                if len(tup) == 1:
                    Assert(net_type is not None)
                    for i in range(comp.n_pins()):
                        pin = comp.pin(i)
                        if pin.net is not None and pin.net.type == net_type:
                            list_of_pintuples.append((refdes, pin.name))

                else:
                    Assert(len(tup) > 2)
                    Assert(tup[1] == 'All')
                    nets = list(tup)[2:]
                    for i in range(comp.n_pins()):
                        pin = comp.pin(i)
                        if pin.net is not None and pin.net.name in nets:
                            list_of_pintuples.append((refdes, pin.name))

        return list_of_pintuples

    def apply_tech(self, tech):
        db = self.db
        if type(tech) != list:
            warning('tech data has been ignored')
            return
        sotmp = sys.stdout
        sys.stdout = sys.__stdout__
        names_seen = set()
        for ldata in tech:
            name = ldata['name']
            if name in names_seen:
                error("Layer name '%s' used multiple times in stackup" % name)
            names_seen.add(name)
            l = db.layer(name)
            if l is None:
                continue
            errmsg = 'error in tech data for layer %s' % name
            if 'Conductivity' in ldata:
                cond = ldata['Conductivity']
                if l.material.type != layoutdbPy.MaterialType.Conductor:
                    warning(errmsg)
                else:
                    l.material.condtan = float(cond)
                if 'DielectricConstant' in ldata:
                    diel = ldata['DielectricConstant']
                    if l.material.type != layoutdbPy.MaterialType.Dielectric:
                        warning(errmsg)
                    else:
                        l.material.eps = float(diel)
                if 'Thickness' in ldata:
                    th = float(ldata['Thickness'])
                    from common.units import length_unit_convert
                    l.thickness = length_unit_convert('m', th, db.length_unit)

        sys.stdout = sotmp

    def set_explicit_pin_layers(self, explicit_pin_layers):
        db = self.db
        for entry in explicit_pin_layers:
            Assert(len(entry) >= 2)
            refdes = entry[0]
            comp = db.component(refdes)
            if comp is None:
                raise AltiumPluginException("component '%s' specified in the solver input does not exist in the design" % refdes)
            layername = entry[1]
            layer = db.layer(layername)
            if layer is None:
                raise AltiumPluginException("layer '%s' specified in the solver input does not exist in the design" % layername)
            if len(entry) >= 3:
                pins = []
                for i in range(2, len(entry)):
                    pin = comp.pin(entry[i])
                    if pin is None:
                        raise AltiumPluginException("component pin '%s-%s' specified in the solver input does not exist in the design" % (refdes, entry[i]))
                    pins.append(pin)

            else:
                pins = [comp.pin(i) for i in range(comp.n_pins())]
            for pin in pins:
                pin.layer = layer

    def preprocss_passives(self, passives):
        new_passives = []
        db = self.db
        for refdes, value in passives.items():
            comp = db.component(refdes)
            if comp is None:
                error('Component %s not contained in layout, but used in list of passives.' % refdes)
            else:
                pins = []
                for i in range(comp.n_pins()):
                    pin = comp.pin(i)
                    Assert(pin is not None)
                    pins.append((refdes, pin.name))

                Assert(len(pins) == 2)
                np = {'pins':pins, 
                 'value':value}
                new_passives.append(np)

        return new_passives

    def create_passives(self, passives):
        import layoutdbPy
        Assert(type(passives) == list)
        db = self.db
        for comp in db.components():
            comp.em_model = ''

        db.part_model_db = pdb = layoutdbPy.PartModelDB()
        items = []
        for passive in passives:
            pins = passive['pins']
            value = passive['value']
            Assert(len(pins) == 2)
            pin1, pin2 = pins
            id = passive['id'] if 'id' in passive else None
            vcomp = VirtualComp(id)
            vcomp.add_orig_pin(pin1)
            vcomp.add_orig_pin(pin2)
            self.virtual_components[vcomp.name] = vcomp
            refdes = vcomp.name
            partname = refdes
            vcomp.em_model = partname
            if value.upper().endswith('ROHMS'):
                typ = 'R'
                value = value[:-5]
            else:
                if value.upper().endswith('OHMS'):
                    typ = 'R'
                    value = value[:-4]
                    if value == '0':
                        value = '0.001'
                        warning('replaced short by 1 milli-Ohms resistance for %s' % refdes)
                else:
                    if value.upper().endswith('HENRY'):
                        typ = 'L'
                        value = value[:-5]
                    else:
                        error("Unable to interpret value '%s' of passive %s" % (value, refdes))
                        continue
            items.append((refdes, partname, typ, value))

        from common.layoutdb import create_lumped_element_table
        lumped_element_list, refdes_to_lumped_element, warnings = create_lumped_element_table(items)
        for le in lumped_element_list:
            pdb.add_lumped_element(le)

        if warnings:
            s = 'There were some warnings reading the list of passives:\n'
            for w in warnings:
                s += '\t' + w + '\n'

            warning(s)
        self.lumped_elements = lumped_element_list

    def create_shorts(self, shorts):
        db = self.db
        short_comps = []
        for short in shorts:
            pinpairs = short['pinpairs']
            id = short['id'] if 'id' in short else None
            vcomp = VirtualComp(id)
            vpinpairs = []
            for p1, p2 in pinpairs:
                pins = self.expand_pin_tuple(p1)
                pins += self.expand_pin_tuple(p2)
                vpins = []
                for refdes, pinname in pins:
                    vpin = vcomp.add_orig_pin((refdes, pinname))
                    vpins.append(vpin)

                Assert(len(vpins) >= 2)
                for i in range(len(vpins) - 1):
                    vpinpairs.append((vpins[i], vpins[(i + 1)]))

            self.virtual_components[vcomp.name] = vcomp
            short_comps.append((vcomp.name, NPin(vcomp, vpinpairs)))

        self.shorted_comps = short_comps

    def add_quiescent_current_sources_from_VRMs(self, vrms):
        for vrm in vrms:
            refdes, ins, refs = vrm['refdes'], vrm['in'], vrm['ref']
            Iqu = float(vrm['i1'])
            x = {'type':'load', 
             'power_pins':[(refdes, in_) for in_ in ins], 
             'ground_pins':[(refdes, ref) for ref in refs], 
             'current':Iqu}
            self.excitation.append(x)

    def create_ICs(self, excitation, voltage_regulators):
        db = self.db
        if len(excitation) == 0:
            raise AltiumPluginException('Missing excitation')
        self.ics = ics = []
        for item in excitation:
            id = item['id'] if 'id' in item else None
            vcomp = VirtualComp(id)
            model = IntegratedCircuit(db, vcomp, item, None)
            ics.append((vcomp.name, model))
            self.virtual_components[vcomp.name] = vcomp

        for vrm in voltage_regulators:
            id = vrm['id'] if 'id' in vrm else None
            vcomp = VirtualComp(id)
            self.expand_pin_list((vrm['in']), net_type=None)
            self.expand_pin_list((vrm['out']), net_type=None)
            model = IntegratedCircuit(db, vcomp, None, vrm)
            ics.append((vcomp.name, model))
            self.virtual_components[vcomp.name] = vcomp

    def create_plb_file(self, plbfile):
        db = self.db
        cps = PCBComponentParts(self.lumped_elements, self.shorted_comps, self.ics)
        elem = build_elem(cps)
        write_elem(elem, plbfile)
        import altium_pluginPy
        res = altium_pluginPy.check_passives_in_plb(plbfile, db.part_model_db)
        if res != 'OK':
            s = 'Some passives could not be translated to the CST database.\n' + res
            error(s)

    def create_control_file(self, controlfile, darfile, plbfile):
        db = self.db
        control = Elem('ControlData')
        control.format = 'PCBSSimulationControllFile'
        control.analysis = 'IR_DROP'
        wdir = dirname(controlfile)
        control.WorkingDir = StringValue('WorkingDir', wdir)
        tmpdir = join(wdir, 'tmp-solverccd')
        if not os.path.exists(tmpdir):
            os.mkdir(tmpdir)
        control.TmpDir = StringValue('TmpDir', tmpdir)
        outdir = join(wdir, 'IRDROPRESULTS')
        if not os.path.exists(outdir):
            os.mkdir(outdir)
        control.OutputDir = StringValue('OutputDir', outdir)
        control.ResultsDir = StringValue('ResultsDir', outdir)
        logfile = join(outdir, 'logfile.log')
        control.LogFile = StringValue('LogFile', logfile)
        control.DarFile = StringValue('DarFile', darfile)
        control.PlbFile = StringValue('PlbFile', plbfile)
        control.AltiumJSONFile = BoolValue('isAltium', True)
        control.TcfFileName = StringValue('TcfFileName', 'peecmodel.tcf')
        control.VBAFile = StringValue('VBAFile', darfile + '.vbacommand.mrc')
        import copy
        ics = copy.deepcopy(self.ics)
        groups = []
        for name, ic in ics:
            groups.extend(ic.Groups.Group)

        for g in groups:
            g.my_special_name = 'TerminalGroup'

        control.TerminalGroups = Groups(groups)
        control.TerminalGroups.my_special_name = 'TerminalGroups'
        power_supply_terminals = []
        ic_terminals = []
        voltage_regulator_terminals = []
        groups_covered = {}
        for name, ic in ics:
            for pin in ic.pin:
                if pin.Type == 'power':
                    if hasattr(pin, 'PowerModel'):
                        groupid = pin.GroupInfo.OwnGroupId
                        if groupid in groups_covered:
                            continue
                        groups_covered[groupid] = True
                        p = pin.PowerModel
                        if p.Type == 'VoltageSourceModel':
                            pin.my_special_name = 'Term'
                            power_supply_terminals.append(pin)
                            pin.RSource = p.RSource
                            pin.VSource = p.VSource
                            pin.RPin = p.RPin
                            pin.LPin = p.LPin
                            delattr(pin, 'PowerModel')
                        else:
                            if p.Type == 'RegulatorSupplyModel':
                                pass
                            else:
                                if p.Type == 'VoltageRegulatorModel':
                                    pin.my_special_name = 'Term'
                                    voltage_regulator_terminals.append(pin)
                                    pin.RSource = p.RSource
                                    pin.VSource = p.VSource
                                    pin.RPin = p.RPin
                                    pin.LPin = p.LPin
                                    pin.SupplyPowerGroupID = p.SupplyPowerGroupID
                                    pin.RegulatorType = p.RegulatorType
                                    delattr(pin, 'PowerModel')
                                else:
                                    if p.Type == 'CurrentDrainModel':
                                        pin.my_special_name = 'Term'
                                        ic_terminals.append(pin)
                                    else:
                                        raise AltiumPluginException('unknown pin type: ' + str(p.Type))

        control.Terminals = Elem('Terminals')
        control.Terminals.power_supply_terminals = Groups(power_supply_terminals)
        control.Terminals.power_supply_terminals.my_special_name = 'PowerSupplyTerminals'
        control.Terminals.voltage_regulator_terminals = Groups(voltage_regulator_terminals)
        control.Terminals.voltage_regulator_terminals.my_special_name = 'VoltageRegulatorTerminals'
        control.Terminals.ic_terminals = Groups(ic_terminals)
        control.Terminals.ic_terminals.my_special_name = 'IntegratedCircuitTerminals'
        nets = []
        for n in self.simulated_nets:
            nets.append(StringValue('Net', n.upper()))

        control.SelectedNets = Groups(nets)
        control.SelectedNets.my_special_name = 'SelectedNets'
        control.Settings = sett = Elem('Settings')
        sp = Elem('SimulationProject')
        sp.LinkGeometry = 'false'
        sp.SP_Type = 'PCBS'
        sp.CreateSP = 'false'
        sett.SimulationProject = sp
        sett.DirectSolver = BoolValue('DirectSolver', True)
        sett.IsTestsuiteRunning = BoolValue('IsTestsuiteRunning', False)
        sett.dsunits = dsu = Elem('DSUnits')
        dsu.Time = 'Nano'
        dsu.Frequency = 'Giga'
        control.SpecialSettings = spsett = Elem('SpecialSettings')
        spsett.Units = 'mil'
        spsett.param = []
        mm2mil = 39.37007874015748
        ss = {}
        ss['smooth_angle'] = 11.25
        ss['smooth_length'] = 0.25 * mm2mil
        ss['smooth_deviation'] = 0.1 * mm2mil
        ss['channel_width'] = 8 * mm2mil
        ss['mesh_size'] = 1 * mm2mil
        ss['removecutoutsize'] = 2 * mm2mil
        ss['defaultpindiameter'] = 0.25 * mm2mil
        if 'special_settings' in self.args:
            ss.update(self.args['special_settings'])
        for key, val in ss.items():
            spsett.param.append(SpecialSettingsParam(key, str(val)))

        elem = build_elem(control)
        write_elem(elem, controlfile, encoding='windows-1252')

    def switch_to_virtual_comps(self):
        import layoutdbPy
        from utils2dPy import CShapeWithHoles, make_circle_shape, make_rectangle_shape, R2, BoundingBox
        db = self.db
        ocomps = db.components()
        new_comps = []
        pad = layoutdbPy.new_iLPad()
        pad.name = 'dummy!'
        pad.add_shape(CShapeWithHoles(make_circle_shape(R2(0, 0), db.tolerance, True)))
        lps = layoutdbPy.new_iLPadstack()
        lps.pad(layoutdbPy.WhereType.top, layoutdbPy.ConnectType.connect, pad)
        lps.pad(layoutdbPy.WhereType.bottom, layoutdbPy.ConnectType.connect, pad)
        lps.pad(layoutdbPy.WhereType.inner, layoutdbPy.ConnectType.connect, pad)
        for vcomp in list(self.virtual_components.values()):
            comp = layoutdbPy.new_iComponent()
            comp.name = vcomp.name
            bbox = None
            for o, v in vcomp.o2v_pin.items():
                ocomp = db.component(o[0])
                if ocomp is None:
                    raise AltiumPluginException("component '%s' specified in the solver input does not exist in the design" % o[0])
                opin = ocomp.pin(o[1])
                if opin is None:
                    raise AltiumPluginException("pin '%s-%s' specified in the solver input does not exist in the design" % (o[0], o[1]))
                pin = layoutdbPy.Pin()
                pin.name = str(v)
                pin.net = opin.net
                pin.position = opin.position
                pin.layer = layoutdbPy.pin_layer(db, ocomp, opin.name)
                Assert(pin.layer is not None)
                comp.add_pin(pin)
                ps = layoutdbPy.new_iPadstack()
                ps.library_padstack = lps
                ps.position = pin.position
                ps.layer_from = ps.layer_to = pin.layer
                ps.connect(pin.layer, layoutdbPy.ConnectType.connect)
                ps.net = pin.net
                comp.add_padstack(ps)
                if bbox is None:
                    bbox = BoundingBox(pin.position, pin.position)
                else:
                    bbox.extend(pin.position)

            bbox = bbox.extended(100 * db.tolerance, 100 * db.tolerance)
            outline = CShapeWithHoles(make_rectangle_shape(bbox.lower_left(), bbox.upper_right(), 1))
            comp.add_outline_shape(outline)
            if hasattr(vcomp, 'em_model'):
                comp.em_model = vcomp.em_model
            new_comps.append(comp)

        for comp in ocomps:
            for i in range(comp.n_padstacks()):
                ps = comp.padstack(i)
                db.add_padstack(ps)

        db.delete_components()
        for ocomp in new_comps:
            db.add_component(ocomp)

    def postprocess_csv_file(self, filename):
        pin2data = {}
        f = open(filename)
        Assert(f.readline().startswith('refdes;pin;voltage;current;rpin'))
        for l in f:
            l = l.strip()
            if len(l) == 0:
                pass
            else:
                a = l.split(';')
                vrefdes, vpin, voltage, current, rpin = (
                 a[0], a[1], float(a[2]), float(a[3]), float(a[4]))
                Assert(vrefdes.startswith('VCOMP'))
                Assert(vpin.startswith(vrefdes + '-'))
            vpin = vpin[len(vrefdes) + 1:]
            vcomp = self.virtual_components[vrefdes.upper()]
            opin = vcomp.v2o_pin[int(vpin)]
            if opin not in pin2data:
                pin2data[opin] = {'pin':opin,  'voltage':voltage, 
                 'current':current, 
                 'count':1}
            else:
                pd = pin2data[opin]
                pd['voltage'] += voltage
                pd['current'] += current
                pd['count'] += 1

        destdir = os.path.dirname(filename)
        import csv
        pinsfile = os.path.join(destdir, 'pins.csv')
        cfile = csv.writer(open(pinsfile, 'w', newline=''), delimiter=';')
        cfile.writerow(['refdes', 'pin', 'voltage', 'current'])
        for pd in list(pin2data.values()):
            csvline = []
            csvline.append(pd['pin'][0])
            csvline.append(pd['pin'][1])
            csvline.append(pd['voltage'] / pd['count'])
            csvline.append(pd['current'])
            cfile.writerow(csvline)

        with open(join(destdir, 'vpin2pin.csv'), 'w') as (f):
            f.write('vrefdes;vpin;refdes;pin\n')
            for vrefdes, vcomp in self.virtual_components.items():
                for vpin, opin in vcomp.v2o_pin.items():
                    f.write('%s;%s;%s;%s\n' % (vcomp.name, vpin, opin[0], opin[1]))

        with open(join(destdir, 'vcomp2id.csv'), 'w') as (f):
            f.write('vrefdes;id\n')
            for vrefdes, vcomp in self.virtual_components.items():
                f.write('%s;%s\n' % (vcomp.name, vcomp.id))

    def create_debug_output(self, darfilename):
        tmpdir = dirname(darfilename)
        with open(join(tmpdir, 'stackup.csv'), 'w') as (f):
            f.write('layername\n')
            db = self.db
            for l in db.layers():
                f.write('%s\n' % l.name)
# okay decompiling pidc.pyc
