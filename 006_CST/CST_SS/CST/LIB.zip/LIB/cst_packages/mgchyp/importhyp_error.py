# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\mgchyp\importhyp.py
# Compiled at: 2019-02-26 22:11:16
# Size of source mod 2**32: 47517 bytes
Instruction context:
   
 L. 731      1080  LOAD_CONST               None
                1082  STORE_FAST               'in_poly'
                1084  JUMP_BACK           190  'to 190'
->              1086  POP_BLOCK        
              1088_0  COME_FROM_LOOP      172  '172'
"""
This module contains all functionality to create a layoutdb.LayoutDB database from an ODB++ directory tree.
"""
import math, os, string, sys, types
from common.utils2d import R2, Shape, ShapeWithHoles, CShapeWithHoles, CShape, CurveSegment, ArrayCurveSegment, Make_CClockwise
from common.utils2d import Make_Clockwise, make_compressed_swh, decompress_shape, check_shape, segment2shape, CirclePath
from common import utils2d
from common.units import floatmag
from common.layoutdb import DatabaseReadError, check_pin_names
from common.utils2d import ShapeProcessor
import utils2dPy, layoutdbPy, shlex

def my_split(s):
    return shlex.split(s.replace('\\', '\\\\'))


class FileWithPush:

    def __init__(this, file):
        this.file = file
        this.pushed = []
        this.eof = False
        this.line_no = 0

    def readline(this):
        if len(this.pushed) > 0:
            l = this.pushed.pop()
        else:
            l = this.file.readline()
            this.line_no += 1
        if len(l) == 0:
            this.eof = True
        return l

    def push(this, line):
        if len(this.pushed) > 0:
            raise Exception('already pushed:%s' % this.pushed)
        this.pushed.append(line)

    def nextline(this):
        l = this.readline()
        while len(l) == 0 and not this.eof:
            l = this.readline()

        return l

    def skiplines_starting_with(this, s):
        i = len(s)
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            if l.strip()[:i] != s:
                this.push(l)
                return True

    def skiplines_starting_with_tokens(this, tokens):
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            a = l.strip().split()
            if len(a) == 0 or a[0] not in tokens:
                this.push(l)
                return True

    def skip_until_starts_with(this, s):
        i = len(s)
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            l = l.strip()
            if l[:i] == s:
                this.push(l)
                return True

    def skip_empty_lines(this):
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            if len(l.strip()) != 0:
                this.push(l)
                return True

    def __str__(this):
        name = os.path.split(this.file.name)
        name = os.path.join(os.path.split(name[0])[(-1)], name[(-1)])
        return '<File %s, line %d>' % (name, this.line_no)


def make_list(x):
    if type(x) == list:
        return x
    else:
        return [
         x]


def unique_name(s, ss):
    if s in ss:
        s0 = s
        count = 1
        while s in ss:
            s = '%s-%d' % (s0, count)
            count += 1

    ss.add(s)
    return s


class Block:

    def __init__(this):
        this.header = None


class HyperLynxImporter:

    def __init__(this, hypfilename, progressbar=None):
        this.hypfilename = hypfilename
        this.progressbar = progressbar
        import shlex
        this.shlex = shlex.shlex()

    def __del__(this):
        if hasattr(this, 'basepath'):
            del this.basepath

    def find_close_bracket(this, s, openbracket, closebracket):
        count_quotes = 0
        level = 0
        res = ''
        i = 0
        while i < len(s):
            if s[i] == '"':
                if count_quotes % 2 == 0:
                    res += "'"
                    count_quotes += 1
                else:
                    if i + 1 < len(s):
                        if s[(i + 1)] == '"':
                            res += '"'
                            i += 1
                    res += "'"
                    count_quotes += 1
            else:
                res += s[i]
            if s[i] == openbracket:
                if count_quotes % 2 == 0:
                    level += 1
            if s[i] == closebracket:
                if count_quotes % 2 == 0:
                    level -= 1
                    if level <= 0:
                        return res
            i += 1

        return res

    def strip_comment(this, l):
        l = l.strip()
        if l.startswith('{'):
            return this.find_close_bracket(l, '{', '}')
        if l.startswith('('):
            return this.find_close_bracket(l, '(', ')')
        else:
            if l.startswith('}'):
                return l[0]
            return l

    def read_next_block(this, file):
        block = Block()
        file.skip_empty_lines()
        file.skiplines_starting_with('*')
        file.skip_until_starts_with('{')
        if file.eof:
            return block
        else:
            l = file.readline().strip()
            file.push(l)
            assert l[0] == '{'
            block.starts_at = file.line_no
            l = this.strip_comment(l)
            block.header = l.strip('{}')
            block.body = body = []
            level = 0
            while not file.eof:
                file.skip_empty_lines()
                file.skiplines_starting_with('*')
                l = file.readline()
                l = l.strip()
                l = this.strip_comment(l)
                if len(l) == 0:
                    pass
                else:
                    if l.startswith('{'):
                        level += 1
                    if l.endswith('}'):
                        level -= 1
                        if level <= 0:
                            break
                    body.append(l)

            return block

    def parse_BOARD_FILE(this, token, block, db):
        pass

    def parse_VERSION(this, token, block, db):
        this.version = float(token.split('=')[(-1)])
        print('Version of Hyperlynx file: ', this.version)
        if this.version <= 2:
            raise DatabaseReadError('Import of HyperLynx files prior to version 2 is not supported.')

    def parse_UNITS(this, token, block, db):
        from common.units import standardize, get_typical_manufacturing_tolerance
        unit = token.split('=')[(-1)].upper()
        if not unit in ('ENGLISH', 'METRIC'):
            raise AssertionError
        else:
            if unit == 'METRIC':
                db.length_unit = 'cm'
            else:
                if unit == 'ENGLISH':
                    db.length_unit = 'inch'
                else:
                    raise DatabaseReadError('Unsupported unit: %s' % unit)
        db.tolerance = this.tolerance = get_typical_manufacturing_tolerance((db.length_unit), tolmu=1)
        this.sp = ShapeProcessor(db.tolerance)

    def compute_bbox(this, ss):
        assert len(ss) > 0
        from common.utils2d import BoundingBox
        res = BoundingBox(ss[0].get_bounding_box())
        for s in ss:
            res.extend(s.get_bounding_box())

        return res

    def parse_BOARD(this, token, block, db):
        if not 'UNITS' in this.tokens_parsed:
            raise AssertionError
        else:
            count = 0
            segs = ArrayCurveSegment(0)
            for l in block.body[1:]:
                l = l.strip('()')
                count += 1
                a = l.split()
                assert len(a) > 0
                if a[0] == 'PERIMETER_SEGMENT':
                    assert len(a) >= 5
                    x1, y1, x2, y2 = [float(s.split('=')[(-1)]) for s in a[1:5]]
                    p1, p2 = R2(x1, y1), R2(x2, y2)
                    if p1 != p2:
                        seg = CurveSegment(p1, p2)
                        segs.append(seg)
                else:
                    if a[0] == 'PERIMETER_ARC':
                        assert len(a) >= 8
                        x1, y1, x2, y2, xc, yc, R = [float(s.split('=')[(-1)]) for s in a[1:8]]
                        p1, p2, c = R2(x1, y1), R2(x2, y2), R2(xc, yc)
                        seg = CurveSegment(p1, p2, c, R)
                        segs.append(seg)
                    else:
                        print('WARNING: unsupported syntax in line %d:\n' % (block.starts_at + count), l)

            if len(segs) == 0:
                return
            plast = segs[0].a
            shapes = []
            new_shape = ArrayCurveSegment(0)
            for seg in segs:
                if seg.a != plast:
                    if seg.b != plast:
                        shapes.append(new_shape)
                        new_shape = ArrayCurveSegment(0)
                if seg.a != plast:
                    if seg.b == plast:
                        seg.reverse()
                new_shape.append(seg)
                plast = seg.b

            shapes.append(new_shape)
            try:
                outline = Shape(shapes[0])
                board_outline = this.sp(outline, sense=1, info='board outline')
                if board_outline is not None:
                    if len(shapes) > 1:
                        for i in range(1, len(shapes)):
                            if len(shapes[i]) == 1:
                                seg = shapes[i][0]
                                if seg.is_arc:
                                    if seg.a == seg.b:
                                        if seg.c != seg.a:
                                            d = seg.c - seg.a
                                            hole = utils2d.CircleShape(seg.c, d.getNorm())
                            else:
                                hole = Shape(shapes[i])
                            if hole is not None:
                                if hole.sense() == 1:
                                    hole.reverse()
                                board_outline.add_hole(CShape(hole, db.tolerance))

                        board_outline = this.sp(board_outline, sense=1, info='board outline')
                if board_outline is not None:
                    db.board_outline = board_outline
                else:
                    print('WARNING: could not read board outline (taking PCB bounding box instead)')
                    bbox = this.compute_bbox(segs)
                    db.board_outline = utils2d.make_compressed_swh(utils2d.Bbox2Rectangle(bbox))
            except:
                print('WARNING: could not read board outline (taking PCB bounding box instead)')
                bbox = this.compute_bbox(segs)
                db.board_outline = utils2d.make_compressed_swh(utils2d.Bbox2Rectangle(bbox))

    def parse_STACKUP(this, token, block, db):
        from common.layoutdb import check_layer_stackup
        assert 'UNITS' in this.tokens_parsed
        count = 0
        names = set()
        condtan, eps, matname = {}, {}, {}
        this.toplayer, this.bottomlayer = (None, None)
        for l in block.body[1:]:
            l = l.strip('()')
            count += 1
            a = shlex.split(l)
            assert len(a) > 0
            typ = a[0].upper()
            pairs = {}
            for p in a[1:]:
                if '=' in p:
                    a2 = p.split('=')
                    pairs[a2[0].upper()] = a2[1]

            layer = layoutdbPy.new_iLayer()
            is_cond = True
            if typ == 'SIGNAL':
                layer.layer_type = layoutdbPy.LayerType.Signal
            else:
                if typ == 'PLANE':
                    layer.layer_type = layoutdbPy.LayerType.Plane
                else:
                    if typ == 'DIELECTRIC':
                        layer.layer_type = layoutdbPy.LayerType.Dielectric
                        is_cond = False
                    else:
                        print('WARNING: unsupported syntax in line %d:\n' % (block.starts_at + count), l)
                        continue
            if is_cond:
                if this.toplayer is None:
                    this.toplayer = pairs['L']
                this.bottomlayer = pairs['L']
            if 'L' in pairs:
                layer.name = unique_name(pairs['L'], names)
            if 'T' in pairs:
                layer.thickness = float(pairs['T'])
            if 'BR' in pairs:
                assert is_cond
                condtan[layer.name] = float(pairs['BR'])
            if 'ER' in pairs:
                eps[layer.name] = float(pairs['ER'])
            if 'C' in pairs:
                if is_cond:
                    condtan[layer.name] = float(pairs['C'])
                else:
                    eps[layer.name] = float(pairs['C'])
            if 'LT' in pairs:
                if is_cond:
                    condtan[layer.name] = float(pairs['LT'])
            if 'M' in pairs:
                matname[layer.name] = pairs['M']
            if 'PS' in pairs:
                if layer.name not in this.plane_sep_inf['LAYERS']:
                    this.plane_sep_inf['LAYERS'][layer.name] = {}
                this.plane_sep_inf['LAYERS'][layer.name]['stackup_ps'] = float(pairs['PS'])
            db.add_layer_below(layer, layer)
            names.add(layer.name)

        check_layer_stackup(db)
        for l, m in matname.items():
            if m != '':
                l = db.layer(l)
                l.material.name = m

        for l, c in condtan.items():
            l = db.layer(l)
            l.material.condtan = c

        for l, e in eps.items():
            l = db.layer(l)
            l.material.eps = e

    def parse_DEVICES(this, token, block, db):
        if not 'UNITS' in this.tokens_parsed:
            raise AssertionError
        else:
            assert 'STACKUP' in this.tokens_parsed
            this.em_model_items = []
            for l in block.body[1:]:
                l = l.strip('()')
                a = my_split(l)
                assert len(a) > 0
                tok = a[0]
                pairs = {}
                for p in a[1:]:
                    if '=' in p:
                        a2 = p.split('=')
                        pairs[a2[0].upper()] = a2[1]

                comp = layoutdbPy.new_iComponent()
                comp.name = pairs['REF']
                if pairs['L'] == this.toplayer:
                    comp.side = layoutdbPy.WhereType.top
                else:
                    if pairs['L'] == this.bottomlayer:
                        comp.side = layoutdbPy.WhereType.bottom
                    else:
                        print('WARNING: component %s not placed on outer conductor layer' % comp.name)
                typ = comp.name[0].upper()
                if 'NAME' in pairs:
                    partname = pairs['NAME']
                    if 'VAL' in pairs:
                        value = pairs['VAL']
                    else:
                        value = ''
                    this.em_model_items.append((comp.name, partname, typ, value))
                db.add_component(comp)

            from common.layoutdb import set_read_elements
            print('Reading component values...')
            warnings = set_read_elements(db, (this.em_model_items), print_warnings=False)
            print()
            for w in warnings:
                print(w)

            if len(this.em_model_items):
                filename = os.path.splitext(this.hypfilename)[0] + '.csv'
                from common.layoutdb import export_lumped_elements_to_csv
                export_lumped_elements_to_csv(this.em_model_items, filename)
                print('INFO: Created CSV file (' + filename + ') with lumped-element values for review/re-import.')

    def parse_PADSTACK(this, token, block, db):
        if not 'UNITS' in this.tokens_parsed:
            raise AssertionError
        else:
            a = token.split(',')
            drill = 0
            ah = block.header.split(',')
            if len(ah) > 1:
                d = ah[(-1)].strip()
                if len(d):
                    drill = float(d)
            a = a[0].split('=')
            assert len(a) == 2
            lps = layoutdbPy.new_iLPadstack()
            lps.name = a[1]
            if drill > 0:
                lps.via_hole_shape = utils2dPy.make_circle_shape(R2(0, 0), drill * 0.5, True)
            padnames = set()
            layers_present = []
            count = 0
            MDEF_pads = []
            pads_are_deff = []
            has_thermal = []
            for l in block.body[1:]:
                l = l.strip('()')
                count += 1
                if l[0] == "'":
                    import re
                    a = []
                    split_res = re.split("'", l)
                    a.append(split_res[1])
                    l = split_res[2].replace(',', ' ')
                    a.extend(shlex.split(l))
                else:
                    l = l.replace(',', ' ')
                    a = shlex.split(l)
                assert len(a) >= 5
                layer_name, pad_shape, pad_sx, pad_sy, pad_angle = a[:5]
                pad_sx, pad_sy, pad_angle = float(pad_sx), float(pad_sy), float(pad_angle) * math.pi / 180
                thermal_clear_shape, thermal_clear_sx, thermal_clear_sy, thermal_clear_angle, pad_type = (None,
                                                                                                          None,
                                                                                                          None,
                                                                                                          None,
                                                                                                          None)
                if len(a) > 5:
                    if len(a) > 6:
                        assert len(a) == 10
                        thermal_clear_shape, thermal_clear_sx, thermal_clear_sy, thermal_clear_angle, pad_type = a[5:]
                    else:
                        pad_type = a[5]
                if pad_type is None:
                    if len(a) > 8:
                        pad_type = 'T'
                    else:
                        pad_type = 'M'
                if pad_type == 'M':
                    conn = layoutdbPy.ConnectType.connect
                else:
                    if pad_type == 'T':
                        conn = layoutdbPy.ConnectType.thermal
                        has_thermal.append(layer_name.upper())
                    else:
                        conn = layoutdbPy.ConnectType.clearance
                        this.has_antipads = True
                layer = db.layer(layer_name)
                pads_are_deff.append((layer, conn))
                pad = None
                if pad_shape == '0':
                    if pad_sx == pad_sy == 0:
                        pass
                    else:
                        pad = layoutdbPy.new_iLPad()
                        if drill and drill == pad_sx:
                            if layer:
                                layers_present.append(layer)
                                continue
                            w = pad_sx
                            h = pad_sy
                            assert w > 0 and h > 0
                            if w != h:
                                if w > h:
                                    a = R2((w - h) * 0.5, 0)
                                    w = h
                                else:
                                    a = R2(0, (h - w) * 0.5)
                                b = -a
                                shape = utils2d.PolyarcShape(utils2d.straight_path_segment_to_XYR(a, b, w))
                            else:
                                shape = utils2d.CircleShape(R2(0, 0), w * 0.5)
                            Make_CClockwise(shape)
                            pad.add_shape(CShapeWithHoles(shape))
                if pad_shape == '1' or pad_shape == '2':
                    if pad_sx == pad_sy == 0:
                        continue
                    pad = layoutdbPy.new_iLPad()
                    if pad_shape == '1':
                        pleftlower = R2(-pad_sx * 0.5, -pad_sy * 0.5)
                        prightupper = -pleftlower
                        shape = utils2dPy.make_rectangle_shape(pleftlower, prightupper, True)
                        Make_CClockwise(shape)
                        pad.add_shape(CShapeWithHoles(shape))
                    if pad_shape == '2':
                        w = pad_sx
                        h = pad_sy
                        assert w > 0 and h > 0
                        if w != h:
                            if w > h:
                                a = R2((w - h) * 0.5, 0)
                                w = h
                            else:
                                a = R2(0, (h - w) * 0.5)
                            b = -a
                            shape = utils2d.PolyarcShape(utils2d.straight_path_segment_to_XYR(a, b, w))
                        else:
                            shape = utils2d.CircleShape(R2(0, 0), w * 0.5)
                        Make_CClockwise(shape)
                        pad.add_shape(CShapeWithHoles(shape))
                    if pad is not None:
                        for i in range(pad.n_shapes()):
                            s = pad.shape(i)
                            s.rotate(pad_angle)

                        if layer_name == 'MDEF':
                            MDEF_pads.append((pad, conn))
                            layers_present.append(db.top_etch_layer())
                            layers_present.append(db.bottom_etch_layer())
                        elif layer:
                            layers_present.append(layer)
                            lps.pad(layer, conn, pad)

            for pad, conn in MDEF_pads:
                for i in range(db.n_layers()):
                    layer = db.layer(i)
                    if (layer, conn) not in pads_are_deff:
                        lps.pad(layer, conn, pad)

            if lps.name in this.padstack_names:
                print('WARNING: duplicate padstack', lps.name)
            this.padstack_names.add(lps.name)
            db.add_lpadstack(lps)
            if len(has_thermal):
                this.lpds_has_thermal[lps.name] = has_thermal
            if len(layers_present) > 0:
                lto = lfrom = layers_present[0]
                for l in layers_present:
                    if l.number < lfrom.number:
                        lfrom = l
                    if l.number > lto.number:
                        lto = l

                this.lps2layerspan[lps.name] = (
                 lfrom, lto)

    def parse_PLANE_SEP(this, token, block, db):
        sep = token.split('=')[(-1)].upper()
        sep = float(sep)
        this.plane_sep_inf['PLANE_SEP'] = sep

    def parse_DATA_MODE(this, token, block, db):
        this.data_mode = token.split('=')[(-1)].upper()

    def parse_NET_CLASS(this, token, block, db):
        pass

    def parse_END(this, token, block, db):
        pass

    def parse_NET--- This code section failed: ---

 L. 618         0  LOAD_STR                 'UNITS'
                2  LOAD_FAST                'this'
                4  LOAD_ATTR                tokens_parsed
                6  COMPARE_OP               in
                8  POP_JUMP_IF_TRUE     14  'to 14'
               10  LOAD_ASSERT              AssertionError
               12  RAISE_VARARGS_1       1  'exception'
             14_0  COME_FROM             8  '8'

 L. 622        14  LOAD_FAST                'token'
               16  STORE_FAST               'a'

 L. 623        18  LOAD_FAST                'a'
               20  LOAD_ATTR                startswith
               22  LOAD_STR                 'NET='
               24  CALL_FUNCTION_1       1  '1 positional argument'
               26  POP_JUMP_IF_FALSE    42  'to 42'

 L. 624        28  LOAD_FAST                'a'
               30  LOAD_CONST               4
               32  LOAD_CONST               None
               34  BUILD_SLICE_2         2 
               36  BINARY_SUBSCR    
               38  STORE_FAST               'netname'
               40  JUMP_FORWARD         54  'to 54'
               42  ELSE                     '54'

 L. 626        42  LOAD_GLOBAL              DatabaseReadError
               44  LOAD_STR                 'Wrong syntax in net declaration:%s'
               46  LOAD_FAST                'token'
               48  BINARY_MODULO    
               50  CALL_FUNCTION_1       1  '1 positional argument'
               52  RAISE_VARARGS_1       1  'exception'
             54_0  COME_FROM            40  '40'

 L. 628        54  LOAD_GLOBAL              layoutdbPy
               56  LOAD_ATTR                Net
               58  CALL_FUNCTION_0       0  '0 positional arguments'
               60  STORE_FAST               'net'

 L. 629        62  LOAD_FAST                'netname'
               64  LOAD_FAST                'net'
               66  STORE_ATTR               name

 L. 630        68  LOAD_FAST                'db'
               70  LOAD_ATTR                add_net
               72  LOAD_FAST                'net'
               74  CALL_FUNCTION_1       1  '1 positional argument'
               76  POP_TOP          

 L. 631        78  LOAD_FAST                'db'
               80  LOAD_ATTR                net_index
               82  LOAD_FAST                'net'
               84  LOAD_ATTR                name
               86  CALL_FUNCTION_1       1  '1 positional argument'
               88  STORE_FAST               'net_index'

 L. 633        90  LOAD_GLOBAL              my_split
               92  LOAD_FAST                'block'
               94  LOAD_ATTR                header
               96  CALL_FUNCTION_1       1  '1 positional argument'
               98  STORE_FAST               'ah'

 L. 634       100  LOAD_GLOBAL              len
              102  LOAD_FAST                'ah'
              104  CALL_FUNCTION_1       1  '1 positional argument'
              106  LOAD_CONST               1
              108  COMPARE_OP               >
              110  POP_JUMP_IF_FALSE   156  'to 156'
              112  LOAD_FAST                'ah'
              114  LOAD_CONST               1
              116  BINARY_SUBSCR    
              118  LOAD_ATTR                startswith
              120  LOAD_STR                 'PS='
              122  CALL_FUNCTION_1       1  '1 positional argument'
              124  POP_JUMP_IF_FALSE   156  'to 156'

 L. 635       126  LOAD_GLOBAL              float
              128  LOAD_FAST                'ah'
              130  LOAD_CONST               1
              132  BINARY_SUBSCR    
              134  LOAD_CONST               3
              136  LOAD_CONST               None
              138  BUILD_SLICE_2         2 
              140  BINARY_SUBSCR    
              142  CALL_FUNCTION_1       1  '1 positional argument'
              144  LOAD_FAST                'this'
              146  LOAD_ATTR                plane_sep_inf
              148  LOAD_STR                 'NET_PS'
              150  BINARY_SUBSCR    
              152  LOAD_FAST                'net_index'
              154  STORE_SUBSCR     
            156_0  COME_FROM           124  '124'
            156_1  COME_FROM           110  '110'

 L. 636       156  LOAD_CONST               0
              158  STORE_FAST               'count'

 L. 637       160  BUILD_LIST_0          0 
              162  STORE_FAST               'polygonsvoids'

 L. 638       164  BUILD_LIST_0          0 
              166  STORE_FAST               'segs'

 L. 639       168  LOAD_CONST               None
              170  STORE_FAST               'in_poly'

 L. 640       172  SETUP_LOOP         1088  'to 1088'
              176  LOAD_FAST                'block'
              178  LOAD_ATTR                body
              180  LOAD_CONST               1
              182  LOAD_CONST               None
              184  BUILD_SLICE_2         2 
              186  BINARY_SUBSCR    
              188  GET_ITER         
              190  FOR_ITER           1086  'to 1086'
              194  STORE_FAST               'l'

 L. 641       196  LOAD_FAST                'l'
              198  LOAD_ATTR                strip
              200  CALL_FUNCTION_0       0  '0 positional arguments'
              202  LOAD_ATTR                strip
              204  LOAD_STR                 '()'
              206  CALL_FUNCTION_1       1  '1 positional argument'
              208  STORE_FAST               'l'

 L. 642       210  LOAD_FAST                'count'
              212  LOAD_CONST               1
              214  INPLACE_ADD      
              216  STORE_FAST               'count'

 L. 643       218  LOAD_FAST                'in_poly'
              220  LOAD_CONST               None
              222  COMPARE_OP               is
              224  POP_JUMP_IF_FALSE  1046  'to 1046'

 L. 644       228  LOAD_GLOBAL              my_split
              230  LOAD_FAST                'l'
              232  CALL_FUNCTION_1       1  '1 positional argument'
              234  STORE_FAST               'a'

 L. 645       236  LOAD_FAST                'a'
              238  LOAD_CONST               0
              240  BINARY_SUBSCR    
              242  STORE_FAST               'tok'

 L. 646       244  BUILD_MAP_0           0 
              246  STORE_FAST               'pairs'

 L. 647       248  SETUP_LOOP          312  'to 312'
              250  LOAD_FAST                'a'
              252  LOAD_CONST               1
              254  LOAD_CONST               None
              256  BUILD_SLICE_2         2 
              258  BINARY_SUBSCR    
              260  GET_ITER         
              262  FOR_ITER            310  'to 310'
              264  STORE_FAST               'p'

 L. 648       266  LOAD_STR                 '='
              268  LOAD_FAST                'p'
              270  COMPARE_OP               in
              272  POP_JUMP_IF_FALSE   262  'to 262'

 L. 649       276  LOAD_FAST                'p'
              278  LOAD_ATTR                split
              280  LOAD_STR                 '='
              282  CALL_FUNCTION_1       1  '1 positional argument'
              284  STORE_FAST               'a2'

 L. 650       286  LOAD_FAST                'a2'
              288  LOAD_CONST               1
              290  BINARY_SUBSCR    
              292  LOAD_FAST                'pairs'
              294  LOAD_FAST                'a2'
              296  LOAD_CONST               0
              298  BINARY_SUBSCR    
              300  LOAD_ATTR                upper
              302  CALL_FUNCTION_0       0  '0 positional arguments'
              304  STORE_SUBSCR     
              306  JUMP_BACK           262  'to 262'
              310  POP_BLOCK        
            312_0  COME_FROM_LOOP      248  '248'

 L. 651       312  LOAD_FAST                'tok'
              314  LOAD_STR                 'SEG'
              316  COMPARE_OP               ==
              318  POP_JUMP_IF_FALSE   488  'to 488'

 L. 653       322  LOAD_GLOBAL              R2
              324  LOAD_GLOBAL              float
              326  LOAD_FAST                'pairs'
              328  LOAD_STR                 'X1'
              330  BINARY_SUBSCR    
              332  CALL_FUNCTION_1       1  '1 positional argument'
              334  LOAD_GLOBAL              float
              336  LOAD_FAST                'pairs'
              338  LOAD_STR                 'Y1'
              340  BINARY_SUBSCR    
              342  CALL_FUNCTION_1       1  '1 positional argument'
              344  CALL_FUNCTION_2       2  '2 positional arguments'
              346  STORE_FAST               'p1'

 L. 654       348  LOAD_GLOBAL              R2
              350  LOAD_GLOBAL              float
              352  LOAD_FAST                'pairs'
              354  LOAD_STR                 'X2'
              356  BINARY_SUBSCR    
              358  CALL_FUNCTION_1       1  '1 positional argument'
              360  LOAD_GLOBAL              float
              362  LOAD_FAST                'pairs'
              364  LOAD_STR                 'Y2'
              366  BINARY_SUBSCR    
              368  CALL_FUNCTION_1       1  '1 positional argument'
              370  CALL_FUNCTION_2       2  '2 positional arguments'
              372  STORE_FAST               'p2'

 L. 655       374  LOAD_GLOBAL              float
              376  LOAD_FAST                'pairs'
              378  LOAD_STR                 'W'
              380  BINARY_SUBSCR    
              382  CALL_FUNCTION_1       1  '1 positional argument'
              384  STORE_FAST               'width'

 L. 656       386  LOAD_FAST                'pairs'
              388  LOAD_STR                 'L'
              390  BINARY_SUBSCR    
              392  LOAD_ATTR                upper
              394  CALL_FUNCTION_0       0  '0 positional arguments'
              396  STORE_FAST               'layer'

 L. 657       398  LOAD_GLOBAL              CurveSegment
              400  LOAD_FAST                'p1'
              402  LOAD_FAST                'p2'
              404  CALL_FUNCTION_2       2  '2 positional arguments'
              406  STORE_FAST               'cseg'

 L. 658       408  LOAD_STR                 'PS'
              410  LOAD_FAST                'pairs'
              412  COMPARE_OP               in
              414  POP_JUMP_IF_FALSE   432  'to 432'

 L. 659       418  LOAD_GLOBAL              float
              420  LOAD_FAST                'pairs'
              422  LOAD_STR                 'PS'
              424  BINARY_SUBSCR    
              426  CALL_FUNCTION_1       1  '1 positional argument'
              428  STORE_FAST               'plane_s'
              430  JUMP_FORWARD        436  'to 436'
              432  ELSE                     '436'

 L. 661       432  LOAD_CONST               0
              434  STORE_FAST               'plane_s'
            436_0  COME_FROM           430  '430'

 L. 662       436  LOAD_STR                 'LPS'
              438  LOAD_FAST                'pairs'
              440  COMPARE_OP               in
              442  POP_JUMP_IF_FALSE   460  'to 460'

 L. 663       446  LOAD_GLOBAL              float
              448  LOAD_FAST                'pairs'
              450  LOAD_STR                 'LPS'
              452  BINARY_SUBSCR    
              454  CALL_FUNCTION_1       1  '1 positional argument'
              456  STORE_FAST               'lplane_s'
              458  JUMP_FORWARD        464  'to 464'
              460  ELSE                     '464'

 L. 665       460  LOAD_CONST               0
              462  STORE_FAST               'lplane_s'
            464_0  COME_FROM           458  '458'

 L. 666       464  LOAD_FAST                'segs'
              466  LOAD_ATTR                append
              468  LOAD_FAST                'cseg'
              470  LOAD_FAST                'width'
              472  LOAD_FAST                'layer'
              474  LOAD_FAST                'plane_s'
              476  LOAD_FAST                'lplane_s'
              478  BUILD_TUPLE_5         5 
              480  CALL_FUNCTION_1       1  '1 positional argument'
              482  POP_TOP          
              484  JUMP_ABSOLUTE      1084  'to 1084'
              488  ELSE                     '1044'

 L. 667       488  LOAD_FAST                'tok'
              490  LOAD_STR                 'ARC'
              492  COMPARE_OP               ==
              494  POP_JUMP_IF_FALSE   704  'to 704'

 L. 669       498  LOAD_GLOBAL              R2
              500  LOAD_GLOBAL              float
              502  LOAD_FAST                'pairs'
              504  LOAD_STR                 'X1'
              506  BINARY_SUBSCR    
              508  CALL_FUNCTION_1       1  '1 positional argument'
              510  LOAD_GLOBAL              float
              512  LOAD_FAST                'pairs'
              514  LOAD_STR                 'Y1'
              516  BINARY_SUBSCR    
              518  CALL_FUNCTION_1       1  '1 positional argument'
              520  CALL_FUNCTION_2       2  '2 positional arguments'
              522  STORE_FAST               'p1'

 L. 670       524  LOAD_GLOBAL              R2
              526  LOAD_GLOBAL              float
              528  LOAD_FAST                'pairs'
              530  LOAD_STR                 'X2'
              532  BINARY_SUBSCR    
              534  CALL_FUNCTION_1       1  '1 positional argument'
              536  LOAD_GLOBAL              float
              538  LOAD_FAST                'pairs'
              540  LOAD_STR                 'Y2'
              542  BINARY_SUBSCR    
              544  CALL_FUNCTION_1       1  '1 positional argument'
              546  CALL_FUNCTION_2       2  '2 positional arguments'
              548  STORE_FAST               'p2'

 L. 671       550  LOAD_GLOBAL              R2
              552  LOAD_GLOBAL              float
              554  LOAD_FAST                'pairs'
              556  LOAD_STR                 'XC'
              558  BINARY_SUBSCR    
              560  CALL_FUNCTION_1       1  '1 positional argument'
              562  LOAD_GLOBAL              float
              564  LOAD_FAST                'pairs'
              566  LOAD_STR                 'YC'
              568  BINARY_SUBSCR    
              570  CALL_FUNCTION_1       1  '1 positional argument'
              572  CALL_FUNCTION_2       2  '2 positional arguments'
              574  STORE_FAST               'c'

 L. 672       576  LOAD_GLOBAL              float
              578  LOAD_FAST                'pairs'
              580  LOAD_STR                 'W'
              582  BINARY_SUBSCR    
              584  CALL_FUNCTION_1       1  '1 positional argument'
              586  STORE_FAST               'width'

 L. 673       588  LOAD_GLOBAL              float
              590  LOAD_FAST                'pairs'
              592  LOAD_STR                 'R'
              594  BINARY_SUBSCR    
              596  CALL_FUNCTION_1       1  '1 positional argument'
              598  STORE_FAST               'R'

 L. 674       600  LOAD_FAST                'pairs'
              602  LOAD_STR                 'L'
              604  BINARY_SUBSCR    
              606  STORE_FAST               'layer'

 L. 675       608  LOAD_GLOBAL              CurveSegment
              610  LOAD_FAST                'p1'
              612  LOAD_FAST                'p2'
              614  LOAD_FAST                'c'
              616  LOAD_FAST                'R'
              618  UNARY_NEGATIVE   
              620  CALL_FUNCTION_4       4  '4 positional arguments'
              622  STORE_FAST               'cseg'

 L. 676       624  LOAD_STR                 'PS'
              626  LOAD_FAST                'pairs'
              628  COMPARE_OP               in
              630  POP_JUMP_IF_FALSE   648  'to 648'

 L. 677       634  LOAD_GLOBAL              float
              636  LOAD_FAST                'pairs'
              638  LOAD_STR                 'PS'
              640  BINARY_SUBSCR    
              642  CALL_FUNCTION_1       1  '1 positional argument'
              644  STORE_FAST               'plane_s'
              646  JUMP_FORWARD        652  'to 652'
              648  ELSE                     '652'

 L. 679       648  LOAD_CONST               0
              650  STORE_FAST               'plane_s'
            652_0  COME_FROM           646  '646'

 L. 680       652  LOAD_STR                 'LPS'
              654  LOAD_FAST                'pairs'
              656  COMPARE_OP               in
              658  POP_JUMP_IF_FALSE   676  'to 676'

 L. 681       662  LOAD_GLOBAL              float
              664  LOAD_FAST                'pairs'
              666  LOAD_STR                 'LPS'
              668  BINARY_SUBSCR    
              670  CALL_FUNCTION_1       1  '1 positional argument'
              672  STORE_FAST               'lplane_s'
              674  JUMP_FORWARD        680  'to 680'
              676  ELSE                     '680'

 L. 683       676  LOAD_CONST               0
              678  STORE_FAST               'lplane_s'
            680_0  COME_FROM           674  '674'

 L. 684       680  LOAD_FAST                'segs'
              682  LOAD_ATTR                append
              684  LOAD_FAST                'cseg'
              686  LOAD_FAST                'width'
              688  LOAD_FAST                'layer'
              690  LOAD_FAST                'plane_s'
              692  LOAD_FAST                'lplane_s'
              694  BUILD_TUPLE_5         5 
              696  CALL_FUNCTION_1       1  '1 positional argument'
              698  POP_TOP          

 L. 685       700  JUMP_ABSOLUTE      1084  'to 1084'
              704  ELSE                     '1044'

 L. 686       704  LOAD_FAST                'tok'
              706  LOAD_CONST               ('VIA', 'PIN')
              708  COMPARE_OP               in
              710  POP_JUMP_IF_FALSE   930  'to 930'

 L. 689       714  LOAD_GLOBAL              R2
              716  LOAD_GLOBAL              float
              718  LOAD_FAST                'pairs'
              720  LOAD_STR                 'X'
              722  BINARY_SUBSCR    
              724  CALL_FUNCTION_1       1  '1 positional argument'
              726  LOAD_GLOBAL              float
              728  LOAD_FAST                'pairs'
              730  LOAD_STR                 'Y'
              732  BINARY_SUBSCR    
              734  CALL_FUNCTION_1       1  '1 positional argument'
              736  CALL_FUNCTION_2       2  '2 positional arguments'
              738  LOAD_FAST                'pairs'
              740  LOAD_STR                 'P'
              742  BINARY_SUBSCR    
              744  LOAD_ATTR                upper
              746  CALL_FUNCTION_0       0  '0 positional arguments'
              748  ROT_TWO          
              750  STORE_FAST               'pos'
              752  STORE_FAST               'ps'

 L. 690       754  LOAD_GLOBAL              layoutdbPy
              756  LOAD_ATTR                new_iPadstack
              758  CALL_FUNCTION_0       0  '0 positional arguments'
              760  STORE_FAST               'via'

 L. 691       762  LOAD_FAST                'pos'
              764  LOAD_FAST                'via'
              766  STORE_ATTR               position

 L. 692       768  LOAD_FAST                'db'
              770  LOAD_ATTR                lpadstack
              772  LOAD_FAST                'ps'
              774  CALL_FUNCTION_1       1  '1 positional argument'
              776  DUP_TOP          
              778  LOAD_FAST                'via'
              780  STORE_ATTR               library_padstack
              782  STORE_FAST               'lps'

 L. 693       784  LOAD_FAST                'net'
              786  LOAD_FAST                'via'
              788  STORE_ATTR               net

 L. 694       790  LOAD_FAST                'ps'
              792  LOAD_FAST                'this'
              794  LOAD_ATTR                lps2layerspan
              796  COMPARE_OP               in
              798  POP_JUMP_IF_FALSE   820  'to 820'

 L. 695       802  LOAD_FAST                'this'
              804  LOAD_ATTR                lps2layerspan
              806  LOAD_FAST                'ps'
              808  BINARY_SUBSCR    
              810  UNPACK_SEQUENCE_2     2 
              812  LOAD_FAST                'via'
              814  STORE_ATTR               layer_from
              816  LOAD_FAST                'via'
              818  STORE_ATTR               layer_to
            820_0  COME_FROM           798  '798'

 L. 696       820  LOAD_FAST                'tok'
              822  LOAD_STR                 'PIN'
              824  COMPARE_OP               ==
              826  POP_JUMP_IF_FALSE   912  'to 912'

 L. 697       830  LOAD_FAST                'pairs'
              832  LOAD_STR                 'R'
              834  BINARY_SUBSCR    
              836  LOAD_ATTR                split
              838  LOAD_STR                 '.'
              840  CALL_FUNCTION_1       1  '1 positional argument'
              842  UNPACK_SEQUENCE_2     2 
              844  STORE_FAST               'refdes'
              846  STORE_FAST               'pinname'

 L. 700       848  LOAD_GLOBAL              layoutdbPy
              850  LOAD_ATTR                Pin
              852  CALL_FUNCTION_0       0  '0 positional arguments'
              854  STORE_FAST               'pin'

 L. 701       856  LOAD_FAST                'pinname'
              858  LOAD_FAST                'pin'
              860  STORE_ATTR               name

 L. 702       862  LOAD_FAST                'net'
              864  LOAD_FAST                'pin'
              866  STORE_ATTR               net

 L. 703       868  LOAD_FAST                'pos'
              870  LOAD_FAST                'pin'
              872  STORE_ATTR               position

 L. 704       874  LOAD_FAST                'db'
              876  LOAD_ATTR                component
              878  LOAD_FAST                'refdes'
              880  CALL_FUNCTION_1       1  '1 positional argument'
              882  STORE_FAST               'comp'

 L. 705       884  LOAD_FAST                'comp'
              886  LOAD_ATTR                add_pin
              888  LOAD_FAST                'pin'
              890  CALL_FUNCTION_1       1  '1 positional argument'
              892  POP_TOP          

 L. 706       894  LOAD_FAST                'lps'
              896  POP_JUMP_IF_FALSE   928  'to 928'

 L. 707       900  LOAD_FAST                'comp'
              902  LOAD_ATTR                add_padstack
              904  LOAD_FAST                'via'
              906  CALL_FUNCTION_1       1  '1 positional argument'
              908  POP_TOP          
              910  JUMP_FORWARD        928  'to 928'
              912  ELSE                     '928'

 L. 709       912  LOAD_FAST                'lps'
              914  POP_JUMP_IF_FALSE  1044  'to 1044'

 L. 710       918  LOAD_FAST                'db'
              920  LOAD_ATTR                add_padstack
              922  LOAD_FAST                'via'
              924  CALL_FUNCTION_1       1  '1 positional argument'
              926  POP_TOP          
            928_0  COME_FROM           910  '910'
            928_1  COME_FROM           896  '896'
              928  JUMP_FORWARD       1044  'to 1044'
              930  ELSE                     '1044'

 L. 711       930  LOAD_FAST                'tok'
              932  LOAD_STR                 'USEG'
              934  COMPARE_OP               ==
              936  POP_JUMP_IF_FALSE   942  'to 942'

 L. 715       940  JUMP_FORWARD       1044  'to 1044'
              942  ELSE                     '1044'

 L. 716       942  LOAD_FAST                'tok'
              944  LOAD_ATTR                startswith
              946  LOAD_STR                 '{POLYGON'
              948  CALL_FUNCTION_1       1  '1 positional argument'
              950  POP_JUMP_IF_FALSE   976  'to 976'

 L. 717       954  BUILD_LIST_0          0 
              956  STORE_FAST               'in_poly'

 L. 718       958  LOAD_FAST                'tok'
              960  LOAD_CONST               1
              962  LOAD_CONST               None
              964  BUILD_SLICE_2         2 
              966  BINARY_SUBSCR    
              968  LOAD_FAST                'pairs'
              970  BUILD_TUPLE_2         2 
              972  STORE_FAST               'header'
              974  JUMP_FORWARD       1044  'to 1044'
              976  ELSE                     '1044'

 L. 719       976  LOAD_FAST                'tok'
              978  LOAD_ATTR                startswith
              980  LOAD_STR                 '{POLYVOID'
              982  CALL_FUNCTION_1       1  '1 positional argument'
              984  POP_JUMP_IF_FALSE  1010  'to 1010'

 L. 720       988  BUILD_LIST_0          0 
              990  STORE_FAST               'in_poly'

 L. 721       992  LOAD_FAST                'tok'
              994  LOAD_CONST               1
              996  LOAD_CONST               None
              998  BUILD_SLICE_2         2 
             1000  BINARY_SUBSCR    
             1002  LOAD_FAST                'pairs'
             1004  BUILD_TUPLE_2         2 
             1006  STORE_FAST               'header'
             1008  JUMP_FORWARD       1044  'to 1044'
             1010  ELSE                     '1044'

 L. 722      1010  LOAD_FAST                'tok'
             1012  LOAD_ATTR                startswith
             1014  LOAD_STR                 '{POLYLINE'
             1016  CALL_FUNCTION_1       1  '1 positional argument'
             1018  POP_JUMP_IF_FALSE  1084  'to 1084'

 L. 723      1022  BUILD_LIST_0          0 
             1024  STORE_FAST               'in_poly'

 L. 724      1026  LOAD_FAST                'tok'
             1028  LOAD_CONST               1
             1030  LOAD_CONST               None
             1032  BUILD_SLICE_2         2 
             1034  BINARY_SUBSCR    
             1036  LOAD_FAST                'pairs'
             1038  BUILD_TUPLE_2         2 
             1040  STORE_FAST               'header'
             1042  JUMP_FORWARD       1044  'to 1044'
           1044_0  COME_FROM          1042  '1042'
           1044_1  COME_FROM          1008  '1008'
           1044_2  COME_FROM           974  '974'
           1044_3  COME_FROM           940  '940'
           1044_4  COME_FROM           928  '928'
           1044_5  COME_FROM           914  '914'

 L. 726      1044  CONTINUE            190  'to 190'

 L. 728      1046  LOAD_FAST                'in_poly'
             1048  LOAD_ATTR                append
             1050  LOAD_FAST                'l'
             1052  CALL_FUNCTION_1       1  '1 positional argument'
             1054  POP_TOP          

 L. 729      1056  LOAD_FAST                'l'
             1058  LOAD_ATTR                endswith
             1060  LOAD_STR                 '}'
             1062  CALL_FUNCTION_1       1  '1 positional argument'
             1064  POP_JUMP_IF_FALSE   190  'to 190'

 L. 730      1066  LOAD_FAST                'polygonsvoids'
             1068  LOAD_ATTR                append
             1070  LOAD_FAST                'header'
             1072  LOAD_FAST                'in_poly'
             1074  BUILD_TUPLE_2         2 
             1076  CALL_FUNCTION_1       1  '1 positional argument'
             1078  POP_TOP          

 L. 731      1080  LOAD_CONST               None
             1082  STORE_FAST               'in_poly'
             1084  JUMP_BACK           190  'to 190'
             1086  POP_BLOCK        
           1088_0  COME_FROM_LOOP      172  '172'

 L. 733      1088  LOAD_FAST                'in_poly'
             1090  LOAD_CONST               None
             1092  COMPARE_OP               is-not
             1094  POP_JUMP_IF_FALSE  1112  'to 1112'

 L. 734      1098  LOAD_FAST                'polygonsvoids'
             1100  LOAD_ATTR                append
             1102  LOAD_FAST                'header'
             1104  LOAD_FAST                'in_poly'
             1106  BUILD_TUPLE_2         2 
             1108  CALL_FUNCTION_1       1  '1 positional argument'
             1110  POP_TOP          
           1112_0  COME_FROM          1094  '1094'

 L. 739      1112  SETUP_LOOP         1394  'to 1394'
             1116  LOAD_FAST                'segs'
             1118  GET_ITER         
             1120  FOR_ITER           1392  'to 1392'
             1124  UNPACK_SEQUENCE_5     5 
             1126  STORE_FAST               'seg'
             1128  STORE_FAST               'width'
             1130  STORE_FAST               'lyr'
             1132  STORE_FAST               'plane_s'
             1134  STORE_FAST               'lplane_s'

 L. 740      1136  LOAD_FAST                'db'
             1138  LOAD_ATTR                layer
             1140  LOAD_FAST                'lyr'
             1142  CALL_FUNCTION_1       1  '1 positional argument'
             1144  STORE_FAST               'l'

 L. 741      1146  LOAD_FAST                'l'
             1148  LOAD_CONST               None
             1150  COMPARE_OP               is-not
             1152  POP_JUMP_IF_TRUE   1160  'to 1160'
             1156  LOAD_ASSERT              AssertionError
             1158  RAISE_VARARGS_1       1  'exception'
           1160_0  COME_FROM          1152  '1152'

 L. 742      1160  LOAD_GLOBAL              layoutdbPy
             1162  LOAD_ATTR                Trace
             1164  CALL_FUNCTION_0       0  '0 positional arguments'
             1166  STORE_FAST               'trace'

 L. 743      1168  LOAD_FAST                'seg'
             1170  LOAD_ATTR                a
             1172  LOAD_FAST                'seg'
             1174  LOAD_ATTR                b
             1176  COMPARE_OP               ==
             1178  POP_JUMP_IF_FALSE  1186  'to 1186'

 L. 743      1182  CONTINUE           1120  'to 1120'
             1186  ELSE                     '1390'

 L. 744      1186  LOAD_FAST                'trace'
             1188  LOAD_ATTR                add_segment
             1190  LOAD_FAST                'seg'
             1192  LOAD_FAST                'width'
             1194  CALL_FUNCTION_2       2  '2 positional arguments'
             1196  POP_TOP          

 L. 745      1198  LOAD_FAST                'width'
             1200  LOAD_CONST               0
             1202  COMPARE_OP               >
             1204  POP_JUMP_IF_FALSE  1230  'to 1230'
             1208  LOAD_FAST                'width'
             1210  LOAD_FAST                'db'
             1212  LOAD_ATTR                simulation_settings
             1214  LOAD_ATTR                lateral_reference_length
             1216  COMPARE_OP               <
             1218  POP_JUMP_IF_FALSE  1230  'to 1230'

 L. 746      1222  LOAD_FAST                'width'
             1224  LOAD_FAST                'db'
             1226  LOAD_ATTR                simulation_settings
             1228  STORE_ATTR               lateral_reference_length
           1230_0  COME_FROM          1218  '1218'
           1230_1  COME_FROM          1204  '1204'

 L. 747      1230  LOAD_FAST                'net_index'
             1232  LOAD_FAST                'trace'
             1234  STORE_ATTR               net_index

 L. 748      1236  LOAD_FAST                'l'
             1238  LOAD_ATTR                add_trace
             1240  LOAD_FAST                'trace'
             1242  CALL_FUNCTION_1       1  '1 positional argument'
             1244  POP_TOP          

 L. 749      1246  LOAD_FAST                'plane_s'
             1248  POP_JUMP_IF_TRUE   1258  'to 1258'
             1252  LOAD_FAST                'lplane_s'
           1254_0  COME_FROM          1248  '1248'
             1254  POP_JUMP_IF_FALSE  1120  'to 1120'

 L. 750      1258  LOAD_GLOBAL              layoutdbPy
             1260  LOAD_ATTR                AntiTrace
             1262  LOAD_FAST                'l'
             1264  LOAD_ATTR                n_traces
             1266  CALL_FUNCTION_0       0  '0 positional arguments'
             1268  LOAD_CONST               1
             1270  BINARY_SUBTRACT  
             1272  LOAD_FAST                'trace'
             1274  LOAD_ATTR                n_segments
             1276  CALL_FUNCTION_0       0  '0 positional arguments'
             1278  LOAD_CONST               1
             1280  BINARY_SUBTRACT  
             1282  LOAD_FAST                'plane_s'
             1284  LOAD_FAST                'lplane_s'
             1286  LOAD_FAST                'net_index'
             1288  CALL_FUNCTION_5       5  '5 positional arguments'
             1290  STORE_FAST               'anti_trace'

 L. 752      1292  LOAD_FAST                'lyr'
             1294  LOAD_FAST                'this'
             1296  LOAD_ATTR                plane_sep_inf
             1298  LOAD_STR                 'LAYERS'
             1300  BINARY_SUBSCR    
             1302  COMPARE_OP               not-in
             1304  POP_JUMP_IF_FALSE  1322  'to 1322'

 L. 753      1308  BUILD_MAP_0           0 
             1310  LOAD_FAST                'this'
             1312  LOAD_ATTR                plane_sep_inf
             1314  LOAD_STR                 'LAYERS'
             1316  BINARY_SUBSCR    
             1318  LOAD_FAST                'lyr'
             1320  STORE_SUBSCR     
           1322_0  COME_FROM          1304  '1304'

 L. 754      1322  LOAD_STR                 'segm_ps'
             1324  LOAD_FAST                'this'
             1326  LOAD_ATTR                plane_sep_inf
             1328  LOAD_STR                 'LAYERS'
             1330  BINARY_SUBSCR    
             1332  LOAD_FAST                'lyr'
             1334  BINARY_SUBSCR    
             1336  COMPARE_OP               not-in
             1338  POP_JUMP_IF_FALSE  1364  'to 1364'

 L. 755      1342  LOAD_GLOBAL              layoutdbPy
             1344  LOAD_ATTR                vectorAntiTrace
             1346  CALL_FUNCTION_0       0  '0 positional arguments'
             1348  LOAD_FAST                'this'
             1350  LOAD_ATTR                plane_sep_inf
             1352  LOAD_STR                 'LAYERS'
             1354  BINARY_SUBSCR    
             1356  LOAD_FAST                'lyr'
             1358  BINARY_SUBSCR    
             1360  LOAD_STR                 'segm_ps'
             1362  STORE_SUBSCR     
           1364_0  COME_FROM          1338  '1338'

 L. 756      1364  LOAD_FAST                'this'
             1366  LOAD_ATTR                plane_sep_inf
             1368  LOAD_STR                 'LAYERS'
             1370  BINARY_SUBSCR    
             1372  LOAD_FAST                'lyr'
             1374  BINARY_SUBSCR    
             1376  LOAD_STR                 'segm_ps'
             1378  BINARY_SUBSCR    
             1380  LOAD_ATTR                append
             1382  LOAD_FAST                'anti_trace'
             1384  CALL_FUNCTION_1       1  '1 positional argument'
             1386  POP_TOP          
             1388  JUMP_BACK          1120  'to 1120'
             1392  POP_BLOCK        
           1394_0  COME_FROM_LOOP     1112  '1112'

 L. 760      1394  LOAD_GLOBAL              len
             1396  LOAD_FAST                'polygonsvoids'
             1398  CALL_FUNCTION_1       1  '1 positional argument'
             1400  POP_JUMP_IF_FALSE  2274  'to 2274'

 L. 783      1404  LOAD_FAST                'polygonsvoids'
             1406  LOAD_ATTR                sort
             1408  LOAD_LAMBDA              '<code_object <lambda>>'
             1410  LOAD_STR                 'HyperLynxImporter.parse_NET.<locals>.<lambda>'
             1412  MAKE_FUNCTION_0          'Neither defaults, keyword-only args, annotations, nor closures'
             1414  LOAD_CONST               ('key',)
             1416  CALL_FUNCTION_KW_1     1  '1 total positional and keyword args'
             1418  POP_TOP          

 L. 784      1420  BUILD_LIST_0          0 
             1422  STORE_FAST               'swhs'

 L. 786      1424  LOAD_GLOBAL              len
             1426  LOAD_FAST                'polygonsvoids'
             1428  CALL_FUNCTION_1       1  '1 positional argument'
             1430  STORE_FAST               'n'

 L. 787      1432  LOAD_CONST               0
             1434  STORE_FAST               'i'

 L. 788      1436  BUILD_LIST_0          0 
             1438  STORE_FAST               'polylines'

 L. 789      1440  LOAD_STR                 '0'
             1442  STORE_FAST               'polygon_width'

 L. 790      1444  SETUP_LOOP         1804  'to 1804'
             1448  LOAD_FAST                'i'
             1450  LOAD_FAST                'n'
             1452  COMPARE_OP               <
             1454  POP_JUMP_IF_FALSE  1802  'to 1802'

 L. 791      1458  LOAD_FAST                'polygonsvoids'
             1460  LOAD_FAST                'i'
             1462  BINARY_SUBSCR    
             1464  UNPACK_SEQUENCE_2     2 
             1466  STORE_FAST               'header'
             1468  STORE_FAST               'poly'

 L. 792      1470  LOAD_FAST                'header'
             1472  LOAD_CONST               0
             1474  BINARY_SUBSCR    
             1476  LOAD_STR                 'POLYGON'
             1478  COMPARE_OP               ==
             1480  POP_JUMP_IF_FALSE  1762  'to 1762'

 L. 793      1484  LOAD_STR                 'W'
             1486  LOAD_FAST                'header'
             1488  LOAD_CONST               1
             1490  BINARY_SUBSCR    
             1492  COMPARE_OP               in
             1494  POP_JUMP_IF_FALSE  1512  'to 1512'

 L. 794      1498  LOAD_FAST                'header'
             1500  LOAD_CONST               1
             1502  BINARY_SUBSCR    
             1504  LOAD_STR                 'W'
             1506  BINARY_SUBSCR    
             1508  STORE_FAST               'polygon_width'
             1510  JUMP_FORWARD       1516  'to 1516'
             1512  ELSE                     '1516'

 L. 796      1512  LOAD_STR                 '0'
             1514  STORE_FAST               'polygon_width'
           1516_0  COME_FROM          1510  '1510'

 L. 797      1516  LOAD_FAST                'header'
             1518  LOAD_FAST                'poly'
             1520  BUILD_TUPLE_2         2 
             1522  BUILD_LIST_1          1 
             1524  STORE_FAST               'swh'

 L. 798      1526  LOAD_FAST                'i'
             1528  LOAD_CONST               1
             1530  INPLACE_ADD      
             1532  STORE_FAST               'i'

 L. 799      1534  LOAD_CONST               None
             1536  STORE_FAST               'shape_type'

 L. 800      1538  LOAD_STR                 'T'
             1540  LOAD_FAST                'header'
             1542  LOAD_CONST               1
             1544  BINARY_SUBSCR    
             1546  COMPARE_OP               in
             1548  POP_JUMP_IF_FALSE  1574  'to 1574'
             1552  LOAD_FAST                'header'
             1554  LOAD_CONST               1
             1556  BINARY_SUBSCR    
             1558  LOAD_STR                 'T'
             1560  BINARY_SUBSCR    
             1562  LOAD_STR                 'PLANE'
             1564  COMPARE_OP               ==
             1566  POP_JUMP_IF_FALSE  1574  'to 1574'

 L. 801      1570  LOAD_STR                 'PLANE'
             1572  STORE_FAST               'shape_type'
           1574_0  COME_FROM          1566  '1566'
           1574_1  COME_FROM          1548  '1548'

 L. 802      1574  SETUP_LOOP         1746  'to 1746'
             1576  LOAD_FAST                'i'
             1578  LOAD_FAST                'n'
             1580  COMPARE_OP               <
             1582  POP_JUMP_IF_FALSE  1744  'to 1744'
             1586  LOAD_FAST                'polygonsvoids'
             1588  LOAD_FAST                'i'
             1590  BINARY_SUBSCR    
             1592  LOAD_CONST               0
             1594  BINARY_SUBSCR    
             1596  LOAD_CONST               0
             1598  BINARY_SUBSCR    
             1600  LOAD_STR                 'POLYVOID'
             1602  COMPARE_OP               ==
             1604  POP_JUMP_IF_TRUE   1630  'to 1630'
             1608  LOAD_FAST                'polygonsvoids'
             1610  LOAD_FAST                'i'
             1612  BINARY_SUBSCR    
             1614  LOAD_CONST               0
             1616  BINARY_SUBSCR    
             1618  LOAD_CONST               0
             1620  BINARY_SUBSCR    
             1622  LOAD_STR                 'POLYLINE'
             1624  COMPARE_OP               ==
           1626_0  COME_FROM          1604  '1604'
             1626  POP_JUMP_IF_FALSE  1744  'to 1744'

 L. 803      1630  LOAD_FAST                'polygonsvoids'
             1632  LOAD_FAST                'i'
             1634  BINARY_SUBSCR    
             1636  LOAD_CONST               0
             1638  BINARY_SUBSCR    
             1640  LOAD_CONST               0
             1642  BINARY_SUBSCR    
             1644  LOAD_STR                 'POLYVOID'
             1646  COMPARE_OP               ==
             1648  POP_JUMP_IF_FALSE  1696  'to 1696'

 L. 804      1652  LOAD_FAST                'polygon_width'
             1654  LOAD_FAST                'polygonsvoids'
             1656  LOAD_FAST                'i'
             1658  BINARY_SUBSCR    
             1660  LOAD_CONST               0
             1662  BINARY_SUBSCR    
             1664  LOAD_CONST               1
             1666  BINARY_SUBSCR    
             1668  LOAD_STR                 'W'
             1670  STORE_SUBSCR     

 L. 805      1672  LOAD_FAST                'swh'
             1674  LOAD_ATTR                append
             1676  LOAD_FAST                'polygonsvoids'
             1678  LOAD_FAST                'i'
             1680  BINARY_SUBSCR    
             1682  CALL_FUNCTION_1       1  '1 positional argument'
             1684  POP_TOP          

 L. 806      1686  LOAD_FAST                'i'
             1688  LOAD_CONST               1
             1690  INPLACE_ADD      
             1692  STORE_FAST               'i'
             1694  JUMP_FORWARD       1740  'to 1740'
             1696  ELSE                     '1740'

 L. 807      1696  LOAD_FAST                'polygonsvoids'
             1698  LOAD_FAST                'i'
             1700  BINARY_SUBSCR    
             1702  LOAD_CONST               0
             1704  BINARY_SUBSCR    
             1706  LOAD_CONST               0
             1708  BINARY_SUBSCR    
             1710  LOAD_STR                 'POLYLINE'
             1712  COMPARE_OP               ==
             1714  POP_JUMP_IF_FALSE  1576  'to 1576'

 L. 808      1718  LOAD_FAST                'polylines'
             1720  LOAD_ATTR                append
             1722  LOAD_FAST                'polygonsvoids'
             1724  LOAD_FAST                'i'
             1726  BINARY_SUBSCR    
             1728  CALL_FUNCTION_1       1  '1 positional argument'
             1730  POP_TOP          

 L. 809      1732  LOAD_FAST                'i'
             1734  LOAD_CONST               1
             1736  INPLACE_ADD      
             1738  STORE_FAST               'i'
           1740_0  COME_FROM          1694  '1694'
             1740  JUMP_BACK          1576  'to 1576'
           1744_0  COME_FROM          1626  '1626'
           1744_1  COME_FROM          1582  '1582'
             1744  POP_BLOCK        
           1746_0  COME_FROM_LOOP     1574  '1574'

 L. 810      1746  LOAD_FAST                'swhs'
             1748  LOAD_ATTR                append
             1750  LOAD_FAST                'swh'
             1752  LOAD_FAST                'shape_type'
             1754  BUILD_TUPLE_2         2 
             1756  CALL_FUNCTION_1       1  '1 positional argument'
             1758  POP_TOP          
             1760  JUMP_FORWARD       1798  'to 1798'
             1762  ELSE                     '1798'

 L. 812      1762  LOAD_FAST                'header'
             1764  LOAD_CONST               0
             1766  BINARY_SUBSCR    
             1768  LOAD_STR                 'POLYLINE'
             1770  COMPARE_OP               ==
             1772  POP_JUMP_IF_FALSE  1448  'to 1448'

 L. 813      1776  LOAD_FAST                'polylines'
             1778  LOAD_ATTR                append
             1780  LOAD_FAST                'polygonsvoids'
             1782  LOAD_FAST                'i'
             1784  BINARY_SUBSCR    
             1786  CALL_FUNCTION_1       1  '1 positional argument'
             1788  POP_TOP          

 L. 814      1790  LOAD_FAST                'i'
             1792  LOAD_CONST               1
             1794  INPLACE_ADD      
             1796  STORE_FAST               'i'
           1798_0  COME_FROM          1760  '1760'
             1798  JUMP_BACK          1448  'to 1448'
           1802_0  COME_FROM          1454  '1454'
             1802  POP_BLOCK        
           1804_0  COME_FROM_LOOP     1444  '1444'

 L. 816      1804  SETUP_LOOP         2056  'to 2056'
             1806  LOAD_FAST                'swhs'
             1808  GET_ITER         
             1810  FOR_ITER           2054  'to 2054'
             1812  UNPACK_SEQUENCE_2     2 
             1814  STORE_FAST               'swh'
             1816  STORE_FAST               'shape_type'

 L. 817      1818  LOAD_GLOBAL              len
             1820  LOAD_FAST                'swh'
             1822  CALL_FUNCTION_1       1  '1 positional argument'
             1824  LOAD_CONST               0
             1826  COMPARE_OP               >
             1828  POP_JUMP_IF_TRUE   1836  'to 1836'
             1832  LOAD_ASSERT              AssertionError
             1834  RAISE_VARARGS_1       1  'exception'
           1836_0  COME_FROM          1828  '1828'

 L. 818      1836  LOAD_FAST                'swh'
             1838  LOAD_CONST               0
             1840  BINARY_SUBSCR    
             1842  LOAD_CONST               0
             1844  BINARY_SUBSCR    
             1846  UNPACK_SEQUENCE_2     2 
             1848  STORE_FAST               'tok'
             1850  STORE_FAST               'pairs'

 L. 819      1852  LOAD_FAST                'this'
             1854  LOAD_ATTR                extract_polygon_with_holes
             1856  LOAD_FAST                'swh'
             1858  LOAD_FAST                'db'
             1860  LOAD_ATTR                tolerance
             1862  CALL_FUNCTION_2       2  '2 positional arguments'
             1864  STORE_FAST               'shapes'

 L. 820      1866  SETUP_LOOP         2050  'to 2050'
             1868  LOAD_FAST                'shapes'
             1870  GET_ITER         
             1872  FOR_ITER           2048  'to 2048'
             1874  STORE_FAST               'shape'

 L. 821      1876  LOAD_FAST                'shape'
             1878  LOAD_CONST               None
             1880  COMPARE_OP               is
             1882  POP_JUMP_IF_FALSE  1898  'to 1898'

 L. 822      1886  LOAD_GLOBAL              print
             1888  LOAD_STR                 'WARNING: unable to extract polygon'
             1890  CALL_FUNCTION_1       1  '1 positional argument'
             1892  POP_TOP          

 L. 823      1894  CONTINUE           1872  'to 1872'
             1898  ELSE                     '2046'

 L. 824      1898  LOAD_FAST                'net_index'
             1900  LOAD_FAST                'shape'
             1902  STORE_ATTR               net_index

 L. 825      1904  LOAD_FAST                'pairs'
             1906  LOAD_STR                 'L'
             1908  BINARY_SUBSCR    
             1910  LOAD_ATTR                upper
             1912  CALL_FUNCTION_0       0  '0 positional arguments'
             1914  STORE_FAST               'layer'

 L. 826      1916  LOAD_FAST                'shape_type'
             1918  LOAD_STR                 'PLANE'
             1920  COMPARE_OP               ==
             1922  POP_JUMP_IF_FALSE  2024  'to 2024'

 L. 827      1926  LOAD_FAST                'layer'
             1928  LOAD_FAST                'this'
             1930  LOAD_ATTR                plane_sep_inf
             1932  LOAD_STR                 'LAYERS'
             1934  BINARY_SUBSCR    
             1936  COMPARE_OP               not-in
             1938  POP_JUMP_IF_FALSE  1956  'to 1956'

 L. 828      1942  BUILD_MAP_0           0 
             1944  LOAD_FAST                'this'
             1946  LOAD_ATTR                plane_sep_inf
             1948  LOAD_STR                 'LAYERS'
             1950  BINARY_SUBSCR    
             1952  LOAD_FAST                'layer'
             1954  STORE_SUBSCR     
           1956_0  COME_FROM          1938  '1938'

 L. 829      1956  LOAD_STR                 'plane_shapes'
             1958  LOAD_FAST                'this'
             1960  LOAD_ATTR                plane_sep_inf
             1962  LOAD_STR                 'LAYERS'
             1964  BINARY_SUBSCR    
             1966  LOAD_FAST                'layer'
             1968  BINARY_SUBSCR    
             1970  COMPARE_OP               not-in
             1972  POP_JUMP_IF_FALSE  1998  'to 1998'

 L. 830      1976  LOAD_GLOBAL              layoutdbPy
             1978  LOAD_ATTR                vectorShapeWithHoles
             1980  CALL_FUNCTION_0       0  '0 positional arguments'
             1982  LOAD_FAST                'this'
             1984  LOAD_ATTR                plane_sep_inf
             1986  LOAD_STR                 'LAYERS'
             1988  BINARY_SUBSCR    
             1990  LOAD_FAST                'layer'
             1992  BINARY_SUBSCR    
             1994  LOAD_STR                 'plane_shapes'
             1996  STORE_SUBSCR     
           1998_0  COME_FROM          1972  '1972'

 L. 831      1998  LOAD_FAST                'this'
             2000  LOAD_ATTR                plane_sep_inf
             2002  LOAD_STR                 'LAYERS'
             2004  BINARY_SUBSCR    
             2006  LOAD_FAST                'layer'
             2008  BINARY_SUBSCR    
             2010  LOAD_STR                 'plane_shapes'
             2012  BINARY_SUBSCR    
             2014  LOAD_ATTR                append
             2016  LOAD_FAST                'shape'
             2018  CALL_FUNCTION_1       1  '1 positional argument'
             2020  POP_TOP          
             2022  JUMP_FORWARD       2044  'to 2044'
             2024  ELSE                     '2044'

 L. 833      2024  LOAD_FAST                'db'
             2026  LOAD_ATTR                layer
             2028  LOAD_FAST                'layer'
             2030  CALL_FUNCTION_1       1  '1 positional argument'
             2032  STORE_FAST               'l'

 L. 834      2034  LOAD_FAST                'l'
             2036  LOAD_ATTR                add_plane_shape
             2038  LOAD_FAST                'shape'
             2040  CALL_FUNCTION_1       1  '1 positional argument'
             2042  POP_TOP          
           2044_0  COME_FROM          2022  '2022'
             2044  JUMP_BACK          1872  'to 1872'
             2048  POP_BLOCK        
           2050_0  COME_FROM_LOOP     1866  '1866'
             2050  JUMP_BACK          1810  'to 1810'
             2054  POP_BLOCK        
           2056_0  COME_FROM_LOOP     1804  '1804'

 L. 836      2056  SETUP_LOOP         2274  'to 2274'
             2058  LOAD_FAST                'polylines'
             2060  GET_ITER         
             2062  FOR_ITER           2272  'to 2272'
             2064  STORE_FAST               'line'

 L. 837      2066  LOAD_FAST                'line'
             2068  UNPACK_SEQUENCE_2     2 
             2070  STORE_FAST               'header'
             2072  STORE_FAST               'poly'

 L. 838      2074  LOAD_FAST                'this'
             2076  LOAD_ATTR                extract_polygonvoid
             2078  LOAD_FAST                'header'
             2080  LOAD_FAST                'poly'
             2082  CALL_FUNCTION_2       2  '2 positional arguments'
             2084  STORE_FAST               'segs'

 L. 839      2086  LOAD_FAST                'header'
             2088  LOAD_CONST               1
             2090  BINARY_SUBSCR    
             2092  LOAD_STR                 'L'
             2094  BINARY_SUBSCR    
             2096  STORE_FAST               'lyr'

 L. 840      2098  LOAD_FAST                'db'
             2100  LOAD_ATTR                layer
             2102  LOAD_FAST                'lyr'
             2104  CALL_FUNCTION_1       1  '1 positional argument'
             2106  STORE_FAST               'l'

 L. 841      2108  LOAD_FAST                'l'
             2110  LOAD_CONST               None
             2112  COMPARE_OP               is-not
             2114  POP_JUMP_IF_TRUE   2122  'to 2122'
             2118  LOAD_ASSERT              AssertionError
             2120  RAISE_VARARGS_1       1  'exception'
           2122_0  COME_FROM          2114  '2114'

 L. 842      2122  LOAD_GLOBAL              float
             2124  LOAD_FAST                'header'
             2126  LOAD_CONST               1
             2128  BINARY_SUBSCR    
             2130  LOAD_STR                 'W'
             2132  BINARY_SUBSCR    
             2134  CALL_FUNCTION_1       1  '1 positional argument'
             2136  STORE_FAST               'width'

 L. 843      2138  LOAD_FAST                'width'
             2140  LOAD_CONST               0
             2142  COMPARE_OP               ==
             2144  POP_JUMP_IF_TRUE   2062  'to 2062'
             2148  LOAD_GLOBAL              len
             2150  LOAD_FAST                'segs'
             2152  CALL_FUNCTION_1       1  '1 positional argument'
             2154  LOAD_CONST               None
             2156  COMPARE_OP               ==
             2158  POP_JUMP_IF_FALSE  2166  'to 2166'

 L. 844      2162  CONTINUE           2062  'to 2062'
             2166  ELSE                     '2270'

 L. 845      2166  LOAD_GLOBAL              layoutdbPy
             2168  LOAD_ATTR                Trace
             2170  CALL_FUNCTION_0       0  '0 positional arguments'
             2172  STORE_FAST               'trace'

 L. 846      2174  LOAD_FAST                'width'
             2176  LOAD_CONST               0
             2178  COMPARE_OP               >
             2180  POP_JUMP_IF_FALSE  2206  'to 2206'
             2184  LOAD_FAST                'width'
             2186  LOAD_FAST                'db'
             2188  LOAD_ATTR                simulation_settings
             2190  LOAD_ATTR                lateral_reference_length
             2192  COMPARE_OP               <
             2194  POP_JUMP_IF_FALSE  2206  'to 2206'

 L. 847      2198  LOAD_FAST                'width'
             2200  LOAD_FAST                'db'
             2202  LOAD_ATTR                simulation_settings
             2204  STORE_ATTR               lateral_reference_length
           2206_0  COME_FROM          2194  '2194'
           2206_1  COME_FROM          2180  '2180'

 L. 848      2206  SETUP_LOOP         2252  'to 2252'
             2208  LOAD_FAST                'segs'
             2210  GET_ITER         
             2212  FOR_ITER           2250  'to 2250'
             2214  STORE_FAST               'seg'

 L. 849      2216  LOAD_FAST                'seg'
             2218  LOAD_ATTR                a
             2220  LOAD_FAST                'seg'
             2222  LOAD_ATTR                b
             2224  COMPARE_OP               ==
             2226  POP_JUMP_IF_FALSE  2234  'to 2234'

 L. 849      2230  CONTINUE           2212  'to 2212'
             2234  ELSE                     '2248'

 L. 850      2234  LOAD_FAST                'trace'
             2236  LOAD_ATTR                add_segment
             2238  LOAD_FAST                'seg'
             2240  LOAD_FAST                'width'
             2242  CALL_FUNCTION_2       2  '2 positional arguments'
             2244  POP_TOP          
             2246  JUMP_BACK          2212  'to 2212'
             2250  POP_BLOCK        
           2252_0  COME_FROM_LOOP     2206  '2206'

 L. 851      2252  LOAD_FAST                'net_index'
             2254  LOAD_FAST                'trace'
             2256  STORE_ATTR               net_index

 L. 852      2258  LOAD_FAST                'l'
             2260  LOAD_ATTR                add_trace
             2262  LOAD_FAST                'trace'
             2264  CALL_FUNCTION_1       1  '1 positional argument'
             2266  POP_TOP          
             2268  JUMP_BACK          2062  'to 2062'
             2272  POP_BLOCK        
           2274_0  COME_FROM_LOOP     2056  '2056'
           2274_1  COME_FROM          1400  '1400'

Parse error at or near `POP_BLOCK' instruction at offset 1086

    def extract_polygonvoid(this, header, poly):
        tok1, pairs = header
        sense = 1
        if tok1 == 'POLYVOID':
            sense = -1
        else:
            void = tok1 == 'POLYVOID'
            if 'W' in pairs:
                if float(pairs['W']) != 0:
                    width = float(pairs['W'])
            width = 0
        startpos = R2(float(pairs['X'].strip(',')), float(pairs['Y'].strip(',')))
        lastpos = startpos
        segs = []
        shapes = []
        for l in poly:
            l = l.strip().strip('()')
            a = my_split(l)
            tok = a[0]
            pairs = {}
            for p in a[1:]:
                if '=' in p:
                    a2 = p.split('=')
                    pairs[a2[0].upper()] = a2[1]

            if tok == 'LINE':
                pos = R2(float(pairs['X']), float(pairs['Y']))
                if pos != lastpos:
                    segs.append(utils2dPy.CurveSegment(lastpos, pos))
                    lastpos = pos
            elif tok == 'CURVE':
                p1 = R2(float(pairs['X1']), float(pairs['Y1']))
                p2 = R2(float(pairs['X2']), float(pairs['Y2']))
                center = R2(float(pairs['XC']), float(pairs['YC']))
                R = float(pairs['R'])
                if p1 == p2:
                    if len(poly) == 2:
                        if R == 0:
                            continue
                        shapes = [
                         (
                          utils2dPy.make_circle_shape(center, R, sense > 0), void)]
                        if width:
                            tmpsh = CirclePath(center, R, width)
                            for sh in tmpsh:
                                shapes.append((utils2dPy.CShapeWithHoles(sh), False))

                        return shapes
                seg = utils2dPy.CurveSegment(p1, p2, center, R)
                if p1 != lastpos:
                    seg.reverse()
                segs.append(seg)
                lastpos = seg.b
            elif tok == '}':
                pass
            else:
                print('WARNING: unknown token: %s' % tok)

        if tok1 == 'POLYLINE':
            return segs
        try:
            asegs = ArrayCurveSegment(0)
            for seg in segs:
                asegs.append(seg)

            shape = Shape(asegs)
            shape = this.sp(shape, sense=sense)
            if shape is not None:
                shapes = [
                 (
                  shape.shape, void)]
            else:
                print('WARNING: skipped broken shape', tok1, startpos)
                shapes = [(None, void)]
            if width:
                for seg in segs:
                    if seg.a == seg.b:
                        pass
                    else:
                        shape = segment2shape(seg, width, (this.tolerance), roundcaps=True)
                        shape = this.sp(shape, sense=1)
                        if shape is not None:
                            shapes.append((shape, False))
                        else:
                            print('WARNING: skipped broken shape', tok1, startpos)

            return shapes
        except:
            print('WARNING: skipped broken shape', tok1, startpos)
            return [(None, void)]

    def extract_polygon_with_holes(this, swh, tolerance):
        shapes = []
        for header, poly in swh:
            shapes.extend(this.extract_polygonvoid(header, poly))

        if len(shapes) == 0 or shapes[0][0] is None:
            return []
        else:
            shapes = [s for s in shapes if s[0] is not None]
            cswh = utils2dPy.CShapeWithHoles()
            cswh.shape = shapes[0][0]
            res = []
            for s in shapes[1:]:
                if s[1] == True:
                    cswh.add_hole(s[0])
                else:
                    res.append(s[0])

            res.append(cswh)
            res2 = []
            for cswh in res:
                swh = cswh.to_ShapeWithHoles()
                swh = this.sp(swh, sense=1)
                if swh is not None:
                    res2.append(swh)
                else:
                    print('WARNING: skipped broken shape', poly)

            return res2

    def think_about_padstack_connectivity(this, db):
        pss = []
        for i in range(db.n_padstacks()):
            pss.append(db.padstack(i))

        for comp in db.components():
            for i in range(comp.n_padstacks()):
                pss.append(comp.padstack(i))

        connect = layoutdbPy.ConnectType.connect
        thermal = layoutdbPy.ConnectType.thermal
        for ps in pss:
            for l in db.layers():
                if l.is_etch():
                    if ps.library_padstack.name in this.lpds_has_thermal:
                        if l.name in this.lpds_has_thermal[ps.library_padstack.name]:
                            lps = ps.library_padstack
                            pad_t = lps.pad(l, thermal)
                            lps.pad(l, connect, pad_t)
                    ps.connect(l, connect)

    def fix_components(this, db):
        for comp in db.components():
            bbox = None
            if comp.n_pins():
                bbox = utils2dPy.BoundingBox(comp.pin(0).position, comp.pin(0).position)
                pos = R2(0, 0)
                for i in range(comp.n_pins()):
                    pos += comp.pin(i).position
                    bbox.extend(comp.pin(i).position)

                comp.position = pos / comp.n_pins()
            if bbox is not None:
                comp.add_outline_shape(utils2dPy.CShapeWithHoles(utils2dPy.make_rectangle_shape(bbox.lower_left(), bbox.upper_right(), True)))

    def create_implicit_geometries(this, db):
        return
        warned = False
        for l in db.layers():
            if l.layer_type == layoutdbPy.LayerType.Plane:
                l.add_plane_shape(db.board_outline)

    def create_clearance(this, db):
        if this.data_mode == 'DETAILED':
            return
        else:
            print('WARNING: the .HYP file might not contain all of the physical details required for accurate 3D simulation. For more information see online help.')
            net_sep = layoutdbPy.vectorNetPlaneSep()
            for ni, v in this.plane_sep_inf['NET_PS'].items():
                net_sep.append(layoutdbPy.NetPlaneSep(ni, v))

            if 'PLANE_SEP' in this.plane_sep_inf:
                plane_sep = this.plane_sep_inf['PLANE_SEP']
            else:
                plane_sep = 0
        errors = set()
        for lname, attr in this.plane_sep_inf['LAYERS'].items():
            if 'plane_shapes' not in attr:
                pass
            else:
                if 'stackup_ps' in attr:
                    layer_sep = attr['stackup_ps']
                else:
                    layer_sep = plane_sep
                if 'segm_ps' in attr:
                    segm_ps = attr['segm_ps']
                else:
                    segm_ps = layoutdbPy.vectorAntiTrace()
            if layer_sep == 0 and len(net_sep) == 0 and len(segm_ps) == 0 and not this.has_antipads:
                errors.add(lname)
                layer = db.layer(lname)
                for shape in attr['plane_shapes']:
                    layer.add_plane_shape(shape)

            else:
                res_shapes = layoutdbPy.get_plane_shapes_with_clearance(lname, layer_sep, net_sep, db, attr['plane_shapes'], segm_ps)
                if len(res_shapes):
                    layer = db.layer(lname)
                    for shape in res_shapes:
                        layer.add_plane_shape(shape)

        if len(errors):
            msg = ', '.join(sorted(list(errors)))
            print('WARNING: can not create correct geometry for layer(s) %s because of missing antipads and plane separation information in the design' % msg)

    def to_LayoutDB(this):
        this.db = db = layoutdbPy.new_iLayoutDB()
        this.lps2layerspan = {}
        db.name = this.hypfilename
        db.origin = 'CST Hyperlynx Import V2'
        db.part_model_db = layoutdbPy.PartModelDB()
        db.simulation_settings.lateral_reference_length = 1e+30
        this.lpds_has_thermal = {}
        this.data_mode = None
        file = FileWithPush(open(this.hypfilename))
        supported_tokens = ('BOARD_FILE', 'VERSION', 'UNITS', 'PLANE_SEP', 'DATA_MODE',
                            'BOARD', 'STACKUP', 'DEVICES', 'PADSTACK', 'NET_CLASS',
                            'NET', 'END')
        this.tokens_parsed = []
        this.padstack_names = set()
        this.plane_sep_inf = {'NET_PS':{},  'LAYERS':{}}
        if this.progressbar is not None:
            n_lines = len(open(this.hypfilename).readlines())
            this.progressbar.reset('Parsing file', n_lines)
        while not file.eof:
            if this.progressbar is not None:
                this.progressbar.set(file.line_no)
            block = this.read_next_block(file)
            if block.header is None:
                pass
            else:
                a = my_split(block.header)
                assert len(a) > 0
                token = a[0].upper()
                for t in supported_tokens:
                    if token.startswith(t):
                        getattr(this, 'parse_' + t)(token, block, db)
                        this.tokens_parsed.append(t)
                        break
                else:
                    print('WARNING: unsupported token %s skipped' % token)

        if db.board_outline is None:
            print('WARNING: could not read board outline (taking PCB bounding box instead)')
            db.board_outline = layoutdbPy.compute_board_outline(db, 0.05)
        if this.progressbar is not None:
            this.progressbar.finished()
        this.think_about_padstack_connectivity(db)
        this.fix_components(db)
        check_pin_names(db.components())
        this.create_implicit_geometries(db)
        this.has_antipads = False
        this.create_clearance(db)
        return db


def Run(filename, importer):
    print('=' * 60)
    print('Reading Mentor Graphics HyperLynx file...\n')
    hyp = HyperLynxImporter(filename, progressbar=importer)
    db = hyp.to_LayoutDB()
    print('Finished reading database.')
    print('=' * 60)
    if db is not None:
        importer.db = db
    return 0


if __name__ == '__main__':
    import sys
    name = sys.argv[1]
    i = HyperLynxImporter(name)
    db = i.to_LayoutDB()
