# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\ipc2581\importipc2581.py
# Compiled at: 2019-03-12 19:09:02
# Size of source mod 2**32: 55246 bytes
import sys, os, types, math, re
from common.utils2d import R2, CurveSegment, ArrayCurveSegment, Shape, Make_CClockwise, Make_Clockwise, BoundingBox, Planeprocessor, vectorShapeWithHoles
from common.utils2d import CircleShape, RectangleC, PolyarcShape, straight_path_segment_to_XYR, PolylineShape, Xyrs2Segments
from common.utils2d import ShapeProcessor, polyarc_path_to_polyarc_shapes
from common.layoutdb import check_layer_stackup
from common.layoutdb import DatabaseReadError
from common.helpers import to_float
from common.helpers import make_list
from common.layoutdb import check_layer_stackup, check_pin_names
from common.units import length_unit_convert
from common.shapemanager import create_standart_shapes
from layoutdbPy import *
import layoutdbPy
from utils2dPy import *
import utils2dPy
from common import parsexml

class IPCImport:
    __doc__ = ' ipc2581 parser class '

    def __init__(this, layoutfilename, progressbar=None):
        this.layoutfilename = layoutfilename
        data = parsexml.read_XML(layoutfilename, progressbar=progressbar)
        this.data = getattr(data, 'IPC-2581')
        this.progressbar = progressbar
        this.design_name = os.path.basename(layoutfilename)
        this.EntryStandard = {}
        this.EntryUser = {}
        this.lps_count = 0

    def get_simple_shape(this, shapename, data):
        res = []
        if hasattr(data.LineDesc, 'lineWidth'):
            w = float(data.LineDesc.lineWidth)
        else:
            w = 0
        if hasattr(data.LineDesc, 'lineEnd'):
            roundcaps = str(data.LineDesc.lineEnd).upper() == 'ROUND'
        else:
            roundcaps = True
        if shapename == 'Arc':
            sX, sY, eX, eY, cX, cY = (
             data.startX, data.startY, data.endX, data.endY, data.centerX, data.centerY)
            sX, sY, eX, eY, cX, cY = (float(sX), float(sY), float(eX), float(eY), float(cX), float(cY))
            if hasattr(data, 'clockwise'):
                clockwise = data.clockwise.upper() == 'TRUE'
            else:
                clockwise = False
            a = R2(sX, sY)
            b = R2(eX, eY)
            c = R2(cX, cY)
            R = (a - c).getNorm()
            if clockwise:
                R *= -1.0
            seg = CurveSegment(a, b, c, R)
            segs = utils2dPy.ArrayCurveSegment(0)
            segs.push_back(seg)
            res.append([segs, w, roundcaps])
        if shapename == 'Line':
            sX, sY, eX, eY = (
             data.startX, data.startY, data.endX, data.endY)
            sX, sY, eX, eY = (float(sX), float(sY), float(eX), float(eY))
            a = R2(sX, sY)
            b = R2(eX, eY)
            seg = CurveSegment(a, b)
            segs = utils2dPy.ArrayCurveSegment(0)
            segs.push_back(seg)
            res.append([segs, w, roundcaps])
        if shapename == 'Polyline':
            xyrs = this.get_xyrs_from_steps(data.PolyBegin, data.PolySteps)
            segs = Xyrs2Segments(xyrs)
            res.append([segs, w, roundcaps])
        if shapename == 'Outline':
            shape = this.create_swh(data.Polygon, [])
            if w != 0:
                swh = shape.to_ShapeWithHoles()
                for seg in swh.shape.segments:
                    res.append(thicken_curvesegment(seg, w, True, this.tolerance, roundcaps))

            shape = this.sp(shape, sense=1, info='Outline')
            if shape is not None:
                res.append(shape)
        return res

    def get_xyrs_from_steps(this, begin, steps):
        xyrs = [
         (
          R2(begin.x, begin.y), 0)]
        for step in make_list(steps):
            a = R2(step.x, step.y)
            if hasattr(step, 'centerX'):
                if hasattr(step, 'centerY'):
                    if hasattr(step, 'clockwise'):
                        c = R2(step.centerX, step.centerY)
                        R = (c - a).getNorm()
                        if step.clockwise.upper() == 'FALSE':
                            R *= -1.0
                        xyrs.append((c, R))
            xyrs.append((a, 0))

        return xyrs

    def get_shape_from_steps(this, begin, steps):
        xyrs = this.get_xyrs_from_steps(begin, steps)
        shape = PolyarcShape(xyrs)
        return shape

    def create_swh(this, polygon, cutouts):
        shape = this.get_shape_from_steps(polygon.PolyBegin, polygon.PolySteps)
        swh = utils2dPy.ShapeWithHoles()
        swh.shape = shape
        for cutout in make_list(cutouts):
            hole = this.get_shape_from_steps(cutout.PolyBegin, cutout.PolySteps)
            swh.holes.append(hole)

        res = this.sp(swh, sense=1, info='board outline')
        return res

    def get_contour(this, contour):
        polygon = contour.Polygon
        if hasattr(contour, 'Cutout'):
            cutouts = make_list(contour.Cutout)
        else:
            cutouts = []
        cswh = this.create_swh(polygon, cutouts)
        return cswh

    def get_EntryStandard(this, entry):
        id = str(entry.id)
        swhs = []
        if hasattr(entry, 'Contour'):
            swhs = [
             this.get_contour(entry.Contour)]
        else:
            if hasattr(entry, 'Circle'):
                data = entry.Circle
                d = float(data.diameter)
                swhs = create_standart_shapes('Circle', [d])
            else:
                if hasattr(entry, 'Diamond'):
                    data = entry.Diamond
                    w, h = float(data.width), float(data.height)
                    swhs = create_standart_shapes('Diamond')
                else:
                    if hasattr(entry, 'Donut'):
                        data = entry.Donut
                        shape, od, id = data.shape, float(data.outerDiameter), float(data.innerDiameter)
                        if shape == 'ROUND':
                            swhs = create_standart_shapes('RoundDonut', [od, id])
                        else:
                            if shape == 'SQUARE':
                                swhs = create_standart_shapes('SquareDonut', [od, id])
                            else:
                                if shape == 'HEXAGON':
                                    swhs = create_standart_shapes('HexagonDonut', [od, id])
                                else:
                                    if shape == 'OCTAGON':
                                        swhs = create_standart_shapes('OctagonDonut', [od, id])
                                    else:
                                        print('Warning: unknown donut shape %s, skipped' % shape)
                    else:
                        if hasattr(entry, 'Ellipse'):
                            print('WARNING: replaced elipse Entry Standard by oval')
                            data = entry.Ellipse
                            w, h = float(data.width), float(data.height)
                            swhs = create_standart_shapes('Oval', [w, h])
                        else:
                            if hasattr(entry, 'Hexagon'):
                                data = entry.Hexagon
                                l = float(data.length)
                                swhs = create_standart_shapes('Hexagon', [])
                            else:
                                if hasattr(entry, 'Moire'):
                                    data = entry.Moire
                                    d, rw, rg, nr, lw, ll, la = (data.diameter, data.ringWidth, data.ringGap, data.ringNumber, data.lineWidth, data.lineLength, data.lineAngle)
                                    d, rw, rg, nr, lw, ll, la = (float(d), float(rw), float(rg), int(nr), float(lw), float(ll), float(la) * math.pi / 180.0)
                                    swhs = create_standart_shapes('Moire', [rw, rg, nr, lw, ll, la])
                                else:
                                    if hasattr(entry, 'Octagon'):
                                        data = entry.Octagon
                                        l = float(data.length)
                                        swhs = create_standart_shapes('Octagon_l', [l])
                                    else:
                                        if hasattr(entry, 'Oval'):
                                            data = entry.Oval
                                            w, h = float(data.width), float(data.height)
                                            swhs = create_standart_shapes('Oval', [w, h])
                                        else:
                                            if hasattr(entry, 'RectCenter'):
                                                data = entry.RectCenter
                                                w, h = float(data.width), float(data.height)
                                                swhs = create_standart_shapes('Rect', [w, h])
                                            else:
                                                if hasattr(entry, 'RectCham'):
                                                    data = entry.RectCham
                                                    w, h, rad = float(data.width), float(data.height), float(data.chamfer)
                                                    corners = ''
                                                    if hasattr(data, 'upperRight'):
                                                        if str(data.upperRight).upper() == 'TRUE':
                                                            corners += '1'
                                                    if hasattr(data, 'upperLeft'):
                                                        if str(data.upperLeft).upper() == 'TRUE':
                                                            corners += '2'
                                                    if hasattr(data, 'lowerLeft'):
                                                        if str(data.lowerLeft).upper() == 'TRUE':
                                                            corners += '3'
                                                    if hasattr(data, 'lowerRight'):
                                                        if str(data.lowerRight).upper() == 'TRUE':
                                                            corners += '4'
                                                    swhs = create_standart_shapes('RectCham', [w, h, rad, corners])
                                                else:
                                                    if hasattr(entry, 'RectCorner'):
                                                        data = entry.RectCorner
                                                        llx, lly, urx, ury = (float(data.lowerLeftX), float(data.lowerLeftY), float(data.upperRightX), float(data.upperRightY))
                                                        swhs = create_standart_shapes('RectCorner', [llx, lly, urx, ury])
                                                    else:
                                                        if hasattr(entry, 'RectRound'):
                                                            data = entry.RectRound
                                                            w, h, rad = float(data.width), float(data.height), float(data.radius)
                                                            corners = ''
                                                            if hasattr(data, 'upperRight'):
                                                                if str(data.upperRight).upper() == 'TRUE':
                                                                    corners += '1'
                                                            if hasattr(data, 'upperLeft'):
                                                                if str(data.upperLeft).upper() == 'TRUE':
                                                                    corners += '2'
                                                            if hasattr(data, 'lowerLeft'):
                                                                if str(data.lowerLeft).upper() == 'TRUE':
                                                                    corners += '3'
                                                            if hasattr(data, 'lowerRight'):
                                                                if str(data.lowerRight).upper() == 'TRUE':
                                                                    corners += '4'
                                                            swhs = create_standart_shapes('RectRound', [w, h, rad, corners])
                                                        else:
                                                            if hasattr(entry, 'Triangle'):
                                                                data = entry.Triangle
                                                                b, h = float(data.base), float(data.height)
                                                                swhs = create_standart_shapes('Triangle', [b, h])
                                                            else:
                                                                if hasattr(entry, 'Thermal'):
                                                                    data = entry.Thermal
                                                                    shape, od, id, angle, num_sp, gap = (data.shape, data.outerDiameter, data.innerDiameter, data.spokeStartAngle, data.spokeCount, data.gap)
                                                                    od, id, angle, num_sp, gap = (float(od), float(id), float(angle) * math.pi / 180.0, int(num_sp), float(gap))
                                                                    if shape == 'ROUND':
                                                                        swhs = create_standart_shapes('RoundThermal', [od, id, angle, num_sp, gap])
                                                                    else:
                                                                        if shape == 'SQUARE':
                                                                            swhs = create_standart_shapes('SquareThermal', [od, id, angle, num_sp, gap])
                                                                        else:
                                                                            if shape == 'HEXAGON':
                                                                                swhs = create_standart_shapes('HexagonThermal', [od, id, angle, num_sp, gap])
                                                                            else:
                                                                                if shape == 'OCTAGON':
                                                                                    swhs = create_standart_shapes('OctagonThermal', [od, id, angle, num_sp, gap])
                                                                                else:
                                                                                    print('Warning: unknown thermal shape %s, skipped' % shape)
                                                                else:
                                                                    if hasattr(entry, 'Butterfly'):
                                                                        data = entry.Butterfly
                                                                        shape = data.shape
                                                                        if shape == 'ROUND':
                                                                            d = float(data.diameter)
                                                                            swhs = create_standart_shapes('RoundButterfly', [d])
                                                                        else:
                                                                            if shape == 'SQUARE':
                                                                                s = float(data.side)
                                                                                swhs = create_standart_shapes('SquareButterfly', [s])
                                                                    else:
                                                                        print('WARNING: unknown EntryStandard: ', entry)
        return swhs

    def to_LayoutDB(this):
        from common.units import get_typical_manufacturing_tolerance
        units = this.data.Ecad.CadHeader.units
        if units == 'MICRON':
            this.db_unit = 'mu'
        else:
            if units == 'INCH':
                this.db_unit = 'in'
            else:
                if units == 'MILLIMETER':
                    this.db_unit = 'mm'
        layoutdb = new_iLayoutDB()
        layoutdb.name = this.design_name
        layoutdb.description = 'IPC-2581 Import'
        layoutdb.origin = 'IPC-2581'
        layoutdb.length_unit = this.db_unit
        layoutdb.tolerance = get_typical_manufacturing_tolerance(layoutdb.length_unit) * 0.5
        this.tolerance = layoutdb.tolerance
        this.sp = ShapeProcessor(get_typical_manufacturing_tolerance(this.db_unit))
        layoutdb.is_x_mirror_mode = False
        if hasattr(this.data, 'revision'):
            if this.data.revision in ('A', 'B'):
                print('WARNING: The current file format, IPC-2581 (Revision %s), is not fully supported -> Some design data may be lost.' % str(this.data.revision))
        else:
            if hasattr(this.data.Ecad.CadData, 'StepList'):
                steps = make_list(this.data.Ecad.CadData.StepList.Step)
            else:
                steps = make_list(this.data.Ecad.CadData.Step)
        if len(steps) > 1:
            print('WARNING: design has more then one step, only first one will be imported')
        this.Step = steps[0]
        outline_shape = this.extract_outline()
        layoutdb.board_outline = outline_shape
        this.extract_stackup(layoutdb)
        if hasattr(this.data.Content, 'DictionaryStandard'):
            this.parse_DictionaryStandard(this.data.Content.DictionaryStandard)
        if hasattr(this.data.Content, 'DictionaryUser'):
            this.parse_DictionaryUser(this.data.Content.DictionaryUser)
        this.extract_BomItems()
        this.extract_Package()
        this.extract_Component(layoutdb)
        this.extract_LayerFeature(layoutdb)
        check_layer_stackup(layoutdb)
        check_pin_names(layoutdb.components())
        this.extract_drills(layoutdb)
        this.extract_padstacks(layoutdb)
        return layoutdb

    def extract_outline(this):
        polygon = this.Step.Profile.Polygon
        if hasattr(this.Step.Profile, 'Cutout'):
            cutouts = make_list(this.Step.Profile.Cutout)
        else:
            cutouts = []
        cswh = this.create_swh(polygon, cutouts)
        return cswh

    def extract_stackup(this, layoutdb):
        if hasattr(this.data.Ecad.CadData, 'LayerDesc'):
            layers = make_list(this.data.Ecad.CadData.LayerDesc.Layer)
            if hasattr(this.data.Ecad.CadData.LayerDesc, 'Stackup'):
                stackup = this.data.Ecad.CadData.LayerDesc.Stackup
            else:
                stackup = None
        else:
            layers = make_list(this.data.Ecad.CadData.Layer)
            if hasattr(this.data.Ecad.CadData, 'Stackup'):
                stackup = this.data.Ecad.CadData.Stackup
            else:
                stackup = None
            this.layer_list = {}
            layer_orig_order = []
            this.comp_layers = {}
            this.drill_layers = {}
            top_sm = bot_sm = None
            for ldata in layers:
                layerFunction = ldata.layerFunction.upper()
                if layerFunction in ('SOLDERMASK', 'CONDUCTOR', 'SIGNAL', 'MIXED',
                                     'PLANE', 'COMPONENT'):
                    lname = str(ldata.name)
                    layer = layoutdbPy.new_iLayer()
                    layer.name = lname
                    layer.is_positive = ldata.polarity == 'POSITIVE'
                    if layerFunction in ('CONDUCTOR', 'SIGNAL', 'MIXED'):
                        layer.layer_type = layoutdbPy.LayerType.Signal
                    else:
                        if layerFunction == 'PLANE':
                            layer.layer_type = layoutdbPy.LayerType.Plane
                        else:
                            if layerFunction == 'PLANE':
                                layer.layer_type = layoutdbPy.LayerType.Plane
                            else:
                                if layerFunction == 'SOLDERMASK':
                                    layer.layer_type = layoutdbPy.LayerType.Soldermask
                                    if ldata.side.upper() == 'TOP':
                                        top_sm = layer
                                    else:
                                        if ldata.side.upper() == 'BOTTOM':
                                            bot_sm = layer
                                else:
                                    if layerFunction == 'COMPONENT':
                                        side = str(ldata.side).upper()
                                        this.comp_layers[lname] = {'layer':layer,  'side':side}
                        this.layer_list[lname] = {'layer':layer, 
                         'side':str(ldata.side),  'layer_type':str(layerFunction)}
                        layer_orig_order.append(lname)
                    if layerFunction == 'DRILL':
                        this.drill_layers[str(ldata.name)] = ldata

            if stackup != None:
                overallThickness = float(stackup.overallThickness)
                for StackupGroup in make_list(stackup.StackupGroup):
                    if hasattr(StackupGroup, 'stackupGroupName') and StackupGroup.stackupGroupName in this.layer_list:
                        lname = StackupGroup.stackupGroupName
                        ldata = this.layer_list[lname]
                        lthickness = float(StackupGroup.thickness)
                        layer = ldata['layer']
                        layer.thickness = lthickness
                        layoutdb.add_layer_below(layer, layer)
                    else:
                        for StackupLayer in make_list(StackupGroup.StackupLayer):
                            lname = str(StackupLayer.layerOrGroupRef)
                            if lname in this.layer_list:
                                ldata = this.layer_list[lname]
                                layer = ldata['layer']
                                lthickness = float(StackupLayer.thickness)
                                layer.thickness = lthickness
                                material = layoutdbPy.Material()
                                if hasattr(StackupLayer, 'materialType'):
                                    material.name = str(StackupLayer.materialType)
                                    if layer.is_conductor():
                                        material.type = layoutdbPy.MaterialType.Conductor
                                    else:
                                        material.type = layoutdbPy.MaterialType.Dielectric
                                    layer.material = material
                                elif hasattr(StackupLayer, 'materialType'):
                                    if 'DIELECTRIC' in lname or 'FR-4' in str(StackupLayer.materialType) or 'FR4' in str(StackupLayer.materialType):
                                        layer = layoutdbPy.new_iLayer()
                                        layer.name = lname
                                        layer.layer_type = layoutdbPy.LayerType.Dielectric
                                        lthickness = float(StackupLayer.thickness)
                                        layer.thickness = lthickness
                                    else:
                                        continue
                                if hasattr(StackupLayer, 'NonstandardAttribute'):
                                    for attr in make_list(StackupLayer.NonstandardAttribute):
                                        if attr.name == 'LAYER_ELECTRICAL_CONDUCTIVITY':
                                            val = float(arr.val)

                                layoutdb.add_layer_below(layer, None)

            else:
                top_etch = bot_etch = None
                for lname in layer_orig_order:
                    ldata = this.layer_list[lname]
                    if ldata['layer_type'] in ('CONDUCTOR', 'SIGNAL', 'MIXED', 'PLANE'):
                        if ldata['side'].upper() == 'TOP':
                            top_etch = ldata['layer']
                        else:
                            if ldata['side'].upper() == 'BOTTOM':
                                bot_etch = ldata['layer']
                            else:
                                layoutdb.add_layer_below(ldata['layer'], None)

                if top_etch != None:
                    layoutdb.add_layer_above(top_etch, None)
        if bot_etch != None:
            layoutdb.add_layer_below(bot_etch, None)
        if top_sm != None:
            if not layoutdb.layer(0).is_etch():
                layoutdb.delete_layer(layoutdb.layer(0))
            layoutdb.add_layer_above(top_sm, None)
        if bot_sm != None:
            if not layoutdb.layer(layoutdb.n_layers() - 1).is_etch():
                layoutdb.delete_layer(layoutdb.layer(layoutdb.n_layers() - 1))
            layoutdb.add_layer_below(bot_sm, None)

    def parse_DictionaryStandard(this, dictionaryStandard):
        units = dictionaryStandard.units
        if units == 'MILLIMETER':
            lscale = length_unit_convert(this.db_unit, 1.0, 'mm')
        else:
            if units == 'MICRON':
                lscale = length_unit_convert(this.db_unit, 1.0, 'um')
            else:
                if units == 'INCH':
                    lscale = length_unit_convert(this.db_unit, 1.0, 'in')
        if hasattr(dictionaryStandard, 'EntryStandard'):
            for entry in dictionaryStandard.EntryStandard:
                id = str(entry.id)
                swhs = this.get_EntryStandard(entry)
                cswhs = []
                for shape in swhs:
                    shape.scale(lscale)
                    cswh = this.sp(shape, sense=1, info='EntryStandard')
                    if cswh != None:
                        cswhs.append(cswh)
                    else:
                        print('Warning: skipped brocken shape for EntryStandard ', id)

                this.EntryStandard[id] = cswhs

    def parse_DictionaryUser(this, dictionaryUser):
        units = dictionaryUser.units
        if units == 'MILLIMETER':
            lscale = length_unit_convert(this.db_unit, 1.0, 'mm')
        else:
            if units == 'MICRON':
                lscale = length_unit_convert(this.db_unit, 1.0, 'um')
            else:
                if units == 'INCH':
                    lscale = length_unit_convert(this.db_unit, 1.0, 'in')
        if hasattr(dictionaryUser, 'EntryUser'):
            for entry in make_list(dictionaryUser.EntryUser):
                id = str(entry.id)
                shapes = []
                shapes = this.get_basic_figures(entry)
                if hasattr(entry, 'UserSpecial'):
                    for userspecial in make_list(entry.UserSpecial):
                        shapes.extend(this.get_basic_figures(userspecial))

                cswhs = []
                for shape in shapes:
                    if type(shape) == utils2dPy.CShapeWithHoles:
                        shape.scale(lscale)
                        cswhs.append(shape)
                    else:
                        if type(shape) == list and type(shape[0]) == utils2dPy.ArrayCurveSegment:
                            w = shape[1]
                            roundcaps = shape[2]
                            if w != 0:
                                for segm in shape[0]:
                                    shapetmp = thicken_curvesegment(segm, w, True, this.tolerance, roundcaps)
                                    shapetmp.scale(lscale)
                                    cswh = this.sp(shapetmp, sense=1, info='EntryUser')
                                    if cswh != None:
                                        cswhs.append(cswh)

                this.EntryUser[id] = cswhs

    def get_basic_figures(this, feature):
        shapes = []
        if hasattr(feature, 'Arc'):
            for arc in make_list(feature.Arc):
                shapes.extend(this.get_simple_shape('Arc', arc))

        if hasattr(feature, 'Line'):
            for line in make_list(feature.Line):
                shapes.extend(this.get_simple_shape('Line', line))

        if hasattr(feature, 'Outline'):
            for outline in make_list(feature.Outline):
                shapes.extend(this.get_simple_shape('Outline', outline))

        if hasattr(feature, 'Polyline'):
            for polyline in make_list(feature.Polyline):
                shapes.extend(this.get_simple_shape('Polyline', polyline))

        if hasattr(feature, 'Contour'):
            for contour in make_list(feature.Contour):
                shapes.append(this.get_contour(contour))

        if hasattr(feature, 'UserPrimitiveRef'):
            for userprimitive in make_list(feature.UserPrimitiveRef):
                userprimitive_name = str(userprimitive.id)
                if userprimitive_name in this.EntryUser:
                    shapes = this.EntryUser[userprimitive_name]
                else:
                    print('Warning: cannot find UserPrimitiveRef %s, skipped' % userprimitive_name)

        return shapes

    def extract_LayerFeature(this, layoutdb):
        pin_layer_candidates = {}
        for lf in this.Step.LayerFeature:
            if layoutdb.has_layer(str(lf.layerRef)) and (layoutdb.layer(str(lf.layerRef)).is_conductor() or layoutdb.layer(str(lf.layerRef)).layer_type == layoutdbPy.LayerType.Soldermask):
                layer = layoutdb.layer(str(lf.layerRef))
                for set in make_list(lf.Set):
                    netname = 'NONE'
                    if hasattr(set, 'net'):
                        netname = str(set.net).split(':')[(-1)]
                    is_negative = False
                    if hasattr(set, 'polarity'):
                        if str(set.polarity).upper() == 'NEGATIVE':
                            is_negative = True
                        if hasattr(set, 'Features'):
                            for feature in make_list(set.Features):
                                layoutdb.add_net_dirty(netname)
                                shapes = []
                                shapes = this.get_basic_figures(feature)
                                if hasattr(feature, 'UserSpecial'):
                                    for userspecial in make_list(feature.UserSpecial):
                                        shapes.extend(this.get_basic_figures(userspecial))

                                if hasattr(feature, 'Location'):
                                    pos = R2(feature.Location.x, feature.Location.y)
                                else:
                                    pos = R2(0, 0)
                                for shape in shapes:
                                    if type(shape) == utils2dPy.CShapeWithHoles:
                                        shape.translate(pos)
                                        shape.net_index = layoutdb.net_index(netname)
                                        if is_negative:
                                            shape.reverse()
                                        layer.add_plane_shape(shape)
                                    elif type(shape) == list and type(shape[0]) == utils2dPy.ArrayCurveSegment:
                                        trace = layoutdbPy.Trace()
                                        w = shape[1]
                                        roundcaps = shape[2]
                                        if w != 0:
                                            for segm in shape[0]:
                                                segm.translate(pos)
                                                trace.add_segment(segm, w)

                                            trace.net_index = layoutdb.net_index(netname)
                                            trace.is_capped = roundcaps
                                            if is_negative:
                                                trace.is_positive = False
                                            layer.add_trace(trace)
                                    else:
                                        print('Warning: unknown shape type in layes Set', shape)

                        if hasattr(set, 'Pad'):
                            layoutdb.add_net_dirty(netname)
                            for pad in make_list(set.Pad):
                                position = R2(pad.Location.x, pad.Location.y)
                                if hasattr(pad, 'StandardPrimitiveRef'):
                                    shape_id = str(pad.StandardPrimitiveRef.id)
                                    shapes = this.EntryStandard[shape_id]
                                else:
                                    if hasattr(pad, 'UserPrimitiveRef'):
                                        shape_id = str(pad.UserPrimitiveRef.id)
                                        shapes = shapes = this.EntryUser[shape_id]
                                    else:
                                        print('WARNING: pad with unclear shape on position (%f,%f) and layer %s will be skiped' % (pad.Location.x, pad.Location.y, layer))
                                    if hasattr(pad, 'Xform'):
                                        offset, rotation, mirror, scale = this.get_Xform(pad.Xform)
                                    else:
                                        offset = R2(0, 0)
                                        rotation = 0.0
                                        mirror = False
                                        scale = 1.0
                                position = position + offset
                                ps = layoutdbPy.new_iPadstack()
                                lpsname = 'lps-' + str(this.lps_count)
                                this.lps_count += 1
                                lps = layoutdbPy.new_iLPadstack()
                                lps.name = lpsname
                                lpad = layoutdbPy.new_iLPad()
                                for sh in shapes:
                                    shape = CShapeWithHoles(sh)
                                    shape.scale(scale)
                                    lpad.add_shape(shape)

                                if layer.is_positive:
                                    if is_negative:
                                        connect = layoutdbPy.ConnectType.clearance
                                    else:
                                        connect = layoutdbPy.ConnectType.connect
                                else:
                                    if is_negative:
                                        connect = layoutdbPy.ConnectType.connect
                                    else:
                                        connect = layoutdbPy.ConnectType.clearance
                                    lps.pad(layer, connect, lpad)
                                    layoutdb.add_lpadstack(lps)
                                    ps.library_padstack = lps
                                    ps.layer_from = ps.layer_to = layer
                                    ps.position = position
                                    if mirror:
                                        rotation = -rotation
                                    ps.rotation = rotation
                                    ps.is_x_mirrowed = mirror
                                    ps.connect(ps.layer_from, connect)
                                    ps.net = layoutdb.net(netname)
                                    if hasattr(pad, 'pin'):
                                        if layer.is_conductor():
                                            pin_data = pad.pin.split('.')
                                            if len(pin_data) == 2:
                                                comp_name, pin_name = str(pin_data[0]), str(pin_data[1])
                                                comp = layoutdb.component(comp_name)
                                                if comp_name in pin_layer_candidates:
                                                    if pin_name in pin_layer_candidates[comp_name]:
                                                        pin_layer_candidates[comp_name][pin_name].append(layer.number)
                                                    else:
                                                        pin_layer_candidates[comp_name][pin_name] = [
                                                         layer.number]
                                                else:
                                                    pin_layer_candidates[comp_name] = {pin_name: [layer.number]}
                                                comp.add_padstack(ps)
                                                continue
                                    layoutdb.add_padstack(ps)

        for comp_name, pins in pin_layer_candidates.items():
            comp = layoutdb.component(comp_name)
            for pin_name, layers in pins.items():
                pin = comp.pin(pin_name)
                if len(layers) == 1:
                    pin.layer = layoutdb.layer(layers[0])
                else:
                    layers.sort()
                    if comp.side == layoutdbPy.WhereType.top:
                        pin.layer = layoutdb.layer(layers[0])
                    else:
                        pin.layer = layoutdb.layer(layers[(-1)])

    def get_Xform(this, Xform):
        offset = R2(0, 0)
        rotation = 0.0
        mirror = False
        scale = 1.0
        if hasattr(Xform, 'xOffset'):
            xOffset = float(Xform.xOffset)
            offset = position = R2(xOffset, 0.0)
        if hasattr(Xform, 'yOffset'):
            yOffset = float(Xform.yOffset)
            offset = position = R2(0.0, yOffset)
        if hasattr(Xform, 'rotation'):
            rotation = float(Xform.rotation) * math.pi / 180.0
        if hasattr(Xform, 'mirror'):
            mirror = str(Xform.mirror).upper() == 'TRUE'
        if hasattr(Xform, 'scale'):
            scale = float(Xform.scale)
        return [
         offset, rotation, mirror, scale]

    def extract_BomItems(this):
        this.bomitems = {}
        this.refdes2bomitems = {}
        if hasattr(this.data.Bom, 'BomItem'):
            for bomitem in make_list(this.data.Bom.BomItem):
                if hasattr(bomitem, 'internalPartNumber'):
                    PartName = str(bomitem.internalPartNumber).split(':')[(-1)]
                else:
                    if hasattr(bomitem, 'OEMDesignNumberRef'):
                        PartName = str(bomitem.OEMDesignNumberRef).split(':')[(-1)]
                    else:
                        PartName = None
                value = ''
                if hasattr(bomitem, 'Characteristics'):
                    if hasattr(bomitem.Characteristics, 'Textual'):
                        for charact in make_list(bomitem.Characteristics.Textual):
                            if hasattr(charact, 'textualCharacteristicName') and str(charact.textualCharacteristicName).upper() == 'COMP_VALUE' and hasattr(charact, 'textualCharacteristicValue'):
                                value = str(charact.textualCharacteristicValue)

                    if hasattr(bomitem, 'description'):
                        description = str(bomitem.description)
                        descrs = description.split(' ')
                        for des in descrs:
                            des_list = des.split('=')
                            if len(des_list) == 2 and des_list[0].upper() == 'COMP_VALUE':
                                value = des_list[1]

                    if PartName != None:
                        this.bomitems[PartName] = value
                        for refdes in make_list(bomitem.RefDes):
                            refdes_name = str(refdes.name).split(':')[(-1)]
                            this.refdes2bomitems[refdes_name] = PartName

    def extract_Package(this):
        this.packages = {}
        for pkg in this.Step.Package:
            pname = str(pkg.name)
            ptype = str(pkg.type)
            if hasattr(pkg, 'height'):
                height = float(pkg.height)
            else:
                height = 0.0
            if hasattr(pkg, 'Outline'):
                outlines = this.get_simple_shape('Outline', pkg.Outline)
            else:
                outlines = []
            pins = {}
            if hasattr(pkg, 'LandPattern'):
                LandPattern = pkg.LandPattern
            if hasattr(pkg, 'Pin'):
                for pin in make_list(pkg.Pin):
                    if hasattr(pin, 'name'):
                        if len(str(pin.name)) != 0:
                            name = str(pin.name)
                        else:
                            name = str(pin.number)
                    else:
                        type = str(pin.type)
                        position = R2(pin.Location.x, pin.Location.y)
                        if hasattr(pin, 'Xform'):
                            offset, rotation, mirror, scale = this.get_Xform(pin.Xform)
                        else:
                            offset = R2(0, 0)
                            rotation = 0.0
                            mirror = False
                            scale = 1.0
                        position = position + offset
                        shapes = []
                        if hasattr(pin, 'Outline'):
                            shapes.extend(this.get_simple_shape('Outline', pin.Outline))
                        if hasattr(pin, 'StandardPrimitiveRef'):
                            shape_id = str(pin.StandardPrimitiveRef.id)
                            shapes.extend(this.EntryStandard[shape_id])
                    res_shapes = []
                    for sh in shapes:
                        shape = CShapeWithHoles(sh)
                        shape.scale(scale)
                        shape.rotate(rotation)
                        if mirror:
                            shape.x_mirror()
                        shape.translate(position)
                        res_shapes.append(shape)

                    pins[name] = {'type':type, 
                     'position':position,  'shapes':res_shapes}

            this.packages[pname] = {'type':ptype, 
             'height':height,  'outlines':outlines,  'pins':pins}

    def extract_Component(this, layoutdb):
        this.em_model_items = []
        for comp in make_list(this.Step.Component):
            new_comp = layoutdbPy.new_iComponent()
            comp_name = str(comp.refDes)
            new_comp.name = comp_name.split(':')[(-1)]
            if hasattr(comp, 'Xform'):
                offset, rotation, mirror, scale = this.get_Xform(comp.Xform)
            else:
                offset = R2(0, 0)
                rotation = 0.0
                mirror = False
                scale = 1.0
            position = R2(comp.Location.x, comp.Location.y)
            position = position + offset
            new_comp.position = position
            new_comp.rotation = rotation
            layerRef = str(comp.layerRef)
            if layerRef in this.comp_layers:
                if this.comp_layers[layerRef]['side'] == 'TOP':
                    new_comp.side = layoutdbPy.WhereType.top
                    is_top = True
                else:
                    if this.comp_layers[layerRef]['side'] == 'BOTTOM':
                        new_comp.side = layoutdbPy.WhereType.bottom
                        is_top = False
                    else:
                        print('WARNING: embedded component? which layer?', new_comp.name, layerRef)
                        is_top = True
            else:
                if str(layerRef).upper() == 'TOP':
                    new_comp.side = layoutdbPy.WhereType.top
                    is_top = True
                else:
                    if str(layerRef).upper() == 'BOTTOM':
                        new_comp.side = layoutdbPy.WhereType.bottom
                        is_top = False
                    else:
                        print('WARNING: embedded component? which layer?', new_comp.name, layerRef)
                        is_top = True
                    mountType = str(comp.mountType).upper()
                    if mountType == 'SMT':
                        new_comp.mount_type = layoutdbPy.MountType.surface
                    else:
                        if mountType == 'THMT':
                            new_comp.mount_type = layoutdbPy.MountType.through
                        elif mountType == 'OTHER':
                            new_comp.mount_type = layoutdbPy.MountType.unknown
                packageRef = str(comp.packageRef)
                if packageRef not in this.packages:
                    print('WARNING: missing Package to component %s, skipped component' % new_comp.name)
                else:
                    package = this.packages[packageRef]
                    if hasattr(comp, 'height'):
                        new_comp.height = float(comp.height)
                    else:
                        new_comp.height = package['height']
                    for shape in package['outlines']:
                        shape = CShapeWithHoles(shape)
                        if is_top:
                            shape.rotate(rotation)
                        else:
                            swh = shape.to_ShapeWithHoles()
                            swh.rotate(rotation, R2(0, 0))
                            swh.x_mirror()
                        shape = this.sp(swh, info='component outline')
                        if shape == None:
                            continue
                        shape.translate(position)
                        new_comp.add_outline_shape(shape)

                    if len(list(package['pins'].keys())) >= 1:
                        pins_have_same_pos = True
                        first_pin_pos = package['pins'][list(package['pins'].keys())[0]]['position'] * 1
                        for pin_name, pin_data in package['pins'].items():
                            new_pin = layoutdbPy.new_Pin()
                            pnt = pin_data['position'] * 1
                            if pnt != first_pin_pos:
                                pins_have_same_pos = False
                            if is_top:
                                pnt.turn(rotation)
                            else:
                                pnt.x = -pnt.x
                                pnt.turn(-rotation)
                            pnt += new_comp.position
                            new_pin.position = pnt
                            if is_top:
                                new_pin.layer = layoutdb.top_etch_layer()
                            else:
                                new_pin.layer = layoutdb.bottom_etch_layer()
                            new_pin.name = pin_name
                            new_comp.add_pin(new_pin)

                        if pins_have_same_pos:
                            for pin_name, pin_data in package['pins'].items():
                                shapes = []
                                for shape in pin_data['shapes']:
                                    shape = CShapeWithHoles(shape)
                                    if is_top:
                                        shape.rotate(rotation)
                                    else:
                                        swh = shape.to_ShapeWithHoles()
                                        swh.rotate(rotation, R2(0, 0))
                                        swh.x_mirror()
                                    shape = this.sp(swh, info='component outline')
                                    if shape == None:
                                        continue
                                    shape.translate(position)
                                    shapes.append(shape)

                                new_pin = new_comp.pin(pin_name)
                                if len(shapes) >= 1:
                                    bbox = shapes[0].bbox
                                    new_pin.position = R2((bbox.xmax + bbox.xmin) * 0.5, (bbox.ymax + bbox.ymin) * 0.5)
                                else:
                                    print('Warning! Cannot determine correct pin position for pin %s component %s' % (pin_name, new_comp))

                    layoutdb.add_component(new_comp)
                    comp_art = new_comp.name[0]
                    if comp_art in 'RCL':
                        typ = comp_art
                    else:
                        typ = ''
                    part_name = str(comp.part)
                    value = ''
                    if part_name in this.bomitems:
                        value = this.bomitems[part_name]
                    this.em_model_items.append((new_comp.name, part_name, typ, value))

        from common.layoutdb import set_read_elements
        import os
        print('Reading component values...')
        warnings = set_read_elements(layoutdb, (this.em_model_items), print_warnings=False)
        print()
        for w in warnings:
            print(w)

        if len(this.em_model_items):
            filename = os.path.splitext(this.layoutfilename)[0] + '.csv'
            from common.layoutdb import export_lumped_elements_to_csv
            export_lumped_elements_to_csv(this.em_model_items, filename)
            print('INFO: Created CSV file (' + filename + ') with lumped-element values for review/re-import.')

    def extract_drills(this, layoutdb):
        for lf in this.Step.LayerFeature:
            if lf.layerRef in list(this.drill_layers.keys()):
                drill_layer = this.drill_layers[lf.layerRef]
                if hasattr(drill_layer, 'Span'):
                    layer_from = layoutdb.layer(str(drill_layer.Span.fromLayer))
                    layer_to = layoutdb.layer(str(drill_layer.Span.toLayer))
                else:
                    if hasattr(drill_layer, 'SpanType'):
                        layer_from = layoutdb.layer(str(drill_layer.SpanType.fromLayer))
                        layer_to = layoutdb.layer(str(drill_layer.SpanType.toLayer))
                    else:
                        layer_from = layoutdb.top_etch_layer()
                        layer_to = layoutdb.bottom_etch_layer()
                if hasattr(lf, 'Set'):
                    for set in make_list(lf.Set):
                        if hasattr(set, 'Hole'):
                            for hole in make_list(set.Hole):
                                diameter = float(hole.diameter)
                                shape = CShape(CircleShape(R2(0, 0), diameter * 0.5), layoutdb.tolerance)
                                lps_name = str(hole.name)
                                if layoutdb.has_lpadstack(lps_name):
                                    if layoutdb.lpadstack(lps_name).via_hole_shape != None:
                                        if layoutdb.lpadstack(lps_name).via_hole_shape.bbox == shape.bbox:
                                            lpadstack = layoutdb.has_lpadstack(lps_name)
                                    else:
                                        lpadstack = layoutdbPy.new_iLPadstack()
                                        lpadstack.name = lps_name + '-' + str(this.lps_count)
                                        this.lps_count += 1
                                        lpadstack.via_hole_shape = shape
                                        layoutdb.add_lpadstack(lpadstack)
                                else:
                                    lpadstack = layoutdbPy.new_iLPadstack()
                                    lpadstack.name = lps_name
                                    lpadstack.via_hole_shape = shape
                                    layoutdb.add_lpadstack(lpadstack)
                                new_padstack = layoutdbPy.new_iPadstack()
                                new_padstack.position = R2(hole.x, hole.y)
                                new_padstack.library_padstack = lpadstack
                                new_padstack.layer_from = layer_from
                                new_padstack.layer_to = layer_to
                                layoutdb.add_padstack(new_padstack)

    def extract_padstacks(this, layoutdb):
        if hasattr(this.Step, 'PadStack'):
            for padstack in make_list(this.Step.PadStack):
                lpsname = 'lps-' + str(this.lps_count)
                this.lps_count += 1
                lps = layoutdbPy.new_iLPadstack()
                lps.name = lpsname
                layer_from = layoutdb.top_etch_layer()
                layer_to = layoutdb.bottom_etch_layer()
                position = None
                if hasattr(padstack, 'LayerHole'):
                    hole = padstack.LayerHole
                    diameter = float(hole.diameter)
                    shape = CShape(CircleShape(R2(0, 0), diameter * 0.5), layoutdb.tolerance)
                    lps.via_hole_shape = shape
                    if hasattr(hole, 'Span'):
                        layer_from = layoutdb.layer(str(hole.Span.fromLayer))
                        layer_to = layoutdb.layer(str(hole.Span.toLayer))
                    position = R2(hole.x, hole.y)
                ps = layoutdbPy.new_iPadstack()
                ps.library_padstack = lps
                ps.layer_from = layer_from
                ps.layer_to = layer_to
                if hasattr(padstack, 'net'):
                    netname = str(padstack.net).split(':')[(-1)]
                    layoutdb.add_net_dirty(netname)
                else:
                    netname = 'None'
                if hasattr(padstack, 'LayerPad'):
                    for pad in make_list(padstack.LayerPad):
                        if layoutdb.has_layer(str(pad.layerRef)):
                            layer = layoutdb.layer(str(pad.layerRef))
                        else:
                            continue
                        shape_id = str(pad.StandardPrimitiveRef.id)
                        shapes = this.EntryStandard[shape_id]
                        postmp = R2(pad.Location.x, pad.Location.y)
                        if position == None:
                            position = postmp
                        lpad = layoutdbPy.new_iLPad()
                        if hasattr(pad, 'Xform'):
                            offset, rotation, mirror, scale = this.get_Xform(pad.Xform)
                        else:
                            offset = R2(0, 0)
                            rotation = 0.0
                            mirror = False
                            scale = 1.0
                        position = position + offset
                        for sh in shapes:
                            shape = CShapeWithHoles(sh)
                            shape.scale(scale)
                            if position != postmp:
                                shape.translate(postmp - position)
                            shape.rotate(rotation)
                            if mirror:
                                shape.x_mirror()
                            lpad.add_shape(shape)

                        lps.pad(layer, layoutdbPy.ConnectType.connect, lpad)
                        layoutdb.add_lpadstack(lps)
                        ps.connect(layer, layoutdbPy.ConnectType.connect)

                ps.position = position
                ps.net = layoutdb.net(netname)
                layoutdb.add_padstack(ps)


def Run(filename, importer):
    print('=' * 60)
    print('Reading IPC2581  database ...\n')
    e = IPCImport(filename, progressbar=importer)
    layoutdb = e.to_LayoutDB()
    print('Finished reading IPC2581 database.')
    print('=' * 60)
    if layoutdb is not None:
        importer.db = layoutdb
    return 0


if __name__ == '__main__':
    import sys
    e = IPCImport(sys.argv[1])
    db = e.to_LayoutDB()
# okay decompiling importipc2581.pyc
