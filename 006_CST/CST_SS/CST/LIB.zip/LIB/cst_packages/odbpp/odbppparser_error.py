# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\odbpp\odbppparser.py
# Compiled at: 2019-03-13 21:58:21
# Size of source mod 2**32: 145411 bytes
Instruction context:
   
 L.1656      1116  BUILD_LIST_0          0 
                1118  LOAD_DEREF               'this'
                1120  LOAD_ATTR                toeprints_candidates
                1122  LOAD_FAST                'lyr_name'
                1124  BINARY_SUBSCR    
                1126  LOAD_FAST                'f_num'
                1128  STORE_SUBSCR     
              1130_0  COME_FROM           794  '794'
                1130  JUMP_BACK           676  'to 676'
                1134  POP_BLOCK        
->              1136  JUMP_BACK           550  'to 550'
                1140  ELSE                     '1424'
"""
This module contains all functionality to create a layoutdb.LayoutDB database from an ODB++ directory tree.
"""
import math, os, sys
from .attributesv64 import get_system_attributes
from common.utils2d import R2, Shape, ShapeWithHoles, CurveSegment, ArrayCurveSegment, Make_CClockwise, Make_Clockwise, ShapeProcessor, vectorShapeWithHoles, CShapeWithHoles, BoundingBox, Planeprocessor
from common import utils2d
from common.units import floatmag
from common.layoutdb import DatabaseReadError, type_name_to_RLC_type
from common.layoutdb import check_layer_stackup, check_pin_names
from common.units import get_length_unit_conversion_factor_in, get_length_unit_conversion_factor_mu
import utils2dPy, layoutdbPy, tarfile

def valid_odbpp_dir(dir):
    if not os.path.exists(dir):
        return 'Error: the source directory\n"%s" does not exist' % dir
    else:
        l = os.listdir(dir)
        txt = 'The following ODB++ sub-directories are missing\n[in directory "%s"]:\n' % dir
        okay = True
        for name in ('matrix', 'steps', 'symbols'):
            if name not in l:
                txt += '\t- %s\n' % name
                okay = False

        if okay:
            return 'ok'
        return txt


def valid_odbpp_file(name):
    dum, ext = os.path.splitext(name)
    if ext == '.xml':
        return 'ok:xml'
    if not os.path.exists(name):
        return 'Error: the ODB++ zipfile\n"%s" does not exist' % name
    import zipfile
    if zipfile.is_zipfile(name):
        z = zipfile.ZipFile(name, 'r')
        errs = z.testzip()
        if errs is None:
            return 'ok'
        return 'Error: in zipped file "%s", archive member %s' % (name, errs)
    else:
        import tarfile
        if tarfile.is_tarfile(name):
            return 'ok:ODB++'
        return 'Error: no archive file: "%s"' % name


def unzip_all_files(odbpath):
    count = 0
    for path, dirs, files in os.walk(odbpath):
        for file in files:
            r, ext = os.path.splitext(file)
            if ext in ('.Z', '.gz'):
                filename = os.path.join(path, file)
                print('Unzipping %s' % filename)
                os.system('gzip -d %s' % filename)
                count += 1

    return count


class FileWithPush:

    def __init__(this, file):
        this.file = file
        this.pushed = []
        this.eof = False
        this.line_no = 0
        this.my_approx_pos = 0

    def readline(this):
        if len(this.pushed) > 0:
            l = this.pushed.pop()
        else:
            l = this.file.readline()
            this.line_no += 1
            this.my_approx_pos += len(l)
        if len(l) == 0:
            this.eof = True
        return l

    def push(this, line):
        if len(this.pushed) > 0:
            raise Exception('already pushed:%s' % this.pushed)
        this.pushed.append(line)

    def nextline(this):
        l = this.readline()
        while len(l) == 0 and not this.eof:
            l = this.readline()

        return l

    def skiplines_starting_with(this, s):
        i = len(s)
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            if l.strip()[:i] != s:
                this.push(l)
                return True

    def skiplines_starting_with_tokens(this, tokens):
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            a = l.strip().split()
            if len(a) == 0 or a[0] not in tokens:
                this.push(l)
                return True

    def skip_until_starts_with(this, s):
        i = len(s)
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            if l[:i] == s:
                this.push(l)
                return True

    def skip_empty_lines(this):
        while 1:
            l = this.readline()
            if len(l) == 0:
                return False
            if len(l.strip()) != 0:
                this.push(l)
                return True

    def __str__(this):
        name = os.path.split(this.file.name)
        name = os.path.join(os.path.split(name[0])[(-1)], name[(-1)])
        return '<File %s, line %d>' % (name, this.line_no)


def make_list(x):
    if isinstance(x, list):
        return x
    else:
        return [
         x]


def readblock(file):
    l = '\n'
    while len(l) > 0 and '{' not in l:
        l = file.readline()

    if len(l) == 0:
        return
    else:
        name = l.split()[0]
        block = {}
        while 1:
            l = file.readline()
            s = l.strip()
            if len(s) == 0:
                if len(l) == 0:
                    raise Exception('unterminated block found (%s)' % str(file))
                else:
                    continue
                if s == '}':
                    break
                a = s.split('=')
                a = [i.strip() for i in a]
                assert len(a) >= 2
                att, val = a[0], '='.join(a[1:])
                block[att] = val

        return (
         name, block)


def is_intel_specific():
    tmpkey = 'CST_ODBPP_USING_SPECIAL_NAMING_CONVENTIONS'
    return tmpkey in os.environ and os.environ[tmpkey].upper() == 'YES'


class ODBPPparser:
    system_attributes = get_system_attributes()

    def __init__(this, odbroot, db_unit='mil', progressbar=None):
        import zipfile, tarfile
        this.root = odbroot = str(odbroot)
        error_string = 'Could not open archive %s, please unpack and zip again with standard tool (e.g. Linux tar or Windows zip).' % odbroot
        error_string += " Please make sure to zip the **parent** folder of the ODB++ folders 'fonts', 'matrix', 'misc', etc."
        if zipfile.is_zipfile(odbroot):
            this.zipfile = zipfile.ZipFile(odbroot, 'r')
            this.zippedfiles = this.zipfile.namelist()
            allowed_compression_types = set([zipfile.ZIP_DEFLATED, zipfile.ZIP_STORED])
            used_compression_types = set([i.compress_type for i in this.zipfile.infolist()])
            if not used_compression_types.issubset(allowed_compression_types):
                error_string = 'Found unsupported compression type of zipfile. ' + error_string
                raise DatabaseReadError(error_string)
        else:
            if tarfile.is_tarfile(odbroot):
                import gzip
                with gzip.open(odbroot, 'rb') as (f):
                    file_content = f.read()
                from io import BytesIO
                this.zipfile = tarfile.open(fileobj=(BytesIO(file_content)))
                this.zippedfiles = this.zipfile.getnames()
            else:
                raise DatabaseReadError(error_string)
        import re
        tmp = [n for n in this.zippedfiles if n[-13:] == 'matrix/matrix']
        if len(tmp) != 1:
            if len(tmp) > 1:
                msg = 'ERROR: Multiple designs (%s) are defined in the compressed file. Please generate the ODB++ archive with only the desired design.' % ', '.join(["'" + t[:-14] + "'" for t in tmp])
                print(msg)
                raise DatabaseReadError(msg)
            else:
                msg = 'ERROR: No design is defined (missing matrix) in the ODB++ archive.'
                raise DatabaseReadError(msg)
        tmp = tmp[0].split('/')
        this.basepath = list(tmp[:-2])
        this.db_unit = db_unit
        this.scale_inch = 1.0 / get_length_unit_conversion_factor_in(this.db_unit)
        this.scale_mil = this.scale_inch * 0.001
        this.scale_mu = 1.0 / get_length_unit_conversion_factor_mu(this.db_unit)
        this.scale_mm = this.scale_mu * 1000.0
        this.progressbar = progressbar
        this.lps_counter = 0
        this.duplicate_vertices_ignored = 0
        this.drill_holes_missing_net_info = 0
        this.origin = 'unknown'
        this.copper_weight_to_mu = 34.26366837085699

    def __del__(this):
        if hasattr(this, 'basepath'):
            del this.basepath
        else:
            if hasattr(this, 'comps'):
                del this.comps
            else:
                if hasattr(this, 'progressbar'):
                    del this.progressbar
                else:
                    if hasattr(this, 'root'):
                        del this.root
                    else:
                        if hasattr(this, 'nets'):
                            del this.nets
                        else:
                            if hasattr(this, 'layers'):
                                del this.layers
                            else:
                                if hasattr(this, 'feature2nets'):
                                    del this.feature2nets
                                else:
                                    if hasattr(this, 'netpoints'):
                                        del this.netpoints
                                    if hasattr(this, 'pkglist'):
                                        del this.pkglist
                                if hasattr(this, 'pkgoutlines'):
                                    del this.pkgoutlines
                            if hasattr(this, 'pkgs'):
                                del this.pkgs
                        if hasattr(this, 'symboltable'):
                            del this.symboltable
                    if hasattr(this, 'zipfile'):
                        del this.zipfile
                if hasattr(this, 'zippedfiles'):
                    del this.zippedfiles
            if hasattr(this, 'layoutdb'):
                del this.layoutdb

    def file_in_zipped_files(this, path):
        path = path.lower()
        for n in this.zippedfiles:
            if n.lower() == path:
                return n
        else:
            return

    def fileopen(this, path):
        from common.helpers import FileFromStringList
        truepath = this.file_in_zipped_files(path)
        if truepath is None:
            path += '.Z'
            truepath = this.file_in_zipped_files(path)
        if truepath is None:
            print('file not found: %s' % path)
            return
        else:
            path = truepath
            print('Reading file %s...' % path)
            if type(this.zipfile) == tarfile.TarFile:
                s = this.zipfile.extractfile(this.zipfile.getmember(path)).read()
            else:
                s = this.zipfile.read(path)
            h, t = os.path.splitext(path)
            if t.lower() == '.z':
                try:
                    import gzip
                    from io import BytesIO
                    s = gzip.GzipFile(fileobj=(BytesIO(s))).read()
                except:
                    from common.utils2d import decompress
                    try:
                        s = decompress(s)
                    except:
                        import zipfile
                        fileobj = BytesIO(s)
                        try:
                            zipfile = zipfile.ZipFile(fileobj, 'r')
                            assert len(zipfile.filelist) == 1
                            s = zipfile.read(zipfile.filelist[0].filename)
                        except:
                            raise DatabaseReadError('Unable to decompress file %s' % path)

            if type(s) == bytes:
                s = s.decode('iso-8859-15')
            file = FileFromStringList(s.split('\n'))
            file.name = path
            return file

    def getpath(this, names):
        names = make_list(names)
        return '/'.join(this.basepath + names)

    def getsubdirs(this, names):
        sd = this.getpath(names)
        lsd = len(sd)
        res0 = [name[lsd + 1:-1] for name in this.zippedfiles if name[:lsd] == sd]
        res = set()
        for name in res0:
            a = os.path.split(name)
            if not len(a) <= 1:
                if len(a[0]) == 0:
                    pass
                elif len(a):
                    res.add(a[0])

        return res

    def s2R2(this, ss):
        assert len(ss) == 2
        return R2(this.scale * float(ss[0]), this.scale * float(ss[1]))

    def get_tmp_csale(this, unit_tmp):
        unit_tmp = unit_tmp.upper()
        if unit_tmp == this.design_units:
            return 1.0
        else:
            if unit_tmp == 'INCH':
                if this.design_units == 'MM':
                    return 25.4
            if unit_tmp == 'MM':
                if this.design_units == 'INCH':
                    return 0.03937007874015748
            print('ERROR: UNITS:', unit_tmp)
            return 1.0

    def get_step_name(this, steps):
        design_steps = []
        for col, step in steps.items():
            stepname = step['NAME'].lower()
            filename = this.getpath(['steps', stepname, 'stephdr'])
            file = this.fileopen(filename)
            step_repait = []
            while 1:
                res = readblock(file)
                if res is None:
                    break
                name, block = res
                if name == 'STEP-REPEAT':
                    step_repait.append(block)

            if len(step_repait) == 0:
                design_steps.append(step)

        if len(steps.keys()) > len(design_steps):
            print('Info: Nested steps are detected')
        return design_steps

    def to_LayoutDB(this):
        from common.units import standardize, get_typical_manufacturing_tolerance
        this.design_units = 'INCH'
        this.parse_info()
        if this.design_units == 'INCH':
            this.scale = this.scale_inch
        else:
            this.scale = this.scale_mm
        steps, layers = this.parse_matrix()
        if len(steps) == 1:
            col, step = list(steps.items())[0]
        else:
            if len(steps) > 1:
                design_steps = this.get_step_name(steps)
                if len(design_steps) == 1:
                    step = design_steps[0]
                    print('Import step ', step['NAME'].lower())
                else:
                    if len(design_steps) < 1:
                        msg = 'ERROR: No step defined in the ODB++ job matrix'
                        print(msg)
                        raise DatabaseReadError(msg)
                    else:
                        msg = 'ERROR: Multiple steps (%s) are defined in the ODB++ job matrix. Please generate the ODB++ archive with only the desired step.' % ', '.join(["'" + step['NAME'] + "'" for step in list(steps.values())])
                        print(msg)
                        raise DatabaseReadError(msg)
            else:
                msg = 'ERROR: No step defined in the ODB++ job matrix'
                print(msg)
                raise DatabaseReadError(msg)
        stepname = step['NAME'].lower()
        this.layoutdb = layoutdbPy.new_iLayoutDB()
        this.layoutdb.name = stepname
        this.layoutdb.length_unit = standardize(this.db_unit)
        this.layoutdb.tolerance = this.tol = get_typical_manufacturing_tolerance((this.layoutdb.length_unit), tolmu=1)
        this.sp = ShapeProcessor(this.tol)
        try:
            outline = this.parse_outline(stepname)
            if outline is None:
                raise DatabaseReadError('Board outline could not be determined')
            this.layoutdb.board_outline = this.sp(outline, sense=1, info='board outline')
        except:
            print('WARNING: no board outline found (using bounding box instead)')

        this.layoutdb.origin = 'CST ODB++ IMPORT V1'
        this.layoutdb.part_model_db = layoutdbPy.PartModelDB()
        this.layoutdb.simulation_settings.lateral_reference_length = 500 * this.layoutdb.tolerance
        this.parse_symbols()
        this.is_mentor = False
        warnings = {}
        this.parse_eda_data(stepname, warnings)
        for warn in list(warnings.keys()):
            print('WARNING:%s(%d time(s))' % (warn, warnings[warn]))

        print('eda data: %d packages, %d nets.' % (len(this.pkgs), len(this.nets)))
        f2n = this.feature2nets = {}
        this.multiple_assignments_to = set()
        for net, features in this.nets.items():
            this.layoutdb.add_net_dirty(net)
            for lyrname, fid in features:
                if lyrname not in f2n:
                    f2n[lyrname] = {}
                if fid in f2n[lyrname]:
                    this.multiple_assignments_to.add((lyrname, fid))
                f2n[lyrname][fid] = net

        if len(this.multiple_assignments_to):
            print('ERROR: multiple nets assigned to ODB++ layer features')
            todo = 10
            for lyrname, fid in this.multiple_assignments_to:
                print('\tlayer %s, feature ID %s' % (lyrname, fid))
                todo -= 1
                if todo <= 0:
                    break

            if todo <= 0:
                n = len(this.multiple_assignments_to) - 10
                if n > 0:
                    print('\t< and %d more>' % n)
        this.process_layers(stepname, layers)
        this.build_outline()
        this.process_drill_layers(stepname, layers)
        this.process_components(stepname, layers)
        check_pin_names(this.layoutdb.components())
        for layer in list(this.toeprints_candidates.values()):
            for f_num in list(layer.values()):
                for ps in f_num:
                    this.layoutdb.add_padstack(ps)

        this.set_comp_layer()
        this.process_wire_bond_layer(stepname, layers)
        return this.layoutdb

    def process_layers(this, stepname, layers):
        """
        TYPE The layer type must be one of the following values:
            SIGNAL A layer used for regular signal transfer
            POWER_GROUND A plane layer, used for power or ground signals
            DIELECTRIC A dielectric layer that separates two copper layers. (since V.8.0)
            MIXED A combination of a signal and a plane layer
            SOLDER_MASK A layer used for solder mask application
            SOLDER_PASTE A layer used for depositing solder paste for assembly
            SILK_SCREEN A layer used for application of text legend
            DRILL A layer used to produce drill programs
            ROUT A layer used to produce rout program
            DOCUMENT A layer used for drawings, testing, auxiliary processes, etc.
            COMPONENT A layer containing components locations and outlines.
            MASK A layer containing additional information used by the Frontline GenFlex product.
        """
        etchlayers = [layer for layer in list(layers.values()) if layer['CONTEXT'] in ('BOARD',
                                                                                       'MISC') if layer['TYPE'] in ('SIGNAL',
                                                                                                                    'POWER_GROUND',
                                                                                                                    'MIXED',
                                                                                                                    'SOLDER_MASK',
                                                                                                                    'DOCUMENT',
                                                                                                                    'DIELECTRIC')]
        etchlayers.sort(key=(lambda a: int(a['ROW'])))
        for layer in etchlayers:
            layer['tb'] = ''

        for layer in etchlayers:
            if layer['TYPE'] in ('SIGNAL', 'POWER_GROUND', 'MIXED'):
                layer['tb'] = 'top'
                break

        for layer in reversed(etchlayers):
            if layer['TYPE'] in ('SIGNAL', 'POWER_GROUND', 'MIXED'):
                layer['tb'] = 'bottom'
                break

        if this.progressbar is not None:
            this.progressbar.reset('Reading layers', len(etchlayers))
        this.odbpp8v_candidate = []
        ipc = 0
        support_dielectric_type = False
        for layer in etchlayers:
            if not (layer['CONTEXT'] == 'BOARD' or layer['CONTEXT'] == 'MISC' and this.is_mentor):
                pass
            else:
                new_layer = layoutdbPy.new_iLayer()
                typ = layer['TYPE'].upper()
                new_layer.name = name = layer['NAME']
                if typ in ('SIGNAL', 'MIXED', 'POWER_GROUND'):
                    if typ in ('SIGNAL', 'MIXED'):
                        new_layer.layer_type = layoutdbPy.LayerType.Signal
                    else:
                        new_layer.layer_type = layoutdbPy.LayerType.Plane
                    new_layer.is_positive = is_positive = layer['POLARITY'].lower() != 'negative'
                else:
                    if this.is_mentor and typ == 'DOCUMENT':
                        if len(name) > 5:
                            if name[:5].upper() in ('CAV_F', 'DP_T_', 'DP_B_', 'BW_T_',
                                                    'BW_B_'):
                                this.odbpp8v_candidate.append(name)
                                new_layer.layer_type = layoutdbPy.LayerType.Visualization
                            else:
                                continue
                if typ == 'DOCUMENT':
                    continue
                else:
                    if typ == 'DIELECTRIC':
                        new_layer.layer_type = layoutdbPy.LayerType.Dielectric
                        support_dielectric_type = True
                    else:
                        if typ == 'SOLDER_MASK':
                            new_layer.layer_type = layoutdbPy.LayerType.Soldermask
                        else:
                            new_layer.layer_type = layoutdbPy.LayerType.Dielectric
                        if 'POLARITY' in layer:
                            new_layer.is_positive = is_positive = layer['POLARITY'].lower() != 'negative'
                        else:
                            new_layer.is_positive = is_positive = False
                        this.layoutdb.add_layer_below(new_layer, new_layer)
                        keep_tr = False
                        if new_layer.is_etch() or name in this.odbpp8v_candidate:
                            keep_tr = True
                        features = this.parse_feature_file((this.getpath(['steps', stepname, 'layers', name.lower(), 'features'])), keep_traces=keep_tr,
                          create_padstacks=True)
                        if name.lower() in this.feature2nets:
                            tmp = this.feature2nets[name.lower()]
                        else:
                            tmp = {}
                    skipped_features = 0
                    created_features = 0
                    for i in range(len(features)):
                        if i not in tmp:
                            if new_layer.is_positive:
                                pass
                            net = 'NONE'
                        else:
                            net = tmp[i]
                        inet = this.layoutdb.net_index(net)
                        vnet = this.layoutdb.net(net)
                        f, options = features[i]
                        if 'nomenclature' in options:
                            if options['nomenclature']:
                                skipped_features += 1
                                continue
                        else:
                            created_features += 1
                        for shape in f:
                            if isinstance(shape, layoutdbPy.Trace):
                                shape.net_index = inet
                                new_layer.add_trace(shape)
                            else:
                                if isinstance(shape, tuple):
                                    ps, polarity = shape
                                    if not isinstance(ps, layoutdbPy.vPadstack):
                                        raise AssertionError
                                    else:
                                        ps.net = vnet
                                        ps.layer_from = ps.layer_to = new_layer
                                        lps = ps.library_padstack
                                        if is_positive:
                                            if polarity > 0:
                                                connect = layoutdbPy.ConnectType.connect
                                        connect = layoutdbPy.ConnectType.clearance
                                    lps.pad(new_layer, connect, lps.pad(layoutdbPy.WhereType.top, layoutdbPy.ConnectType.noconnect))
                                    ps.connect(new_layer, connect)
                                    if name.lower() in this.toeprints_candidates:
                                        if i in this.toeprints_candidates[name.lower()]:
                                            this.toeprints_candidates[name.lower()][i].append(ps)
                                        else:
                                            this.layoutdb.add_padstack(ps)
                                    else:
                                        shape.set_net(inet)
                                        sense = shape.polarity
                                        cswh = this.sp(shape, sense=sense, layer=new_layer)
                                        if cswh is not None:
                                            new_layer.add_plane_shape(cswh)

                    print(created_features, 'SWHs on layer', name, end='')
                    if skipped_features > 0:
                        print(', skipped %d non-geometrical feature(s)' % skipped_features)
                    else:
                        print()
                del features
                if this.progressbar is not None:
                    this.progressbar.set(ipc)
                ipc += 1

        if this.progressbar is not None:
            this.progressbar.finished()
        if this.layoutdb.n_layers() == 0:
            raise DatabaseReadError('No layers defined')
        top_layer = this.layoutdb.layer(0)
        bottom_layer = this.layoutdb.layer(this.layoutdb.n_layers() - 1)
        for i in range(this.layoutdb.n_padstacks()):
            ps = this.layoutdb.padstack(i)
            ps.lfrom = top_layer
            ps.lto = bottom_layer

        check_layer_stackup(this.layoutdb)
        layers_less_material = []
        for layer in etchlayers:
            name = layer['NAME']
            if not (layer['CONTEXT'] == 'BOARD' or layer['CONTEXT'] == 'MISC' and this.is_mentor):
                pass
            else:
                path = this.getpath(['steps', stepname, 'layers', name.lower(), 'attrlist'])
                layer = this.layoutdb.layer(name)
                if layer == None:
                    continue
            file = FileWithPush(this.fileopen(path))
            tmp_unit = this.design_units
            scale_tmp = 1.0
            has_die_const = has_loss_tan = False
            if file.file is not None:
                while 1:
                    l = file.readline()
                    if len(l) == 0:
                        break
                    l = l.strip()
                    if len(l) == 0:
                        pass
                    else:
                        l = l.replace(' ', '')
                        a = l.strip().split()
                        if 'UNITS' in a[0]:
                            a = a[0].split('=')
                            if len(a) == 2 and a[0] == 'UNITS':
                                tmp_unit = a[1]
                                scale_tmp = this.get_tmp_csale(tmp_unit)
                                continue
                    a = l[1:].split('=')
                    if len(a) == 2:
                        try:
                            if a[0] == 'copper_weight':
                                if layer.is_etch():
                                    if tmp_unit == 'MM':
                                        layer.thickness = float(a[1]) * this.scale_mu
                                    else:
                                        layer.thickness = float(a[1]) * this.copper_weight_to_mu * this.scale_mu
                                else:
                                    if a[0] == 'layer_dielectric':
                                        if support_dielectric_type and layer.layer_type == layoutdbPy.LayerType.Dielectric or layer.layer_type == layoutdbPy.LayerType.Soldermask:
                                            layer.thickness = float(a[1]) * this.scale * scale_tmp
                                        elif layer.number + 1 < this.layoutdb.n_layers():
                                            layer_below = this.layoutdb.layer(layer.number + 1)
                                            if layer_below.layer_type == layoutdbPy.LayerType.Dielectric:
                                                layer_below.thickness = float(a[1]) * this.scale * scale_tmp
                                    if a[0] == 'dielectric_constant':
                                        if float(a[1]) > 0:
                                            layer.material.eps = float(a[1])
                                            has_die_const = True
                            else:
                                if a[0] == 'loss_tangent':
                                    if float(a[1]) > 0:
                                        layer.material.condtan = float(a[1])
                                        has_loss_tan = True
                        except:
                            continue

            if not (has_loss_tan and has_die_const):
                layers_less_material.append(name)

        this.layoutdb.update_elevations()
        if len(layers_less_material):
            msg = ', '.join(["'" + l + "'" for l in layers_less_material])
            print('WARNING: material values were set to default due to missing information for the following layers: ', msg)

    def build_outline(this):
        if this.layoutdb.board_outline is None:
            print('BUILDING BOARD OUTLINE AS BOUNDING BOX OF ALL ETCH SHAPES...')
            bbox = None
            for l in this.layoutdb.layers():
                if l.is_etch():
                    for swh in l.all_shapes(this.layoutdb):
                        if bbox is None:
                            bbox = swh.bbox
                        else:
                            bbox.extend(swh.bbox)

            if bbox is None or bbox.xmax == bbox.xmin or bbox.ymin == bbox.ymax:
                raise DatabaseReadError('unable to compute bounding box')
            x, y = (bbox.xmin + bbox.xmax) * 0.5, (bbox.ymin + bbox.ymax) * 0.5
            dx, dy = -bbox.xmin + bbox.xmax, -bbox.ymin + bbox.ymax
            outline = utils2dPy.make_rectangle_shape(utils2dPy.R2(x - dx * 0.55, y - dy * 0.55), utils2dPy.R2(x + dx * 0.55, y + dy * 0.55), True)
            this.layoutdb.board_outline = utils2dPy.CShapeWithHoles(outline)

    def process_drill_layers(this, stepname, layers):
        skipped_single_layer_plated = 0
        name2row = {}
        for row in layers:
            name2row[layers[row]['NAME']] = row

        thislayoutdblayers = {}
        for l in this.layoutdb.layers():
            thislayoutdblayers[l.name] = l

        backdrills = []
        for layer in list(layers.values()):
            if not layer['CONTEXT'] != 'BOARD':
                if layer['TYPE'] != 'DRILL':
                    pass
                else:
                    if 'START_NAME' in layer:
                        lyrfrom = layer['START_NAME']
                    else:
                        print('WARNING: missing start layer in layer span', layer['NAME'])
                        lyrfrom = ''
                    if 'END_NAME' in layer:
                        lyrto = layer['END_NAME']
                    else:
                        print('WARNING: missing end layer in layer span', layer['NAME'])
                        lyrto = ''
                    if 'ADD_TYPE' in layer:
                        if layer['ADD_TYPE'] == 'BACKDRILL':
                            is_backdrill = True
                    else:
                        is_backdrill = False
                    drill_warning_issued = False
                    drill_warning_issued2 = False
                    if len(lyrfrom) == 0 or lyrfrom not in name2row:
                        row = 1
                        if not len(lyrfrom) == 0:
                            print("WARNING: drill start layer '%s' for drill layer %s does not exist in job matrix (using top etch layer instead)." % (lyrfrom, layer['NAME']))
                    else:
                        row = name2row[lyrfrom]
                    while row in layers:
                        lyrname = layers[row]['NAME']
                        if lyrname.upper() in thislayoutdblayers:
                            if this.layoutdb.layer(lyrname) is not None:
                                if this.layoutdb.layer(lyrname).is_etch():
                                    lyrfrom = layers[row]['NAME']
                                    break
                        row += 1
                    else:
                        print('WARNING: drill start layer not found for drill layer %s, using top etch layer.' % layer['NAME'])
                        lyrfrom = this.layoutdb.top_etch_layer().name

                    if len(lyrto) == 0 or lyrto not in name2row:
                        row = max(layers.keys())
                        if not len(lyrto) == 0:
                            print("WARNING: drill end layer '%s' for drill layer %s does not exist in job matrix (using bottom etch layer instead)." % (lyrto, layer['NAME']))
                    else:
                        row = name2row[lyrto]
                    while row in layers:
                        lyrname = layers[row]['NAME']
                        if lyrname.upper() in thislayoutdblayers:
                            if this.layoutdb.layer(lyrname) is not None:
                                if this.layoutdb.layer(lyrname).is_etch():
                                    lyrto = layers[row]['NAME']
                                    break
                        row -= 1
                    else:
                        print('WARNING: drill end layer not found for drill layer %s, using bottom etch layer.' % layer['NAME'])
                        lyrto = this.layoutdb.bottom_etch_layer().name

                    print('parsing drills %s-%s' % (lyrfrom, lyrto))
                    holes = this.parse_feature_file((this.getpath(['steps', stepname, 'layers', layer['NAME'].lower(), 'features'])), drill=True, create_padstacks=True)
                    if layer['NAME'].lower() in this.feature2nets:
                        tmp = this.feature2nets[layer['NAME'].lower()]
                    else:
                        tmp = {}
                    n_drill_features_skipped = 0
                    for ifeat in range(len(holes)):
                        padstack, opts = holes[ifeat]
                        if len(padstack) != 1 or not isinstance(padstack[0], tuple) or not isinstance(padstack[0][0], layoutdbPy.vPadstack):
                            n_drill_features_skipped += 1
                        else:
                            padstack = padstack[0]
                            padstack, polarity = padstack
                            if ifeat not in tmp:
                                if 'drill' not in opts or opts['drill'] != 1:
                                    if 'padusage' not in opts or opts['padusage'] != 4:
                                        this.drill_holes_missing_net_info += 1
                                net = 'NONE'
                            else:
                                net = tmp[ifeat]
                            if 'drill' in opts and opts['drill'] not in (0, 1, 2):
                                plated = True
                                if not drill_warning_issued2:
                                    print("WARNING: untypical drill type(s) definition (plated/non-plated) on layer %s (assumed 'plated')" % layer['NAME'])
                                    drill_warning_issued2 = True
                            else:
                                if 'drill' not in opts or opts['drill'] in (0, 2):
                                    plated = True
                                    if 'drill' not in opts:
                                        if not drill_warning_issued:
                                            print("WARNING: missing drill type(s) (plated/non-plated) on layer %s (assumed 'plated')" % layer['NAME'])
                                            drill_warning_issued = True
                                else:
                                    plated = False
                            if plated:
                                if lyrfrom == lyrto:
                                    skipped_single_layer_plated += 1
                                    continue
                            padstack.layer_from = this.layoutdb.layer(lyrfrom)
                            padstack.layer_to = this.layoutdb.layer(lyrto)
                            if padstack.library_padstack is None:
                                print('WARNING: no library_padstack (drill layer %s)' % layer['NAME'])
                            else:
                                padstack.library_padstack.is_via_plated = plated
                                this.layoutdb.add_net_dirty(net)
                                padstack.net = this.layoutdb.net(net)
                                if is_backdrill:
                                    backdrills.append(padstack)
                                else:
                                    this.layoutdb.add_padstack(padstack)

                    if n_drill_features_skipped:
                        print('WARNING: skipped %s drill features on drill layer %s\n' % (n_drill_features_skipped, layer['NAME']))

        if skipped_single_layer_plated > 0:
            print('WARNING: skipped %d plated drills through single layer' % skipped_single_layer_plated)
        if len(backdrills):
            for bdr in backdrills:
                for i in range(this.layoutdb.n_padstacks()):
                    ps = this.layoutdb.padstack(i)
                    l = None
                    if ps.layer_from != ps.layer_to:
                        if ps.position == bdr.position:
                            if bdr.layer_from == this.layoutdb.top_etch_layer():
                                if ps.layer_from.number < bdr.layer_to.number:
                                    for i in range(bdr.layer_to.number + 1, this.layoutdb.n_layers()):
                                        if this.layoutdb.layer(i).is_etch():
                                            l = this.layoutdb.layer(i)
                                            break

                                    if l != None:
                                        ps.layer_from = l
                        if bdr.layer_to == this.layoutdb.bottom_etch_layer() and ps.layer_to.number > bdr.layer_from.number:
                            for i in range(bdr.layer_from.number - 1, 0, -1):
                                if this.layoutdb.layer(i).is_etch():
                                    l = this.layoutdb.layer(i)
                                    break

                            if l != None:
                                ps.layer_to = l

    def process_components(this, stepname, layers):
        this.comps = {}
        for layer in list(layers.values()):
            if not layer['CONTEXT'] != 'BOARD':
                if layer['TYPE'] != 'COMPONENT':
                    pass
                else:
                    comps = this.parse_component_file(this.getpath(['steps', stepname, 'layers', layer['NAME'].lower(), 'components']))
                    if '+_top' in layer['NAME'].lower():
                        side = layoutdbPy.WhereType.top
                    else:
                        if '+_bot' in layer['NAME'].lower():
                            side = layoutdbPy.WhereType.bottom
                        else:
                            print('WARNING: could not process component layer %s.' % layer['NAME'])
                            continue
                    this.comps[side] = comps

        em_models = {}
        dummy_lpadstack = layoutdbPy.new_iLPadstack()
        for placementside, comps in this.comps.items():
            for name, comp in comps.items():
                refdes = name
                args = {}
                if 'comp_height' in comp['options']:
                    height = comp['options']['comp_height']
                else:
                    height = 0
                mount_type = None
                if 'comp_mount_type' in comp['options']:
                    t = comp['options']['comp_mount_type']
                    tmp = {0:'other',  1:'smt',  2:'thmt',  3:'pressfit'}
                    if t in tmp:
                        mount_type = tmp[t]
                mirror = None
                if 'mirror' in comp:
                    if comp['mirror'].upper() in ('Y', 'M'):
                        mirror = True
                new_comp = layoutdbPy.new_iComponent()
                new_comp.name = name
                new_comp.position = comp['pos']
                new_comp.rotation = -comp['rot'] * math.pi / 180.0
                new_comp.side = placementside
                new_comp.height = height * this.scale
                if new_comp.side == layoutdbPy.WhereType.top:
                    new_comp.layer = this.layoutdb.top_etch_layer()
                else:
                    new_comp.layer = this.layoutdb.bottom_etch_layer()
                partname = comp['part_name']
                if partname == '':
                    partname = comp['pkg']
                if partname not in em_models:
                    em_models[partname] = set()
                em_models[partname].add(refdes)
                new_comp.em_model = partname
                new_comp.mount_type = {'other':layoutdbPy.MountType.unknown, 
                 'smt':layoutdbPy.MountType.surface, 
                 'thmt':layoutdbPy.MountType.through, 
                 'pressfit':layoutdbPy.MountType.unknown, 
                 None:layoutdbPy.MountType.unknown}[mount_type]
                if 'BOMOPTION' in comp['prps']:
                    opt = comp['prps']['BOMOPTION']
                    opt = opt.strip("'").strip('"')
                    if opt.upper() == 'NOSTUFF':
                        new_comp.mounted = False
                if comp['pkg'] in this.pkgs:
                    pkg = this.pkgs[comp['pkg']]
                    for s in this.pkgoutlines[pkg['name']]:
                        try:
                            s = this.sp(s, info='component outline')
                            swh = s.to_ShapeWithHoles()
                        except:
                            print('WARNING: Broken outline for ', pkg['name'])
                            continue

                        if mirror:
                            swh.x_mirror()
                            swh.rotate(new_comp.rotation, R2(0, 0))
                        else:
                            if placementside == layoutdbPy.WhereType.bottom:
                                swh.rotate(new_comp.rotation, R2(0, 0))
                                swh.x_mirror()
                            else:
                                swh.rotate(new_comp.rotation, R2(0, 0))
                            swh.translate(new_comp.position)
                            swh = this.sp(swh, info='component outline')
                            if swh is not None:
                                new_comp.add_outline_shape(swh)
                            else:
                                print('WARNING: Broken outline (2) for ', pkg['name'])

                else:
                    print("WARNING: unable to create outline/pin names for component %s. Pins will be numbered '0','1', ..." % name)
                    pkg = None
                if is_intel_specific():
                    if pkg:
                        if len(pkg['pins']) and 'shape' in pkg['pins'][0]:
                            if comp['comp_name'][0] == 'U':
                                this.layoutdb.tolerance = this.scale_mu * 0.25
                                diestack = layoutdbPy.Diestack()
                                diestack.name = new_comp.name
                                diestack.is_top = new_comp.side == layoutdbPy.WhereType.top
                                this.layoutdb.add_diestack(diestack)
                                new_comp.mount_type = layoutdbPy.MountType.flipchip
                                bumplayer = layoutdbPy.new_iLayer()
                                bumplayer.name = new_comp.name + '-bumps'
                                bumplayer.layer_type = layoutdbPy.LayerType.Bumps
                                layer = layoutdbPy.new_iLayer()
                                layer.layer_type = layoutdbPy.LayerType.Die
                                layer.name = diestack.name + '-die'
                                if new_comp.n_outline_shapes():
                                    layer.outline = new_comp.outline_shape(0)
                                else:
                                    layer.outline = this.layoutdb.board_outline
                            else:
                                dielayer = layoutdbPy.new_iLayer()
                                dielayer.layer_type = layoutdbPy.LayerType.DiePads
                                dielayer.name = layer.name + '-pads'
                                diestack.add_component(new_comp, dielayer)
                                diestack.add_layer(layer)
                                diestack.add_layer(dielayer)
                                diestack.add_layer(bumplayer)
                                if diestack.is_top:
                                    this.layoutdb.add_layer_above(bumplayer, None)
                                    this.layoutdb.add_layer_above(dielayer, None)
                                    this.layoutdb.add_layer_above(layer, None)
                                else:
                                    this.layoutdb.add_layer_below(bumplayer, None)
                                    this.layoutdb.add_layer_below(dielayer, None)
                                    this.layoutdb.add_layer_below(layer, None)
                        else:
                            if comp['comp_name'] == 'A1':
                                this.layoutdb.tolerance = this.scale_mu * 0.25
                                new_comp.mount_type = layoutdbPy.MountType.bga
                                new_comp.side = layoutdbPy.WhereType.bottom
                                bgalayer = layoutdbPy.new_iLayer()
                                bgalayer.name = 'BGA'
                                bgalayer.layer_type = layoutdbPy.LayerType.BGA
                                this.layoutdb.add_layer_below(bgalayer, None)
                    else:
                        if comp['comp_name'][0] == 'U':
                            text = 'flip-chip bumps'
                        else:
                            if comp['comp_name'] == 'A1':
                                text = 'bga balls'
                            else:
                                text = None
                    if text is not None:
                        print('WARNING: unable to create %s' % text)
                bump_bbox = None
                layer_for_bump = None
                for pinnumber, pinprops in comp['pins'].items():
                    try:
                        pinnumber = int(pinnumber)
                        pinname = pkg['pins'][pinnumber]['name']
                    except:
                        pinname = str(pinnumber)
                        print('WARNING: unable to find correct pin name of pin #%s (component %s), using %s instead' % (pinnumber, name, pinname))

                    pnt = pinprops['pos'] * 1
                    netname = pinprops['net']
                    this.layoutdb.add_net_dirty(netname)
                    pin = layoutdbPy.new_Pin()
                    pin.position = pnt
                    pin.name = pinname
                    pin.net = this.layoutdb.net(netname)
                    new_comp.add_pin(pin)
                    if placementside == layoutdbPy.WhereType.top:
                        side = 'T'
                    else:
                        side = 'B'
                    for toep_num in pinprops['toep_nums']:
                        if comp['comp_number'] != None and comp['comp_number'] in this.toeprints4comp[side] and toep_num in this.toeprints4comp[side][comp['comp_number']]:
                            for lay_name, f_nums in this.toeprints4comp[side][comp['comp_number']][toep_num].items():
                                for f_num in f_nums:
                                    if lay_name in this.toeprints_candidates and f_num in list(this.toeprints_candidates[lay_name].keys()):
                                        for pad_cand in this.toeprints_candidates[lay_name][f_num]:
                                            new_comp.add_padstack(pad_cand)

                                        this.toeprints_candidates[lay_name].pop(f_num)

                            layer_candidats = list(this.toeprints4comp[side][comp['comp_number']][toep_num].keys())
                            comp_on_top = new_comp.side == layoutdbPy.WhereType.top
                            this.define_pin_layer(pin, layer_candidats, comp_on_top, new_comp.name)

                    if is_intel_specific() and (new_comp.mount_type == layoutdbPy.MountType.bga or new_comp.mount_type == layoutdbPy.MountType.flipchip):
                        try:
                            for shape in pkg['pins'][pinnumber]['shape']:
                                bump_shape = this.sp(shape, sense=1)
                                if bump_shape is None:
                                    raise 'shape is no good'
                                bump_shape = bump_shape.to_ShapeWithHoles()
                                if new_comp.mount_type == layoutdbPy.MountType.flipchip:
                                    bb = bump_shape.bbox
                                    center = R2((bb.xmax + bb.xmin) / 2, (bb.ymax + bb.ymin) / 2)
                                    bump_shape.translate(-center)
                                    bump_shape.scale(0.8)
                                    bump_shape.translate(center)
                                bump_shape.rotate(new_comp.rotation, R2(0, 0))
                                if new_comp.side == layoutdbPy.WhereType.bottom:
                                    if not (is_intel_specific() and new_comp.mount_type == layoutdbPy.MountType.bga):
                                        bump_shape.x_mirror()
                                    else:
                                        bump_shape.translate(new_comp.position)
                                        netname = pin.net.name
                                        bump_shape = this.sp(bump_shape, sense=1)
                                        if bump_shape is None:
                                            raise 'shape is no good'
                                        if new_comp.mount_type == layoutdbPy.MountType.bga:
                                            layer_for_bump = bgalayer
                                        else:
                                            if new_comp.mount_type == layoutdbPy.MountType.flipchip:
                                                layer_for_bump = bumplayer
                                        if layer_for_bump is not None:
                                            layer_for_bump.add_plane_shape(bump_shape)
                                        bump_shape.net_index = this.layoutdb.net_index(netname)
                                        if bump_bbox == None:
                                            bump_bbox = bump_shape.bbox
                                        elif bump_bbox.area() > bump_shape.bbox.area():
                                            pass
                                        bump_bbox = bump_shape.bbox

                        except:
                            if new_comp.mount_type == layoutdbPy.MountType.flipchip:
                                print('WARNING: unable to create flip-chip bump for pin #%s (component %s)' % (pinnumber, name))
                            else:
                                print('WARNING: problem with bga ball definition')

                if this.is_mentor:
                    if len(comp['pins']) == 0:
                        print("WARNING: component '%s': no pins contained in regular file, using footprint pins instead" % new_comp.name)
                        for pin_data in pkg['pins']:
                            pin = layoutdbPy.new_Pin()
                            pos = R2(pin_data['point'])
                            pin.name = pin_data['name']
                            if new_comp.side == layoutdbPy.WhereType.top:
                                pos.turn(new_comp.rotation)
                            else:
                                pos.turn(new_comp.rotation)
                                pos.x = -pos.x
                            pin.position = pos + new_comp.position
                            new_comp.add_pin(pin)

                if is_intel_specific():
                    if new_comp.mount_type == layoutdbPy.MountType.bga or new_comp.mount_type == layoutdbPy.MountType.flipchip:
                        if bump_bbox:
                            if layer_for_bump:
                                bga_rad = 0.5 * max(bump_bbox.xmax - bump_bbox.xmin, bump_bbox.ymax - bump_bbox.ymin)
                                layer_for_bump.solder_ball_radius_top = bga_rad * 0.8
                                layer_for_bump.solder_ball_radius_center = bga_rad
                                layer_for_bump.solder_ball_radius_bottom = bga_rad * 0.8
                                layer_for_bump.thickness = bga_rad
                        else:
                            (
                             'WARNING: unable to create bga balls for component ', name)
                this.layoutdb.add_component(new_comp)

        if is_intel_specific():
            check_layer_stackup((this.layoutdb), add_soldermasks=False)
        for model, refdess in em_models.items():
            n_pinss = set([this.layoutdb.component(r).n_pins() for r in refdess])
            if len(n_pinss) != 1:
                print('WARNING: unequal pin numbers in component group: ')
                for r in refdess:
                    print('\t', r)

            else:
                n = n_pinss.pop()
                if n != 2:
                    pass
                else:
                    refdesprefixes = set([r[:1] for r in refdess])
                    if len(refdesprefixes) != 1:
                        print('WARNING: different refdes prefixes in component group %s: ' % model)
                        for r in refdess:
                            print('\t', r)

                        continue
            refdesprefix = refdesprefixes.pop().upper()
            if refdesprefix in ('R', 'L', 'C'):
                le = layoutdbPy.LumpedElementModel()
                le.type = type_name_to_RLC_type(refdesprefix)
                le.name = model
                this.layoutdb.part_model_db.add_lumped_element(le)

        if this.duplicate_vertices_ignored > 0:
            print('INFO: %d duplicate vertices ignored' % this.duplicate_vertices_ignored)
        if this.drill_holes_missing_net_info > 0:
            print('INFO: %d plated drill holes without logical net information' % this.drill_holes_missing_net_info)
        if len(list(this.comps.values())) > 0:
            csvname = this.component_properties_to_csv()
            from common.layoutdb import import_lumped_elements, set_read_elements
            try:
                status, les, assignments, warnings = import_lumped_elements(csvname, 'csv', errors_as_warnings=True)
                pdb = this.layoutdb.part_model_db
                if pdb is None:
                    layoutdb.part_model_db = pdb = layoutdbPy.PartModelDB()
                for le in les:
                    pdb.add_lumped_element(le)

                for refdes, model in assignments:
                    comp = this.layoutdb.component(refdes)
                    if comp is not None:
                        comp.em_model = model

            except:
                status = 10

            print('=' * 40)
            if status > 1:
                print("WARNING: Loading the auto-generated CSV-file '%s' failed. Please review the file under Components->Load (csv)." % csvname)
            else:
                if len(warnings) != 0:
                    print("WARNING: There were some warnings while importing the auto-generated CSV-file '%s'. Please review the auto-generated file under Parts Editor->Load (csv)." % csvname)
                else:
                    print("Auto-imported CSV-file '%s'." % csvname)
            print('=' * 40)

    def parse_info(this):
        file = this.fileopen(this.getpath(['misc', 'info']))
        if file == None:
            return
        while 1:
            l = file.readline()
            if len(l) == 0:
                return
            a = l.strip().split()
            if len(a) >= 1:
                pass
            if 'UNITS' in a[0]:
                a = a[0].split('=')
                if len(a) == 2 and a[0] == 'UNITS':
                    units = a[1].upper()
                    if units not in ('INCH', 'MM'):
                        print('ERROR: invalid design units %s (using %s instead)' % (units, this.design_units))
                    else:
                        this.design_units = units
                        continue
                        if 'ODB_VERSION_MAJOR' in a[0]:
                            a = a[0].split('=')
                            if len(a) == 2 and a[0] == 'ODB_VERSION_MAJOR':
                                this.version = int(a[1])

    def parse_matrix(this):
        file = this.fileopen(this.getpath(['matrix', 'matrix']))
        this.steps = {}
        this.layers = {}
        while True:
            res = readblock(file)
            if res is None:
                break
            name, block = res
            assert name in ('STEP', 'LAYER')
            if name == 'STEP':
                this.steps[int(block['COL'])] = block
            else:
                this.layers[int(block['ROW'])] = block

        for layer in list(this.layers.values()):
            if 'CONTEXT' not in layer:
                layer['CONTEXT'] = 'unknown'

        return (
         this.steps, this.layers)

    def parse_outline(this, stepname):
        outline = this.parse_profile(stepname)
        if len(outline) != 1:
            if len(outline) == 0:
                s = 'Missing board outline'
            else:
                s = 'More than one board outline shape defined'
            raise DatabaseReadError(s)
        outline, opts = outline[0]
        if len(outline) != 1:
            if len(outline) == 0:
                s = 'Missing board outline'
            else:
                s = 'More than one board outline shape defined'
            raise DatabaseReadError(s)
        outline = outline[0]
        if len(outline.holes) > 0:
            tmp = outline
            outline = ShapeWithHoles()
            outline.shape = tmp.shape
            print('WARNING: removed %d holes from outline shape' % len(tmp.holes))
        return outline

    def parse_profile(this, stepname):
        filename = this.getpath(['steps', stepname, 'profile'])
        return this.parse_feature_file(filename)

    def create_lpad(this, symname, shapes):
        l_orig = len(shapes)
        new_pad = layoutdbPy.new_iLPad()
        new_pad.name = symname
        count = 0
        for shape in shapes:
            cswh = this.sp(shape, sense=1, info='pad')
            if cswh is not None:
                new_pad.add_shape(cswh)
                count += 1

        this.layoutdb.add_lpad(new_pad)
        if count > 0:
            if count < l_orig:
                print('WARNING: Creating pad %s: %d erroneous shapes skipped' % (symname, l_orig - count))
        if count == 0:
            print('WARNING: Pad %s does not contain any shapes' % symname)
        return new_pad

    def parse_symbols(this):
        symnames = this.getsubdirs('symbols')
        this.symboltable = {}
        for symname in sorted(symnames):
            features = this.parse_feature_file((this.getpath(['symbols', symname, 'features'])), keep_traces=False)
            if len(features) == 0:
                print('WARNING: no shapes found for symbol %s' % symname)
                this.symboltable[symname] = None
            else:
                shapes = []
                for ss, opts in features:
                    shapes.extend(ss)

                if len(shapes) > 1:
                    last_polarity = shapes[0].polarity
                    polarity_change = False
                    for swh in shapes:
                        if swh.polarity != last_polarity:
                            polarity_change = True

                    if polarity_change:
                        try:
                            vhs = vectorShapeWithHoles()
                            bbox = shapes[0].bbox
                            for swh in shapes:
                                bbox.extend(swh.bbox)
                                cswh = this.sp(swh, sense=(swh.polarity), info='pad')
                                if cswh is not None:
                                    vhs.append(cswh)

                            pp = Planeprocessor(bbox.extended(0.1), 0.0001)
                            pp.add_shapes(vhs)
                            res = pp.boolean_add2()
                            shapes = [r.to_ShapeWithHoles() for r in res]
                        except:
                            shapes = []
                            print('WARNING: no shapes created for symbol %s' % symname)

                this.symboltable[symname] = shapes

    def read_properties(this, file):
        res = {}
        while True:
            l = file.readline()
            if len(l) == 0:
                return res
            a = l.strip().split()
            if len(a) < 3 or a[0] != 'PRP':
                file.push(l)
                return res
            res[a[1]] = ' '.join(a[2:])

    def parse_eda_data--- This code section failed: ---

 L.1430         0  LOAD_CLOSURE             'this'
                2  BUILD_TUPLE_1         1 
                4  LOAD_CODE                <code_object read_outline>
                6  LOAD_STR                 'ODBPPparser.parse_eda_data.<locals>.read_outline'
                8  MAKE_FUNCTION_8          'closure'
               10  STORE_DEREF              'read_outline'

 L.1470        12  LOAD_CLOSURE             'read_outline'
               14  LOAD_CLOSURE             'this'
               16  BUILD_TUPLE_2         2 
               18  LOAD_CODE                <code_object read_pins>
               20  LOAD_STR                 'ODBPPparser.parse_eda_data.<locals>.read_pins'
               22  MAKE_FUNCTION_8          'closure'
               24  STORE_FAST               'read_pins'

 L.1531        26  BUILD_MAP_0           0 
               28  LOAD_DEREF               'this'
               30  STORE_ATTR               nets

 L.1532        32  BUILD_LIST_0          0 
               34  LOAD_DEREF               'this'
               36  STORE_ATTR               index2net

 L.1533        38  BUILD_MAP_0           0 
               40  LOAD_DEREF               'this'
               42  STORE_ATTR               pkgs

 L.1534        44  BUILD_MAP_0           0 
               46  LOAD_DEREF               'this'
               48  STORE_ATTR               pkgoutlines

 L.1535        50  BUILD_LIST_0          0 
               52  LOAD_DEREF               'this'
               54  STORE_ATTR               pkglist

 L.1537        56  BUILD_MAP_0           0 
               58  BUILD_MAP_0           0 
               60  LOAD_CONST               ('T', 'B')
               62  BUILD_CONST_KEY_MAP_2     2 
               64  LOAD_DEREF               'this'
               66  STORE_ATTR               toeprints4comp

 L.1539        68  BUILD_MAP_0           0 
               70  LOAD_DEREF               'this'
               72  STORE_ATTR               toeprints_candidates

 L.1541        74  SETUP_EXCEPT        104  'to 104'

 L.1542        76  LOAD_DEREF               'this'
               78  LOAD_ATTR                fileopen
               80  LOAD_DEREF               'this'
               82  LOAD_ATTR                getpath
               84  LOAD_STR                 'steps'
               86  LOAD_FAST                'stepname'
               88  LOAD_STR                 'eda'
               90  LOAD_STR                 'data'
               92  BUILD_LIST_4          4 
               94  CALL_FUNCTION_1       1  '1 positional argument'
               96  CALL_FUNCTION_1       1  '1 positional argument'
               98  STORE_FAST               'file'
              100  POP_BLOCK        
              102  JUMP_FORWARD        120  'to 120'
            104_0  COME_FROM_EXCEPT     74  '74'

 L.1543       104  POP_TOP          
              106  POP_TOP          
              108  POP_TOP          

 L.1544       110  LOAD_CONST               None
              112  STORE_FAST               'file'
              114  POP_EXCEPT       
              116  JUMP_FORWARD        120  'to 120'
              118  END_FINALLY      
            120_0  COME_FROM           116  '116'
            120_1  COME_FROM           102  '102'

 L.1545       120  LOAD_FAST                'file'
              122  LOAD_CONST               None
              124  COMPARE_OP               is
              126  POP_JUMP_IF_FALSE   152  'to 152'

 L.1546       128  LOAD_STR                 "The essential file 'steps/%s/eda/data(.Z)' is missing in the archive."
              130  LOAD_FAST                'stepname'
              132  BINARY_MODULO    
              134  STORE_FAST               'msg'

 L.1547       136  LOAD_GLOBAL              print
              138  LOAD_STR                 'WARNING: '
              140  LOAD_FAST                'msg'
              142  BINARY_ADD       
              144  CALL_FUNCTION_1       1  '1 positional argument'
              146  POP_TOP          

 L.1549       148  LOAD_CONST               None
              150  RETURN_END_IF    
            152_0  COME_FROM           126  '126'

 L.1551       152  LOAD_GLOBAL              FileWithPush
              154  LOAD_FAST                'file'
              156  CALL_FUNCTION_1       1  '1 positional argument'
              158  STORE_FAST               'file'

 L.1554       160  SETUP_EXCEPT        192  'to 192'

 L.1555       162  LOAD_FAST                'file'
              164  LOAD_ATTR                skiplines_starting_with
              166  LOAD_STR                 '#'
              168  CALL_FUNCTION_1       1  '1 positional argument'
              170  POP_JUMP_IF_TRUE    176  'to 176'

 L.1556       172  LOAD_CONST               None
              174  RETURN_END_IF    
            176_0  COME_FROM           170  '170'

 L.1557       176  LOAD_FAST                'file'
              178  LOAD_ATTR                skip_empty_lines
              180  CALL_FUNCTION_0       0  '0 positional arguments'
              182  POP_JUMP_IF_TRUE    188  'to 188'

 L.1558       184  LOAD_CONST               None
              186  RETURN_END_IF    
            188_0  COME_FROM           182  '182'
              188  POP_BLOCK        
              190  JUMP_FORWARD        202  'to 202'
            192_0  COME_FROM_EXCEPT    160  '160'

 L.1559       192  POP_TOP          
              194  POP_TOP          
              196  POP_TOP          

 L.1560       198  LOAD_CONST               None
              200  RETURN_VALUE     
            202_0  COME_FROM           190  '190'

 L.1561       202  LOAD_FAST                'file'
              204  LOAD_ATTR                readline
              206  CALL_FUNCTION_0       0  '0 positional arguments'
              208  STORE_FAST               'l'

 L.1562       210  LOAD_FAST                'l'
              212  LOAD_ATTR                strip
              214  CALL_FUNCTION_0       0  '0 positional arguments'
              216  LOAD_ATTR                split
              218  CALL_FUNCTION_0       0  '0 positional arguments'
              220  STORE_FAST               'a'

 L.1563       222  LOAD_FAST                'a'
              224  LOAD_CONST               0
              226  BINARY_SUBSCR    
              228  LOAD_STR                 'HDR'
              230  COMPARE_OP               ==
              232  POP_JUMP_IF_FALSE   258  'to 258'

 L.1564       236  LOAD_STR                 ' '
              238  LOAD_ATTR                join
              240  LOAD_FAST                'a'
              242  LOAD_CONST               1
              244  LOAD_CONST               None
              246  BUILD_SLICE_2         2 
              248  BINARY_SUBSCR    
              250  CALL_FUNCTION_1       1  '1 positional argument'
              252  LOAD_DEREF               'this'
              254  STORE_ATTR               origin
              256  JUMP_FORWARD        268  'to 268'
              258  ELSE                     '268'

 L.1566       258  LOAD_FAST                'file'
              260  LOAD_ATTR                push
              262  LOAD_FAST                'l'
              264  CALL_FUNCTION_1       1  '1 positional argument'
              266  POP_TOP          
            268_0  COME_FROM           256  '256'

 L.1568       268  LOAD_GLOBAL              print
              270  LOAD_STR                 'Origin of ODB++ database: '
              272  LOAD_DEREF               'this'
              274  LOAD_ATTR                origin
              276  CALL_FUNCTION_2       2  '2 positional arguments'
              278  POP_TOP          

 L.1569       280  LOAD_CONST               False
              282  LOAD_DEREF               'this'
              284  STORE_ATTR               is_mentor

 L.1571       286  LOAD_STR                 'ExpeditionPCB Database'
              288  LOAD_ATTR                upper
              290  CALL_FUNCTION_0       0  '0 positional arguments'
              292  LOAD_DEREF               'this'
              294  LOAD_ATTR                origin
              296  LOAD_ATTR                upper
              298  CALL_FUNCTION_0       0  '0 positional arguments'
              300  COMPARE_OP               in
              302  POP_JUMP_IF_TRUE    326  'to 326'
              306  LOAD_STR                 'Mentor'
              308  LOAD_ATTR                upper
              310  CALL_FUNCTION_0       0  '0 positional arguments'
              312  LOAD_DEREF               'this'
              314  LOAD_ATTR                origin
              316  LOAD_ATTR                upper
              318  CALL_FUNCTION_0       0  '0 positional arguments'
              320  COMPARE_OP               in
            322_0  COME_FROM           302  '302'
              322  POP_JUMP_IF_FALSE   340  'to 340'

 L.1573       326  LOAD_CONST               34.26366837085699
              328  LOAD_DEREF               'this'
              330  STORE_ATTR               copper_weight_to_mu

 L.1574       332  LOAD_CONST               True
              334  LOAD_DEREF               'this'
              336  STORE_ATTR               is_mentor
              338  JUMP_FORWARD        374  'to 374'
              340  ELSE                     '374'

 L.1575       340  LOAD_STR                 'Altium'
              342  LOAD_ATTR                upper
              344  CALL_FUNCTION_0       0  '0 positional arguments'
              346  LOAD_DEREF               'this'
              348  LOAD_ATTR                origin
              350  LOAD_ATTR                upper
              352  CALL_FUNCTION_0       0  '0 positional arguments'
              354  COMPARE_OP               in
              356  POP_JUMP_IF_FALSE   368  'to 368'

 L.1576       360  LOAD_CONST               35.814
              362  LOAD_DEREF               'this'
              364  STORE_ATTR               copper_weight_to_mu
              366  JUMP_FORWARD        374  'to 374'
              368  ELSE                     '374'

 L.1580       368  LOAD_CONST               35.812772299856135
              370  LOAD_DEREF               'this'
              372  STORE_ATTR               copper_weight_to_mu
            374_0  COME_FROM           366  '366'
            374_1  COME_FROM           338  '338'

 L.1583       374  LOAD_FAST                'file'
              376  LOAD_ATTR                skiplines_starting_with
              378  LOAD_STR                 '#'
              380  CALL_FUNCTION_1       1  '1 positional argument'
              382  POP_JUMP_IF_TRUE    390  'to 390'

 L.1583       386  LOAD_CONST               None
              388  RETURN_END_IF    
            390_0  COME_FROM           382  '382'

 L.1584       390  LOAD_FAST                'file'
              392  LOAD_ATTR                readline
              394  CALL_FUNCTION_0       0  '0 positional arguments'
              396  LOAD_ATTR                strip
              398  CALL_FUNCTION_0       0  '0 positional arguments'
              400  LOAD_ATTR                split
              402  CALL_FUNCTION_0       0  '0 positional arguments'
              404  STORE_FAST               'a'

 L.1586       406  LOAD_CONST               1.0
              408  STORE_FAST               'scale_tmp'

 L.1587       410  LOAD_STR                 'UNITS'
              412  LOAD_FAST                'a'
              414  LOAD_CONST               0
              416  BINARY_SUBSCR    
              418  COMPARE_OP               in
              420  POP_JUMP_IF_FALSE   516  'to 516'

 L.1588       424  LOAD_FAST                'a'
              426  LOAD_CONST               0
              428  BINARY_SUBSCR    
              430  LOAD_ATTR                split
              432  LOAD_STR                 '='
              434  CALL_FUNCTION_1       1  '1 positional argument'
              436  STORE_FAST               'a'

 L.1589       438  LOAD_GLOBAL              len
              440  LOAD_FAST                'a'
              442  CALL_FUNCTION_1       1  '1 positional argument'
              444  LOAD_CONST               2
              446  COMPARE_OP               ==
              448  POP_JUMP_IF_FALSE   484  'to 484'
              452  LOAD_FAST                'a'
              454  LOAD_CONST               0
              456  BINARY_SUBSCR    
              458  LOAD_STR                 'UNITS'
              460  COMPARE_OP               ==
              462  POP_JUMP_IF_FALSE   484  'to 484'

 L.1590       466  LOAD_FAST                'a'
              468  LOAD_CONST               1
              470  BINARY_SUBSCR    
              472  STORE_FAST               'units'

 L.1591       474  LOAD_DEREF               'this'
              476  LOAD_ATTR                get_tmp_csale
              478  LOAD_FAST                'units'
              480  CALL_FUNCTION_1       1  '1 positional argument'
              482  STORE_FAST               'scale_tmp'
            484_0  COME_FROM           462  '462'
            484_1  COME_FROM           448  '448'

 L.1593       484  LOAD_FAST                'file'
              486  LOAD_ATTR                skiplines_starting_with
              488  LOAD_STR                 '#'
              490  CALL_FUNCTION_1       1  '1 positional argument'
              492  POP_JUMP_IF_TRUE    500  'to 500'

 L.1593       496  LOAD_CONST               None
              498  RETURN_END_IF    
            500_0  COME_FROM           492  '492'

 L.1594       500  LOAD_FAST                'file'
              502  LOAD_ATTR                readline
              504  CALL_FUNCTION_0       0  '0 positional arguments'
              506  LOAD_ATTR                strip
              508  CALL_FUNCTION_0       0  '0 positional arguments'
              510  LOAD_ATTR                split
              512  CALL_FUNCTION_0       0  '0 positional arguments'
              514  STORE_FAST               'a'
            516_0  COME_FROM           420  '420'

 L.1596       516  LOAD_FAST                'a'
              518  LOAD_CONST               0
              520  BINARY_SUBSCR    
              522  LOAD_STR                 'LYR'
              524  COMPARE_OP               ==
              526  POP_JUMP_IF_TRUE    534  'to 534'
              530  LOAD_ASSERT              AssertionError
              532  RAISE_VARARGS_1       1  'exception'
            534_0  COME_FROM           526  '526'

 L.1597       534  LOAD_FAST                'a'
              536  LOAD_CONST               1
              538  LOAD_CONST               None
              540  BUILD_SLICE_2         2 
              542  BINARY_SUBSCR    
              544  STORE_FAST               'layers'

 L.1600       546  SETUP_LOOP         1428  'to 1428'

 L.1601       550  LOAD_FAST                'file'
              552  LOAD_ATTR                skiplines_starting_with
              554  LOAD_STR                 '#'
              556  CALL_FUNCTION_1       1  '1 positional argument'
              558  POP_JUMP_IF_TRUE    566  'to 566'

 L.1601       562  LOAD_CONST               None
              564  RETURN_END_IF    
            566_0  COME_FROM           558  '558'

 L.1602       566  LOAD_FAST                'file'
              568  LOAD_ATTR                skip_empty_lines
              570  CALL_FUNCTION_0       0  '0 positional arguments'
              572  POP_JUMP_IF_TRUE    580  'to 580'

 L.1602       576  LOAD_CONST               None
              578  RETURN_END_IF    
            580_0  COME_FROM           572  '572'

 L.1603       580  LOAD_FAST                'file'
              582  LOAD_ATTR                readline
              584  CALL_FUNCTION_0       0  '0 positional arguments'
              586  STORE_FAST               'l'

 L.1604       588  LOAD_FAST                'l'
              590  LOAD_ATTR                split
              592  LOAD_STR                 ';'
              594  CALL_FUNCTION_1       1  '1 positional argument'
              596  STORE_FAST               'a'

 L.1605       598  LOAD_FAST                'a'
              600  LOAD_CONST               0
              602  BINARY_SUBSCR    
              604  LOAD_ATTR                strip
              606  CALL_FUNCTION_0       0  '0 positional arguments'
              608  LOAD_ATTR                split
              610  CALL_FUNCTION_0       0  '0 positional arguments'
              612  STORE_FAST               'a'

 L.1606       614  LOAD_FAST                'a'
              616  LOAD_CONST               0
              618  BINARY_SUBSCR    
              620  LOAD_STR                 'NET'
              622  COMPARE_OP               ==
              624  POP_JUMP_IF_FALSE  1140  'to 1140'

 L.1607       628  LOAD_STR                 ' '
              630  LOAD_ATTR                join
              632  LOAD_FAST                'a'
              634  LOAD_CONST               1
              636  LOAD_CONST               None
              638  BUILD_SLICE_2         2 
              640  BINARY_SUBSCR    
              642  CALL_FUNCTION_1       1  '1 positional argument'
              644  STORE_FAST               'net'

 L.1608       646  LOAD_DEREF               'this'
              648  LOAD_ATTR                index2net
              650  LOAD_ATTR                append
              652  LOAD_FAST                'net'
              654  CALL_FUNCTION_1       1  '1 positional argument'
              656  POP_TOP          

 L.1609       658  BUILD_LIST_0          0 
              660  STORE_FAST               'features'

 L.1610       662  LOAD_FAST                'features'
              664  LOAD_DEREF               'this'
              666  LOAD_ATTR                nets
              668  LOAD_FAST                'net'
              670  STORE_SUBSCR     

 L.1623       672  SETUP_LOOP         1422  'to 1422'

 L.1624       676  LOAD_FAST                'file'
              678  LOAD_ATTR                skiplines_starting_with
              680  LOAD_STR                 'PRP'
              682  CALL_FUNCTION_1       1  '1 positional argument'
              684  POP_JUMP_IF_TRUE    690  'to 690'

 L.1625       688  BREAK_LOOP       
            690_0  COME_FROM           684  '684'

 L.1626       690  LOAD_FAST                'file'
              692  LOAD_ATTR                readline
              694  CALL_FUNCTION_0       0  '0 positional arguments'
              696  STORE_FAST               'l'

 L.1627       698  LOAD_GLOBAL              len
              700  LOAD_FAST                'l'
              702  CALL_FUNCTION_1       1  '1 positional argument'
              704  LOAD_CONST               0
              706  COMPARE_OP               ==
              708  POP_JUMP_IF_FALSE   714  'to 714'

 L.1627       712  BREAK_LOOP       
            714_0  COME_FROM           708  '708'

 L.1628       714  LOAD_FAST                'l'
              716  LOAD_ATTR                strip
              718  CALL_FUNCTION_0       0  '0 positional arguments'
              720  LOAD_ATTR                split
              722  CALL_FUNCTION_0       0  '0 positional arguments'
              724  STORE_FAST               'a'

 L.1629       726  LOAD_GLOBAL              len
              728  LOAD_FAST                'a'
              730  CALL_FUNCTION_1       1  '1 positional argument'
              732  LOAD_CONST               0
              734  COMPARE_OP               ==
              736  POP_JUMP_IF_TRUE    754  'to 754'
              740  LOAD_FAST                'a'
              742  LOAD_CONST               0
              744  BINARY_SUBSCR    
              746  LOAD_CONST               ('SNT', 'FID')
              748  COMPARE_OP               not-in
            750_0  COME_FROM           736  '736'
              750  POP_JUMP_IF_FALSE   766  'to 766'

 L.1630       754  LOAD_FAST                'file'
              756  LOAD_ATTR                push
              758  LOAD_FAST                'l'
              760  CALL_FUNCTION_1       1  '1 positional argument'
              762  POP_TOP          

 L.1631       764  BREAK_LOOP       
            766_0  COME_FROM           750  '750'

 L.1632       766  LOAD_FAST                'a'
              768  LOAD_CONST               0
              770  BINARY_SUBSCR    
              772  LOAD_STR                 'SNT'
              774  COMPARE_OP               ==
              776  POP_JUMP_IF_FALSE   856  'to 856'

 L.1633       780  LOAD_CONST               False
              782  STORE_FAST               'is_toeprint'

 L.1634       784  LOAD_FAST                'a'
              786  LOAD_CONST               1
              788  BINARY_SUBSCR    
              790  LOAD_STR                 'TOP'
              792  COMPARE_OP               ==
              794  POP_JUMP_IF_FALSE  1130  'to 1130'

 L.1635       798  LOAD_FAST                'a'
              800  LOAD_CONST               2
              802  BINARY_SUBSCR    
              804  LOAD_GLOBAL              int
              806  LOAD_FAST                'a'
              808  LOAD_CONST               3
              810  BINARY_SUBSCR    
              812  CALL_FUNCTION_1       1  '1 positional argument'
              814  LOAD_GLOBAL              int
              816  LOAD_FAST                'a'
              818  LOAD_CONST               4
              820  BINARY_SUBSCR    
              822  CALL_FUNCTION_1       1  '1 positional argument'
              824  ROT_THREE        
              826  ROT_TWO          
              828  STORE_FAST               'side'
              830  STORE_FAST               'comp_num'
              832  STORE_FAST               'toep_num'

 L.1636       834  LOAD_FAST                'side'
              836  LOAD_CONST               ('T', 'B')
              838  COMPARE_OP               in
              840  POP_JUMP_IF_TRUE    848  'to 848'
              844  LOAD_ASSERT              AssertionError
              846  RAISE_VARARGS_1       1  'exception'
            848_0  COME_FROM           840  '840'

 L.1637       848  LOAD_CONST               True
              850  STORE_FAST               'is_toeprint'
              852  JUMP_BACK           676  'to 676'
              856  ELSE                     '1132'

 L.1639       856  LOAD_GLOBAL              len
              858  LOAD_FAST                'a'
              860  CALL_FUNCTION_1       1  '1 positional argument'
              862  LOAD_CONST               4
              864  COMPARE_OP               ==
              866  POP_JUMP_IF_TRUE    874  'to 874'
              870  LOAD_ASSERT              AssertionError
              872  RAISE_VARARGS_1       1  'exception'
            874_0  COME_FROM           866  '866'

 L.1640       874  LOAD_FAST                'a'
              876  LOAD_CONST               1
              878  BINARY_SUBSCR    
              880  LOAD_GLOBAL              int
              882  LOAD_FAST                'a'
              884  LOAD_CONST               2
              886  BINARY_SUBSCR    
              888  CALL_FUNCTION_1       1  '1 positional argument'
              890  LOAD_GLOBAL              int
              892  LOAD_FAST                'a'
              894  LOAD_CONST               3
              896  BINARY_SUBSCR    
              898  CALL_FUNCTION_1       1  '1 positional argument'
              900  ROT_THREE        
              902  ROT_TWO          
              904  STORE_FAST               'typ'
              906  STORE_FAST               'lyr_num'
              908  STORE_FAST               'f_num'

 L.1641       910  LOAD_FAST                'typ'
              912  LOAD_CONST               ('C', 'H', 'L')
              914  COMPARE_OP               in
              916  POP_JUMP_IF_FALSE   676  'to 676'

 L.1642       920  LOAD_FAST                'layers'
              922  LOAD_FAST                'lyr_num'
              924  BINARY_SUBSCR    
              926  STORE_FAST               'lyr_name'

 L.1643       928  LOAD_FAST                'features'
              930  LOAD_ATTR                append
              932  LOAD_FAST                'lyr_name'
              934  LOAD_FAST                'f_num'
              936  BUILD_TUPLE_2         2 
              938  CALL_FUNCTION_1       1  '1 positional argument'
              940  POP_TOP          

 L.1645       942  LOAD_FAST                'is_toeprint'
              944  POP_JUMP_IF_FALSE   676  'to 676'

 L.1646       948  LOAD_FAST                'comp_num'
              950  LOAD_DEREF               'this'
              952  LOAD_ATTR                toeprints4comp
              954  LOAD_FAST                'side'
              956  BINARY_SUBSCR    
              958  COMPARE_OP               not-in
              960  POP_JUMP_IF_FALSE   978  'to 978'

 L.1647       964  BUILD_MAP_0           0 
              966  LOAD_DEREF               'this'
              968  LOAD_ATTR                toeprints4comp
              970  LOAD_FAST                'side'
              972  BINARY_SUBSCR    
              974  LOAD_FAST                'comp_num'
              976  STORE_SUBSCR     
            978_0  COME_FROM           960  '960'

 L.1648       978  LOAD_FAST                'toep_num'
              980  LOAD_DEREF               'this'
              982  LOAD_ATTR                toeprints4comp
              984  LOAD_FAST                'side'
              986  BINARY_SUBSCR    
              988  LOAD_FAST                'comp_num'
              990  BINARY_SUBSCR    
              992  COMPARE_OP               not-in
              994  POP_JUMP_IF_FALSE  1016  'to 1016'

 L.1649       998  BUILD_MAP_0           0 
             1000  LOAD_DEREF               'this'
             1002  LOAD_ATTR                toeprints4comp
             1004  LOAD_FAST                'side'
             1006  BINARY_SUBSCR    
             1008  LOAD_FAST                'comp_num'
             1010  BINARY_SUBSCR    
             1012  LOAD_FAST                'toep_num'
             1014  STORE_SUBSCR     
           1016_0  COME_FROM           994  '994'

 L.1650      1016  LOAD_FAST                'lyr_name'
             1018  LOAD_DEREF               'this'
             1020  LOAD_ATTR                toeprints4comp
             1022  LOAD_FAST                'side'
             1024  BINARY_SUBSCR    
             1026  LOAD_FAST                'comp_num'
             1028  BINARY_SUBSCR    
             1030  LOAD_FAST                'toep_num'
             1032  BINARY_SUBSCR    
             1034  COMPARE_OP               not-in
             1036  POP_JUMP_IF_FALSE  1066  'to 1066'

 L.1651      1040  LOAD_FAST                'f_num'
             1042  BUILD_LIST_1          1 
             1044  LOAD_DEREF               'this'
             1046  LOAD_ATTR                toeprints4comp
             1048  LOAD_FAST                'side'
             1050  BINARY_SUBSCR    
             1052  LOAD_FAST                'comp_num'
             1054  BINARY_SUBSCR    
             1056  LOAD_FAST                'toep_num'
             1058  BINARY_SUBSCR    
             1060  LOAD_FAST                'lyr_name'
             1062  STORE_SUBSCR     
             1064  JUMP_FORWARD       1094  'to 1094'
             1066  ELSE                     '1094'

 L.1653      1066  LOAD_DEREF               'this'
             1068  LOAD_ATTR                toeprints4comp
             1070  LOAD_FAST                'side'
             1072  BINARY_SUBSCR    
             1074  LOAD_FAST                'comp_num'
             1076  BINARY_SUBSCR    
             1078  LOAD_FAST                'toep_num'
             1080  BINARY_SUBSCR    
             1082  LOAD_FAST                'lyr_name'
             1084  BINARY_SUBSCR    
             1086  LOAD_ATTR                append
             1088  LOAD_FAST                'f_num'
             1090  CALL_FUNCTION_1       1  '1 positional argument'
             1092  POP_TOP          
           1094_0  COME_FROM          1064  '1064'

 L.1654      1094  LOAD_FAST                'lyr_name'
             1096  LOAD_DEREF               'this'
             1098  LOAD_ATTR                toeprints_candidates
             1100  COMPARE_OP               not-in
             1102  POP_JUMP_IF_FALSE  1116  'to 1116'

 L.1655      1106  BUILD_MAP_0           0 
             1108  LOAD_DEREF               'this'
             1110  LOAD_ATTR                toeprints_candidates
             1112  LOAD_FAST                'lyr_name'
             1114  STORE_SUBSCR     
           1116_0  COME_FROM          1102  '1102'

 L.1656      1116  BUILD_LIST_0          0 
             1118  LOAD_DEREF               'this'
             1120  LOAD_ATTR                toeprints_candidates
             1122  LOAD_FAST                'lyr_name'
             1124  BINARY_SUBSCR    
             1126  LOAD_FAST                'f_num'
             1128  STORE_SUBSCR     
           1130_0  COME_FROM           794  '794'
             1130  JUMP_BACK           676  'to 676'
             1134  POP_BLOCK        
             1136  JUMP_BACK           550  'to 550'
             1140  ELSE                     '1424'

 L.1658      1140  LOAD_FAST                'a'
             1142  LOAD_CONST               0
             1144  BINARY_SUBSCR    
             1146  LOAD_STR                 'PKG'
             1148  COMPARE_OP               ==
             1150  POP_JUMP_IF_FALSE  1342  'to 1342'

 L.1660      1154  LOAD_GLOBAL              len
             1156  LOAD_FAST                'a'
             1158  CALL_FUNCTION_1       1  '1 positional argument'
             1160  LOAD_CONST               7
             1162  COMPARE_OP               !=
             1164  POP_JUMP_IF_FALSE  1202  'to 1202'

 L.1661      1168  LOAD_GLOBAL              print
             1170  LOAD_STR                 'WARNING: unable to extract PKG data (%s)'
             1172  LOAD_GLOBAL              str
             1174  LOAD_FAST                'file'
             1176  CALL_FUNCTION_1       1  '1 positional argument'
             1178  BINARY_MODULO    
             1180  CALL_FUNCTION_1       1  '1 positional argument'
             1182  POP_TOP          

 L.1662      1184  LOAD_CONST               ('', 0, 0, 0, 0, 0)
             1186  UNPACK_SEQUENCE_6     6 
             1188  STORE_FAST               'name'
             1190  STORE_FAST               'pitch'
             1192  STORE_FAST               'xmin'
             1194  STORE_FAST               'ymin'
             1196  STORE_FAST               'xmax'
             1198  STORE_FAST               'ymax'
             1200  JUMP_FORWARD       1226  'to 1226'
             1202  ELSE                     '1226'

 L.1664      1202  LOAD_FAST                'a'
             1204  LOAD_CONST               1
             1206  LOAD_CONST               None
             1208  BUILD_SLICE_2         2 
             1210  BINARY_SUBSCR    
             1212  UNPACK_SEQUENCE_6     6 
             1214  STORE_FAST               'name'
             1216  STORE_FAST               'pitch'
             1218  STORE_FAST               'xmin'
             1220  STORE_FAST               'ymin'
             1222  STORE_FAST               'xmax'
             1224  STORE_FAST               'ymax'
           1226_0  COME_FROM          1200  '1200'

 L.1665      1226  BUILD_MAP_0           0 
             1228  STORE_FAST               'record'

 L.1666      1230  LOAD_FAST                'name'
             1232  LOAD_FAST                'record'
             1234  LOAD_STR                 'name'
             1236  STORE_SUBSCR     

 L.1669      1238  LOAD_DEREF               'read_outline'
             1240  LOAD_FAST                'file'
             1242  LOAD_FAST                'scale_tmp'
             1244  LOAD_FAST                'warnings'
             1246  CALL_FUNCTION_3       3  '3 positional arguments'
             1248  DUP_TOP          
             1250  LOAD_DEREF               'this'
             1252  LOAD_ATTR                pkgoutlines
             1254  LOAD_FAST                'name'
             1256  STORE_SUBSCR     
             1258  STORE_FAST               's'

 L.1671      1260  LOAD_DEREF               'this'
             1262  LOAD_ATTR                read_properties
             1264  LOAD_FAST                'file'
             1266  CALL_FUNCTION_1       1  '1 positional argument'
             1268  LOAD_FAST                'record'
             1270  LOAD_STR                 'prps'
             1272  STORE_SUBSCR     

 L.1673      1274  LOAD_FAST                'read_pins'
             1276  LOAD_FAST                'file'
             1278  LOAD_FAST                'scale_tmp'
             1280  LOAD_FAST                'warnings'
             1282  CALL_FUNCTION_3       3  '3 positional arguments'
             1284  LOAD_FAST                'record'
             1286  LOAD_STR                 'pins'
             1288  STORE_SUBSCR     

 L.1675      1290  LOAD_FAST                'name'
             1292  LOAD_DEREF               'this'
             1294  LOAD_ATTR                pkgs
             1296  COMPARE_OP               in
             1298  POP_JUMP_IF_FALSE  1318  'to 1318'

 L.1676      1302  LOAD_GLOBAL              print
             1304  LOAD_STR                 'WARNING: package %s specified twice (skipped)'
             1306  LOAD_GLOBAL              str
             1308  LOAD_FAST                'name'
             1310  CALL_FUNCTION_1       1  '1 positional argument'
             1312  BINARY_MODULO    
             1314  CALL_FUNCTION_1       1  '1 positional argument'
             1316  POP_TOP          
           1318_0  COME_FROM          1298  '1298'

 L.1678      1318  LOAD_FAST                'record'
             1320  LOAD_DEREF               'this'
             1322  LOAD_ATTR                pkgs
             1324  LOAD_FAST                'name'
             1326  STORE_SUBSCR     

 L.1679      1328  LOAD_DEREF               'this'
             1330  LOAD_ATTR                pkglist
             1332  LOAD_ATTR                append
             1334  LOAD_FAST                'record'
             1336  CALL_FUNCTION_1       1  '1 positional argument'
             1338  POP_TOP          
             1340  JUMP_FORWARD       1422  'to 1422'
             1342  ELSE                     '1422'

 L.1681      1342  LOAD_FAST                'a'
             1344  LOAD_CONST               0
             1346  BINARY_SUBSCR    
             1348  LOAD_STR                 'PRP'
             1350  COMPARE_OP               ==
             1352  POP_JUMP_IF_FALSE  1362  'to 1362'

 L.1682      1356  CONTINUE            550  'to 550'
             1360  JUMP_FORWARD       1422  'to 1422'
             1362  ELSE                     '1422'

 L.1683      1362  LOAD_FAST                'a'
             1364  LOAD_CONST               0
             1366  BINARY_SUBSCR    
             1368  LOAD_STR                 'FGR'
             1370  COMPARE_OP               ==
             1372  POP_JUMP_IF_FALSE  1406  'to 1406'

 L.1684      1376  LOAD_FAST                'file'
             1378  LOAD_ATTR                skiplines_starting_with
             1380  LOAD_STR                 '#'
             1382  CALL_FUNCTION_1       1  '1 positional argument'
             1384  POP_JUMP_IF_TRUE   1390  'to 1390'

 L.1685      1388  BREAK_LOOP       
           1390_0  COME_FROM          1384  '1384'

 L.1686      1390  LOAD_FAST                'file'
             1392  LOAD_ATTR                skiplines_starting_with_tokens
             1394  LOAD_CONST               ('FID', 'PRP')
             1396  CALL_FUNCTION_1       1  '1 positional argument'
             1398  POP_JUMP_IF_TRUE   1422  'to 1422'

 L.1687      1402  BREAK_LOOP       
           1404_0  COME_FROM          1398  '1398'
             1404  JUMP_FORWARD       1422  'to 1422'
             1406  ELSE                     '1422'

 L.1689      1406  LOAD_GLOBAL              print
             1408  LOAD_STR                 'WARNING: unexpected syntax of EDA data file:%s'
             1410  LOAD_GLOBAL              str
             1412  LOAD_FAST                'file'
             1414  CALL_FUNCTION_1       1  '1 positional argument'
             1416  BINARY_MODULO    
             1418  CALL_FUNCTION_1       1  '1 positional argument'
             1420  POP_TOP          
           1422_0  COME_FROM          1404  '1404'
           1422_1  COME_FROM          1360  '1360'
           1422_2  COME_FROM          1340  '1340'
             1422  JUMP_BACK           550  'to 550'
             1426  POP_BLOCK        
           1428_0  COME_FROM_LOOP      546  '546'

Parse error at or near `JUMP_BACK' instruction at offset 1136

    def parse_component_file(this, filename):
        file = FileWithPush(this.fileopen(filename))
        syms = {}
        cans = {}
        texts = {}
        comps = {}
        comp_number = 0
        comp_number_tmp = None
        scale_tmp = 1.0
        while 1:
            l = file.readline()
            if len(l) == 0:
                break
            l = l.strip()
            if len(l) == 0:
                pass
            else:
                if l[0] == '$':
                    a = l[1:].split()
                    assert len(a) == 2
                    syms[a[0]] = a[1]
                    continue
                if l[0] == '@':
                    a = l[1:].split()
                    assert len(a) == 2
                    cans[a[0]] = a[1][1:]
                    continue
            if l[0] == '&':
                a = l[1:].split()
                if len(a) == 2:
                    texts[a[0]] = a[1]
                else:
                    if len(a) == 1:
                        print('WARNING: missing attribute name: ', a)
                        texts[a[0]] = ''
                    else:
                        print('WARNING: incorrect attribute definition: ', a)
            else:
                if l[0] == '#':
                    l.split()
                    if 'CMP' in l:
                        a = l[1:].split()
                        if len(a) == 2:
                            comp_number_tmp = int(a[1])
                            continue
                        else:
                            continue
                a = l.split()
                if 'UNITS' in a[0]:
                    a = a[0].split('=')
                    if len(a) == 2:
                        if a[0] == 'UNITS':
                            units = a[1]
                            scale_tmp = this.get_tmp_csale(units)
                            continue
                            if 'ID' in a[0]:
                                pass
                            else:
                                if a[0] in ('CPN', 'DSC', 'PKG', 'IPN', 'VPL_VND',
                                            'VPL_MPN', 'VND', 'MPN'):
                                    pass
                                elif a[0] != 'CMP' or len(a) < 8:
                                    print('ERROR: wrong syntax in components file %s.' % str(file))
                                    return comps
                                else:
                                    b = l.split(';')
                                    a = b[0].split()
                                    if a[0] != 'CMP' or len(a) != 8:
                                        print('ERROR: wrong syntax in components file %s.' % str(file))
                                        return comps
                                    comp = {}
                                    pkg_ref, x, y, comp['rot'], comp['mirror'], comp['comp_name'], comp['part_name'] = a[1:]
                                    if comp_number_tmp != None:
                                        if comp_number_tmp != comp_number:
                                            print('WARNING: Component number is not clear for component %s, %i!=%i ' % (comp['comp_name'], comp_number, comp_number_tmp))
                                    comp['comp_number'] = comp_number
                                    comp_number += 1
                                    rlc_type = comp['comp_name'].upper()[0]
                                    if rlc_type in ('R', 'L', 'C'):
                                        comp['comp_type'] = rlc_type
                                    comp['rot'] = float(comp['rot'])
                                    if int(pkg_ref) < len(this.pkglist):
                                        comp['pkg'] = this.pkglist[int(pkg_ref)]['name']
                                    else:
                                        comp['pkg'] = None
                                    comp['pos'] = R2(float(x), float(y)) * this.scale * scale_tmp
                                    options = {}
                                    if len(b) > 1:
                                        assert len(b) >= 2
                                        params = b[1].strip()
                                        if len(params):
                                            attributemap = cans
                                            textmap = texts
                                            for p in params.split(','):
                                                a = p.split('=')
                                                if len(a) == 0 or a[0].strip() not in attributemap:
                                                    print('ERROR: erroneous component file, ', file)
                                                else:
                                                    attr = attributemap[a[0].strip()]
                                                    if attr not in this.system_attributes:
                                                        pass
                                                    else:
                                                        atspec = this.system_attributes[attr]
                                                        if len(a) == 1:
                                                            assert atspec[0] == bool
                                                            val = True
                                                        else:
                                                            if atspec[0] == 'Option':
                                                                val = int(a[1])
                                                            else:
                                                                if atspec[0] in (int, float, bool):
                                                                    val = atspec[0](a[1])
                                                                else:
                                                                    assert atspec[0] == 'Text'
                                                                    if a[1] in textmap:
                                                                        val = textmap[a[1]]
                                                                    else:
                                                                        val = a[1]
                                                options[attr] = val

                                    comp['options'] = options
                                    comp['prps'] = this.read_properties(file)
                                    comp['pins'] = pins = {}
                                    toep_num = 0
                                    while True:
                                        l = file.readline()
                                        if l[:3] not in ('TOP', 'PRP'):
                                            file.push(l)
                                            break
                                        if l[:3] == 'PRP':
                                            pass
                                        else:
                                            a = l.split()
                                            if len(a) < 9:
                                                pass
                                            else:
                                                pin_num, x, y, rot, mirror, net_num, subnet_num, toeprint_name = a[1:9]
                                                if int(net_num) >= 0:
                                                    if int(net_num) < len(this.index2net):
                                                        netname = this.index2net[int(net_num)]
                                                else:
                                                    netname = 'NONE'
                                                if pin_num in pins:
                                                    pins[pin_num]['toep_nums'].append(toep_num)
                                                else:
                                                    pins[pin_num] = {'net':netname, 
                                                     'pos':utils2dPy.R2(float(x), float(y)) * this.scale * scale_tmp,  'toep_nums':[toep_num]}
                                                toep_num += 1

                                    partname = comp['part_name']
                                    props = comp['prps']
                                    if 'PART_NUMBER' in props:
                                        partname = props['PART_NUMBER']
                                    else:
                                        if 'PART_NAME' in props:
                                            partname = props['PART_NAME']
                                        elif 'PARENT_PPT_PART' in props:
                                            partname = props['PARENT_PPT_PART']
                            if 'TYPE' in props:
                                type = props['TYPE'].lower()
                                if 'resistor' in type:
                                    comp['comp_type'] = 'R'
                                else:
                                    if 'inductor' in type:
                                        comp['comp_type'] = 'L'
                                    elif 'capacitor' in type:
                                        comp['comp_type'] = 'C'
                        if partname == '':
                            print('WARNING: no part found for component %s (skipped)' % comp['comp_name'])
                            continue
                        partname = partname.strip("'").strip('"')
                        comp['part_name'] = partname
                        comps[comp['comp_name']] = comp

        return comps

    def component_properties_to_csv(this):
        import os, csv
        if this.progressbar is None:
            print('Missing output filename.')
            filename = 'D:\\Work\\test.csv'
        else:
            filename = os.path.splitext(this.progressbar.outputfile)[0] + '.csv'
        propnames = set()
        for cs in list(this.comps.values()):
            for props in list(cs.values()):
                propnames.update(list(props['prps'].keys()))

        ffile = open(filename, 'w', encoding='utf-8', newline='')
        cfile = csv.writer(ffile, delimiter=';')
        propnames = sorted(list(propnames))
        for propname in propnames:
            if propname == 'PART_NAME':
                propnames.remove('PART_NAME')

        if 'boardstation' in this.origin.lower():
            propnames_l = [n.lower() for n in propnames]
            if 'instpar' in propnames_l:
                if 'value' not in propnames_l:
                    if 'val' not in propnames_l:
                        for cs in list(this.comps.values()):
                            for props in list(cs.values()):
                                props = props['prps']
                                if 'INSTPAR' in props:
                                    props['VALUE'] = props['INSTPAR']
                                else:
                                    if 'instpar' in props:
                                        props['VALUE'] = props['instpar']
                                    else:
                                        props['VALUE'] = ''

                        propnames.append('VALUE')
        if 'cadence' in this.origin.lower():
            propnames_l = [n.lower() for n in propnames]
            if 'value_1' in propnames_l:
                if 'value' not in propnames_l:
                    if 'val' not in propnames_l:
                        for comps in list(this.comps.values()):
                            for props in list(comps.values()):
                                props = props['prps']
                                if 'VALUE_1' in props:
                                    props['VALUE'] = props['VALUE_1']

                        propnames.append('VALUE')
        if 'altium' in this.origin.lower():
            propnames_l = [n.lower() for n in propnames]
            if 'value' not in propnames_l:
                if 'val' not in propnames_l:
                    for comps in list(this.comps.values()):
                        for comp in list(comps.values()):
                            comp['prps']['VALUE'] = comp.get('part_name', ' ')

                    propnames.append('VALUE')
        if 'expedition' in this.origin.lower():
            propnames_l = [n.lower() for n in propnames]
            if 'value' not in propnames_l:
                if 'val' not in propnames_l:
                    for cs in list(this.comps.values()):
                        for props in list(cs.values()):
                            props = props['prps']
                            val_set = ''
                            for key in ('CAPACITANCE', 'INDUCTANCE', 'RESISTANCE'):
                                if key in props:
                                    s = props[key]
                                    if len(s):
                                        if len(val_set):
                                            print('WARNING: conflicting nominal values %s and %s, using %s' % (val_set, s, s))
                                        val_set = s

                            props['VALUE'] = val_set

                    propnames.append('VALUE')
        header = [
         'refdes', 'partname', 'type']
        propnames = sorted(list(propnames))
        header.extend(propnames)
        cfile.writerow(header)
        for comps in list(this.comps.values()):
            for key in sorted(comps.keys()):
                comp = comps[key]
                props = comp['prps']
                csvline = [
                 key, comp.get('part_name', ' '), comp.get('comp_type', ' ')]
                for propname in propnames:
                    if propname == 'PART_NAME':
                        pass
                    else:
                        sval = props.get(propname, ' ')
                        sval = sval.replace(';', ' ')
                        sval = sval.strip("'")
                        sval = ' ' + sval
                        csvline.append(sval)

                cfile.writerow(csvline)

        ffile.close()
        print('=' * 40)
        print('INFO: Created CSV file (' + filename + ') with component properties extracted from ODB++ file.')
        print('=' * 40)
        return filename

    def parse_netlist(this, stepname):
        this.netlist = {}
        try:
            filename = this.getpath(['steps', stepname, 'netlists', 'cadnet', 'netlist'])
            file = FileWithPush(this.fileopen(filename))
            hdr = file.readline()
        except:
            print('WARNING: empty/non-existing netlist file.')
            return
        else:
            while True:
                l = file.readline()
                if len(l) == 0:
                    return
                l = l.strip()
                if len(l) == 0:
                    break
                if l[0] != '$':
                    break
                a = l.split()
                assert len(a) == 2
                this.netlist[int(a[0][1:])] = a[1]

            while len(l) == 0:
                l = file.readline()
                if len(l) == 0:
                    return
                l = l.strip()

            this.netpoints = {}
            assert l[0] == '#'
            assert 'netlist points' in file.readline().lower()
            assert file.readline().strip() == '#'
            while 1:
                l = file.readline()
                if len(l) == 0:
                    return
                l = l.strip()
                if len(l) == 0:
                    return
                a = l.split()
                assert len(a) >= 5
                net_num, radius, p, side = (
                 int(a[0]), this.scale * 0.001 * float(a[1]), this.s2R2(a[2:4]), a[4])
                toplayer, botlayer = (None, None)
                if side == 'B':
                    side = 'TD'
                if 'T' in side:
                    toplayer = this.layoutdb.top_clayer
                    if toplayer is None:
                        print('WARNING: no top layer exported -> netlists may be incomplete')
                    if 'D' in side:
                        botlayer = this.layoutdb.bottom_clayer
                        if botlayer is None:
                            print('WARNING: no bottom layer exported -> netlists may be incomplete')
                    if toplayer is not None:
                        toplayer.add_netpoint(p, this.netlist[net_num])
                    if botlayer is not None:
                        botlayer.add_netpoint(p, this.netlist[net_num])

    def consider_for_min_trace_width(this, w):
        if w is None or w <= 0 or not hasattr(this, 'layoutdb'):
            return
        if this.layoutdb.simulation_settings.lateral_reference_length < 0 or w < this.layoutdb.simulation_settings.lateral_reference_length:
            this.layoutdb.simulation_settings.lateral_reference_length = w

    def parse_feature_file(this, filename, drill=False, feature2net={}, keep_traces=False, create_padstacks=False):
        from .shapemanager import get_symbol

        def scale_factor(symbolunits, units):
            if symbolunits:
                if symbolunits == 'i':
                    res = this.scale_mil
                else:
                    if symbolunits == 'm':
                        res = this.scale_mu
                    else:
                        print('WARNING: skipped path (units %s unknown): ' % symbolunits)
            else:
                if units:
                    units = units.upper()
                    if units == 'INCH':
                        res = this.scale_mil
                    else:
                        if units == 'MM':
                            res = this.scale_mu
                        else:
                            print('WARNING: skipped path (units %s unknown): ' % units)
                else:
                    res = this.scale * 0.001
            return res

        file = this.fileopen(filename)
        if file is None:
            return []
        else:
            skipped = []
            file = FileWithPush(file)
            symbolmap = {}
            symbolunitsmap = {}
            attributemap = {}
            textmap = {}
            features = []
            noheader = False
            auxmap = {'$':'Feature symbol names',  '@':'Feature attribute names',  '&':'Feature attribute text strings',  'U':'units',  'F':'num features'}
            units = None
            scale_s2R2 = 1.0
            missing_drill_holes = 0
            warnings = {}
            while 1:
                remainders = True
                while 1:
                    lastline = file.line_no
                    if not file.skip_empty_lines():
                        remainders = False
                        break
                    if not file.skiplines_starting_with('#'):
                        remainders = False
                        break
                    if file.line_no == lastline:
                        break

                l = file.readline()
                if len(l) == 0:
                    break
                l2 = l.strip()
                if len(l2) == 0:
                    print('WARNING: strange feature file (%s)' % str(file))
                    break
                if l2[0] in auxmap:
                    hdrline = auxmap[l2[0]].lower()
                elif len(l2) > 2:
                    if l2[:3] == 'ID=':
                        continue
                else:
                    hdrline = 'layer features'
                file.push(l)
                if 'feature symbol names' in hdrline:
                    l = file.readline()
                    if len(l) == 0:
                        break
                    while l[0] == '$':
                        a = l.strip().split()
                        assert len(a) >= 2
                        symbolmap[a[0][1:]] = a[1]
                        if len(a) == 3:
                            symbolunitsmap[a[0][1:]] = a[2].lower()
                        else:
                            symbolunitsmap[a[0][1:]] = None
                        l = file.readline()
                        if len(l) == 0:
                            break

                    file.push(l)
                elif 'feature attribute names' in hdrline:
                    l = file.readline()
                    if len(l) == 0:
                        break
                    while l[0] == '@':
                        a = l.strip().split()
                        assert len(a) == 2
                        attributemap[a[0][1:]] = a[1][1:]
                        l = file.readline()
                        if len(l) == 0:
                            break

                    file.push(l)
                elif 'feature attribute text strings' in hdrline:
                    l = file.readline()
                    if len(l) == 0:
                        break
                    while l[0] == '&':
                        a = l.strip().split()
                        b = ' '.join(a[1:])
                        textmap[a[0][1:]] = b
                        l = file.readline()
                        if len(l) == 0:
                            break

                    file.push(l)
                else:
                    if 'num features' in hdrline:
                        l = file.readline()
                        if len(l) == 0:
                            break
                        while l[0] == 'F':
                            a = l.strip().split()
                            l = file.readline()
                            if len(l) == 0:
                                break

                        file.push(l)
                    else:
                        if 'units' in hdrline:
                            l = file.readline()
                            if len(l) == 0:
                                break
                            while l[0] == 'U':
                                a = l.strip().split()
                                if len(a) == 2:
                                    units = a[1]
                                else:
                                    a = l.strip().split('=')
                                if len(a) == 2:
                                    if a[0] == 'UNITS':
                                        units = a[1]
                                scale_s2R2 = this.get_tmp_csale(units)
                                l = file.readline()
                                if len(l) == 0:
                                    break

                            file.push(l)
                        else:
                            if 'layer features' in hdrline:
                                if not file.skiplines_starting_with('#'):
                                    break
                                while True:
                                    l = file.readline()
                                    l = l.strip()
                                    if len(l) == 0:
                                        break
                                    tmp = l.split(';')
                                    params = tmp[1:]
                                    a = tmp[0].split()
                                    assert len(a) > 1
                                    if a[0] == 'T':
                                        features.append(([], {}))
                                        continue
                                    else:
                                        if a[0] == 'B':
                                            features.append(([], {}))
                                            continue
                                        else:
                                            assert a[0] == 'L' and len(a) >= 8
                                            p0, p1, sym_num, polarity, dcode = (this.s2R2(a[1:3]), this.s2R2(a[3:5]), a[5], a[6], int(a[7]))
                                            p0 *= scale_s2R2
                                            p1 *= scale_s2R2
                                            sym = symbolmap[sym_num]
                                            if sym[0] not in 'rs':
                                                print('WARNING: skipped path (symbol=%s): ' % sym, l, str(file))
                                                skipped.append(CurveSegment(p0, p1))
                                                features.append(([], {}))
                                                continue
                                            try:
                                                w = float(sym[1:]) * scale_factor(symbolunitsmap[sym_num], units)
                                            except:
                                                w = None

                                            this.consider_for_min_trace_width(w)
                                    if w == 0:
                                        print('WARNING: skipped path (width=0): ', l, 'sym: ', sym, str(file))
                                        skipped.append(CurveSegment(p0, p1))
                                        features.append(([], {}))
                                        continue
                                    if (p1 - p0).getNorm2() != 0:
                                        if w is None:
                                            print('WARNING: skipped path (symbol=%s): ' % sym, l, str(file))
                                            skipped.append(CurveSegment(p0, p1))
                                            features.append(([], {}))
                                            continue
                                        else:
                                            roundcaps = sym[0] == 'r'
                                            if keep_traces:
                                                shape = layoutdbPy.Trace()
                                                shape.add_segment(CurveSegment(p0, p1), w)
                                                if polarity == 'N':
                                                    shape.is_positive = False
                                                shape.is_capped = roundcaps
                                            else:
                                                if sym[0] == 's':
                                                    from math import atan2
                                                    w2 = w * 0.5
                                                    dr = p1 - p0
                                                    adr = dr.getNorm()
                                                    xys = [R2(-w2, -w2), R2(-w2, w2), R2(adr + w2, w2), R2(adr + w2, -w2), R2(-w2, -w2)]
                                                    shape = utils2d.PolylineShape(xys)
                                                    shape.rotate(atan2(dr.y, dr.x), R2(0, 0))
                                                    shape.translate(p0)
                                                else:
                                                    shape = utils2d.PolyarcShape(utils2d.straight_path_segment_to_XYR(p0, p1, w, roundcaps=roundcaps))
                                    elif w is None:
                                        shapes = get_symbol(sym, None)
                                        for shape in shapes:
                                            shape.scale(scale_factor(symbolunitsmap[sym_num], units))
                                            shape.translate(p0)

                                        if len(shapes) == 1:
                                            shape = shapes[0]
                                        else:
                                            print('WARNING: skipped path (symbol=%s): ' % sym, l, str(file))
                                            skipped.append(CurveSegment(p0, p1))
                                            features.append(([], {}))
                                            continue
                                    else:
                                        if sym[0] == 'r':
                                            shape = utils2d.CircleShape(p0, w / 2.0)
                                        else:
                                            p0.x -= w / 2
                                            p0.y -= w / 2
                                            p1.x += w / 2
                                            p1.y += w / 2
                                            shape = utils2dPy.make_rectangle_shape(p0, p1, 1)
                                        if not drill:
                                            if isinstance(shape, utils2dPy.Shape):
                                                if polarity == 'N':
                                                    shape.polarity = -1
                                                else:
                                                    shape.polarity = 1
                                            feat = [
                                             shape]
                                        elif create_padstacks:
                                            if shape:
                                                new_lpadstack = layoutdbPy.new_iLPadstack()
                                                new_lpadstack.name = 'lps-%d' % this.lps_counter
                                                this.lps_counter += 1
                                                posx = (shape.bbox.xmax + shape.bbox.xmin) / 2
                                                posy = (shape.bbox.ymax + shape.bbox.ymin) / 2
                                                shape.translate(R2(-posx, -posy))
                                                shape.scale(this.scale * 0.001)
                                                cshape = utils2dPy.CShape(shape, this.layoutdb.tolerance)
                                                new_lpadstack.via_hole_shape = cshape
                                                this.layoutdb.add_lpadstack(new_lpadstack)
                                                new_padstack = layoutdbPy.new_iPadstack()
                                                new_padstack.position = R2(posx, posy)
                                                new_padstack.library_padstack = new_lpadstack
                                                if polarity == 'N':
                                                    sense = -1
                                                else:
                                                    sense = 1
                                                feat = [
                                                 (
                                                  new_padstack, sense)]
                                            else:
                                                feat = []
                                        else:
                                            if a[0] == 'A':
                                                if drill:
                                                    print('WARNING: skipped non-drill feature on drill layer (%s)' % str(file))
                                                    features.append(([], {}))
                                                else:
                                                    assert len(a) >= 11
                                                    a, b, c, sym_num, polarity, dcode, cw = (this.s2R2(a[1:3]), this.s2R2(a[3:5]), this.s2R2(a[5:7]), a[7], a[8], int(a[9]), a[10] == 'Y')
                                                    a *= scale_s2R2
                                                    b *= scale_s2R2
                                                    c *= scale_s2R2
                                                    sym = symbolmap[sym_num]
                                                    if sym[0] not in 'rs':
                                                        print('WARNING: skipped arced path (symbol=%s): ' % sym, l, str(file))
                                                        skipped.append(CurveSegment(p0, p1))
                                                        features.append(([], {}))
                                                    else:
                                                        R = (c - a).getNorm()
                                                        if cw:
                                                            R = -R
                                                        w = float(sym[1:]) * scale_factor(symbolunitsmap[sym_num], units)
                                                        if w == 0:
                                                            print('WARNING: skipped path (width=0): ', l, 'sym: ', sym, str(file))
                                                            if a != b:
                                                                skipped.append(CurveSegment(a, b, c, R))
                                                            else:
                                                                m = c + c - a
                                                                skipped.append(CurveSegment(a, m, c, R))
                                                                skipped.append(CurveSegment(m, b, c, R))
                                                            features.append(([], {}))
                                                        else:
                                                            this.consider_for_min_trace_width(w)
                                                            if (a - b).getNorm() == 0:
                                                                if w != 0:
                                                                    shapes = utils2d.CirclePath(c, R, w)
                                                                else:
                                                                    assert 0
                                                                    shapes = [utils2d.CircleShape(c, R)]
                                                            else:
                                                                if keep_traces:
                                                                    shape = layoutdbPy.Trace()
                                                                    shape.add_segment(CurveSegment(a, b, c, R), w)
                                                                    shape.is_capped = True
                                                                    if polarity == 'N':
                                                                        shape.is_positive = False
                                                                    shapes = [
                                                                     shape]
                                                                else:
                                                                    xyrss = utils2d.curved_path_segment_to_XYR(a, b, c, -R, w, this.layoutdb.tolerance)
                                                                    assert len(xyrss) >= 1
                                                                    if isinstance(xyrss[0], list):
                                                                        shapes = [utils2d.PolyarcShape(xyrs) for xyrs in xyrss]
                                                                    else:
                                                                        xyrs = xyrss
                                                                        shapes = [
                                                                         utils2d.PolyarcShape(xyrs)]
                                                                for shape in shapes:
                                                                    if isinstance(shape, utils2dPy.Shape):
                                                                        if polarity == 'N':
                                                                            shape.polarity = -1
                                                                        else:
                                                                            shape.polarity = 1

                                                            feat = shapes
                                            else:
                                                if a[0] == 'P':
                                                    assert len(a) >= 7
                                                    resize_factor = 1
                                                    assert a[3] == -1 and len(a) >= 9
                                                    x0, sym_num, resize_factor, polarity, dcode, orient = (this.s2R2(a[1:3]), a[4], float(a[5]), a[6], a[7], int(a[8]))
                                                    size_name = '-' + a[5]
                                                else:
                                                    x0, sym_num, polarity, dcode, orient = (
                                                     this.s2R2(a[1:3]), a[3], a[4], a[5], int(a[6]))
                                                    size_name = ''
                                                x0 *= scale_s2R2
                                                if orient & 8 != 0:
                                                    if a[3] == -1:
                                                        assert len(a) >= 10
                                                        angle = float(a[9])
                                                    else:
                                                        assert len(a) >= 8
                                                        angle = float(a[7])
                                                else:
                                                    angle = {0:0, 
                                                     1:90,  2:180,  3:270}[(orient & 3)]
                                        mirror = orient & 4 != 0 or orient == 9
                                        if polarity == 'N':
                                            polarity = -1
                                        else:
                                            polarity = 1
                                    if sym_num in symbolmap:
                                        symspec = symbolmap[sym_num]
                                        unit_name = ''
                                        if symbolunitsmap[sym_num] is not None:
                                            unit_name = '-' + symbolunitsmap[sym_num]
                                        padname = symspec + unit_name + size_name
                                        if this.layoutdb.has_lpad(padname):
                                            lpad = this.layoutdb.lpad(padname)
                                        else:
                                            if symspec in this.symboltable:
                                                shapes = this.symboltable[symspec]
                                                if shapes == None:
                                                    features.append(([], {}))
                                                    continue
                                                else:
                                                    shapes = get_symbol(symspec, None)
                                                    for shape in shapes:
                                                        shape.scale(scale_factor(symbolunitsmap[sym_num], units) * resize_factor)

                                                if create_padstacks:
                                                    lpad = this.create_lpad(padname, shapes)
                                            else:
                                                print('WARNING: symbol %s not in table (%s), skipped!' % (sym_num, str(file)))
                                                features.append(([], {}))
                                                continue
                                        if create_padstacks:
                                            new_lpadstack = layoutdbPy.new_iLPadstack()
                                            new_lpadstack.name = 'lps-%d' % this.lps_counter
                                            this.lps_counter += 1
                                            if lpad is not None:
                                                if drill:
                                                    if lpad.n_shapes() == 0:
                                                        missing_drill_holes += 1
                                                        if missing_drill_holes <= 10:
                                                            print('WARNING: no drill hole or hole too small (skipped): %s' % str(file))
                                                            if missing_drill_holes == 10:
                                                                print('WARNING: further skipped holes will not be reported')
                                                        features.append(([], {}))
                                                    else:
                                                        if lpad.n_shapes() > 1:
                                                            missing_drill_holes += 1
                                                            if missing_drill_holes <= 10:
                                                                print('WARNING: multiple drill holes given (skipped): %s' % str(file))
                                                                if missing_drill_holes == 10:
                                                                    print('WARNING: further skipped holes will not be reported')
                                                            features.append(([], {}))
                                                        else:
                                                            cswh = lpad.shape(0)
                                                            new_lpadstack.via_hole_shape = cswh.shape
                                                else:
                                                    new_lpadstack.pad(layoutdbPy.WhereType.top, layoutdbPy.ConnectType.noconnect, lpad)
                                            this.layoutdb.add_lpadstack(new_lpadstack)
                                            new_padstack = layoutdbPy.new_iPadstack()
                                            new_padstack.position = x0
                                            if mirror:
                                                angle = -angle
                                            new_padstack.rotation = -angle * math.pi / 180.0
                                            new_padstack.is_x_mirrowed = mirror
                                            new_padstack.library_padstack = new_lpadstack
                                            feat = [(new_padstack, polarity)]
                                        else:
                                            if angle != 0:
                                                rad = -angle * math.pi / 180.0
                                                for shape in shapes:
                                                    shape.rotate(rad, R2(0, 0))

                                            if mirror:
                                                for shape in shapes:
                                                    shape.x_mirror()

                                            for shape in shapes:
                                                shape.polarity = polarity
                                                shape.translate(x0)

                                            feat = shapes
                                    else:
                                        if a[0] == 'S':
                                            file.push(l)
                                            tmp = this.parse_surface(file, warnings, firstline=None)
                                            feat = []
                                            for shape in tmp:
                                                feat.append(shape)

                                            for shape in feat:
                                                shape.scale(scale_s2R2)

                                        else:
                                            raise Exception('wrong feature type %s (%s)!' % (str(a), str(file)))
                                        options = {}
                                        if len(params) >= 1:
                                            params = params[0]
                                            if '#' in params:
                                                params = params.split('#')[0]
                                            params = params.strip()
                                            if not len(params) == 0:
                                                for p in params.split(','):
                                                    a = p.split('=')
                                                    a[0] = a[0].replace(' ', '')
                                                    if a[0] not in attributemap:
                                                        print('WARNING: attribute %s not in attribute list (%s)' % (a[0], str(file)))
                                                        continue
                                                    attr = attributemap[a[0]]
                                                    if attr not in this.system_attributes:
                                                        if len(a) < 2:
                                                            pass
                                                        else:
                                                            if a[1] in textmap:
                                                                val = textmap[a[1]]
                                                            else:
                                                                val = a[1]
                                                    else:
                                                        atspec = this.system_attributes[attr]
                                                        if len(a) == 1:
                                                            assert atspec[0] == bool
                                                            val = True
                                                        else:
                                                            if atspec[0] == 'Option':
                                                                val = int(a[1])
                                                            else:
                                                                if atspec[0] in (int, float, bool):
                                                                    val = atspec[0](a[1])
                                                                else:
                                                                    assert atspec[0] == 'Text'
                                                                    if a[1] in textmap:
                                                                        val = textmap[a[1]]
                                                                    else:
                                                                        val = a[1]
                                                        options[attr] = val

                                        features.append((feat, options))

            for warn in list(warnings.keys()):
                print('WARNING:%s(%d time(s))' % (warn, warnings[warn]))

            if missing_drill_holes:
                print('WARNING: %s drill holes have been skipped' % missing_drill_holes)
            if len(skipped):
                print('WARNING: %d paths skipped' % len(skipped))
            return features

    def parse_surface(this, file, warnings, firstline=None):
        if hasattr(this, 'layoutdb'):
            tol2 = (this.layoutdb.tolerance * 0.01) ** 2
        else:
            tol2 = 0
        if firstline is None:
            firstline = file.readline()
            assert len(firstline) > 0
            firstline = firstline.strip()
        else:
            tmp = firstline.split(';')
            params, attrs = tmp[0], tmp[1:]
            a = params.split()
            if len(a) >= 3:
                polarity, dcode = a[1], int(a[2])
            else:
                polarity, dcode = ('P', 0)
            assert polarity in ('P', 'N')
        polygons = []
        while 1:
            l = file.readline()
            assert len(l.strip()) > 0
            if l[:2] in ('SE', 'CE'):
                break
            a = l.strip().split()
            assert a[0] == 'OB'
            if len(a) == 3:
                x0, typ = this.s2R2(a[1:3]), 'I'
            else:
                if len(a) == 4:
                    x0, typ = this.s2R2(a[1:3]), a[3]
                else:
                    print('WARNING: Unknown shape in', firstline)
                    continue
                xlast = x0
                segs = ArrayCurveSegment(0)
                while 1:
                    l = file.readline()
                    assert len(l) > 0
                    l = l.strip()
                    assert len(l) > 0
                    if l == 'OE':
                        break
                    a = l.split()
                    assert a[0] in ('OS', 'OC')
                    if a[0] == 'OS':
                        if not len(a) >= 3:
                            raise AssertionError
                        else:
                            if len(a) > 3:
                                w_tmp = ' Ignoring '
                                for i in range(3, len(a)):
                                    w_tmp += a[i]

                                if w_tmp in warnings:
                                    warnings[w_tmp] += 1
                                else:
                                    warnings[w_tmp] = 1
                                x = this.s2R2(a[1:3])
                                if (xlast - x).getNorm2() <= tol2:
                                    this.duplicate_vertices_ignored += 1
                                else:
                                    segs.push_back(CurveSegment(xlast, x))
                                    xlast = x
                            else:
                                assert len(a) == 6
                                x, xc, cw = this.s2R2(a[1:3]), this.s2R2(a[3:5]), a[5] == 'Y'
                                R = 0.5 * ((x - xc).getNorm() + (xlast - xc).getNorm())
                            if cw:
                                R = -R
                            if abs(R) > this.layoutdb.tolerance:
                                segs.push_back(CurveSegment(xlast, x, xc, R))
                                xlast = x

                if len(segs) > 0:
                    x0 = segs[0].a
                    if x0 != xlast:
                        print('INFO: end point of polygon corrected by %g (%s).' % ((x0 - xlast).getNorm(), str(file)))
                        seg = segs[(len(segs) - 1)]
                        if seg.is_arc:
                            seg = CurveSegment(seg.a, x0, seg.c, seg.R)
                        else:
                            seg = CurveSegment(seg.a, x0)
                        segs[len(segs) - 1] = seg
                    try:
                        shape = Shape(segs)
                    except:
                        print('WARNING: could not process polygon input data near %s' % str(file))
                        shape = None

                else:
                    print('WARNING: shape/hole with 0 segments ignored (%s)' % str(file))
                    shape = None
            if shape is not None:
                polygons.append((typ, shape))

        sense = 1
        if polarity == 'N':
            sense = -1
        swhs = []
        for typ, shape in polygons:
            if not typ in ('I', 'H'):
                raise AssertionError
            else:
                if typ == 'I':
                    swh = ShapeWithHoles()
                    swh.shape = shape
                    swhs.append(swh)
                else:
                    if len(swhs) != 1:
                        for i in range(len(swhs) - 1, -1, -1):
                            swh = swhs[i]
                            if swh.shape.contains(shape):
                                swh.holes.push_back(shape)
                                break
                        else:
                            w_tmp = ' found hole outside of island shape (skipped)'
                            if w_tmp in warnings:
                                warnings[w_tmp] += 1
                            else:
                                warnings[w_tmp] = 1

                    else:
                        swhs[0].holes.push_back(shape)

        for swh in swhs:
            swh.polarity = sense

        return swhs

    def num2layer(this, lnum):
        return this.layoutdb.top_etch_layer().number + (lnum - 1) * 2

    def unite_traces(this, layer):
        segm = []
        for i in range(layer.n_traces()):
            trace = layer.trace(i)
            for j in range(trace.n_segments()):
                segm.append(trace.segment(j))

        unated_segms = []
        tmp = ArrayCurveSegment(0)
        tmp.push_back(segm[0])
        for s in segm[1:]:
            if s.a == tmp[(len(tmp) - 1)].b:
                tmp.push_back(s)
            else:
                unated_segms.append(tmp)
                tmp = ArrayCurveSegment(0)
                tmp.push_back(s)

        unated_segms.append(tmp)
        res = []
        for s in unated_segms:
            if s[0].a == s[(len(s) - 1)].b:
                shape = Shape(s)
                if shape:
                    res.append(shape)
            else:
                res.append(s)

        return res

    def define_pin_layer(this, pin, layer_candidats, comp_on_top, comp_name):
        layers = []
        for l in layer_candidats:
            if this.layoutdb.layer(l) and this.layoutdb.layer(l).is_etch():
                layers.append(this.layoutdb.layer(l).number)

        if len(layers) == 0:
            print("WARNING: didn't find pad for pin %s from component %s, place pin on component side" % (pin.name, comp_name))
            print(layer_candidats, layers, pin.position)
            if comp_on_top:
                pin.layer = this.layoutdb.top_etch_layer()
            else:
                pin.layer = this.layoutdb.bottom_etch_layer()
        else:
            if len(layers) == 1:
                pin.layer = this.layoutdb.layer(layers[0])
            else:
                layers.sort()
                if comp_on_top:
                    pin.layer = this.layoutdb.layer(layers[0])
                else:
                    pin.layer = this.layoutdb.layer(layers[(-1)])

    def set_comp_layer(this):
        for comp in this.layoutdb.components():
            comp_layer = []
            for i in range(comp.n_pins()):
                pin = comp.pin(i)
                if pin.layer and pin.layer not in comp_layer:
                    comp_layer.append(pin.layer)

            if len(comp_layer) == 1:
                comp.layer = comp_layer[0]
            else:
                if len(comp_layer) > 1:
                    comp_layer.sort(key=(lambda x: x.number))
                    if comp.side == layoutdbPy.WhereType.top:
                        comp.layer = comp_layer[0]
                    else:
                        comp.layer = comp_layer[(-1)]
                    print("WARNING: placment of component '%s' can not be uniquely determined, placed on layer %s" % (comp.name, comp.layer.name))

    def create_wirebonds(this):

        def get_wb_layer(lname, side, prefix, pos):
            try:
                if len(lname) > 3 and lname[:3] == 'ST_':
                    lname = prefix + lname
                    candidates = this.die_layer_candidates[side][lname]['component']
                    for comp, layer in candidates:
                        if this.layoutdb.component(comp).outline_shape(0).to_ShapeWithHoles().shape.contains_p(pos):
                            return this.layoutdb.layer(layer)

                    return
                else:
                    return this.layoutdb.layer(this.num2layer(int(lname)))
            except:
                return

        for side in list(this.wirebond_candidates.keys()):
            is_top = side == 'top'
            if is_top:
                prefix = 'DP_T_'
            else:
                prefix = 'DP_B_'
            for wb_data in this.wirebond_candidates[side]:
                wb = layoutdbPy.Wirebond()
                wb.position_from = wb_data['wirebond'][0].a
                wb.position_to = wb_data['wirebond'][(len(wb_data['wirebond']) - 1)].b
                wb.profile_name = 'JEDEC4'
                wb.is_top = is_top
                lfrom = get_wb_layer(wb_data['lto'], side, prefix, wb.position_from)
                lto = get_wb_layer(wb_data['lfrom'], side, prefix, wb.position_to)
                if lfrom and lto:
                    wb.layer_from = lfrom
                    wb.layer_to = lto
                    this.layoutdb.add_wirebond(wb)
                else:
                    'WARNING: can not identify wirebond layers from %s, skipped wirebonds from thisa layer' % wb_data['orig_l_name']

        if this.layoutdb.n_wirebonds():
            wb = layoutdbPy.new_WirebondProfile_JEDEC4(100)
            wb.diameter = 20
            wb.is_forward = True
            wb.name = 'JEDEC4'
            material = layoutdbPy.Material()
            material.name = 'GOLD'
            material.eps = material.mu = 1
            wb.material = material
            this.layoutdb.add_wirebond_profile(wb)

    def create_diestack_get_diepad_layer(this, comp):
        if this.layoutdb.diestack(comp.name) != None:
            diestack = this.layoutdb.diestack(comp.name)
        else:
            diestack = layoutdbPy.Diestack()
            diestack.name = comp.name
            is_top = comp.side == layoutdbPy.WhereType.top
            diestack.is_top = is_top
            outline = None
            if comp.n_outline_shapes():
                outline = comp.outline_shape(0)
            dlayer = layoutdbPy.new_iLayer()
            dlayer.layer_type = layoutdbPy.LayerType.Die
            dlayer.name = diestack.name
            if comp.height > 0:
                dlayer.thickness = comp.height
                comp.height = 0
            diepadlayer = layoutdbPy.new_iLayer()
            diepadlayer.layer_type = layoutdbPy.LayerType.DiePads
            diepadlayer.name = dlayer.name + '-pads'
            diestack.add_component(comp, diepadlayer)
            if outline:
                dlayer.outline = outline
                diepadlayer.outline = outline
            if is_top:
                this.layoutdb.add_layer_above(dlayer, None)
                this.layoutdb.add_layer_above(diepadlayer, None)
                diestack.add_layer(diepadlayer)
                diestack.add_layer(dlayer)
            else:
                this.layoutdb.add_layer_below(dlayer, None)
                this.layoutdb.add_layer_below(diepadlayer, None)
                diestack.add_layer(dlayer)
                diestack.add_layer(diepadlayer)
            this.layoutdb.add_diestack(diestack)
        return diestack.layer(comp.name + '-pads')

    def process_wire_bond_layer(this, stepname, layers):
        for layer in list(layers.values()):
            if 'ADD_TYPE' in layer and layer['ADD_TYPE'] == 'WIRE_BONDING':
                name = layer['NAME']
                features = this.parse_feature_file((this.getpath(['steps', stepname, 'layers', name.lower(), 'features'])), keep_traces=True,
                  create_padstacks=True)
                if int(layer['ROW']) > this.layoutdb.n_layers():
                    is_top = False
                else:
                    is_top = True
                wb_list = []
                map_pos_to_layer = []
                for feature, opts in features:
                    for instance in feature:
                        if isinstance(instance, layoutdbPy.Trace):
                            wb_list.append((instance, opts))
                        else:
                            if isinstance(instance, tuple):
                                padstack, polarity = instance
                                comp_name = None
                                pin_name = None
                                if 'comp_name' in opts.keys():
                                    comp_name = opts['comp_name']
                                if 'pin_name' in opts.keys():
                                    pin_name = opts['pin_name']
                                if 'net_name' in opts.keys():
                                    net_name = opts['net_name']
                                else:
                                    net_name = 'None'
                                comp = None
                                if comp_name:
                                    comp = this.layoutdb.component(comp_name)
                                    padlayer = this.create_diestack_get_diepad_layer(comp)
                                else:
                                    padlayer = this.layoutdb.top_etch_layer()
                                lps = padstack.library_padstack
                                new_pad = lps.pad(layoutdbPy.WhereType.top, layoutdbPy.ConnectType.noconnect)
                                connect = layoutdbPy.ConnectType.connect
                                lps.pad(padlayer, connect, lps.pad(layoutdbPy.WhereType.top, layoutdbPy.ConnectType.noconnect))
                                padstack.connect(padlayer, connect)
                                if comp:
                                    comp.add_padstack(padstack)
                                else:
                                    this.layoutdb.add_padstack(padstack)
                                map_pos_to_layer.append([padstack.position, padlayer])
                            else:
                                wb_list.append((feature, opts))

                for trace, opts in wb_list:
                    wb = layoutdbPy.Wirebond()
                    wb.position_from = trace.segment(0).a
                    wb.position_to = trace.segment(trace.n_segments() - 1).b
                    wb.profile_name = 'JEDEC4'
                    wb.is_top = is_top
                    lfrom = this.layoutdb.top_etch_layer()
                    lto = this.layoutdb.top_etch_layer()
                    for pos, layer in map_pos_to_layer:
                        if wb.position_from == pos:
                            lfrom = layer
                        if wb.position_to == pos:
                            lto = layer

                    if lfrom and lto:
                        wb.layer_from = lfrom
                        wb.layer_to = lto
                        this.layoutdb.add_wirebond(wb)

        check_layer_stackup((this.layoutdb), add_soldermasks=False)
        this.layoutdb.update_elevations()


def Run(filename, importer):
    if 'CST_ODBPP_USING_SPECIAL_NAMING_CONVENTIONS' in filename:
        os.environ['CST_ODBPP_USING_SPECIAL_NAMING_CONVENTIONS'] = 'yes'
    print('=' * 60)
    print('Reading ODB++ database ...\n')
    odbpp = ODBPPparser(filename, db_unit='mil', progressbar=importer)
    layoutdb = odbpp.to_LayoutDB()
    del odbpp
    print('Unifying library padstacks...')
    layoutdbPy.eliminate_identical_library_padstacks(layoutdb)
    print('Finished reading database.')
    print('=' * 60)
    if layoutdb is not None:
        importer.db = layoutdb
    import gc
    gc.collect()
    return 0


if __name__ == '__main__':
    import sys
    name = sys.argv[1]
    e = ODBPPparser(name)
    db = e.to_LayoutDB()
