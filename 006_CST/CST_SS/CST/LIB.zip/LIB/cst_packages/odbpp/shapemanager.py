# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\odbpp\shapemanager.py
# Compiled at: 2019-01-31 19:48:52
# Size of source mod 2**32: 24092 bytes
import types
from common.utils2d import R2, CurveSegment, ArrayCurveSegment, Shape, ShapeWithHoles, CircleShape, Make_CClockwise, Make_Clockwise, vectorShapeWithHoles, CShapeWithHoles, BoundingBox, Planeprocessor
from common import utils2d
from common.shapemanager import create_standart_shapes
import math

def make_list(x):
    if type(x) == list:
        return x
    else:
        return [
         x]


def polygon2shape(polygon):
    segs = ArrayCurveSegment(0)
    x0 = R2(polygon.OB.X, polygon.OB.Y)
    seglist = make_list(polygon.SEG)
    if len(seglist) == 1:
        seg = seglist[0]
        assert hasattr(seg, 'CW')
        xc = R2(seg.XC, seg.YC)
        R = (xc - x0).getNorm()
        if seg.CW != 'YES':
            R = -R
        if R != 0:
            return CircleShape(xc, R)
        return
    else:
        xlast = x0
        for seg in seglist:
            x = R2(seg.X, seg.Y)
            if hasattr(seg, 'CW'):
                xc = R2(seg.XC, seg.YC)
                R = (x - xc).getNorm()
                if seg.CW == 'YES':
                    R = -R
                if x == xlast:
                    print('WARNING: SKIPPED CLOSED ARC SEG', seg)
                else:
                    segs.push_back(CurveSegment(xlast, x, xc, R))
            else:
                if x == xlast:
                    print('Strange: duplc. point')
                else:
                    segs.push_back(CurveSegment(xlast, x))

        res = Shape(segs)
        res.make_arcs_less_than(math.pi)
        return res


def get_surface(S, consider_for_min_trace_width=None):
    islands = make_list(S.ISLAND)
    if len(islands) == 1:
        swh = ShapeWithHoles()
        swh.shape = polygon2shape(islands[0].POLYGON)
        if hasattr(S, 'HOLE'):
            for hole in make_list(S.HOLE):
                polygon = polygon2shape(hole.POLYGON)
                if polygon is None:
                    print('WARNING: polygon skipped!')
                else:
                    swh.holes.push_back(polygon)

        for hole in swh.holes:
            res = swh.shape.contains(hole)
            if res != 1:
                print('Problem in containment test: res=%d' % res)
                print('[Shape starting at %s, hole starting at %s.]' % (str(hole.segments[0].a), str(swh.shape.segments[0].a)))

        return [
         swh]
    else:
        if not not hasattr(S, 'HOLE'):
            if not len(make_list(S.HOLE)) == 0:
                raise AssertionError
        res = []
        for i in islands:
            swh = ShapeWithHoles()
            s = polygon2shape(i.POLYGON)
            if s is None:
                pass
            else:
                swh.shape = s
                res.append(swh)

        return res


def get_symbol(sym, cadset):
    rot = 0
    found = sym.rfind('_')
    if found != -1:
        if found + 1 < len(sym):
            if sym[found + 1:].isdigit():
                angle = -float(sym[found + 1:])
                rot = angle * math.pi / 180.0
                sym = sym[:found]
        if found + 1 == len(sym):
            sym = sym[:found]
    try:
        shapes = get_symbol_without_rotation(sym, cadset)
    except:
        print('WARNING: cannot import symbol ', sym)
        return []
    else:
        for shape in shapes:
            if rot:
                shape.rotate(rot, R2(0, 0))

        return shapes


def get_symbol_without_rotation(sym, cadset):

    def get_Planeprocessor_WithShapes(os, symb, symb_hole, gap, angle, angle_sp):
        hs = [
         symb_hole]
        h0 = utils2d.Rectangle(gap, os * math.sqrt(2) + os / 10)
        h0.translate(R2(-gap / 2.0, 0))
        Make_Clockwise(h0)
        h0.rotate(-2 * math.pi / 4 + 2 * math.pi * angle / 360, R2())
        for i in range(num_sp):
            h0.rotate(angle_sp, R2())
            hs.append(h0.clone())

        vhs = vectorShapeWithHoles()
        vhs.append(CShapeWithHoles(symb))
        for h in hs:
            vhs.append(CShapeWithHoles(h))

        pp = Planeprocessor(BoundingBox(-(os * math.sqrt(2) + os / 8), os * math.sqrt(2) + os / 8, -(os * math.sqrt(2) + os / 8), os * math.sqrt(2) + os / 8), 0.0001)
        pp.add_shapes(vhs)
        res = pp.boolean_add2()
        return [r.to_ShapeWithHoles() for r in res]

    def compute_round_off(a, b, c, r):
        if r == 0:
            return [(c, 0)]
        else:
            acrossb = (a - c).cross(b - c)
            if acrossb == 0:
                return [
                 (
                  c, 0)]
            if (a - c).getNorm() < r or (b - c).getNorm() < r:
                return [
                 (
                  c, 0)]
            ua = (a - c) / (a - c).getNorm()
            ub = (b - c) / (b - c).getNorm()
            cosphi = ua.dot(ub)
            phi = math.acos(cosphi)
            l = r / math.tan(phi / 2)
            a1 = c + ua * l
            b1 = c + ub * l
            if acrossb > 0:
                ua.turn_left()
                ub.turn_right()
            else:
                ua.turn_right()
                ub.turn_left()
            m1 = a1 + ua * r
            m2 = b1 + ub * r
            m = (m1 + m2) / 2.0
            if acrossb > 0:
                t = 1.0
            else:
                t = -1.0
            return [
             (
              a1, 0), (m, r * t), (b1, 0)]

    l = len(sym)
    if l > 4 and sym[:4] == 'rect':
        tmp = sym[4:].split('x')
        w, h = float(tmp[0]), float(tmp[1])
        assert w > 0 and h > 0
        if len(tmp) == 2:
            return create_standart_shapes('Rect', [w, h])
        else:
            if len(tmp) not in (3, 4) or tmp[2][0] not in 'rc':
                print('WARNING: rounded/chamfered rectangle %s with wrong syntax (assuming regular rectangle)' % sym)
                print(tmp)
                return [utils2d.RectangleC(w, h)]
            else:
                rounded = tmp[2][0] == 'r'
                rad = float(tmp[2][1:])
                if len(tmp) == 4:
                    corners = tmp[3]
                else:
                    corners = '1234'
                params = [
                 w, h, rad, corners]
                if rounded:
                    res = create_standart_shapes('RectRound', params)
                else:
                    res = create_standart_shapes('RectCham', params)
            return res
    else:
        if l > 3:
            if sym[:3] == 'ths' or sym[:3] == 'thr':
                od, id, angle, num_spokes, gap = sym[3:].split('x')
                od, id, angle, num_spokes, gap = (float(od), float(id), float(angle) * math.pi / 180.0, int(num_spokes), float(gap))
                params = [od, id, angle, num_spokes, gap]
                if sym[:3] == 'ths':
                    return create_standart_shapes('RoundThermal', params)
            else:
                return create_standart_shapes('RoundThermalRoundet', params)
        elif l > 8:
            if sym[:8] == 'donut_rc':
                temp = sym[8:].split('x')
                ow, oh, lw = temp[0], temp[1], temp[2]
                ow, oh, lw = float(ow), float(oh), float(lw)
                if len(temp) == 3:
                    return create_standart_shapes('RectangleDonut', [ow, oh, lw])
                else:
                    if len(temp) in (4, 5):
                        rad = temp[3][1:]
                        if len(temp) == 5:
                            corners = temp[4]
                        else:
                            corners = '1234'
                        rad = float(rad)
                        return create_standart_shapes('RoundedRectangleDonut', [ow, oh, lw, rad, corners])
                    print('WARNING: rounded/chamfered rectangle %s with wrong syntax (assuming regular rectangle)' % sym)
                    print(tmp)
                    return [utils2d.RectangleC(od, od)]
            else:
                if l > 7:
                    if sym[:7] == 'donut_r':
                        od, id = sym[7:].split('x')
                        od, id = float(od), float(id)
                        params = [od, id]
                        return create_standart_shapes('RoundDonut', params)
                if l > 8:
                    if sym[:8] == 'donut_sr':
                        od, id = sym[8:].split('x')
                        od, id = float(od), float(id)
                        return create_standart_shapes('SquareRoundDonut', [od, id])
        elif l > 7:
            if sym[:7] == 'donut_s':
                temp = sym[7:].split('x')
                if len(temp) == 2:
                    od, id = temp[0], temp[1]
                    od, id = float(od), float(id)
                    return create_standart_shapes('SquareDonut', [od, id])
                else:
                    if len(temp) in (3, 4):
                        od, id, rad = temp[0], temp[1], temp[2][1:]
                        if len(temp) == 4:
                            corners = temp[3]
                        else:
                            corners = '1234'
                        od, id, rad = float(od), float(id), float(rad)
                        params = [od, id, rad, corners]
                        return create_standart_shapes('RoundedSquareDonut', params)
                    print('WARNING: rounded/chamfered rectangle %s with wrong syntax (assuming regular rectangle)' % sym)
                    print(tmp)
                    return [utils2d.RectangleC(od, od)]
            elif l > 7:
                if sym[:7] == 'donut_o':
                    temp = sym[7:].split('x')
                    ow, oh, lw = temp[0], temp[1], temp[2]
                    ow, oh, lw = float(ow), float(oh), float(lw)
                    return create_standart_shapes('OvalDonut', [ow, oh, lw])
                else:
                    if l > 4:
                        if sym[:6] == 'oval_h':
                            tmp = sym[6:].split('x')
                            w, h = float(tmp[0]), float(tmp[1])
                            return create_standart_shapes('HalfOval', [w, h])
                        else:
                            if l > 4:
                                if sym[:4] == 'oval':
                                    tmp = sym[4:].split('x')
                                    w, h = float(tmp[0]), float(tmp[1])
                                    return create_standart_shapes('Oval', [w, h])
                                else:
                                    if l > 3:
                                        if sym[:3] == 'oct':
                                            tmp = sym[3:].split('x')
                                            w, h, r = float(tmp[0]), float(tmp[1]), float(tmp[2])
                                            return create_standart_shapes('Octagon', [w, h, r])
                                        if l > 5:
                                            if sym[:5] == 'hex_l':
                                                tmp = sym[5:].split('x')
                                                w, h, r = float(tmp[0]), float(tmp[1]), float(tmp[2])
                                                return create_standart_shapes('Hexagon_l', [w, h, r])
                                    else:
                                        if l > 5:
                                            if sym[:5] == 'hex_s':
                                                tmp = sym[5:].split('x')
                                                w, h, r = float(tmp[0]), float(tmp[1]), float(tmp[2])
                                                return create_standart_shapes('Hexagon_s', [w, h, r])
                                    if l > 3:
                                        if sym[:3] == 'tri':
                                            tmp = sym[3:].split('x')
                                            b, h = float(tmp[0]), float(tmp[1])
                                            return create_standart_shapes('Triangle', [b, h])
                            else:
                                if l > 3:
                                    if sym[:3] == 'bfs':
                                        tmp = sym[3:].split('x')
                                        s = float(tmp[0])
                                        return create_standart_shapes('SquareButterfly', [s])
                            if l > 3:
                                if sym[:3] == 'bfr':
                                    tmp = sym[3:].split('x')
                                    s = float(tmp[0])
                                    return create_standart_shapes('RoundButterfly', [s])
                    else:
                        if l > 4:
                            if sym[:4] == 'hole':
                                tmp = sym[4:].split('x')
                                r = tmp[0]
                                print('WARNING: replaced hole (hole) by round (r) pad')
                                return create_standart_shapes('Circle', [r])
                    if l > 2:
                        if sym[:2] == 'el':
                            tmp = sym[2:].split('x')
                            w, h = float(tmp[0]), float(tmp[1])
                            print('WARNING: replaced elipse (el) by oval (oval) pad')
                            return create_standart_shapes('Oval', [w, h])
            else:
                if l > 2:
                    if sym[:2] == 'di':
                        tmp = sym[2:].split('x')
                        w, h = float(tmp[0]), float(tmp[1])
                        return create_standart_shapes('Diamond', [w, h])
                if l > 6:
                    if sym[:6] == 'sr_ths':
                        os, id, angle, num_sp, gap = sym[6:].split('x')
                        os, id, angle, num_sp, gap = (float(os), float(id), float(angle), int(num_sp), float(gap))
                        return create_standart_shapes('SquareRoundThermal', [os, id, angle, num_sp, gap])
        elif l > 5:
            if sym[:5] == 's_ths':
                tmp = sym[5:].split('x')
                os, id, angle, num_sp, gap = (float(tmp[0]), float(tmp[1]), float(tmp[2]), int(tmp[3]), float(tmp[4]))
                if len(tmp) in (6, 7):
                    rad = float(tmp[5][1:])
                    if len(tmp) == 7:
                        corners = tmp[6]
                    else:
                        corners = '1234'
                    return create_standart_shapes('RoundedSquareThermal', [os, id, angle, num_sp, gap, rad, corners])
                else:
                    rad = 0
                    corners = ''
                    return create_standart_shapes('SquareThermal', [os, id, angle, num_sp, gap])
            elif l > 5:
                if sym[:5] == 's_tho':
                    tmp = sym[5:].split('x')
                    od, id, angle, num_sp, gap = (float(tmp[0]), float(tmp[1]), float(tmp[2]), float(tmp[3]), float(tmp[4]))
                    return create_standart_shapes('RectangularThermalOpenCorners', [od, od, angle, num_sp, gap, (od - id) / 2])
                else:
                    if l > 5:
                        if sym[:5] == 'o_ths':
                            tmp = sym[5:].split('x')
                            ow, oh, angle, num_sp, gap, lw = (float(tmp[0]), float(tmp[1]), float(tmp[2]), int(tmp[3]), float(tmp[4]), float(tmp[5]))
                            return create_standart_shapes('OvalThermal', [ow, oh, angle, num_sp, gap, lw])
                    if l > 6 and sym[:6] == 'rc_ths':
                        tmp = sym[6:].split('x')
                        w, h, angle, num_sp, gap, lw = (float(tmp[0]), float(tmp[1]), float(tmp[2]), int(tmp[3]), float(tmp[4]), float(tmp[5]))
                        if len(tmp) in (7, 8):
                            rad = float(tmp[6][1:])
                            if len(tmp) == 8:
                                corners = tmp[7]
                            else:
                                corners = '1234'
                            return create_standart_shapes('RoundedRectangleThermal', [w, h, angle, num_sp, gap, lw, rad, corners])
                        else:
                            return create_standart_shapes('RectangularThermal', [w, h, angle, num_sp, gap, lw])
                    else:
                        if l > 6:
                            if sym[:6] == 'rc_tho':
                                tmp = sym[6:].split('x')
                                w, h, angle, num_sp, gap, lw = (float(tmp[0]), float(tmp[1]), float(tmp[2]), int(tmp[3]), float(tmp[4]), float(tmp[5]))
                                return create_standart_shapes('RectangularThermalOpenCorners', [w, h, angle, num_sp, gap, lw])
                            else:
                                if l >= 5:
                                    if sym[:5] == 'moire':
                                        tmp = sym[5:].split('x')
                                        rw, rg, nr, lw, ll, la = (float(tmp[0]), float(tmp[1]), int(tmp[2]), float(tmp[3]), float(tmp[4]), float(tmp[5]))
                                        return create_standart_shapes('Moire', [rw, rg, nr, lw, ll, la])
                                    else:
                                        if l > 6:
                                            if sym[:6] == 'hplate':
                                                tmp = sym[6:].split('x')
                                                w, h, c = float(tmp[0]), float(tmp[1]), float(tmp[2])
                                                ra = ro = 0
                                                if len(tmp) > 3:
                                                    ra = tmp[3]
                                                    if ra[:2] == 'ra':
                                                        ra = float(ra[2:])
                                                    if len(tmp) > 4:
                                                        ro = tmp[4]
                                                        if ro[:2] == 'ro':
                                                            ro = float(ro[2:])
                                                return create_standart_shapes('HomePlate', [w, h, c, ra, ro])
                                            if l > 7:
                                                if sym[:7] == 'rhplate':
                                                    tmp = sym[7:].split('x')
                                                    w, h, c = float(tmp[0]), float(tmp[1]), float(tmp[2])
                                                    ra = ro = 0
                                                    if len(tmp) > 3:
                                                        ra = tmp[3]
                                                        if ra[:2] == 'ra':
                                                            ra = float(ra[2:])
                                                        if len(tmp) > 4:
                                                            ro = tmp[4]
                                                            if ro[:2] == 'ro':
                                                                ro = float(ro[2:])
                                                    return create_standart_shapes('InvertedHomePlate', [w, h, c, ra, ro])
                                        else:
                                            if l > 7:
                                                if sym[:7] == 'fhplate':
                                                    tmp = sym[7:].split('x')
                                                    w, h, hc, vc = (float(tmp[0]), float(tmp[1]), float(tmp[2]), float(tmp[3]))
                                                    ra = ro = 0
                                                    if len(tmp) > 4:
                                                        ra = tmp[4]
                                                        if ra[:2] == 'ra':
                                                            ra = float(ra[2:])
                                                        if len(tmp) > 5:
                                                            ro = tmp[5]
                                                            if ro[:2] == 'ro':
                                                                ro = float(ro[2:])
                                                    return create_standart_shapes('FlatHomePlate', [w, h, hc, vc, ra, ro])
                                        if l > 9:
                                            if sym[:9] == 'radhplate':
                                                tmp = sym[9:].split('x')
                                                w, h, ms = float(tmp[0]), float(tmp[1]), float(tmp[2])
                                                ra = 0
                                                w *= 0.5
                                                h *= 0.5
                                                ms *= 0.5
                                                if len(tmp) > 3:
                                                    ra = tmp[3]
                                                    if ra[:2] == 'ra':
                                                        ra = float(ra[2:])
                                                return create_standart_shapes('RadiusedInvertedHomePlate', [w, h, ms, ra])
                                else:
                                    if l > 6:
                                        if sym[:6] == 'dshape':
                                            tmp = sym[6:].split('x')
                                            w, h, r = float(tmp[0]), float(tmp[1]), float(tmp[2])
                                            if len(tmp) > 3:
                                                if tmp[3][:2] == 'ra':
                                                    ra = float(tmp[3][2:])
                                            else:
                                                ra = 0
                                            return create_standart_shapes('RadiusedHomePlate', [w, h, r, ra])
                                if l > 5:
                                    if sym[:5] == 'cross':
                                        tmp = sym[5:].split('x')
                                        w, h, hs, vs, hc, vc, sr = (float(tmp[0]), float(tmp[1]), float(tmp[2]), float(tmp[3]), float(tmp[4]), float(tmp[5]), tmp[6])
                                        ra = 0
                                        if sr == 'r':
                                            if len(tmp) > 7:
                                                ra = tmp[7]
                                                if ra[:2] == 'ra':
                                                    ra = float(ra[2:])
                                            else:
                                                print('Missing corner radius in rounded cross %s, create square cross ' % sym)
                                        return create_standart_shapes('Cross', [w, h, hs, vs, hc, vc, sr, ra])
                        else:
                            if l > 7:
                                if sym[:7] == 'dogbone':
                                    tmp = sym[7:].split('x')
                                    w, h, hs, vs, hc, sr = (float(tmp[0]), float(tmp[1]), float(tmp[2]), float(tmp[3]), float(tmp[4]), tmp[5])
                                    ra = 0
                                    if sr == 'r':
                                        if len(tmp) > 6:
                                            ra = tmp[6]
                                            if ra[:2] == 'ra':
                                                ra = float(ra[2:])
                                        else:
                                            print('Missing corner radius in rounded cross %s, create square cross ' % sym)
                                    return create_standart_shapes('Dogbone', [w, h, hs, vs, hc, sr, ra])
                        if l > 5:
                            if sym[:5] == 'dpack':
                                tmp = sym[5:].split('x')
                                w, h, hg, vg, vn, hn = (float(tmp[0]), float(tmp[1]), float(tmp[2]), float(tmp[3]), int(tmp[4]), int(tmp[5]))
                                if len(tmp) > 6:
                                    if tmp[6][:2] == 'ra':
                                        ra = float(tmp[6][2:])
                                else:
                                    ra = 0
                                return create_standart_shapes('D-Pack', [w, h, hg, vg, vn, hn, ra])
            else:
                if l > 5:
                    if sym[:5] == 's_thr':
                        tmp = sym[5:].split('x')
                        os, id, angle, num_spokes, gap = (float(tmp[0]), float(tmp[1]), float(tmp[2]), float(tmp[3]), int(tmp[4]))
                        return create_standart_shapes('LineThermal', [os, id, angle, num_spokes, gap])
                if l > 10:
                    if sym[:10] == 'oblong_ths':
                        tmp = sym[10:].split('x')
                        ow, oh, angle, num_spokes, gap, lw, rs = (float(tmp[0]), float(tmp[1]), float(tmp[2]), float(tmp[3]), float(tmp[4]), float(tmp[5]), tmp[6])
                        return create_standart_shapes('OblongThermal', [ow, oh, angle, num_spokes, gap, lw, rs])
        else:
            if l > 1 and sym[0] == 'r':
                R = float(sym[1:])
                return create_standart_shapes('Circle', [R])
            else:
                if l > 1:
                    if sym[0] == 's':
                        try:
                            wh = float(sym[1:])
                        except:
                            print('unknown symbol: ', sym)
                            return []
                            return create_standart_shapes('Square', [wh])

                print('unknown symbol: ', sym)
                return []


def L2shape(L, consider_for_min_trace_width=None):
    p0, p1 = R2(L.XS, L.YS), R2(L.XE, L.YE)
    w = L.cadset.SYM
    if w[0] in 'rs':
        w = float(w[1:])
    else:
        raise Exception('strange line specification: %s' % str(L))
    if consider_for_min_trace_width is not None:
        consider_for_min_trace_width(w)
    return utils2d.PolyarcShape(utils2d.straight_path_segment_to_XYR(p0, p1, w))


def P2shape(P, symboltable={}):
    x = R2(P.X, P.Y)
    if P.SYM in symboltable:
        tmp = [s.clone() for s in symboltable[P.SYM]]
    else:
        tmp = get_symbol(P.SYM, P.cadset)
    if hasattr(P, 'MIRROR'):
        if P.MIRROR == 'YES':
            for shape in tmp:
                shape.y_mirror()

    if hasattr(P, 'ANGLE'):
        if P.ANGLE != 0:
            rad = -P.ANGLE * math.pi / 180.0
            for shape in tmp:
                shape.rotate(rad, R2(0, 0))

    for shape in tmp:
        shape.translate(x)

    return tmp


def A2shape(A, consider_for_min_trace_width=None):
    a, b, c = R2(A.XS, A.YS), R2(A.XE, A.YE), R2(A.XC, A.YC)
    w = A.cadset.SYM
    if w[0] in 'rs':
        w = float(w[1:])
    else:
        raise Exception('strange arc specification (%s)' % str(A))
    if consider_for_min_trace_width is not None:
        consider_for_min_trace_width(w)
    R = (c - a).getNorm()
    if A.CW == 'NO':
        R = -R
    return utils2d.PolyarcShape(utils2d.curved_path_segment_to_XYR(a, b, c, R, w, tol=0))


def get_all_shapes(odbx):
    swhs = []
    if hasattr(odbx, 'S'):
        for S in make_list(odbx.S):
            swhs.extend(get_surface(S))

    if hasattr(odbx, 'P'):
        for P in make_list(odbx.P):
            swhs.extend(P2shape(P))

    if hasattr(odbx, 'A'):
        for A in make_list(odbx.A):
            swhs.append(A2shape(A))

    if hasattr(odbx, 'L'):
        for L in make_list(odbx.L):
            swhs.append(L2shape(L))

    return [s for s in swhs if s is not None]


def get_shapes(odbx, lyrname):
    data = odbx.ODX.ODX_CAD.DATA
    assert len(make_list(data.STEP)) == 1
    step = make_list(data.STEP)[0]
    units = data.DATA_HEADER.UNITS
    swhs = []
    for layer in make_list(step.LYR_F):
        print(layer.LYR_NAME)
        if layer.LYR_NAME != lyrname:
            continue
        if hasattr(layer, 'S'):
            for S in make_list(layer.S):
                swhs.extend(get_surface(S))

    return [s for s in swhs if s is not None]


def plot_swhs(odbx, lyrname, **args):
    from mentor.kernel2d.utils import plot_Shape, plot_shapes_with_holes
    swhs = get_shapes(odbx, lyrname)
    print('Plotting %d shape(s)...' % len(swhs))
    plot_shapes_with_holes(swhs, **args)
# okay decompiling shapemanager.pyc
