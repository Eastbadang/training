# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\pcbimportstart.py
# Compiled at: 2019-01-31 18:27:01
# Size of source mod 2**32: 6801 bytes
import layoutdbPy
from common.layoutdb import DatabaseReadError
import site
formats = {'altpcad':('ALT_PCAD', 'Altium PCAD', 'pcb'), 
 'altp99se':('ALT_P99SE', 'Altium Protel 99SE', 'pcb'), 
 'cdsbrdmcm':('CAD_ALLEGRO', 'Cadence Allegro', 'brd'), 
 'cdsbrdmcm':('', 'Cadence APD', 'mcm'), 
 'cdsbrdmcm':('', 'Cadence SiP', 'sip'), 
 'cdsidl':('', 'Cadence IDL', 'in'), 
 'cdsspec':('CAD_SPEC', 'Cadence Specctra (.dsn)', 'dsn'), 
 'ic':('IC', 'IC import control file (.ctrl)', 'ctrl'), 
 'mgcbrd':('MEN_BRDST', 'Mentor Graphics Board Station', ''), 
 'mgchkp':('MEN_EXP', 'Mentor Graphics Expedition', 'hkp'), 
 'mgchyp':('MEN_HYP', 'Mentor Graphics HyperLynx', 'hyp'), 
 'mgcpads':('MEN_PADS', 'Mentor PADS', 'asc'), 
 'zcadif':('ZUK_CADIF', 'Zuken Visula (CADIF)', 'paf'), 
 'zcr5000':('ZUK_CR5K', 'Zuken CR-5000', 'pcf'), 
 'odbpp':('VAL_ODB', 'Valor ODB++', 'tgz'), 
 'ldb':('CST_LDB', 'CST Layout Database', 'ldb'), 
 'simlab':('SIMLAB_DAR', 'Simlab Layout Database', 'dar'), 
 'ipc2581':('IPC2581', 'ipc2581', 'cvg')}

def Run(pcbconverter):
    import sys, os

    def runner(run):
        import time
        inputfile, ext = pcbconverter.inputfile, pcbconverter.targettype
        pcbconverter.filenamebase = filenamebase = os.path.splitext(inputfile)[0]
        print()
        print('Importing %s... [%s]' % (inputfile, time.asctime(time.localtime())))
        pcbconverter.finished()
        run(inputfile, pcbconverter)
        from common.utils2d import warnings_here
        warnings_here = warnings_here.warnings
        if len(warnings_here):
            print('Further warnings:')
            for warning, n in warnings_here.items():
                print(('WARNING: ' + warning), end=' ')
                if n > 1:
                    print('(%d times)' % n)
                else:
                    print()

    def Run_ldb(filename, pcbconverter):
        pcbconverter.db = pcbconverter.load(filename)

    def do_import(pcbconverter):
        try:
            cadtype = pcbconverter.cadtype
            if cadtype == 'mgchkp':
                from mgchkp.exporthkp import Run
            else:
                if cadtype == 'mgcpads':
                    from mgcpads.importasc import Run
                else:
                    if cadtype == 'mgchyp':
                        from mgchyp.importhyp import Run
                    else:
                        if cadtype == 'zcr5000':
                            from zcr5000.pcfftf import Run
                        else:
                            if cadtype == 'odbpp':
                                from odbpp.odbppparser import Run
                            else:
                                if cadtype == 'simlab':
                                    if os.path.exists(os.path.join(os.path.dirname(pcbconverter.inputfile), 'use_legacy_import')):
                                        from simlab.importsimlab import Run
                                    else:
                                        from simlab.importsimlab import Run_dar2 as Run
                                else:
                                    if cadtype == 'cdsbrdmcm':
                                        from cdsbrdmcm.cdsbrdmcm import Run
                                    else:
                                        if cadtype == 'cdsidl':
                                            from idl.idlimport import Run
                                        else:
                                            if cadtype == 'ipc2581':
                                                from ipc2581.importipc2581 import Run
                                            else:
                                                if cadtype == 'gerber':
                                                    from gerber2.import_gerber import Run
                                                else:
                                                    if cadtype == 'ldb':
                                                        Run = Run_ldb
                                                    else:
                                                        if cadtype == 'ic':
                                                            from ic.icimport import Run
                                                        else:
                                                            Run = None
                if Run is not None:
                    runner(Run)
                else:
                    raise DatabaseReadError("unknown CAD type '%s'" % cadtype)
            return 0
        except DatabaseReadError as dbrderr:
            msg = str(dbrderr.value)
            if msg.startswith('ERROR: '):
                msg = msg[7:]
            print('ERROR:', msg)
            pcbconverter.fatal_msg = msg
            return 2

    sys.path = [
     './'] + sys.path
    if pcbconverter.cadtype == '' or pcbconverter.cadtype is None:
        basename, ext = os.path.splitext(pcbconverter.inputfile)
        ext = ext[1:].lower()
        if ext == 'hkp':
            pcbconverter.cadtype = 'mgchkp'
        else:
            if ext == 'asc':
                pcbconverter.cadtype = 'mgcpads'
            else:
                if ext == 'hyp':
                    pcbconverter.cadtype = 'mgchyp'
                else:
                    if ext in ('pcf', 'sdf'):
                        pcbconverter.cadtype = 'zcr5000'
                    else:
                        if ext in ('gz', 'tgz', 'zip'):
                            pcbconverter.cadtype = 'odbpp'
                        else:
                            if ext == 'dar':
                                pcbconverter.cadtype = 'simlab'
                            else:
                                if ext == 'dar2':
                                    pcbconverter.cadtype = 'simlab'
                                else:
                                    if ext in ('brd', 'mcm', 'sip', 'txt'):
                                        pcbconverter.cadtype = 'cdsbrdmcm'
                                    else:
                                        if ext == 'ldb':
                                            pcbconverter.cadtype = 'ldb'
                                        else:
                                            if ext == 'in':
                                                pcbconverter.cadtype = 'cdsidl'
                                            else:
                                                if ext == 'cvg':
                                                    pcbconverter.cadtype = 'ipc2581'
                                                else:
                                                    if ext == 'gerber':
                                                        pcbconverter.cadtype = 'gerber'
                                                    else:
                                                        raise DatabaseReadError('no CAD format given and file extension not understood')
    if pcbconverter.outputfile == '' or pcbconverter.outputfile is None:
        basename, ext = os.path.splitext(pcbconverter.inputfile)
        pcbconverter.outputfile = basename + '.' + pcbconverter.targettype
    profiling = False
    if profiling:
        import cProfile
        pr = cProfile.Profile()
        pr.enable()
    res = do_import(pcbconverter)
    if res == 2:
        return res
    else:
        if profiling:
            pr.disable()
            pr.print_stats()
        i = pcbconverter.inputfile
        from os.path import join, dirname
        for setupfile in (join(dirname(i), 'cst_import_template.py'), i + '.py', i + '.eda'):
            if os.path.exists(setupfile):
                try:
                    from simulation_setup.setup import setup_from_file
                    setup_from_file(setupfile, (pcbconverter.db), output_file=(pcbconverter.outputfile))
                except Exception as e:
                    print('ERROR: simulation setup failed.')
                    from traceback import print_exc
                    print_exc()

        return 0


if __name__ == '__main__':
    import sys
    p = layoutdbPy.PCBconverter()
    p.inputfile = sys.argv[1]
    p.targettype = 'ldb'
    p.cadtype = sys.argv[2]
    Run(p.inputfile, p)
    print('DONE!')
# okay decompiling pcbimportstart.pyc
