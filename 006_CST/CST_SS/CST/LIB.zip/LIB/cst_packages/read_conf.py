# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\read_conf.py
# Compiled at: 2018-05-16 21:27:28
# Size of source mod 2**32: 1747 bytes


def sections_from_conf(conf_str: str, interpolate=False):
    try:
        from configparser import SafeConfigParser, ExtendedInterpolation
        import os
        from io import StringIO
        if interpolate:
            config = SafeConfigParser(interpolation=(ExtendedInterpolation()))
            conf_str = os.path.expandvars(conf_str)
        else:
            config = SafeConfigParser(interpolation=None)
        config.read_string(conf_str)
        res = {}
        for s in config.sections():
            if s is 'DEFAULT':
                pass
            else:
                res[str(s)] = dict(config.items(s))

        return res
    except Exception as e:
        raise Exception(str(e))


def sections_from_conf_file(file):
    with open(file, 'r') as (f):
        contents = f.read()
    res = sections_from_conf(contents, False)
    return res


def sections_from_conf_file_as_strings(file):
    with open(file, 'r') as (f):
        lines = f.readlines()
    import re
    section_name = re.compile('\\s*\\[(.*)\\]\\s*')
    from collections import defaultdict
    sections_plain = defaultdict(list)
    cur_section = 'DEFAULT'
    for l in lines:
        m = re.match(section_name, l)
        if m is not None:
            cur_section = str(m.group(1))
        else:
            sections_plain[cur_section].append(l)

    for k, v in sections_plain.items():
        sections_plain[k] = ''.join(v)

    return sections_plain


def interpolate_conf_snippet(snippet: str):
    tmp_name = 'conf'
    snippet_with_header = '[' + tmp_name + ']\n' + snippet
    res = sections_from_conf(snippet_with_header, True)
    if tmp_name in res:
        return res[tmp_name]
# okay decompiling read_conf.pyc
