# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\simulation_setup\setup.py
# Compiled at: 2019-11-17 17:37:28
# Size of source mod 2**32: 3917 bytes
import sys, os, tempfile
from os.path import join, dirname, basename, abspath
from . import general

def get_val(d, key, default):
    if key in d:
        return d[key]
    else:
        return default


def setup(my_loc, db, doImport=True, output_file=None):
    Type = my_loc['Type'] if 'Type' in my_loc else None
    if 'ground_nets' in my_loc:
        general.set_ground_nets(db, my_loc['ground_nets'])
    if 'power_nets' in my_loc:
        general.set_power_nets(db, my_loc['power_nets'])
    if 'power_pins' in my_loc:
        general.set_power_pins(db, my_loc['power_pins'])
    if 'ground_pins' in my_loc:
        general.set_ground_pins(db, my_loc['ground_pins'])
    if 'RLC_definition_from_partname' in my_loc:
        general.RLC_definition_from_partname(db, my_loc['RLC_definition_from_partname'])
    x = my_loc.get('default_wirebond_profile')
    if x is not None:
        general.set_default_wirebond_profile(db, x)
    x = my_loc.get('dev_script')
    if x is not None:
        x(db)
    x = my_loc.get('user_script')
    if x is not None:
        import layoutdbPy
        x(layoutdbPy.pcb.PCB(db))
    if get_val(my_loc, 'add_missing_soldermasks', False):
        from common.layoutdb import add_soldermask
        add_soldermask(db, True)
        add_soldermask(db, False)
    if Type == 'PCBS':
        if 'component_models' in my_loc:
            from .pcbs_component_setup import PCBS_Component_Setup
            assert output_file is not None
            pm = PCBS_Component_Setup(db, output_file, **my_loc)
    else:
        if Type in ('MWS', 'simulation_setup'):
            from .simulation_setup import Simulation_Setup_Manager
            pm = Simulation_Setup_Manager(db, **my_loc)
            my_loc = pm.process(doImport)
        else:
            if Type == 'CadenceLink':
                from .cadence_link import CadenceLink_Manager
                pm = CadenceLink_Manager(db, **my_loc)
    if doImport:
        print('Successfully set up the simulation.')
    else:
        from .simulation_setup import write_simulation_setup_file
        write_simulation_setup_file(output_file, my_loc)
        print('Successfully exported the simulation setup.')
    return 1


def setup_from_file(setupfile, db, doImport=True, output_file=None):
    my_glob, my_loc = {}, {}
    if doImport:
        print('Setting up simulation for %s from %s...' % (db.origin, setupfile))
        if setupfile.endswith('.py'):
            import importlib, importlib.util
            spec = importlib.util.spec_from_file_location('settings', setupfile)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            my_loc = {}
            for v in dir(mod):
                if not v.startswith('_'):
                    my_loc[v] = getattr(mod, v)

        else:
            with open(setupfile, 'r') as (execFile):
                exec(execFile.read(), my_glob, my_loc)
    else:
        print('Exporting simulation setup for %s to %s...' % (db.origin, setupfile))
        output_file = setupfile
        my_loc['Type'] = 'simulation_setup'
    my_loc['base_dir'] = dirname(abspath(setupfile))
    print(my_loc)
    res = setup(my_loc, db, doImport, output_file=output_file)
    return res
# okay decompiling setup.pyc
