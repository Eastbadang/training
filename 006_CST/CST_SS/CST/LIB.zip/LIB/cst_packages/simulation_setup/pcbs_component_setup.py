# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\simulation_setup\pcbs_component_setup.py
# Compiled at: 2019-05-27 22:35:55
# Size of source mod 2**32: 2700 bytes
import layoutdbPy
from common.helpers import float_with_unit
import os

def value_convert(val):
    return float_with_unit(str(val))


def convert_to_abs_path(s, base_dir):
    if not os.path.isabs(s):
        assert base_dir is not None
        s = os.path.join(base_dir, s)
    s = os.path.normpath(s)
    return s


class PCBS_Component_Setup:

    def __init__(self, db, outputfile, base_dir=None, **args):
        print('PCBS_Component_Setup to', outputfile)
        if base_dir is not None:
            if not os.path.isabs(base_dir):
                raise Exception("Base directory '%s' must be an absolute path" % base_dir)
        outputfile, ext = os.path.splitext(outputfile)
        plb = self.plb = layoutdbPy.PartLib_c()
        plb.setFormat('PCBSPartLibrary')
        plb.setVersion('1.1.2')
        plb_lib = self.plb_lib = layoutdbPy.PartLib_c()
        plb_lib.setFormat('PCBSLibPartLibrary')
        plb.setVersion('1.1.1')
        for entry in args['component_models']:
            etype = entry['type'].upper()
            pin_mapping = entry['pin_mapping'] if 'pin_mapping' in entry else None
            if etype in ('R-HF', 'L-HF', 'C-HF'):
                R = value_convert(entry['R']) if 'R' in entry else 0
                L = value_convert(entry['L']) if 'L' in entry else 0
                C = value_convert(entry['C']) if 'C' in entry else 0
                plb_lib.add_RLC_HF(entry['name'], entry['type'][0].upper(), R, L, C)
            elif etype == 'SUBCIRCUIT':
                filename = convert_to_abs_path(entry['filename'], base_dir)
                assert pin_mapping is None
                type_specialization = entry['type_specialization'] if 'type_specialization' in entry else 'R'
                assert type_specialization in ('R', 'L', 'C')
                plb_lib.add_subcircuit_2_pin(entry['name'], filename, type_specialization)
            else:
                if etype == 'TOUCHSTONE':
                    filename = convert_to_abs_path(entry['filename'], base_dir)
                    assert pin_mapping is None
                    plb_lib.add_touchstone_2_pin(entry['name'], filename)
                else:
                    if etype == 'IBIS':
                        filename = convert_to_abs_path(entry['filename'], base_dir)
                        assert pin_mapping is None
                        plb_lib.add_IBIS_file(entry['name'], filename)
                    else:
                        raise Exception('invalid component type:', etype)

        plb_lib.save(outputfile + '.plb_lib')
        plb.save(outputfile + '.plb')
        db.part_model_db = layoutdbPy.PartModelDB()
# okay decompiling pcbs_component_setup.pyc
