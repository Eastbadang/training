# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\simulation_setup\pidc.py
# Compiled at: 2018-08-27 21:46:15
# Size of source mod 2**32: 12560 bytes
Instruction context:
-> 
 L. 203        20  FOR_ITER             32  'to 32'
                  22  STORE_FAST               'comp'
import layoutdbPy
from layoutdbPy import *
import sys, os

def Assert(x):
    assert x


def warning(x):
    print(x)


class PIDC_Manager_3D(object):

    def __init__(self, db, **args):
        self.db = db
        self.args = args
        self.set_net_types(args['powerNets'], args['groundNets'])
        Assert('excitation' in args)
        self.excitation = self.preprocess_excitation(args['excitation'])
        self.apply_tech(args['tech'])
        self.create_passives(args['passives'] if 'passives' in args else [])
        vrms = args['voltage_regulators'] if 'voltage_regulators' in args else []
        self.create_ports(self.excitation, vrms)

    def set_net_types(self, powernets, groundnets):
        import layoutdbPy
        db = self.db
        for p in powernets:
            net = db.net(p)
            net.type = layoutdbPy.NetType.Power

        for p in groundnets:
            net = db.net(p)
            net.type = layoutdbPy.NetType.GND

        self.simulated_nets = powernets + groundnets

    def preprocess_excitation(self, excitation):
        xs = []
        for x in excitation:
            if type(x) == dict:
                xs.append(x)
            else:
                Assert(type(x) == list)
                y = dict()
                powerNet, refdes, pins, groundNet, supplied_voltage, I_DC = x[:6]
                if len(x) > 6:
                    y['resistance'] = x[6]
                if pins == 'All':
                    y['power_pins'] = [
                     (
                      refdes, 'All', powerNet)]
                else:
                    if type(pins) in (tuple, list):
                        pins = list(pins)
                    else:
                        if type(pins) == str:
                            pins = [
                             pins]
                        else:
                            raise AltiumPluginException('Processing excitation of component %s failed' % refdes)
                        y['power_pins'] = [(refdes, pin) for pin in pins]
                y['ground_pins'] = [
                 (
                  refdes, 'All', groundNet)]
                if len(supplied_voltage) > 0:
                    y['type'] = 'source'
                    y['voltage'] = float(supplied_voltage)
                else:
                    y['type'] = 'load'
                if len(I_DC) > 0:
                    y['current'] = float(I_DC)
                xs.append(y)

        for x in xs:
            self.expand_pin_list(x['power_pins'], layoutdbPy.NetType.Power)
            self.expand_pin_list(x['ground_pins'], layoutdbPy.NetType.GND)

        return xs

    def expand_pin_list(self, list_of_pintuples, net_type):
        Assert(type(list_of_pintuples) == list)
        to_expand = []
        for tup in list_of_pintuples[:]:
            if len(tup) != 2:
                list_of_pintuples.remove(tup)
                to_expand.append(tup)
            else:
                Assert(len(tup) == 2)

        for tup in to_expand:
            refdes = tup[0]
            refdes = refdes.upper()
            comp = self.db.component(refdes)
            if comp is None:
                raise AltiumPluginException("component '%s' specified in the solver input does not exist in the design" % refdes)
            if len(tup) == 1:
                for i in range(comp.n_pins()):
                    pin = comp.pin(i)
                    if pin.net is not None and pin.net.type == net_type:
                        list_of_pintuples.append((refdes, pin.name))

            else:
                Assert(len(tup) > 2)
                Assert(tup[1] == 'All')
                nets = list(tup)[2:]
                for i in range(comp.n_pins()):
                    pin = comp.pin(i)
                    if pin.net is not None and pin.net.name in nets:
                        list_of_pintuples.append((refdes, pin.name))

    def apply_tech(self, tech):
        db = self.db
        if type(tech) != list:
            warning('tech data has been ignored')
            return
        sotmp = sys.stdout
        sys.stdout = sys.__stdout__
        for ldata in tech:
            name = ldata['name']
            l = db.layer(name)
            if l is None:
                continue
            errmsg = 'error in tech data for layer %s' % name
            if 'Conductivity' in ldata:
                cond = ldata['Conductivity']
                if l.material.type != layoutdbPy.MaterialType.Conductor:
                    warning(errmsg)
                else:
                    l.material.condtan = float(cond)
                if 'DielectricConstant' in ldata:
                    diel = ldata['DielectricConstant']
                    if l.material.type != layoutdbPy.MaterialType.Dielectric:
                        warning(errmsg)
                    else:
                        l.material.eps = float(diel)
                if 'Thickness' in ldata:
                    th = float(ldata['Thickness'])
                    from common.units import length_unit_convert
                    l.thickness = length_unit_convert('m', th, db.length_unit)

        sys.stdout = sotmp

    def create_passives--- This code section failed: ---

 L. 192         0  LOAD_CONST               0
                2  LOAD_CONST               None
                4  IMPORT_NAME              layoutdbPy
                6  STORE_FAST               'layoutdbPy'

 L. 194         8  LOAD_GLOBAL              print
               10  LOAD_STR                 'create_passives NOT IMPLMENTED!'
               12  CALL_FUNCTION_1       1  '1 positional argument'
               14  POP_TOP          

 L. 195        16  LOAD_CONST               None
               18  RETURN_VALUE     

 L. 203        20  FOR_ITER             32  'to 32'
               22  STORE_FAST               'comp'

 L. 204        24  LOAD_STR                 ''
               26  LOAD_FAST                'comp'
               28  STORE_ATTR               em_model
               30  JUMP_BACK            20  'to 20'
               32  POP_BLOCK        

 L. 206        34  LOAD_FAST                'layoutdbPy'
               36  LOAD_ATTR                PartModelDB
               38  CALL_FUNCTION_0       0  '0 positional arguments'
               40  DUP_TOP          
               42  LOAD_FAST                'db'
               44  STORE_ATTR               part_model_db
               46  STORE_FAST               'pdb'

 L. 208        48  BUILD_LIST_0          0 
               50  STORE_FAST               'items'

 L. 209        52  SETUP_LOOP          250  'to 250'
               54  LOAD_FAST                'passives'
               56  LOAD_ATTR                items
               58  CALL_FUNCTION_0       0  '0 positional arguments'
               60  GET_ITER         
               62  FOR_ITER            248  'to 248'
               64  UNPACK_SEQUENCE_2     2 
               66  STORE_FAST               'refdes'
               68  STORE_FAST               'value'

 L. 210        70  LOAD_FAST                'db'
               72  LOAD_ATTR                component
               74  LOAD_FAST                'refdes'
               76  CALL_FUNCTION_1       1  '1 positional argument'
               78  STORE_FAST               'comp'

 L. 211        80  LOAD_FAST                'comp'
               82  LOAD_CONST               None
               84  COMPARE_OP               is
               86  POP_JUMP_IF_FALSE    96  'to 96'

 L. 212        88  LOAD_GLOBAL              error
               90  LOAD_STR                 'Component %s not contained in layout, but used in list of passives.'
               92  CALL_FUNCTION_1       1  '1 positional argument'
               94  POP_TOP          
             96_0  COME_FROM            86  '86'

 L. 214        96  LOAD_FAST                'refdes'
               98  STORE_FAST               'partname'

 L. 215       100  LOAD_FAST                'partname'
              102  LOAD_FAST                'comp'
              104  STORE_ATTR               em_model

 L. 217       106  LOAD_FAST                'value'
              108  LOAD_ATTR                endswith
              110  LOAD_STR                 'ROHMS'
              112  CALL_FUNCTION_1       1  '1 positional argument'
              114  POP_JUMP_IF_FALSE   134  'to 134'

 L. 218       116  LOAD_STR                 'R'
              118  STORE_FAST               'typ'

 L. 219       120  LOAD_FAST                'value'
              122  LOAD_CONST               None
              124  LOAD_CONST               -5
              126  BUILD_SLICE_2         2 
              128  BINARY_SUBSCR    
              130  STORE_FAST               'value'
              132  JUMP_FORWARD        228  'to 228'
              134  ELSE                     '228'

 L. 220       134  LOAD_FAST                'value'
              136  LOAD_ATTR                endswith
              138  LOAD_STR                 'OHMS'
              140  CALL_FUNCTION_1       1  '1 positional argument'
              142  POP_JUMP_IF_FALSE   186  'to 186'

 L. 221       144  LOAD_STR                 'R'
              146  STORE_FAST               'typ'

 L. 222       148  LOAD_FAST                'value'
              150  LOAD_CONST               None
              152  LOAD_CONST               -4
              154  BUILD_SLICE_2         2 
              156  BINARY_SUBSCR    
              158  STORE_FAST               'value'

 L. 223       160  LOAD_FAST                'value'
              162  LOAD_STR                 '0'
              164  COMPARE_OP               ==
              166  POP_JUMP_IF_FALSE   228  'to 228'

 L. 225       168  LOAD_STR                 '0.001'
              170  STORE_FAST               'value'

 L. 226       172  LOAD_GLOBAL              warning
              174  LOAD_STR                 'replaced short by 1 milli-Ohms resistance for %s'
              176  LOAD_FAST                'refdes'
              178  BINARY_MODULO    
              180  CALL_FUNCTION_1       1  '1 positional argument'
              182  POP_TOP          
              184  JUMP_FORWARD        228  'to 228'
              186  ELSE                     '228'

 L. 227       186  LOAD_FAST                'value'
              188  LOAD_ATTR                endswith
              190  LOAD_STR                 'HENRY'
              192  CALL_FUNCTION_1       1  '1 positional argument'
              194  POP_JUMP_IF_FALSE   214  'to 214'

 L. 228       196  LOAD_STR                 'L'
              198  STORE_FAST               'typ'

 L. 229       200  LOAD_FAST                'value'
              202  LOAD_CONST               None
              204  LOAD_CONST               -5
              206  BUILD_SLICE_2         2 
              208  BINARY_SUBSCR    
              210  STORE_FAST               'value'
              212  JUMP_FORWARD        228  'to 228'
              214  ELSE                     '228'

 L. 231       214  LOAD_GLOBAL              warning
              216  LOAD_STR                 'ignoring passive %s'
              218  LOAD_FAST                'refdes'
              220  BINARY_MODULO    
              222  CALL_FUNCTION_1       1  '1 positional argument'
              224  POP_TOP          

 L. 232       226  CONTINUE             62  'to 62'
            228_0  COME_FROM           212  '212'
            228_1  COME_FROM           184  '184'
            228_2  COME_FROM           166  '166'
            228_3  COME_FROM           132  '132'

 L. 234       228  LOAD_FAST                'items'
              230  LOAD_ATTR                append
              232  LOAD_FAST                'refdes'
              234  LOAD_FAST                'partname'
              236  LOAD_FAST                'typ'
              238  LOAD_FAST                'value'
              240  BUILD_TUPLE_4         4 
              242  CALL_FUNCTION_1       1  '1 positional argument'
              244  POP_TOP          
              246  JUMP_BACK            62  'to 62'
              248  POP_BLOCK        
            250_0  COME_FROM_LOOP       52  '52'

 L. 236       250  LOAD_CONST               0
              252  LOAD_CONST               ('create_lumped_element_table',)
              254  IMPORT_NAME              common.layoutdb
              256  IMPORT_FROM              create_lumped_element_table
              258  STORE_FAST               'create_lumped_element_table'
              260  POP_TOP          

 L. 237       262  LOAD_FAST                'create_lumped_element_table'
              264  LOAD_FAST                'items'
              266  CALL_FUNCTION_1       1  '1 positional argument'
              268  UNPACK_SEQUENCE_3     3 
              270  STORE_FAST               'lumped_element_list'
              272  STORE_FAST               'refdes_to_lumped_element'
              274  STORE_FAST               'warnings'

 L. 239       276  SETUP_LOOP          302  'to 302'
              278  LOAD_FAST                'lumped_element_list'
              280  GET_ITER         
              282  FOR_ITER            300  'to 300'
              284  STORE_FAST               'le'

 L. 240       286  LOAD_FAST                'pdb'
              288  LOAD_ATTR                add_lumped_element
              290  LOAD_FAST                'le'
              292  CALL_FUNCTION_1       1  '1 positional argument'
              294  POP_TOP          
              296  JUMP_BACK           282  'to 282'
              300  POP_BLOCK        
            302_0  COME_FROM_LOOP      276  '276'

 L. 243       302  LOAD_FAST                'warnings'
              304  POP_JUMP_IF_FALSE   352  'to 352'

 L. 244       308  LOAD_STR                 'There were some warnings reading the list of passives:\n'
              310  STORE_FAST               's'

 L. 245       312  SETUP_LOOP          344  'to 344'
              314  LOAD_FAST                'warnings'
              316  GET_ITER         
              318  FOR_ITER            342  'to 342'
              320  STORE_FAST               'w'

 L. 246       322  LOAD_FAST                's'
              324  LOAD_STR                 '\t'
              326  LOAD_FAST                'w'
              328  BINARY_ADD       
              330  LOAD_STR                 '\n'
              332  BINARY_ADD       
              334  INPLACE_ADD      
              336  STORE_FAST               's'
              338  JUMP_BACK           318  'to 318'
              342  POP_BLOCK        
            344_0  COME_FROM_LOOP      312  '312'

 L. 247       344  LOAD_GLOBAL              warning
              346  LOAD_FAST                's'
              348  CALL_FUNCTION_1       1  '1 positional argument'
              350  POP_TOP          
            352_0  COME_FROM           304  '304'

 L. 249       352  LOAD_FAST                'lumped_element_list'
              354  LOAD_FAST                'self'
              356  STORE_ATTR               lumped_elements

Parse error at or near `FOR_ITER' instruction at offset 20

    def create_shorts(self, shorts):
        db = self.db
        short_comps = []
        for short in shorts:
            refdes = short['refdes']
            pinpairs = short['pinpairs']
            comp = db.component(refdes)
            if comp is None:
                error('Component %s not contained in layout, but used in list of shorts.')
            else:
                vcomp = VirtualComp(db)
                vpinpairs = []
                for p1, p2 in pinpairs:
                    pin1 = comp.pin(p1)
                    Assert(pin1 is not None)
                    vpin1 = vcomp.add_orig_pin((refdes, pin1.name))
                    pin2 = comp.pin(p2)
                    Assert(pin2 is not None)
                    vpin2 = vcomp.add_orig_pin((refdes, pin2.name))
                    vpinpairs.append((vpin1, vpin2))

                self.virtual_components[vcomp.name] = vcomp
                short_comps.append((vcomp.name, NPin(vcomp, vpinpairs)))

        self.shorted_comps = short_comps

    def create_ports(self, excitation, vrms):
        ss = self.db.simulation_settings
        print(excitation)
        print(vrms)
        for y in excitation:
            pins = {}
            for kind in ('power_pins', 'ground_pins'):
                for refdes, pin in y[kind]:
                    pins[(refdes, pin)] = 1

            print('Excited pins:', pins)
            if y['type'] == 'load':
                for refdes, pin in pins:
                    currentPort = CurrentPort('%s_%s' % (refdes, pin), TestPoint(refdes, pin))
                    currentPort.current = float(y['current'])
                    ss.current_ports.append(currentPort)

            else:
                if y['type'] == 'source':
                    for refdes, pin in pins:
                        potential = Potential('%s_%s' % (refdes, pin), TestPoint(refdes, pin))
                        potential.value = float(y['voltage'])
                        ss.potentials.append(potential)


def process_pidc_settings(db, settingsfile):
    print(db)
    my_glob, my_loc = {}, {}
    exec(open(settingsfile).read(), my_glob, my_loc)
    print(my_loc)
    pm = PIDC_Manager_3D(db, **my_loc)


if __name__ == '__main__':
    pass
