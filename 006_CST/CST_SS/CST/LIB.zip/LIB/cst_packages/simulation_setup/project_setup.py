# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\simulation_setup\project_setup.py
# Compiled at: 2019-04-05 16:10:50
# Size of source mod 2**32: 12556 bytes
import sys, os, tempfile
from os.path import *

def write_hist_file(workingfolder, modfilename, history):
    import os
    histfile = join(workingfolder, modfilename)
    fhist = open(histfile, 'w')
    for h in history:
        if type(h) == tuple:
            title, content = h
        else:
            title, content = 'do', h
        fhist.write("'@ %s\n" % title)
        fhist.write(content + '\n')

    fhist.close()
    return histfile


class CST_Project_Manager(object):

    def __init__(self, pcbinputfile, where=None):
        try:
            import cstpy
            self.cst_DE = cstpy.CST.InstallationPaths.DesignEnvironmentExe()
        except:
            ir = irold = __file__
            while basename(ir) != 'python':
                ir = dirname(ir)
                assert ir != irold
                irold = ir

            ir = dirname(dirname(ir))
            import platform
            is_windows = 'windows' in platform.system().lower()
            DE_name = 'CST DESIGN ENVIRONMENT.exe' if is_windows else 'cst_design_environment'
            self.cst_DE = join(ir, DE_name)

        self.history = hist = []
        self.pcbinputfile = pcbinputfile
        settingsfile = pcbinputfile + '.py'
        assert os.path.exists(settingsfile)
        my_glob, my_loc = {}, {}
        exec(open(settingsfile).read(), my_glob, my_loc)
        print(my_loc)
        self.settings = my_loc
        self.project_type = 'MWS'
        type = my_loc['Type']
        if type == 'PIDC':
            self.project_type = 'EMS'
        else:
            if type == 'CadenceLink':
                self.project_type = 'CadenceLink'
            else:
                print('Setting up %s simulation from %s...' % (self.project_type, settingsfile))
                lengthUnit = 'mm'
                length2SI = 0.001
                freqUnit = 'GHz'
                freq2SI = 1000000000.0
                hist.append('\'set the units\nWith Units\n    .Geometry "%s"\n    .Frequency "%s"\n    .Voltage "V"\n    .Resistance "Ohm"\n    .Inductance "NanoH"\n    .TemperatureUnit  "Kelvin"\n    .Time "ns"\n    .Current "A"\n    .Conductance "Siemens"\n    .Capacitance "PikoF"\nEnd With\n' % (lengthUnit, freqUnit))
                hist.append('\nWith Background \n     .ResetBackground \n     .XminSpace "1" \n     .XmaxSpace "1" \n     .YminSpace "1" \n     .YmaxSpace "1" \n     .ZminSpace "1" \n     .ZmaxSpace "1" \n     .ApplyInAllDirections "True" \nEnd With \n\nWith Material \n     .Reset \n     .Rho "0.0"\n     .ThermalType "Normal"\n     .ThermalConductivity "0"\n     .SpecificHeat "0"\n     .DynamicViscosity "0"\n     .Emissivity "0"\n     .MetabolicRate "0.0"\n     .VoxelConvection "0.0"\n     .BloodFlow "0"\n     .MechanicsType "Unused"\n     .FrqType "all"\n     .Type "Normal"\n     .MaterialUnit "Frequency", "Hz"\n     .MaterialUnit "Geometry", "m"\n     .MaterialUnit "Time", "s"\n     .MaterialUnit "Temperature", "Kelvin"\n     .Epsilon "1"\n     .Mu "1"\n     .ReferenceCoordSystem "Global"\n     .CoordSystemType "Cartesian"\n     .NLAnisotropy "False"\n     .NLAStackingFactor "1"\n     .NLADirectionX "1"\n     .NLADirectionY "0"\n     .NLADirectionZ "0"\n     .Colour "0.6", "0.6", "0.6" \n     .Wireframe "False" \n     .Reflection "False" \n     .Allowoutline "True" \n     .Transparentoutline "False" \n     .Transparency "0" \n     .ChangeBackgroundMaterial\nEnd With \n')
                if 'frequencyRange' in my_loc:
                    fmin, fmax = my_loc['frequencyRange']
                    hist.append('Solver.FrequencyRange "%g", "%g"' % (fmin / freq2SI, fmax / freq2SI))
                if 'preferredSolver' in my_loc:
                    ps = my_loc['preferredSolver']
                    if ps == 'fd-tet':
                        hist.append('ChangeSolverType "HF Frequency Domain"')
                if 'meshRefinement' in my_loc:
                    mr = my_loc['meshRefinement']
                    hist.append('FDSolver.MeshAdaptionTet ' + ('True' if mr else 'False'))
                self.extractSParameters = my_loc['extractSParameters'] if 'extractSParameters' in my_loc else False
                if where is None:
                    where = dirname(pcbinputfile)
            assert os.path.exists(where)
        self.workingfolder = abspath(join(where, 'tmp'))
        self.workingfolder = tempfile.mkdtemp(prefix=(self.workingfolder))
        self.result_folder = join(self.workingfolder, 'Results')
        os.makedirs(self.result_folder)
        self.project_folder = join(self.workingfolder, 'Model')
        self.histfile = None
        self.add_EDA_import_command(self.pcbinputfile)

    def setup_project(self):
        modfileext = {'EMS':'ems', 
         'MWS':'mod'}
        modfile = 'Model.%s' % modfileext[self.project_type]
        self.histfile = write_hist_file(self.workingfolder, modfile, self.history)

    def add_EDA_import_command(self, pcbfile):
        pcbext = 'odbpp'
        if pcbfile.endswith('.brd'):
            pcbext = 'cdsbrdmcm'
        self.history.append('\'@ import EDA file: %s\n            With LayoutDB\n                 .SourceFileName "%s"\n                 .LdbFileName "%s"\n                 .PcbType "%s"\n                 .ForceImport "True"\n                 .CreateDB\n                 .LoadDB\n            End With' % (
         pcbfile, pcbfile, '*design.ldb', pcbext))

    def start_project(self, run=False):
        import subprocess
        opt = '-s'
        if self.project_type in ('MWS', 'CadenceLink'):
            opt = '-m'
            if run:
                opt += ' -f'
        if self.project_type == 'EMS':
            opt = '-s'
            if run:
                opt += ' -sj'
        print(str([self.cst_DE, opt, self.histfile]))
        p = subprocess.Popen(self.cst_DE + ' ' + opt + ' ' + self.histfile)
        p.wait()
        self.do_post_processing()
        print('DONE')

    def do_post_processing(self):
        pass


class PostProcessor:

    def __init__(self, cstfile, results_go_to=None):
        self.cstfile = cstfile
        assert cstfile.endswith('.cst')
        self.project_folder = cstfile[:-4]
        if results_go_to is None:
            results_go_to = join(dirname(cstfile), 'Results')
        os.makedirs(results_go_to, exist_ok=True)
        self.results_go_to = results_go_to

    def do_it(self, extractAll=True, extractSParameters=False):
        from resultspy_ext import DirectoryInterface, StorageInterface
        res = {}
        modelres = join(self.project_folder, 'Result', 'Model.res')
        di = DirectoryInterface(modelres)
        model_result = join(self.project_folder, 'Result')
        si = StorageInterface(model_result)
        with open(join(self.results_go_to, 'dd.txt'), 'w') as (f):
            for i in di.all_nonparametric():
                f.write('%s\n' % i.ItemName)

        if extractAll:
            res['all'] = all = {}
            for item in di.all_nonparametric():
                s = item.ItemName
                try:
                    sig = si.GetSignal(item.filename(0), 0)
                    all[s] = sig
                except:
                    print('Unable to extract result item %s/%s' % (item.ItemName, item.treepath))

            for c, n in si.GetChoices():
                sig = si.GetSignal(c, n)
                all[(c, n)] = sig

        if extractSParameters:
            import re
            x = re.compile('S(\\d+),(\\d+)$')
            res['SParameters'] = sp = {}
            for item in di.all_nonparametric():
                s = item.ItemName
                m = x.match(s)
                if m is not None:
                    i, j = m.groups()
                    i, j = int(i), int(j)
                    sig = si.GetSignal(item.filename(0), 0)
                    sp[s] = sig['data']
                    xxx

        self.resfile = join(self.results_go_to, 'results.py')
        with open(self.resfile, 'w') as (f):
            f.write(res.__repr__())


def get_CST_DE():
    key = 'CST_INSTALLATION_DIRECTORY'
    if key in os.environ:
        instdir = os.environ[key]
    else:
        instdir = dirname(dirname(dirname(dirname(__file__))))
    if sys.platform.lower().startswith('win'):
        cstde = 'CST DESIGN ENVIRONMENT.exe'
    else:
        cstde = 'cst_design_environment'
    return normpath(join(instdir, cstde))


def create_project(destdir, project_type='MWS', history=None, run=None, do_1D_ascii_export=False):
    modfileext = {'EMS':'ems', 
     'MWS':'mod'}
    modfile = 'mws.%s' % modfileext[project_type]
    histfile = write_hist_file(destdir, modfile, history)
    modfile = join(destdir, modfile)
    if do_1D_ascii_export:
        import shutil
        for fname in ('mws^ASCII Export.r0d', 'mws.rpp'):
            fname = join(dirname(abspath(__file__)), fname)
            shutil.copy(fname, destdir)

    import subprocess
    opt = '-s'
    if project_type in ('MWS', 'CadenceLink'):
        opt = '-m'
        if run in ('f', 'F'):
            opt += ' -f'
        elif run in ('t', 'T'):
            opt += ' -r'
    if project_type == 'EMS':
        opt = '-s'
        if run:
            opt += ' -sj'
    cst_DE = get_CST_DE()
    p = subprocess.Popen(cst_DE + ' ' + opt + ' ' + modfile)
    p.wait()
    print('DONE')
    return modfile


if __name__ == '__main__':
    import sys
    pcbinputfile = sys.argv[1]
    if pcbinputfile.endswith('.cst'):
        pp = PostProcessor(pcbinputfile)
        pp.do_it()
    else:
        pm = CST_Project_Manager(pcbinputfile)
        pm.setup_project()
        pm.start_project(run=True)
        pp = PostProcessor(pm.project_folder + '.cst')
        pp.do_it()
    print('DONE')
# okay decompiling project_setup.pyc
