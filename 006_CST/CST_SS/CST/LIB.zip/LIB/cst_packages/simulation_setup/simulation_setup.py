# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\simulation_setup\simulation_setup.py
# Compiled at: 2019-10-02 01:26:04
# Size of source mod 2**32: 14199 bytes
import sys, os
from utils2dPy import *
import utils2dPy
from layoutdbPy import *
import layoutdbPy

def value_convert(val):
    from common.helpers import float_with_unit
    return float_with_unit(str(val))


def write_simulation_setup_file(fileName, my_loc):
    f = open(fileName, 'w')
    f.write("Type = 'simulation_setup'")
    for key in my_loc:
        if key != 'Type':
            f.write('\n' + key + ' = ' + repr(my_loc[key]))

    f.close()


class Simulation_Setup_Manager(object):
    __doc__ = '\n    Convert user commands in layout.ext.py file to SimulationSettings\n    '

    def __init__(self, db, **args):
        self.db = db
        self.ss = self.db.simulation_settings
        self.args = args

    def process(self, doImport):
        db = self.db
        ss = self.ss
        args = self.args
        if doImport:
            if 'selectionPolygons' in args or 'layerPolygons' in args:
                if 'selectionPolygons' in args:
                    if 'layerPolygons' in args:
                        self.import_selection_polygons()
                        print('Applied the selectionPolygons and layerPolygons setup.')
                    else:
                        print('WARNING! Both selectionPolygons and layerPolygons should be defined. Ignoring selectionPolygons.')
                elif 'selectionArea' in args:
                    if 'selectionPolygons' in args or 'layerPolygons' in args:
                        print('WARNING! selectionArea will overwrite selectionPolygons and layerPolygons.')
                    self.import_selection_area()
                    print('Applied the selectionArea setup.')
                self.import_selected_nets()
                if 'selectionAreaFromNets' in args and args['selectionAreaFromNets'] == True:
                    ss.nets_for_area_selection = ss.selected_nets
                    ss.is_area_selection_active = True
                    ss.inclusion_distance = 0.001 / layoutdbPy.LengthUnitToMeter(db.length_unit)
                    ss.create_rectangular_selection = True
                    ss.update(self.db)
                    print(ss.get_layer_polygons())
                    p = ss.get_layer_polygons()
                    assert '__P4NETSEL__' in p
                    for l in db.layers():
                        p[l.name] = p['__P4NETSEL__']

                    ss.set_layer_polygons(p)
                if 'component_models' in args:
                    self.add_component_models(args['component_models'])
            else:
                if 'component_model_assignment' in args:
                    self.assign_component_models(args['component_model_assignment'])
                if 'restrict_to_excited_nets' in args:
                    self.ss.is_net_selection_active = args['restrict_to_excited_nets']
            self.import_ports()
            self.import_template()
        else:
            self.export_selection_area()
            self.export_selection_polygons()
            self.export_selected_nets()
            self.export_ports()
            self.export_template()
        return self.args

    def assign_component_models(self, acms):
        db = self.db
        for refdes, model in acms:
            comp = db.component(refdes)
            assert comp is not None
            comp.em_model = model

    def add_component_models(self, cms):
        db = self.db
        for entry in cms:
            etype = entry['type'].upper()
            if etype in ('R-HF', 'L-HF', 'C-HF'):
                R = value_convert(entry['R']) if 'R' in entry else 0
                L = value_convert(entry['L']) if 'L' in entry else 0
                C = value_convert(entry['C']) if 'C' in entry else 0
                le = layoutdbPy.LumpedElementModel()
                le.name = entry['name']
                if R == 0:
                    if L == 0:
                        if C == 0:
                            le.type = layoutdbPy.LEModelType.short
                else:
                    le.R = R
                    le.L = L
                    le.C = C
                    le.type = {'R-HF':layoutdbPy.LEModelType.R_HF,  'L-HF':layoutdbPy.LEModelType.L_HF, 
                     'C-HF':layoutdbPy.LEModelType.C_HF}[etype]
                db.part_model_db.add_lumped_element(le)

    def import_selection_area(self):
        selectionArea = self.args['selectionArea']
        if isinstance(selectionArea, str):
            idx = selectionArea.find('#')
            if idx != -1:
                selectionArea = selectionArea[:idx]
                selectionArea = list(eval(selectionArea))
        self.ss.selection_polygons = mapSizetCShape()
        self.ss.set_layer_polygons({})
        for selection in selectionArea:
            shape = CShape(selection)
            self.ss.add_selection_area_to_all_layers(self.db, shape)

        self.ss.is_area_selection_active = True

    def export_selection_area(self):
        """
        Export selectionPolygons ignoring the layer indices data in layerPolygons so that exported polygons will be applied to all layers
        """
        selectionPolygons = self.ss.selection_polygons
        selectionArea = []
        for selectionPolygon in selectionPolygons:
            selectionArea.append(self.convert_shape_to_segments(selectionPolygon.data()))

        self.args['#selectionArea'] = str(selectionArea) + ' # Remove the first symbol # in this line to use selectionArea instead of selectionPolygons and layerPolygons.' + ' Unlike layerPolygons, selectionArea does not include layer names and applies to all layers in the stackup.'

    def convert_shape_to_segments(self, shape):
        retval = []
        segments = shape.to_Shape().segments
        for s in segments:
            retval.append([(s.a.x, s.a.y), (s.b.x, s.b.y)])

        return retval

    def import_selection_polygons(self):
        dictSelectionPolygons = self.args['selectionPolygons']
        layerPolygons = self.args['layerPolygons']
        selectionPolygons = mapSizetCShape()
        for key in dictSelectionPolygons:
            selectionPolygon = dictSelectionPolygons[key]
            shape = CShape(selectionPolygon)
            selectionPolygons[key] = shape

        self.ss.selection_polygons = selectionPolygons
        self.ss.set_layer_polygons(layerPolygons)
        self.ss.is_area_selection_active = True

    def export_selection_polygons(self):
        """
        References:
        typedef std::map<size_t,utils2d::CShape > SelectionPolygonMap;
        typedef std::map<std::string,std::set<size_t> > LayerPolygonMap;
        SelectionPolygonMap selection_polygons;
        LayerPolygonMap layer_polygons;
        void GLWidget::verify_and_set_selection_polygon()
        """
        selectionPolygons = self.ss.selection_polygons
        layerPolygons = self.ss.get_layer_polygons()
        dictSelectionPolygons = {}
        for selectionPolygon in selectionPolygons:
            dictSelectionPolygons[selectionPolygon.key()] = self.convert_shape_to_segments(selectionPolygon.data())

        self.args['selectionPolygons'] = dictSelectionPolygons
        self.args['layerPolygons'] = layerPolygons

    def import_selected_nets(self):
        if 'selectedNets' in self.args:
            selnets = layoutdbPy.vectorString()
            for netname in self.args['selectedNets']:
                selnets.append(netname)

            self.ss.selected_nets = selnets
            self.ss.is_net_selection_active = True
        print('Applied the selectedNets setup.')

    def export_selected_nets(self):
        print('# TODO: selectedNets export')

    def import_ports(self):
        self.simulatedNets = None
        self.referenceNets = None
        self.selectedPins = None
        if 'simulatedNets' in self.args:
            self.simulatedNets = self.args['simulatedNets']
            print('Applied the simulatedNets setup.')
        if 'referenceNets' in self.args:
            self.referenceNets = self.args['referenceNets']
            print('Applied the referenceNets setup.')
        if 'selectedPins' in self.args:
            self.selectedPins = self.args['selectedPins']
            print('Applied the selectedPins setup.')
        self.set_terminals()

    def export_ports(self):
        print('# TODO: simulatedNets, referenceNets, selectedPins export')

    def add_port(self, tp, netlist):
        portname = tp.decorated_name_dash()
        port = DiscretePort(portname, tp, netlist)
        self.db.simulation_settings.add_discrete_port(port)

    def set_terminals(self):
        if not self.simulatedNets:
            return
        netlist = layoutdbPy.vectorString()
        for netname in self.referenceNets:
            netlist.append(netname)

        if self.selectedPins is None:
            self.selectedPins = []
            for comp in self.db.components():
                for ip in range(comp.n_pins()):
                    pin = comp.pin(ip)
                    for net in self.simulatedNets:
                        if pin.net is not None and pin.net.name.lower() == net.lower():
                            self.selectedPins.append((comp.name, pin.name))

        for pin in self.selectedPins:
            comp = self.db.component(pin[0])
            if comp is None:
                print('ERROR: port creation: pin %s of component %s not found' % (pin[1], pin[0]))
            else:
                if comp.has_pin(pin[1]):
                    tp = TestPoint(comp.name, pin[1])
                    self.add_port(tp, netlist)

    def import_template(self):
        if 'template' not in self.args or self.args['template'] == False:
            return
        else:
            localDir = os.path.dirname(os.path.abspath(__file__))
            templateName = str(self.args['template'])
            if '/' in templateName:
                templatePath = templateName
            else:
                templatePath = os.path.join(localDir, 'templates', templateName)
            if os.path.exists(templatePath):
                templateData = open(templatePath).read()
                self.ss.add_command(templateData)
                print("Applied the template '" + templateName + "' setup.")
            else:
                print("WARNING! Template file '" + templatePath + "' not found.")

    def export_template(self):
        pass
# okay decompiling simulation_setup.pyc
