# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\simulation_setup\general.py
# Compiled at: 2019-05-22 17:24:31
# Size of source mod 2**32: 2786 bytes
import layoutdbPy

def set_net_type(db, nets, nettype):
    for name in nets:
        net = db.net(name)
        if net is not None:
            net.type = nettype


def set_ground_nets(db, nets):
    set_net_type(db, nets, layoutdbPy.NetType.GND)


def set_power_nets(db, nets):
    set_net_type(db, nets, layoutdbPy.NetType.Power)


def get_nets_of_pins(db, pins):
    nets = set()
    for pin in pins:
        if type(pin) == str:
            if '-' in pin:
                a = pin.split('-')
                assert len(a) == 2
                refdes, pinname = a
            else:
                refdes = pin
                pinname = None
        else:
            if not type(pin) == tuple:
                raise AssertionError
            elif not len(pin) == 2:
                raise AssertionError
            refdes, pinname = pin
        comp = db.component(refdes)
        for i in range(comp.n_pins()):
            p = comp.pin(i)
            if pinname is None or p.name == pinname:
                net = p.net
                if net is not None:
                    nets.add(net.name)

    return nets


def set_power_pins(db, pins):
    nets = get_nets_of_pins(db, pins)
    set_power_nets(db, nets)


def set_ground_pins(db, pins):
    nets = get_nets_of_pins(db, pins)
    set_ground_nets(db, nets)


def RLC_definition_from_partname(db, func):
    typemap = {'R':layoutdbPy.LEModelType.R_HF, 
     'L':layoutdbPy.LEModelType.L_HF, 
     'C':layoutdbPy.LEModelType.C_HF}
    pdb = db.part_model_db
    done = set()
    for comp in db.components():
        s = comp.em_model
        if s in done:
            pass
        else:
            done.add(s)
            refdes, partname = comp.name, comp.em_model
            res = func(refdes, partname)
            action = res[0] if type(res) == tuple else res
            if action == 'remove':
                pdb.remove_model(comp.em_model)
                print('("%s", %s),' % (partname, None))
            else:
                if action == 'add':
                    action, typ, value = res
                    print('("%s", %s),' % (partname, value))
                    le = layoutdbPy.LumpedElementModel()
                    le.name = s
                    if value == 0:
                        typ = 'R'
                        value = 0.001
                    le.type = typemap[typ]
                    assert typ in 'RLC'
                    setattr(le, typ, value)
                    pdb.add_lumped_element(le)
                    continue


def set_default_wirebond_profile(db, x):
    wbs = [db.wirebond(i) for i in range(db.n_wirebonds())]
    for wb in wbs:
        wb.profile_name = x
# okay decompiling general.pyc
