# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Projects/Tools/EDA/imports\zcr5000\pcfftf.py
# Compiled at: 2020-03-06 18:37:44
# Size of source mod 2**32: 153129 bytes
Instruction context:
-> 
 L.1566         4  FOR_ITER             82  'to 82'
                   6  STORE_FAST               'surf'
"""
Zuken CR-5000 import.
"""
import math, re, string, types, os
from common.helpers import make_list
from common import utils2d
from common.utils2d import R2, ArrayCurveSegment, CurveSegment, Shape, ShapeWithHoles, ShapeProcessor, CShapeWithHoles, Make_CClockwise, Make_Clockwise, vectorShapeWithHoles, BoundingBox, Planeprocessor, Bbox2Rectangle
from math import pi, sqrt
import utils2dPy, layoutdbPy
from common.layoutdb import DatabaseReadError, check_pin_names

def make_list2(data, attr):
    if hasattr(data, attr):
        return make_list(getattr(data, attr))
    else:
        return []


class FileWithPush:

    def __init__(this, file, progress_start=0, progressbar=None):
        this.progressbar, this.progress_start = progressbar, progress_start
        this.file = file
        this.pushed = []
        this.eof = False
        this.line_no = 0
        this.my_approx_pos = 0

    def readline(this):
        if len(this.pushed) > 0:
            return this.pushed.pop()
        else:
            l = this.file.readline()
            this.my_approx_pos += len(l)
            if this.line_no % 1000 == 0:
                if this.progressbar is not None:
                    this.progressbar.set(this.progress_start + this.my_approx_pos)
            this.line_no += 1
            if len(l) == 0:
                this.eof = True
            return l.strip()

    def push(this, line):
        if len(this.pushed) > 0:
            raise Exception('already pushed:%s' % this.pushed)
        this.pushed.append(line)

    def nextline(this):
        l = this.readline()
        while (len(l) == 0 or l[0:1] == ';') and not this.eof:
            l = this.readline()

        return l


def chop(s, i=0, res=[], progressbar=None):
    n = len(s)
    nextprog = 0
    while i < n:
        if i >= nextprog:
            if progressbar is not None:
                nextprog = i + 1000
                progressbar.set(i)
        c = s[i]
        if c.isspace():
            i += 1
            continue
        if c == '"':
            k = s.find('"', i + 1)
            assert k >= 0
            res.append(s[i + 1:k])
            i = k + 1
            continue
        if c == '(':
            tmp = []
            i = chop(s, (i + 1), tmp, progressbar=progressbar)
            res.append(tmp)
        else:
            if c == ')':
                return i + 1
            if c == ';':
                k = s.find('\n', i)
                if k >= 0:
                    i = k + 1
                else:
                    i = n
            else:
                k = i + 1
                while k < n and s[k] != ')' and not s[k].isspace():
                    k += 1

                res.append(s[i:k])
                i = k

    return n


class DataInstance:
    __doc__ = '\n    ... is an expression contained in ().\n    '

    def __init__(this, ls):
        this.Type = ls[0]
        isvertex = ls[0] == 'vertex'
        if isvertex:
            this.vertices = []
        else:
            for l in ls[1:]:
                if type(l) == list:
                    entry = DataInstance(l)
                    name = entry.Type
                    if isvertex:
                        this.vertices.append(entry)
                    else:
                        if len(entry.__dict__) == 2:
                            if 'data' in entry.__dict__:
                                if type(entry.data) == str:
                                    entry = entry.data
                        if hasattr(this, name):
                            tmp = getattr(this, name)
                            if type(tmp) == list:
                                tmp.append(entry)
                            else:
                                setattr(this, name, [tmp, entry])
                        else:
                            setattr(this, name, entry)
                else:
                    if hasattr(this, 'data'):
                        if type(this.data) == list:
                            this.data.append(l)
                        else:
                            this.data = [
                             this.data, l]
                    else:
                        this.data = l

            if this.Type == 'pt':
                assert len(this.data) == 2
                this.XY = R2(float(this.data[0]), float(this.data[1]))
                if hasattr(this, 'width'):
                    this.width = float(this.width)
                del this.data
            else:
                if this.Type == 'center':
                    assert len(this.data) == 2
                    this.XY = R2(float(this.data[0]), float(this.data[1]))
                    del this.data
                else:
                    if this.Type == 'arc':
                        assert type(this.data) == str
                        this.CCW = this.data == 'CCW'
                        this.r = float(this.r)
                    else:
                        if this.Type == 'property':
                            if hasattr(this, 'data'):
                                if type(this.data) == list and len(this.data) == 2:
                                    this.Type = this.data[0].strip('"')
                                    this.data = this.data[1].strip('"')
        if this.Type == 'in':
            this.Type = 'In'

    def __repr__(this, level=0):
        res = ''
        sp = '  ' * level
        for k, v in this.__dict__.items():
            if isinstance(v, DataInstance):
                res += sp + k + ':\n' + v.__repr__(level + 1)
            else:
                if type(v) == list:
                    count = 0
                    for iv in v:
                        if isinstance(iv, DataInstance):
                            tmp = iv.__repr__(level + 1)
                            res += sp + k + '[%d]:\n' % count + tmp
                        else:
                            res += sp + k + '[%d]:%s\n' % (count, repr(iv))
                        count += 1

                else:
                    res += sp + k + ':%s\n' % str(v)

        return res


def read_z(filename, node=None, progressbar=None):
    cs = []
    from common.helpers import open_text_file
    s = open_text_file(filename, default_encoding='iso-8859-15').read()
    s = s.replace('\\"', "'")
    if progressbar is not None:
        progressbar.reset('Reading %s file' % os.path.splitext(filename)[1], int(len(s) / 0.9))
    chop(s, res=cs, progressbar=progressbar)
    if type(cs) != list:
        print('ERROR: wrong node type:\n%s' % str(cs))
        return
    else:
        if node is None:
            if len(cs) == 1:
                cs = cs[0]
        else:
            if len(cs) > 1:
                for i in cs:
                    if i[0].lower() == node.lower():
                        cs = i
                        break
                else:
                    print("ERROR: node '%s' not found." % node.lower())
                    return

            else:
                cs = cs[0]
        di = DataInstance(cs)
        if progressbar is not None:
            progressbar.finished()
        return di


def get_arc(arc):
    assert g.Type == 'arc'


def create_tarc(a, b, c, r, rmab, rmbc):
    if a == b or b == c:
        return (
         [
          (
           b, 0)], rmab, rmbc)
    else:
        t1, t2 = b - a, c - b
        l1, l2 = t1.getNorm(), t2.getNorm()
        t1 /= l1
        t2 /= l2
        cosphi, sinphi = t1.dot(t2), t1.cross(t2)
        if cosphi > -0.999 and abs(sinphi) > 0.05:
            x = r * abs(sinphi) / (1 + cosphi)
            if x > rmab * 1.01 or x > rmbc * 1.01:
                print('WARNING: tarc at vertex', b, ' skipped.')
                print(a, b, c, r)
                print(l1, l2)
                print(rmab, rmbc)
                print(x)
                return (
                 [
                  (
                   b, 0)], rmab, rmbc)
            else:
                if x > rmab:
                    x = rmab
                else:
                    if x > rmbc:
                        x = rmbc
                    b1 = b - t1 * x
                    a2 = b + t2 * x
                    t1.turn_left()
                    if sinphi < 0:
                        r = -r
                C = b1 + t1 * r
                res = [
                 (
                  b1, 0), (C, -r), (a2, 0)]
                rmab -= x
                rmbc -= x
                return (
                 res, rmab, rmbc)
        return (
         [
          (
           b, 0)], rmab, rmbc)


def remove_identical_points_w(xyrs):
    rem = []
    for i in range(0, len(xyrs) - 1):
        pa, ra, w = xyrs[i]
        pb, rb, w = xyrs[(i + 1)]
        if not ra != 0:
            if rb != 0:
                pass
            elif pa == pb:
                rem.append(i)

    rem.reverse()
    for i in rem:
        del xyrs[i]


def XyrsW2Segments(xyrs):
    remove_identical_points_w(xyrs)
    assert xyrs[0][1] == 0
    segs = ArrayCurveSegment(0)
    widths = []
    for i in range(len(xyrs) - 1):
        x0, R0, w0 = xyrs[i]
        if R0 != 0:
            continue
        x1, R1, w1 = xyrs[(i + 1)]
        if R1 == 0:
            if x0 != x1:
                segs.push_back(CurveSegment(x0, x1))
                widths.append(w0)
        else:
            x2, R2, w2 = xyrs[(i + 2)]
            a, b, c = x0, x2, x1
            assert R2 == 0
            R = -R1
            if a != b:
                seg = CurveSegment(a, b, c, R)
                if abs(seg.phi) > 3.1:
                    m = seg.point(0.5)
                    c = seg.c
                    seg = CurveSegment(a, m, c, R)
                    segs.push_back(seg)
                    widths.append(w0)
                    assert abs(seg.phi) < 3.15
                    seg = CurveSegment(m, b, c, R)
                    segs.push_back(seg)
                    widths.append(w0)
                    assert abs(seg.phi) < 3.15
                else:
                    segs.push_back(seg)
                    widths.append(w0)
            else:
                m = c - a + c
                seg = CurveSegment(a, m, c, R)
                segs.push_back(seg)
                widths.append(w0)
                seg = CurveSegment(m, a, c, R)
                segs.push_back(seg)
                widths.append(w0)

    return (
     segs, widths)


def vertices2segments(vertices, closed=False):
    lastpt = None
    segments = ArrayCurveSegment(0)
    start_pt_has_tarc, end_pt_has_tarc = (None, None)
    lastpt_has_tarc = None
    xyrts = []
    width = 0
    for v in vertices:
        if v.Type == 'pt':
            pt = v
            if hasattr(pt, 'tarc'):
                if pt.tarc.data.lower() == 'on':
                    r = float(pt.tarc.r)
            else:
                r = 0
            if hasattr(pt, 'width'):
                width = pt.width
            xyrts.append((pt.XY, 0, r, width))
        else:
            if v.Type != 'arc':
                xyrts = []
                break
            else:
                a, b = v.begin.pt.XY, v.end.pt.XY
                if hasattr(v.begin.pt, 'width'):
                    width = v.begin.pt.width
                xyrts.append((a, 0, 0, width))
                c = v.center.XY * 1
                c.normalize()
                c *= v.r
                c += a
                r = v.r
                if v.CCW:
                    R = v.r
                else:
                    R = -v.r
                xyrts.append((c, -R, 0, width))
                if hasattr(v.end.pt, 'width'):
                    width = v.end.pt.width
            xyrts.append((b, 0, 0, width))

    if len(xyrts) < 2:
        print('WARNING: length of segment list <2 (skipped):\n%s' % str(vertices))
        return ([], [])
    else:
        xyrs = []
        remainders = [(xyrts[i][0] - xyrts[(i + 1)][0]).getNorm() for i in range(len(xyrts) - 1)]
        remainders.append((xyrts[(-1)][0] - xyrts[0][0]).getNorm())
        for i in range(len(xyrts)):
            b, r, rt, w = xyrts[i]
            if rt == 0:
                xyrs.append((b, r, w))
            else:
                if i == 0:
                    if not closed:
                        print('WARNING: skipped tarc at path start point', b)
                        xyrs.append((b, r, w))
                        continue
                i0 = i - 1
                vprev = xyrts[i0]
                if i + 1 < len(xyrts):
                    vnext = xyrts[(i + 1)]
                    i1 = i + 1
                else:
                    if not closed:
                        print('WARNING: skipped tarc at path end point', b)
                        xyrs.append((b, r, w))
                        continue
                    else:
                        vnext = xyrts[0]
                        i1 = 0
                a = vprev[0]
                c = vnext[0]
                xxx, remainders[i0], remainders[i] = create_tarc(a, b, c, rt, remainders[i0], remainders[i])
                for xy, r in xxx:
                    xyrs.append((xy, r, w))

        if closed:
            if xyrs[0][0] != xyrs[(-1)][0]:
                xyrs.append(xyrs[0])
        return XyrsW2Segments(xyrs)


def vertices2Shape(vertices):
    segments, widths = vertices2segments(vertices, closed=True)
    b, a = segments[0].a, segments[(len(segments) - 1)].b
    if a != b:
        segments.push_back(CurveSegment(a, b))
    return Shape(segments)


def extract_meshplane(meshdata, ignore_empty_line=True):

    def int2bin(n, count=8):
        """returns the binary of integer n, using count number of digits"""
        return ''.join([str(n >> y & 1) for y in range(count - 1, -1, -1)])

    import math
    res = []
    shape = None
    if meshdata.meshShape == 'SQUARE':
        w = h = meshdata.meshShapeDiameter
        shape = utils2d.RectangleC(w, h)
        rad = meshdata.meshFigureAngle * math.pi / 180.0
        shape.rotate(rad, R2(0, 0))
        utils2d.Make_CClockwise(shape)
    else:
        if meshdata.meshShape == 'DIAMOND':
            r = meshdata.meshShapeDiameter / 2.0
            c = R2(0, 0)
            rx = R2(r, 0)
            ry = R2(0, r)
            shape = utils2d.PolylineShape([c + rx, c + ry, c - rx, c - ry])
        else:
            if meshdata.meshShape == 'CIRCLE':
                c = R2(0, 0)
                r = meshdata.meshShapeDiameter / 2.0
                shape = utils2d.CircleShape(c, r)
                utils2d.Make_CClockwise(shape)
            else:
                print('ERROR: unknown meshShape %s. Meshshapes cannot be created' % meshdata.meshShape)
                return res
    if meshdata.meshAngle:
        rad = meshdata.meshAngle * math.pi / 180.0
        shape.rotate(rad, R2(0, 0))
    else:
        points = []
        assert meshdata.meshFlagCount == len(meshdata.meshFlags)
        startx, starty = meshdata.meshBasePoint.x, meshdata.meshBasePoint.y
        xPitch = meshdata.meshPitch
        if meshdata.meshArrangeType == '4POINTS':
            yPitch = meshdata.meshPitch
        else:
            if meshdata.meshArrangeType == '5POINTS':
                yPitch = meshdata.meshPitch / 2.0
            else:
                print('ERROR: unknown meshArrangeType %s. Meshshapes cannot be created' % meshdata.meshArrangeType)
                return res
    if meshdata.meshFlagCount % meshdata.meshFlagXCount:
        print('ERROR: invalid meshFlagCount. Meshshapes cannot be created')
        return res
    else:
        if meshdata.meshArrangeType == '5POINTS':
            startx -= meshdata.meshPitch / 2.0
            starty -= meshdata.meshPitch / 2.0
        y = starty
        for i in range(0, meshdata.meshFlagCount, meshdata.meshFlagXCount):
            x = startx
            if meshdata.meshArrangeType == '5POINTS':
                if i % (2 * meshdata.meshFlagXCount):
                    x += meshdata.meshPitch / 2.0
            for j in range(meshdata.meshFlagXCount):
                flag = int(meshdata.meshFlags[(i + j)])
                bits = int2bin(flag)
                for bit in bits:
                    if bit == '1':
                        points.append(R2(x, y))
                    x += xPitch

            y += yPitch

        for p in points:
            s = shape.clone()
            s.translate(p)
            if meshdata.meshAngle:
                rad = meshdata.meshAngle * math.pi / 180.0
                s.rotate(rad, meshdata.meshRotatePoint)
            res.append(s)

        return res


def extract_meshplanes(geometry):
    if geometry.Type != 'geometry':
        print('ERROR: invalid geometry item given (skipped):\n%s' % str(g))
        return []
    else:
        res = []
        if hasattr(geometry, 'meshplane'):
            meshlist = make_list(geometry.meshplane)
            for meshplane in meshlist:
                shape = vertices2Shape(meshplane.vertex.vertices)
                tmp = ShapeWithHoles()
                tmp.shape = shape
                holes = []
                if hasattr(meshplane, 'openShape'):
                    for opening in make_list(meshplane.openShape):
                        holes.append(vertices2Shape(opening.vertex.vertices))

                if len(holes):
                    for hole in holes:
                        tmp.holes.push_back(hole)

                else:
                    shape = tmp
                    meshdata = DataInstance(['meshdata'])
                    meshdata.meshBasePoint = meshplane.meshBasePoint.pt.XY
                    meshdata.meshPitch = float(meshplane.meshPitch)
                    meshdata.meshShape = meshplane.meshShape
                    meshdata.meshShapeDiameter = float(meshplane.meshShapeDiameter)
                    meshdata.meshArrangeType = meshplane.meshArrangeType
                    meshdata.meshFlagCount = int(meshplane.meshFlagCount)
                    meshdata.meshFlags = meshplane.meshFlags.data
                    meshdata.meshFlagXCount = int(meshplane.meshFlagXCount)
                    meshdata.meshAngle = float(meshplane.meshAngle)
                    meshdata.meshRotatePoint = meshplane.meshRotatePoint.pt.XY
                    meshdata.meshFigureAngle = float(meshplane.meshFigureAngle)
                    if hasattr(meshplane, 'submeshplane'):
                        if hasattr(meshplane.submeshplane, 'submeshparameter'):
                            ignore_empty_line = False
                    ignore_empty_line = True
                meshholes = extract_meshplane(meshdata, ignore_empty_line)
                if hasattr(meshplane, 'submeshplane'):
                    if hasattr(meshplane.submeshplane, 'submeshparameter'):
                        for meshparam in make_list(meshplane.submeshplane.submeshparameter):
                            meshsubdata = DataInstance(['meshdata'])
                            meshsubdata.meshBasePoint = meshparam.meshParamBasePoint.pt.XY
                            meshsubdata.meshPitch = float(meshparam.meshParamPitch)
                            meshsubdata.meshShape = meshparam.meshParamShape
                            meshsubdata.meshShapeDiameter = float(meshparam.meshParamShapeDiameter)
                            meshsubdata.meshArrangeType = meshparam.meshParamArrangeType
                            meshsubdata.meshFlagCount = int(meshparam.meshParamFlagCount)
                            meshsubdata.meshFlags = meshparam.meshParamFlags.data
                            meshsubdata.meshFlagXCount = int(meshparam.meshParamFlagXCount)
                            meshsubdata.meshAngle = float(meshparam.meshParamAngle)
                            meshsubdata.meshRotatePoint = meshparam.meshParamRotatePoint.pt.XY
                            meshsubdata.meshFigureAngle = float(meshparam.meshParamFigureAngle)
                            meshholes.extend(extract_meshplane(meshsubdata, ignore_empty_line))

                if len(meshholes):
                    for hole in meshholes:
                        shape.holes.push_back(hole)

                res.append(shape)

        return res


def extract_geometry(g, mtwsetter=None, convert_line2shape=False, tolerance=0):
    if g.Type != 'geometry':
        print('ERROR: invalid geometry item given (skipped):\n%s' % str(g))
        return []
    else:
        res = []
        if hasattr(g, 'surface'):
            for surf in make_list(g.surface):
                shape = vertices2Shape(surf.vertex.vertices)
                if hasattr(g.surface, 'outlineWidth'):
                    if float(g.surface.outlineWidth) != 0:
                        is_ok = shape.create_rounding_off(float(g.surface.outlineWidth) / 2.0, 1, tolerance)
                        if is_ok == False:
                            print('WARNING: skipped shape because it is not orientable')
                            continue
                holes = []
                if hasattr(surf, 'openShape'):
                    for opening in make_list(surf.openShape):
                        hole = vertices2Shape(opening.vertex.vertices)
                        if hasattr(opening, 'outlineWidth') and float(opening.outlineWidth) != 0:
                            is_ok = hole.create_rounding_off(float(opening.outlineWidth) / 2.0, -1, tolerance)
                            if is_ok == False:
                                print('WARNING: skipped hole because it is not orientable')
                                continue
                        holes.append(hole)

                if len(holes):
                    tmp = ShapeWithHoles()
                    tmp.shape = shape
                    for hole in holes:
                        tmp.holes.push_back(hole)

                    shape = tmp
                res.append(shape)

        if hasattr(g, 'line'):
            for line in make_list(g.line):
                segments, widths = vertices2segments(line.vertex.vertices)
                if mtwsetter is not None:
                    for w in widths:
                        if w > 0:
                            mtwsetter(w)

                if len(segments):
                    trace = layoutdbPy.Trace()
                    for i in range(len(segments)):
                        seg = segments[i]
                        width = widths[i]
                        if width > 0:
                            trace.add_segment(seg, width)
                        else:
                            print('WARNING: skipped zero-width trace segment: ' + str(seg))

                    if trace.n_segments() > 0:
                        if convert_line2shape:
                            if hasattr(line, 'penShape') and line.penShape == 'SQUARE':
                                create_as_rectangle = True
                                shapes = []
                                for i in range(trace.n_segments()):
                                    s = trace.segment(i)
                                    if s.is_arc == False:
                                        if s.a.x == s.b.x or s.a.y == s.b.y:
                                            if s.a.x < s.b.x or s.a.y < s.b.y:
                                                start, end = s.a, s.b
                                            else:
                                                start, end = s.b, s.a
                                            w = trace.width(i) * 0.5
                                            swh = ShapeWithHoles()
                                            cs = utils2dPy.make_rectangle_shape(start - R2(w, w), end + R2(w, w), True)
                                            swh.shape = cs.to_Shape()
                                            shapes.append(swh)
                                    else:
                                        create_as_rectangle = False
                                        break

                                if not create_as_rectangle:
                                    shapes = [shape.to_ShapeWithHoles() for shape in trace.shapes(tolerance)]
                                res.extend(shapes)
                        else:
                            shapes = [shape.to_ShapeWithHoles() for shape in trace.shapes(tolerance)]
                            res.extend(shapes)
                    else:
                        res.append(trace)
                else:
                    vertices = make_list(line.vertex.vertices)
                    if len(vertices) == 2:
                        if vertices[0].Type == 'pt':
                            if vertices[1].Type == 'pt':
                                a, b = vertices[0].XY, vertices[1].XY
                                width = 0
                                if hasattr(vertices[0], 'width'):
                                    width = vertices[0].width
                                if hasattr(vertices[1], 'width'):
                                    width = vertices[1].width
                        if a == b:
                            if width > 0:
                                res.append(utils2d.CircleShape(a, width / 2))

        if hasattr(g, 'circle'):
            for circle in make_list(g.circle):
                c = circle.pt.XY
                r = float(circle.data)
                res.append(utils2d.CircleShape(c, r))

        if hasattr(g, 'rectangle'):
            for rect in make_list(g.rectangle):
                c = rect.pt.XY
                w, h = float(rect.width), float(rect.height)
                tmp = utils2d.RectangleC(w, h, origin=c)
                angle = float(rect.rAngle)
                if angle != 0:
                    tmp.rotate(angle * pi / 180.0, R2(0, 0))
                res.append(tmp)

        if hasattr(g, 'oblong'):
            for o in make_list(g.oblong):
                p1, p2 = o.pt[0].XY, o.pt[1].XY
                width = float(o.width)
                res.append(utils2d.PolyarcShape(utils2d.straight_path_segment_to_XYR(p1, p2, width, roundcaps=True)))

        if hasattr(g, 'roundThermal'):
            for rt in make_list(g.roundThermal):
                od, id, angle, num_spokes, gap = (
                 rt.out, rt.In, rt.bridgeAngle, rt.nBridge, rt.bridgeWidth)
                od, id, angle, num_spokes, gap = (float(od), float(id), float(angle) * math.pi / 180.0, int(num_spokes), float(gap))
                if not (od > id and id > 0 and num_spokes > 0 and gap > 0):
                    return res
                pt = rt.pt.XY
                rmin, rmax, g2 = id, od, gap * 0.5
                dphi = 2 * math.pi / num_spokes
                if rmin <= g2:
                    return res
                x0 = R2(math.sqrt(rmin * rmin - g2 * g2), g2)
                x1 = R2(math.sqrt(rmax * rmax - g2 * g2), g2)
                x2, x3 = R2(x1.x, -x1.y), R2(x0.x, -x0.y)
                x2.turn(dphi)
                x3.turn(dphi)
                xyrs = [(x0, 0), (x1, 0), (R2(0, 0), -rmax), (x2, 0), (x3, 0), (R2(0, 0), rmin), (R2(x0), 0)]
                spoke = utils2d.PolyarcShape(xyrs)
                restmp = [spoke]
                for i in range(1, num_spokes):
                    restmp.append(spoke.clone())

                for i in range(num_spokes):
                    restmp[i].rotate(i * dphi + angle, R2(0, 0))
                    restmp[i].translate(pt)
                    res.append(restmp[i])

        if hasattr(g, 'squareThermal'):
            for st in make_list(g.squareThermal):
                os, id, angle, num_sp, gap = (
                 st.out, st.In, st.bridgeAngle, st.nBridge, st.bridgeWidth)
                os, id, angle, num_sp, gap = (float(os), float(id), float(angle) * math.pi / 180.0, int(num_sp), float(gap))
                pt = st.pt.XY
                if not (os > 0 and id >= 0 and os > id):
                    return res
                if num_sp > 0:
                    angle_sp = 2 * math.pi / num_sp
                else:
                    angle_sp = 0
                symb = utils2d.RectangleC(os, os)
                Make_CClockwise(symb)
                symb_hole = utils2d.RectangleC(id, id)
                hs = [symb_hole]
                h0 = utils2d.Rectangle(gap, os * math.sqrt(2) + os / 10)
                h0.translate(R2(-gap / 2.0, 0))
                Make_Clockwise(h0)
                h0.rotate(-2 * math.pi / 4 + 2 * math.pi * angle / 360, R2())
                for i in range(num_sp):
                    h0.rotate(angle_sp, R2())
                    hs.append(h0.clone())

                vhs = vectorShapeWithHoles()
                vhs.append(CShapeWithHoles(symb))
                for h in hs:
                    vhs.append(CShapeWithHoles(h))

                pp = Planeprocessor(BoundingBox(-(os * math.sqrt(2) + os / 8), os * math.sqrt(2) + os / 8, -(os * math.sqrt(2) + os / 8), os * math.sqrt(2) + os / 8), 0.0001)
                pp.add_shapes(vhs)
                restmp = pp.boolean_add2()
                for r in restmp:
                    r = r.to_ShapeWithHoles()
                    r.translate(pt)
                    res.append(r)

        if hasattr(g, 'donut'):
            for donut in make_list(g.donut):
                od = float(donut.out)
                id = float(donut.In)
                c = donut.pt.XY
                assert od > 0 and id >= 0
                swh = ShapeWithHoles()
                sh = utils2d.CircleShape(c, od)
                Make_CClockwise(sh)
                swh.shape = sh
                if id > 0:
                    if od > id:
                        swh.holes.append(utils2d.CircleShape(c, id))
                res.append(swh)

        if len(res) == 0:
            print('WARNING: no shape extracted from geometry:\n', g)
        for shape in res:
            if not isinstance(shape, layoutdbPy.Trace):
                shape.make_arcs_less_than_pi()

        return res


def create_padshape(pad, tolerance):
    assert pad.Type == 'pad'
    pad.cst_shapes = extract_geometry((pad.geometry), tolerance=tolerance)


def make_dict(a, key):
    res = {}
    if hasattr(a, key):
        for i in make_list(getattr(a, key)):
            assert hasattr(i, 'data') and type(i.data) == str
            res[i.data] = i

    setattr(a, key, res)


class Export:
    connectmap = {'connect':layoutdbPy.ConnectType.connect, 
     'noconnect':layoutdbPy.ConnectType.noconnect, 
     'thermal':layoutdbPy.ConnectType.thermal, 
     'clearance':layoutdbPy.ConnectType.clearance}

    def __init__(this, pcf=None, ftf=None, ruf=None, filenamebase='', progressbar=None):
        from common.layoutdb import DatabaseReadError
        this.pcf, this.ftf, this.ruf = pcf, ftf, ruf
        this.is_8000 = False
        if this.pcf is None:
            import os
            if len(filenamebase) == 0:
                raise DatabaseReadError('ERROR: no filename given for .pcf file')
            if os.path.isfile(filenamebase + '.pcf'):
                this.pcf = read_z((filenamebase + '.pcf'), node='pcf', progressbar=progressbar)
            else:
                if os.path.isfile(filenamebase + '.sdf'):
                    this.pcf = read_z((filenamebase + '.sdf'), node='pcf', progressbar=progressbar)
                    this.is_8000 = True
                if this.pcf is None:
                    raise DatabaseReadError('ERROR: no .pcf/.sdf database read')
        if this.ftf is None:
            if len(filenamebase) == 0:
                raise DatabaseReadError('ERROR: no filename given for .ftf file')
            else:
                if not this.is_8000:
                    if os.path.isfile(filenamebase + '.pcf'):
                        this.ftf = read_z((filenamebase + '.ftf'), node='ftf', progressbar=progressbar)
                if this.is_8000:
                    if os.path.isfile(filenamebase + '.sff'):
                        this.ftf = read_z((filenamebase + '.sff'), node='ftf', progressbar=progressbar)
                if this.ftf is None:
                    raise DatabaseReadError('ERROR: no .ftf/.sff database read')
        if this.ruf is None:
            import os
            for ext in ('.ruf', '.rulf'):
                filename = filenamebase + ext
                if os.path.exists(filename):
                    try:
                        this.ruf = read_z(filename, node='design', progressbar=progressbar)
                        break
                    except:
                        print('WARNING: unable to read rule file', filename)

        this.tech_data = None
        if this.is_8000:
            from cdsbrdmcm import profile_parser
            techfile = filenamebase + '.tech'
            if os.path.exists(techfile):
                try:
                    this.tech_data = profile_parser.read_CDSX(techfile)
                except:
                    print('WARNING: unable to read tech file', filename)

        this.design_name = filenamebase
        this.db_unit = orig_unit = this.pcf.header.unit.lower()
        this.scale = 1.0
        print('original design unit: ', this.db_unit)
        if this.db_unit == 'dbunit':
            this.db_unit = 'mm'
            this.scale = 1e-05
        else:
            if orig_unit != this.db_unit:
                print('now using: ', this.db_unit)
            else:
                if hasattr(this.ftf, 'footprintContainer'):
                    if hasattr(this.ftf.footprintContainer, 'padstacks'):
                        make_dict(this.ftf.footprintContainer.padstacks, 'padstack')
                        this.padstacks = this.ftf.footprintContainer.padstacks.padstack
                    else:
                        this.padstacks = {}
                elif hasattr(this.ftf, 'footprintContainer') and hasattr(this.ftf.footprintContainer, 'pads'):
                    make_dict(this.ftf.footprintContainer.pads, 'pad')
                    this.pads = this.ftf.footprintContainer.pads.pad
                else:
                    this.pads = {}
                if hasattr(this.ftf, 'footprintContainer') and hasattr(this.ftf.footprintContainer, 'footprints'):
                    make_dict(this.ftf.footprintContainer.footprints, 'footprint')
                    this.footprints = this.ftf.footprintContainer.footprints.footprint
            this.footprints = {}
        this.create_foot2cl_maps()

    def create_foot2cl_maps(this):
        this.foot2boardlayer_maps = {}
        for mapping in make_list(this.pcf.technologyContainer.technology.layerMapping.map):
            layer_map = {}
            for corr in make_list(mapping.correspondence):
                if not hasattr(corr, 'boardLayer'):
                    pass
                else:
                    bl = corr.boardLayer
                    if hasattr(bl, 'conductive'):
                        is_cond = True
                        blname = (True, make_list(bl.conductive))
                    else:
                        if hasattr(bl, 'nonConductive'):
                            is_cond = False
                            blname = (False, make_list(bl.nonConductive))
                    for fl in make_list(corr.footLayer):
                        layer_map[fl] = blname

            assert mapping.data in ('A', 'B', 'A_THRU', 'B_THRU')
            this.foot2boardlayer_maps[mapping.data] = layer_map

    def check_foot2cl_maps(this, layoutdb):
        print('Checking foot-to-cl map...')
        top_el, bot_el = layoutdb.top_etch_layer(), layoutdb.bottom_etch_layer()
        nel = 0
        etchlayers = {}
        for l in layoutdb.layers():
            if l.is_etch():
                nel += 1
                etchlayers[l.name] = nel

        ok = True
        for mA, mB in (('A', 'B'), ('A_THRU', 'B_THRU')):
            print('Checking consistency of layer maps %s and %s' % (mA, mB))
            mapA, mapB = this.foot2boardlayer_maps[mA], this.foot2boardlayer_maps[mB]
            ckeysA = set([key for key, val in mapA.items() if val[0] == True])
            ckeysB = set([key for key, val in mapB.items() if val[0] == True])
            if ckeysA != ckeysB:
                print('Unequal footprint layers in maps %s and %s:' % (mA, mB))
                print(mA, ':', ckeysA)
                print(mB, ':', ckeysB)
                ok = False
                ckeysA = ckeysB = ckeysA.intersection(ckeysB)
            for key in ckeysA:
                lyrsA = set(mapA[key][1])
                lyrsB = set(mapB[key][1])
                if lyrsA == lyrsB:
                    continue
                if len(lyrsA) > 1 or len(lyrsB) > 1 or len(lyrsA) != len(lyrsB):
                    print('ERROR: inconsistent layer mappings for footprint layer %s:' % key)
                    print('Map A:\n', mapA)
                    print('Map B:\n', mapB)
                    ok = False
                elif len(lyrsA) == 0:
                    continue
                lA = layoutdb.layer(lyrsA.pop())
                lB = layoutdb.layer(lyrsB.pop())
                if lA == top_el:
                    if lB == bot_el:
                        continue
                if lA == bot_el:
                    if lB == top_el:
                        continue
                if not not lA.is_etch():
                    if not lB.is_etch():
                        pass
                    else:
                        if etchlayers[lA.name] == nel + 1 - etchlayers[lB.name]:
                            pass
                        else:
                            print('ERROR: inconsistent layer mappings for footprint layer %s, layers %s, %s' % (key, str(lA), str(lB)))
                            ok = False
                            continue

        print('Result: Layer mapping', end=' ')
        if ok == True:
            print('consistent.')
        else:
            print('inconsistent.')
        return ok

    def get_board_outline(this, layoutdb):
        outline_shape = None
        outline_shapes = []
        if hasattr(this.pcf.boardContainer, 'boardLayout'):
            for layer in make_list(this.pcf.boardContainer.boardLayout.layout.layer):
                if hasattr(layer, 'systemLayer') and layer.systemLayer.type in ('LAYOUT_AREA',
                                                                                'BOARD_FIGURE'):
                    if not hasattr(layer, 'surface'):
                        print("WARNING: no 'surface' geoemetry found (skipped):\n%s" % str(layer))
                        continue
                    surfaces = make_list(layer.surface)
                    outline_shape_tmp = []
                    for surface in surfaces:
                        res = extract_geometry((surface.geometry), tolerance=(layoutdb.tolerance / this.scale))
                        outline_shape_tmp.extend(res)

                    for s in outline_shape_tmp:
                        s.scale(this.scale)
                        if type(s) == utils2dPy.Shape:
                            tmp = utils2dPy.ShapeWithHoles()
                            tmp.shape = s
                            s = tmp
                        outline_shapes.append(s)

        else:
            if len(outline_shapes) >= 1:
                outline_shapes.sort(key=(lambda x: x.shape.bbox.area()), reverse=True)
                outline_shape = outline_shapes[0]
                ok = True
                for s in outline_shapes[1:]:
                    if not outline_shape.shape.bbox.contains(s.shape.bbox):
                        ok = False

                if not ok:
                    print('WARNING: Board outline data not unique; using total bounding box instead.')
                    b = outline_shape.bbox
                    for s in outline_shapes[1:]:
                        b.extend(s.shape.bbox)

                    outline_shape = utils2d.Bbox2Rectangle(b)
            else:
                outline_shape = None
            if outline_shape is not None:
                outline_shape = this.sp(outline_shape, sense=1, info='board outline')
            if outline_shape is not None:
                layoutdb.board_outline = outline_shape
            else:
                print('WARNING: Unable to extract outline shape (taking bounding box instead)')

    def to_LayoutDB(this):
        from common.units import standardize, get_typical_manufacturing_tolerance
        this.layoutdb = layoutdb = layoutdbPy.new_iLayoutDB()
        layoutdb.name = os.path.basename(this.design_name)
        layoutdb.length_unit = standardize(this.db_unit)
        layoutdb.tolerance = this.tol = get_typical_manufacturing_tolerance((layoutdb.length_unit), tolmu=1)
        this.sp = ShapeProcessor(this.tol)
        this.get_board_outline(layoutdb)
        layoutdb.origin = 'CST ZUKEN CR-5000/8000 IMPORT V1'
        layoutdb.part_model_db = layoutdbPy.PartModelDB()
        layoutdb.is_x_mirror_mode = True
        this.process_stackup(layoutdb)
        this.process_nets(layoutdb)
        this.layermaps_consistent = this.check_foot2cl_maps(layoutdb)
        this.process_boardLayout(layoutdb)
        this.process_via_padstacks(layoutdb)
        this.add_components(layoutdb)
        check_pin_names(layoutdb.components())
        this.process_rules(layoutdb)
        this.check_noconnect_pads(layoutdb)
        if layoutdb.board_outline is None:
            layoutdb.board_outline = layoutdbPy.compute_board_outline(layoutdb, 0.05)
        this.correct_die_pad_layers(layoutdb)
        this.process_bondwires(layoutdb)
        this.process_wirebond_profiles(layoutdb)
        this.process_cavities(layoutdb)
        return layoutdb

    def process_stackup(this, layoutdb):
        import types

        def get_value_if_given(default, arg, attr, warning):
            try:
                if type(default) == float:
                    param = float(getattr(arg, attr))
                else:
                    param = getattr(arg, attr)
                return (
                 param, warning)
            except:
                if len(warning) != 0:
                    warning = ', '.join([warning, attr])
                else:
                    warning = attr
                return (
                 default, warning)

        from common.layoutdb import check_layer_stackup
        tech = make_list(this.pcf.technologyContainer.technology)[0]
        this.refers = {}
        for cl in make_list(tech.conductiveLayer.layerNumber):
            clname = cl.data
            layername = clname
            typ = layoutdbPy.LayerType.Signal
            is_positive = True
            if cl.type.upper() == 'FULLSURF':
                is_positive = False
            new_layer = layoutdbPy.new_iLayer()
            new_layer.name = layername
            new_layer.layer_type = typ
            new_layer.is_positive = is_positive
            new_layer.thickness = 0
            layoutdb.add_layer_below(new_layer, new_layer)
            if hasattr(cl, 'refer'):
                for ref in make_list(cl.refer):
                    this.refers[ref.data] = (
                     cl.data, ref.type)

        check_layer_stackup(layoutdb)
        try:
            if hasattr(this.ruf, 'boardSpec') and hasattr(this.ruf.boardSpec, 'bareBoard'):
                bb = this.ruf.boardSpec.bareBoard
                if hasattr(bb, 'dielectric'):
                    for l in make_list(bb.dielectric):
                        if hasattr(l, 'data'):
                            if len(make_list(l.data)) == 2:
                                l1, l2 = make_list(l.data)
                                l1 = layoutdb.layer(l1)
                                l2 = layoutdb.layer(l2)
                                if not l1.number + 1 == l2.number - 1:
                                    raise AssertionError
                                else:
                                    layer = layoutdb.layer(l1.number + 1)
                                    if layer and layer.material.type == layoutdbPy.MaterialType.Dielectric:
                                        warning = ''
                                        layer.thickness, warning = get_value_if_given(layer.thickness, l, 'thickness', warning)
                                        material = layer.material
                                        material.name, warning = get_value_if_given(material.name, l, 'material', warning)
                                        material.eps, warning = get_value_if_given(material.eps, l, 'dielectricConstant', warning)
                                        material.condtan, warning = get_value_if_given(material.condtan, l, 'lossTangent', warning)
                                        if len(warning):
                                            print('WARNING: Attribute(s) %s not found for layer %s in %s.ruf-file. Using default value(s).' % (warning, layer.name, layoutdb.name))
                                    else:
                                        print('WARNING: cannot find dielectric layer between layers ', make_list(l.data))

                if hasattr(bb, 'conductor'):
                    for l in make_list(bb.conductor):
                        if hasattr(l, 'data'):
                            layer = layoutdb.layer(l.data)
                            if layer and layer.material.type == layoutdbPy.MaterialType.Conductor:
                                warning = ''
                                layer.thickness, warning = get_value_if_given(layer.thickness, l, 'thickness', warning)
                                material = layer.material
                                material.name, warning = get_value_if_given(material.name, l, 'material', warning)
                                restmp, warning = get_value_if_given(-1.0, l, 'resistivity', warning)
                                if restmp > 0:
                                    material.condtan = 1.0 / restmp
                            else:
                                material.eps, warning_IGNORED = get_value_if_given(material.eps, l, 'dielectricConstant', warning)
                                if hasattr(l, 'place'):
                                    if l.place == 'above':
                                        layoutdb.fraction_filled_from_below(layer, 0)
                                    else:
                                        if l.place == 'below':
                                            layoutdb.fraction_filled_from_below(layer, 1)
                                        else:
                                            layoutdb.fraction_filled_from_below(layer, 0.5)
                                    if len(warning):
                                        print('WARNING: Attribute(s) %s not found for layer %s in %s.ruf-file. Using default value(s).' % (warning, layer.name, layoutdb.name))
                                else:
                                    print('WARNING: cannot find conductor layer', l.data)

                if hasattr(bb, 'physical'):
                    for l in make_list(bb.physical):
                        if hasattr(l, 'data'):
                            side = make_list(l.data)[0]
                            if side == 'ABOVE':
                                layer = layoutdb.top_soldermask()
                            elif side == 'BELOW':
                                layer = layoutdb.bottom_soldermask()
                            else:
                                continue
                            if layer:
                                warning = ''
                                layer.thickness, warning = get_value_if_given(layer.thickness, l, 'thickness', warning)
                                material = layer.material
                                material.name, warning = get_value_if_given(material.name, l, 'material', warning)
                                material.eps, warning = get_value_if_given(material.eps, l, 'dielectricConstant', warning)
                                material.condtan, warning = get_value_if_given(material.condtan, l, 'lossTangent', warning)
                                if len(warning):
                                    print('WARNING: Attribute(s) %s not found for layer %s in %s.ruf-file.  Using default value(s).' % (warning, layer.name, layoutdb.name))

                layoutdb.update_elevations()
            if this.is_8000:
                if this.tech_data:
                    materials = {}
                    for m in this.tech_data.Technology.Materials.Material:
                        material = layoutdbPy.Material()
                        material.name = str(m.Name)
                        if m.Type == 'CONDUCTOR':
                            material.type = layoutdbPy.MaterialType.Conductor
                            material.eps = material.mu = 1
                            material.condtan = float(m.Conductivity)
                        else:
                            if m.Type == 'DIELECTRIC':
                                material.type = layoutdbPy.MaterialType.Dielectric
                                material.eps = float(m.DielConstant)
                                material.condtan = float(m.LossTangent)
                                material.mu = 1.0
                        materials[material.name] = material

                    for l in this.tech_data.Technology.Layers.Layer:
                        lname = l.Name
                        matname = ''
                        if l.Type == 'CONDUCTOR':
                            if len(lname) > 5:
                                if lname[:5] == 'LAYER':
                                    lnum = layoutdb.top_etch_layer().number + 2 * int(lname[5:])
                                    layer = layoutdb.layer(lnum)
                                    matname = l.CondMaterial
                        if l.Type == 'DIELECTRIC':
                            if len(lname) > 4:
                                if lname[:4] == 'DIEL':
                                    lnum = layoutdb.top_etch_layer().number + 2 * int(lname[4:]) + 1
                                    layer = layoutdb.layer(lnum)
                                    matname = l.DielMaterial
                            layer.thickness = float(l.Thickness)
                            if matname in materials:
                                layer.material = materials[matname]

        except:
            return

    def process_nets(this, layoutdb):
        if hasattr(this.pcf.boardContainer, 'nets'):
            if hasattr(this.pcf.boardContainer.nets, 'net'):
                nets = make_list2(this.pcf.boardContainer.nets, 'net')
                for net in nets:
                    if hasattr(net, 'type'):
                        layoutdb.add_net_dirty(net.data)
                        n = layoutdb.net(net.data)
                        if net.type == 'POWER':
                            n.type = layoutdbPy.NetType.Power
                        else:
                            if net.type == 'GROUND':
                                n.type = layoutdbPy.NetType.GND
                            else:
                                n.type = layoutdbPy.NetType.Signal
                        layoutdb.add_net(n)

    def add_footprint(this, footprintname, ps, layoutdb):
        if footprintname not in this.footprints:
            return
        else:
            footprint = this.footprints[footprintname]
            partname = footprintname + '-' + this.current_comp + '-cst-' + ps
            if ps == 'R':
                ps = 'B'
            ftmap = this.foot2boardlayer_maps[ps]
            part = {'padstacks':[],  'outlines':[]}
            padstacks, outlines = part['padstacks'], part['outlines']
            for toeprint in make_list2(footprint, 'toeprint'):
                for pin in make_list2(toeprint, 'pin'):
                    pinname = pin.data
                    pinpos = pin.pt.XY * this.scale
                    loss = this.shapes_from_layout((pin.layout), layoutdb, ftmap=ftmap, ps=ps)

            if hasattr(footprint, 'heelprint'):
                top = layoutdb.top_etch_layer()
                shapes = []
                if hasattr(footprint.heelprint, 'layout') and hasattr(footprint.heelprint.layout, 'layer'):
                    for l in make_list(footprint.heelprint.layout.layer):
                        if not hasattr(l, 'footLayer'):
                            pass
                        else:
                            if l.footLayer not in this.foot2boardlayer_maps['A']:
                                pass
                            else:
                                bl = this.foot2boardlayer_maps['A'][l.footLayer][1][0]
                        if bl not in this.refers:
                            pass
                        elif this.refers[bl][1] != 'COMPAREA':
                            pass
                        elif this.refers[bl][0] != top.name:
                            pass
                        else:
                            for area in make_list2(l, 'area'):
                                if not hasattr(area, 'geometry'):
                                    pass
                                else:
                                    tmp = extract_geometry((area.geometry), tolerance=(layoutdb.tolerance / this.scale))
                                    for s in tmp:
                                        s.scale(this.scale)

                                    shapes += tmp

                            break

                if 0:
                    if len(shapes) == 0:
                        if hasattr(footprint.heelprint, 'minRect'):
                            p1, p2 = footprint.minRect.box.pt[0].XY * this.scale, footprint.minRect.box.pt[1].XY * this.scale
                            cswh = this.sp(utils2dPy.make_rectangle_shape(p1, p2, True))
                            shapes = [cswh]
                for s in shapes:
                    s = this.sp(s, info='component outline')
                    if s is not None:
                        outlines.append(s)

            return part

    def shapes_from_layout(this, layout, layoutdb, ftmap=None, ps='A'):
        res = []
        for layoutlayer in make_list2(layout, 'layer'):
            res1 = this.shapes_from_layoutLayer(layoutlayer, layoutdb, ftmap=ftmap, ps=ps)
            res.extend(res1)

        return res

    def shapes_from_layoutLayer(this, layoutlayer, layoutdb, ftmap=None, ps='A'):
        iscond, layer = this.Id2layer(layoutlayer, layoutdb, ftmap=ftmap)
        if not iscond:
            return []
        else:
            dblayers = layer
            prims = this.get_layoutPrims(layoutlayer, dblayers, ps=ps, tolerance=(layoutdb.tolerance))
            return prims

    def Id2layer(this, layoutlayer, layoutdb, ftmap=None):
        if hasattr(layoutlayer, 'conductive'):
            return (True, layoutlayer.conductive)
        else:
            if hasattr(layoutlayer, 'nonconductive'):
                return (
                 False, layoutlayer.nonconductive)
            else:
                if hasattr(layoutlayer, 'systemLayer'):
                    return (None, None)
                if hasattr(layoutlayer, 'footLayer'):
                    if ftmap is not None:
                        if layoutlayer.footLayer in ftmap:
                            return ftmap[layoutlayer.footLayer]
                    print('WARNING: footprint layer %s not found' % layoutlayer.footLayer)
                    return (None, None)
                if hasattr(layoutlayer, 'FPADSTACK'):
                    return (True, 'padstack-cst')
            return (None, None)

    def get_layoutPrims(this, layoutlayer, dblayers, ps='A', tolerance=0):
        prims = []
        for prim_t in ('line', 'surface', 'area', 'hole', 'ovalHole', 'squareHole',
                       'footPadstackPos', 'footPad'):
            prims += getattr(this, 'Prim_' + prim_t)(layoutlayer, dblayers, ps=ps, tolerance=tolerance)

        return prims

    def Prim_line(this, layoutlayer, dblayers, ps='A', tolerance=0):
        net = None
        res = []
        for line in make_list2(layoutlayer, 'line'):
            if line.Type != 'line':
                print("ERROR: unable to interpret 'line' geometry (skipped):\n%s" % str(line))
            else:
                if hasattr(line, 'net'):
                    net = line.net
                tmp = extract_geometry((line.geometry), tolerance=tolerance)
                res.append((net, tmp))

        return res

    def Prim_surface--- This code section failed: ---

 L.1564         0  BUILD_LIST_0          0 
                2  RETURN_VALUE     

 L.1566         4  FOR_ITER             82  'to 82'
                6  STORE_FAST               'surf'

 L.1567         8  LOAD_FAST                'surf'
               10  LOAD_ATTR                Type
               12  LOAD_STR                 'surface'
               14  COMPARE_OP               !=
               16  POP_JUMP_IF_FALSE    36  'to 36'

 L.1568        18  LOAD_GLOBAL              print
               20  LOAD_STR                 "ERROR: unable to interpret 'surface' geometry (skipped):\n%s"
               22  LOAD_GLOBAL              str
               24  LOAD_FAST                'surf'
               26  CALL_FUNCTION_1       1  '1 positional argument'
               28  BINARY_MODULO    
               30  CALL_FUNCTION_1       1  '1 positional argument'
               32  POP_TOP          

 L.1569        34  CONTINUE              4  'to 4'

 L.1570        36  LOAD_GLOBAL              hasattr
               38  LOAD_FAST                'surf'
               40  LOAD_STR                 'net'
               42  CALL_FUNCTION_2       2  '2 positional arguments'
               44  POP_JUMP_IF_FALSE    52  'to 52'

 L.1570        46  LOAD_FAST                'surf'
               48  LOAD_ATTR                net
               50  STORE_FAST               'net'
             52_0  COME_FROM            44  '44'

 L.1571        52  LOAD_GLOBAL              extract_geometry
               54  LOAD_FAST                'surf'
               56  LOAD_ATTR                geometry
               58  LOAD_FAST                'tolerance'
               60  LOAD_CONST               ('tolerance',)
               62  CALL_FUNCTION_KW_2     2  '2 total positional and keyword args'
               64  STORE_FAST               'tmp'

 L.1572        66  LOAD_GLOBAL              res
               68  LOAD_ATTR                append
               70  LOAD_FAST                'net'
               72  LOAD_FAST                'tmp'
               74  BUILD_TUPLE_2         2 
               76  CALL_FUNCTION_1       1  '1 positional argument'
               78  POP_TOP          
               80  JUMP_BACK             4  'to 4'
               82  POP_BLOCK        

 L.1574        84  SETUP_LOOP          128  'to 128'
               86  LOAD_GLOBAL              res
               88  GET_ITER         
               90  FOR_ITER            126  'to 126'
               92  UNPACK_SEQUENCE_2     2 
               94  STORE_FAST               'net'
               96  STORE_FAST               'ss'

 L.1575        98  SETUP_LOOP          124  'to 124'
              100  LOAD_FAST                'ss'
              102  GET_ITER         
              104  FOR_ITER            122  'to 122'
              106  STORE_FAST               's'

 L.1575       108  LOAD_FAST                's'
              110  LOAD_ATTR                scale
              112  LOAD_FAST                'this'
              114  LOAD_ATTR                scale
              116  CALL_FUNCTION_1       1  '1 positional argument'
              118  POP_TOP          
              120  JUMP_BACK           104  'to 104'
              122  POP_BLOCK        
            124_0  COME_FROM_LOOP       98  '98'
              124  JUMP_BACK            90  'to 90'
              126  POP_BLOCK        
            128_0  COME_FROM_LOOP       84  '84'

 L.1576       128  LOAD_GLOBAL              res
              130  RETURN_VALUE     
               -1  RETURN_LAST      

Parse error at or near `FOR_ITER' instruction at offset 4

    def Prim_area(this, layoutlayer, dblayers, ps='A', tolerance=0):
        return []

    def Prim_hole(this, layoutlayer, dblayers, ps='A', tolerance=0):
        return []

    def Prim_ovalHole(this, layoutlayer, dblayers, ps='A', tolerance=0):
        return []

    def Prim_squareHole(this, layoutlayer, dblayers, ps='A', tolerance=0):
        return []

    def Prim_footPadstackPos(this, layoutlayer, dblayers, ps='A', tolerance=0):
        layoutdb = this.layoutdb
        res = []
        for fps in make_list2(layoutlayer, 'fpadstack'):
            pos = fps.pt.XY * this.scale
            angle = this.get_angle(fps)
            if not hasattr(fps, 'padstackGroup'):
                continue
            lps = this.add_library_padstack(fps.padstackGroup.padstack, ps, this.layoutdb)
            if lps is None:
                print('ERROR: no library padstack for footprint created')
            else:
                nps = layoutdbPy.new_iPadstack()
                nps.library_padstack = lps
                nps.position = pos
                nps.rotation = angle
                if ps == 'A':
                    l = layoutdb.top_etch_layer()
                else:
                    l = layoutdb.bottom_etch_layer()
                res.append(('padstack-cst', nps))

        return res

    def get_angle(this, x):
        if hasattr(x, 'angle'):
            return float(x.angle) * pi / 180.0
        else:
            return 0.0

    def Prim_footPad(this, layoutlayer, dblayers, ps='A', tolerance=0):
        layoutdb = this.layoutdb
        res = []
        for fpad in make_list2(layoutlayer, 'fPad'):
            pos = fpad.pt.XY * this.scale
            lpad = this.add_library_pad(fpad.data, layoutdb)
            angle = this.get_angle(fpad)
            lpsname = 'padstack-cst-' + lpad.name + '-' + ps
            if not layoutdb.has_lpadstack(lpsname):
                lps = layoutdbPy.new_iLPadstack()
                lps.name = lpsname
                for dblayer in dblayers:
                    l = layoutdb.layer(dblayer)
                    if l is not None:
                        lps.pad(l, layoutdbPy.ConnectType.connect, lpad)
                    else:
                        print('ERROR: unknown layer %s' % dblayer)

                layoutdb.add_lpadstack(lps)
            else:
                lps = layoutdb.lpadstack(lpsname)
            dps = layoutdbPy.new_iPadstack()
            dps.library_padstack = lps
            dps.position = pos
            dps.rotation = angle
            layers = [layoutdb.layer(l) for l in dblayers]
            layerspan = [l.number for l in layers if l is not None]
            if len(layerspan) == 0:
                print('ERROR: empty layer span')
            else:
                dps.layer_from = layoutdb.layer(min(layerspan))
                dps.layer_to = layoutdb.layer(max(layerspan))
                for l in layers:
                    dps.connect(l, layoutdbPy.ConnectType.connect)

                res.append(('padstack-cst', dps))

        return res

    def process_boardLayout(this, layoutdb):
        layoutdb.simulation_settings.lateral_reference_length = 1e+30

        def mtwsetter(w):
            w *= this.scale
            if w < layoutdb.simulation_settings.lateral_reference_length:
                layoutdb.simulation_settings.lateral_reference_length = w

        for layer in make_list(this.pcf.boardContainer.boardLayout.layout.layer):
            if not hasattr(layer, 'conductive'):
                pass
            else:
                layername = layer.conductive
                dblayer = layoutdb.layer(layername)
                print('Processing etch layer', layername)
                line_list = []
                if hasattr(layer, 'line'):
                    line_list.extend(make_list(layer.line))
                if hasattr(layer, 'shieldLine'):
                    line_list.extend(make_list(layer.shieldLine))
                for line in line_list:
                    if line.Type != 'line':
                        if line.Type != 'shieldLine':
                            print("ERROR: unable to interpret 'line' geometry (skipped):\n%s" % str(line), line.Type)
                            continue
                    else:
                        if hasattr(line, 'net'):
                            net = line.net
                        else:
                            net = 'NONE'
                    tmp = extract_geometry((line.geometry), mtwsetter=mtwsetter, tolerance=(layoutdb.tolerance / this.scale))
                    for s in tmp:
                        s.scale(this.scale)

                    for s in tmp:
                        layoutdb.add_net_dirty(net)
                        if isinstance(s, layoutdbPy.Trace):
                            s.net_index = layoutdb.net_index(net)
                            dblayer.add_trace(s)
                        else:
                            if s.empty():
                                continue
                            if s.sense() < 0:
                                s.reverse()
                            cswh = this.sp(s, sense=1, layer=dblayer)
                            if cswh is not None:
                                cswh.net_index = layoutdb.net_index(net)
                                dblayer.add_plane_shape(cswh)

                if hasattr(layer, 'surface'):
                    for surf in make_list(layer.surface):
                        if surf.Type != 'surface':
                            print("ERROR: unable to interpret 'surface' geometry (skipped):\n%s" % str(surf))
                            continue
                        else:
                            if hasattr(surf, 'net'):
                                net = surf.net
                            else:
                                net = 'NONE'
                        tmp = extract_geometry((surf.geometry), tolerance=(layoutdb.tolerance / this.scale))
                        for s in tmp:
                            s.scale(this.scale)
                            s.heal(layoutdb.tolerance)
                            if s.empty():
                                continue
                            if s.sense() < 0:
                                s.reverse()
                            cswh = this.sp(s, sense=1, layer=dblayer, info='surface')
                            if cswh is not None:
                                layoutdb.add_net_dirty(net)
                                cswh.net_index = layoutdb.net_index(net)
                                dblayer.add_plane_shape(cswh)

                if hasattr(layer, 'meshplane'):
                    for meshplane in make_list(layer.meshplane):
                        try:
                            if hasattr(meshplane, 'net'):
                                net = meshplane.net
                            else:
                                net = 'NONE'
                            tmp = extract_meshplanes(meshplane.geometry)
                            for s in tmp:
                                s.scale(this.scale)
                                s.heal(layoutdb.tolerance)
                                if s.empty():
                                    continue
                                if s.sense() < 0:
                                    s.reverse()
                                cswh = this.sp(s, sense=1, layer=dblayer, info='surface')
                                if cswh is not None:
                                    layoutdb.add_net_dirty(net)
                                    cswh.net_index = layoutdb.net_index(net)
                                    dblayer.add_plane_shape(cswh)

                        except:
                            print('WARNING: meshplane can not be imported')

                if hasattr(layer, 'pad'):
                    for pad in make_list(layer.pad):
                        if hasattr(pad, 'net'):
                            net = pad.net
                        else:
                            net = 'NONE'
                        if hasattr(pad, 'geometry'):
                            pad_shapes = extract_geometry((pad.geometry), convert_line2shape=True,
                              tolerance=(layoutdb.tolerance / this.scale))
                            for shape in pad_shapes:
                                shape.scale(this.scale)
                                s = this.sp(shape, sense=1, info='pad')
                                s.net_index = layoutdb.net_index(net)
                                dblayer.add_plane_shape(s)

                        else:
                            lpad = this.add_library_pad(pad.data, layoutdb)
                            pos = pad.pt.XY
                            pos *= this.scale
                            angle = 0
                            if hasattr(pad, 'angle'):
                                angle = float(pad.angle) * pi / 180.0
                            for i in range(lpad.n_shapes()):
                                s = CShapeWithHoles(lpad.shape(i))
                                s.rotate(angle)
                                s.translate(pos)
                                s.net_index = layoutdb.net_index(net)
                                dblayer.add_plane_shape(s)

    def process_via_padstacks(this, layoutdb):
        layers = [l for l in make_list(this.pcf.boardContainer.boardLayout.layout.layer) if hasattr(l, 'systemLayer') if l.systemLayer.type == 'PADSTACK' if hasattr(l, 'padstack')]
        padstacks = []
        for l in layers:
            padstacks.extend(make_list(l.padstack))

        for padstack in padstacks:
            side = 'A'
            if hasattr(padstack, 'side'):
                side = padstack.side
            this.add_padstack(padstack, side, layoutdb)

    def add_padstack(this, padstack, placementside, layoutdb, is_comp=False, remove_unused_pads=False):
        connectmap = this.connectmap
        if hasattr(padstack.fromTo, 'data'):
            lfrom, lto = padstack.fromTo.data
        else:
            lfrom = lto = padstack.fromTo
        xy = padstack.pt.XY * this.scale
        angle = 0
        if hasattr(padstack, 'angle'):
            angle = float(padstack.angle) * pi / 180.0
        else:
            padstackname = padstack.data
            if hasattr(padstack, 'net'):
                net = padstack.net
            else:
                net = 'NONE'
            conductive, nonconductive = [], []
            if hasattr(padstack, 'conductive') and hasattr(padstack.conductive, 'layerNumber'):
                ok = True
                for i in make_list(padstack.conductive.layerNumber):
                    if type(i.data) != str:
                        ok = False
                        break
                    else:
                        num = i.data
                        connect = i.status.lower()
                        if connect in connectmap:
                            connect = connectmap[connect]
                        else:
                            connect = layoutdbPy.ConnectType.unknown
                    owngeom = None
                    if hasattr(i, 'geometry'):
                        owngeom = extract_geometry((i.geometry), tolerance=(layoutdb.tolerance / this.scale))
                        for s in owngeom:
                            s.scale(this.scale)

                    conductive.append((num, connect, owngeom))

                if not ok:
                    print('ERROR: unable to interpret padstack (skipped):\n%s' % str(padstack))
                    return
            flipX = False
            if hasattr(padstack, 'flipX'):
                if padstack.flipX:
                    flipX = True
            if hasattr(padstack, 'flip'):
                if padstack.flip == 'X':
                    flipX = True
                elif padstack.flip == 'Y':
                    print('WARNING: ignored flip Y')
            new_padstack = this.create_padstack(padstackname, placementside, xy, angle, lfrom, lto, net, conductive=conductive,
              nonconductive=nonconductive,
              layoutdb=layoutdb,
              flipX=flipX,
              remove_unused_pads=remove_unused_pads)
            if new_padstack is None:
                print('WARNING: unable to process padstack %s at %s' % (padstackname, str(xy)))
            else:
                if is_comp:
                    return new_padstack
                if new_padstack.net is None:
                    print('WARNING: via padstack at %s has no net' % str(new_padstack.position))
                layoutdb.add_padstack(new_padstack)

    def get_connect(this, lyr):
        assert lyr.Type == 'layerNumber'
        cl = lyr.data
        status = lyr.status.lower()
        if status in this.connectmap:
            return (cl, this.connectmap[status])
        else:
            return (
             cl, layoutdbPy.ConnectType.unknown)

    def add_pad_to_component(this, layoutdb, pads, comp, layer, ps, pin_layer_candidates=None, ps_needing_net=[], nets=set()):
        for lpad in make_list(pads):
            if hasattr(lpad, 'net'):
                nets.add(lpad.net)
            else:
                pad = this.add_library_pad(lpad.data, layoutdb)
                if hasattr(lpad, 'net'):
                    net = lpad.net
                else:
                    net = 'NONE'
            layoutdb.add_net_dirty(net)
            net = layoutdb.net(net)
            if pad:
                lpsname = 'padstack-cst-' + lpad.data + '-' + ps
                lps = layoutdb.lpadstack(lpsname)
                if lps is None:
                    lps = layoutdbPy.new_iLPadstack()
                    lps.name = lpsname
                    layoutdb.add_lpadstack(lps)
                if layer:
                    if lps.pad(layer, layoutdbPy.ConnectType.connect) is None:
                        lps.pad(layer, layoutdbPy.ConnectType.connect, pad)
                    else:
                        rot = 0
                        if hasattr(lpad, 'angle'):
                            rot += float(lpad.angle) * math.pi / 180
                        dps = layoutdbPy.new_iPadstack()
                        dps.library_padstack = lps
                        dps.position = lpad.pt.XY * this.scale
                        dps.rotation = rot
                        ps_needing_net.append(dps)
                        for lyr in layoutdb.layers():
                            dps.connect(lyr, layoutdbPy.ConnectType.connect)

                        if ps != 'A':
                            dps.is_x_mirrowed = True
                        dps.layer_from = layer
                        dps.layer_to = layer
                        dps.net = net
                        if pin_layer_candidates is not None:
                            pin_layer_candidates.add(layer.name)
                    comp.add_padstack(dps)
                else:
                    print("ERROR: missing pad '%s'" % lpad.data)
                if hasattr(lpad, 'geometry'):
                    tmp = extract_geometry((lpad.geometry), tolerance=(layoutdb.tolerance / this.scale))
                    for s in tmp:
                        s.scale(this.scale)
                        s.translate(-dps.position)
                        dpsrot = dps.rotation
                        s.rotate(-dpsrot, R2(0, 0))
                        if ps != 'A':
                            s.x_mirror()
                        cswh = this.sp(s)
                        if hasattr(lpad, 'net'):
                            net = lpad.net
                        else:
                            net = 'None'
                        layoutdb.add_net_dirty(net)
                        if cswh is not None:
                            lpad = layoutdbPy.new_iLPad()
                            lpad.add_shape(cswh)
                            lps = dps.library_padstack.clone()
                            lps.pad(layer, layoutdbPy.ConnectType.connect, lpad)
                            dps.library_padstack = lps
                            layoutdb.add_lpadstack(lps)

    def add_components(this, layoutdb):

        def comp_has_padstack(c, ps):
            for i in range(c.n_padstacks()):
                pst = c.padstack(i)
                if ps.position == pst.position:
                    if ps.net.name == pst.net.name:
                        if ps.library_padstack.name == pst.library_padstack.name:
                            if ps.layer_from.name == pst.layer_from.name:
                                if ps.layer_to.name == pst.layer_to.name:
                                    return True

            return False

        this.em_model_items = []
        has_wirebonds = False
        this.diecomp_pin_padstacks = {}
        wb_profiles = []
        this.diePadLayers = {}
        if not (hasattr(this.pcf.boardContainer, 'components') and hasattr(this.pcf.boardContainer.components, 'component')):
            return
        else:
            for comp in make_list(this.pcf.boardContainer.components.component):
                is_bga = False
                if hasattr(comp, 'outOfBoard'):
                    if comp.outOfBoard == 'YES':
                        print('Skipped out-of-board component %s' % comp.reference)
                        continue
                if hasattr(comp, 'placed'):
                    if comp.placed != 'YES':
                        print('Skipped non-placed component %s' % comp.reference)
                        continue
                new_comp = layoutdbPy.new_iComponent()
                new_comp.name = refdes = comp.reference
                partname = comp.part
                ps = comp.placementSide.upper()
                if ps not in 'AB':
                    print('WARNING: placementSide must be equal to A or B (using A)')
                    ps = 'A'
                if ps == 'A':
                    new_comp.side = layoutdbPy.WhereType.top
                else:
                    new_comp.side = layoutdbPy.WhereType.bottom
                new_comp.position = comp.location.pt.XY * this.scale
                if hasattr(comp, 'angle'):
                    new_comp.rotation = float(comp.angle) * pi / 180.0
                else:
                    new_comp.rotation = 0
                footprintname = comp.footprint
                if hasattr(comp, 'reverseFootprint'):
                    if ps == 'B':
                        footprintname = comp.reverseFootprint
                        ps = 'R'
                this.current_comp = new_comp.name
                ft = this.add_footprint(footprintname, ps, layoutdb)
                if ft is None:
                    print('WARNING: no footprint created for component %s at %s %s side (skipped)' % (new_comp.name, str(new_comp.position), new_comp.side))
                else:
                    pos, rot = new_comp.position, new_comp.rotation
                    zero = R2(0, 0)
                    for outline in ft['outlines']:
                        swh = outline.to_ShapeWithHoles()
                        if ps == 'A':
                            swh.rotate(rot, zero)
                            swh.translate(pos)
                        else:
                            swh.rotate(-rot, zero)
                            swh.x_mirror()
                            swh.translate(pos)
                        s = this.sp(swh, info='component outline')
                        if s is not None:
                            new_comp.add_outline_shape(s)

                    is_package = False
                    create_die = False
                    is_flip_chip = False
                    die_has_geometry = False
                    if hasattr(comp, 'packageSymbol') and comp.packageSymbol == 'YES' or hasattr(comp, 'package'):
                        is_package = True
                        is_top = ps == 'A'
                        if is_top:
                            comparea = 'CompArea-A'
                        else:
                            comparea = 'CompArea-B'
                        comp_geom = {}
                        comp_geom['cswhs'] = []
                        if hasattr(comp, 'layout'):
                            for layout in make_list(comp.layout):
                                for layer in make_list2(layout, 'layer'):
                                    if hasattr(layer, 'nonConductive'):
                                        if layer.nonConductive == comparea:
                                            if hasattr(layer, 'refer'):
                                                for refer in make_list(layer.refer):
                                                    if hasattr(refer, 'area'):
                                                        if hasattr(refer.area, 'geometry'):
                                                            die_has_geometry = True
                                                            tmp = extract_geometry((refer.area.geometry), tolerance=(layoutdb.tolerance / this.scale))
                                                            for s in tmp:
                                                                s.scale(this.scale)
                                                                s.rotate(rot, R2(0, 0))
                                                                s.translate(pos)
                                                                s.heal(layoutdb.tolerance)
                                                                if s.empty():
                                                                    continue
                                                                if s.sense() < 0:
                                                                    s.reverse()
                                                                cswh = this.sp(s)
                                                                if cswh is not None:
                                                                    comp_geom['cswhs'].append(cswh)
                                                                else:
                                                                    print('WARNING: unable to export component outline for ', new_comp.name)

                                                            if hasattr(refer.area, 'lowerHeight'):
                                                                comp_geom['hmin'] = float(refer.area.lowerHeight) * this.scale
                                                            else:
                                                                comp_geom['hmin'] = 0
                                                            if hasattr(refer.area, 'upperHeight'):
                                                                comp_geom['thickness'] = float(refer.area.upperHeight) * this.scale - comp_geom['hmin']
                                                            else:
                                                                comp_geom['thickness'] = 0

                                        if hasattr(layer, 'nonConductive') and layer.nonConductive.lower() == 'cavity' and hasattr(layer, 'refer') and hasattr(layer.refer, 'cavityFrom') and hasattr(layer.refer, 'cavityTo'):
                                            cavFrom = layer.refer.cavityFrom
                                            cavTo = layer.refer.cavityTo
                                            tmp = extract_geometry((layer.refer.surface.geometry), tolerance=(layoutdb.tolerance / this.scale))
                                            holes = []
                                            for s in tmp:
                                                s.scale(this.scale)
                                                s.rotate(rot, R2(0, 0))
                                                s.translate(pos)
                                                s.heal(layoutdb.tolerance)
                                                if s.empty():
                                                    continue
                                                if s.sense() > 0:
                                                    s.reverse()
                                                holes.append(s)

                                            this.create_cavity(layoutdb, cavFrom, cavTo, holes)

                        if hasattr(comp, 'pkgType'):
                            if comp.pkgType == 'PKGDIE':
                                if die_has_geometry:
                                    this.diecomp_pin_padstacks[new_comp.name.upper()] = {}
                                    create_die = True
                                    diestack = layoutdbPy.Diestack()
                                    diestack.name = new_comp.name
                                    diestack.is_top = is_top
                                    dlayer = layoutdbPy.new_iLayer()
                                    dlayer.layer_type = layoutdbPy.LayerType.Die
                                    dlayer.name = diestack.name
                                    dlayer.thickness = comp_geom['thickness']
                                    diestack.layer_elevation(dlayer.name, comp_geom['hmin'])
                                    dielayer = layoutdbPy.new_iLayer()
                                    dielayer.layer_type = layoutdbPy.LayerType.DiePads
                                    dielayer.name = dlayer.name + '-pads'
                                    dielayer.thickness = 0
                                    diestack.layer_elevation(dielayer.name, comp_geom['hmin'] + comp_geom['thickness'])
                                    diestack.add_component(new_comp, dielayer)
                                    if len(comp_geom['cswhs']):
                                        dlayer.outline = comp_geom['cswhs'][0]
                                        dielayer.outline = comp_geom['cswhs'][0]
                                    if comp.pkgDieType == 'PKGDIEFC':
                                        is_flip_chip = True
                                        new_comp.mount_type = layoutdbPy.MountType.flipchip
                                    else:
                                        new_comp.mount_type = layoutdbPy.MountType.wirebond
                                    if hasattr(comp, 'pkgPadHeight'):
                                        dielayer.thickness = float(comp.pkgPadHeight) * this.scale
                                    if hasattr(comp, 'pkgOffset'):
                                        if is_flip_chip:
                                            diestack.layer_elevation(dlayer.name, float(comp.pkgOffset) * this.scale + dielayer.thickness)
                                            diestack.layer_elevation(dielayer.name, float(comp.pkgOffset) * this.scale)
                                        else:
                                            diestack.layer_elevation(dlayer.name, float(comp.pkgOffset) * this.scale)
                                            diestack.layer_elevation(dielayer.name, float(comp.pkgOffset) * this.scale + dlayer.thickness)
                                    this.diePadLayers[new_comp.name] = dielayer
                                    if not layoutdb.has_layer('bare-chip'):
                                        dummy_layer = layoutdbPy.new_iLayer()
                                        dummy_layer.name = 'bare-chip'
                                        dummy_layer.layer_type = layoutdbPy.LayerType.DiePads
                                        layoutdb.add_layer_above(dummy_layer, dummy_layer)
                                else:
                                    print('WARNING: missing layout data for package component %s,(skipped).' % new_comp.name)
                            if comp.pkgType == 'PKGBALL':
                                new_comp.mount_type = layoutdbPy.MountType.bga
                                bgalayer = layoutdbPy.new_iLayer()
                                bgalayer.name = 'BGA'
                                bgalayer.layer_type = layoutdbPy.LayerType.BGA
                                bgalayer.thickness = float(comp.pkgPadHeight) * this.scale
                                if new_comp.side == layoutdbPy.WhereType.bottom:
                                    layoutdb.add_layer_below(bgalayer, bgalayer)
                                else:
                                    layoutdb.add_layer_above(bgalayer, bgalayer)
                                is_bga = True
                    additional_etch_candidates = []
                    embed_comp = hasattr(comp, 'placementLayNo')
                    if embed_comp:
                        new_comp.layer = layoutdb.layer(comp.placementLayNo)
                    else:
                        if ps == 'A':
                            new_comp.layer = layoutdb.top_etch_layer()
                        else:
                            new_comp.layer = layoutdb.bottom_etch_layer()
                    ok = True
                    additional_padstacks = []
                    if die_has_geometry:
                        diestack = layoutdbPy.Diestack()
                        diestack.name = new_comp.name
                        diestack.is_top = is_top
                        dlayer = layoutdbPy.new_iLayer()
                        dlayer.layer_type = layoutdbPy.LayerType.Die
                        dlayer.name = diestack.name
                        dlayer.thickness = comp_geom['thickness']
                        diestack.layer_elevation(dlayer.name, comp_geom['hmin'])
                        dielayer = layoutdbPy.new_iLayer()
                        dielayer.layer_type = layoutdbPy.LayerType.DiePads
                        dielayer.name = dlayer.name + '-pads'
                        diestack.add_component(new_comp, dielayer)
                        dielayer.thickness = 0
                        diestack.layer_elevation(dielayer.name, comp_geom['hmin'] + comp_geom['thickness'])
                        if len(comp_geom['cswhs']):
                            outline = comp_geom['cswhs'][0]
                            if len(comp_geom['cswhs']) > 1:
                                bb = outline.bbox
                                for i in range(1, len(comp_geom['cswhs'])):
                                    bb.extend(comp_geom['cswhs'][i].bbox)

                                p1 = R2(bb.xmin, bb.ymin)
                                p2 = R2(bb.xmax, bb.ymax)
                                outline = this.sp(utils2dPy.make_rectangle_shape(p1, p2, True))
                            dlayer.outline = outline
                            dielayer.outline = outline
                    if hasattr(comp, 'pin'):
                        for pin in make_list(comp.pin):
                            pin_ps = []
                            newpin = layoutdbPy.new_Pin()
                            newpin.position = pin.pt.XY * this.scale
                            newpin.name = pin.data
                            if hasattr(comp, 'placementLayNo'):
                                newpin.layer = layoutdb.layer(comp.placementLayNo)
                            nets = set()
                            ps_needing_net = []
                            pin_layer = None
                            pin_layer_candidates = set()
                            if hasattr(pin, 'layout'):
                                if hasattr(pin.layout, 'layer'):
                                    for layout in make_list(pin.layout):
                                        for l in make_list2(layout, 'layer'):
                                            if hasattr(l, 'systemLayer'):
                                                if l.systemLayer.type == 'PADSTACK':
                                                    pss4wb = []
                                                    for padstack in make_list2(l, 'padstack'):
                                                        dps = this.add_padstack(padstack, ps, layoutdb, True)
                                                        if embed_comp:
                                                            pin_ps.append(dps)
                                                        if dps:
                                                            if ps != 'A':
                                                                dps.is_x_mirrowed = True
                                                            if not comp_has_padstack(new_comp, dps):
                                                                new_comp.add_padstack(dps)
                                                                pss4wb.append(dps)
                                                            for l2 in layoutdb.layers():
                                                                if l2.is_etch() and len(dps.shapes(l2, layoutdb)) > 0:
                                                                    pin_layer_candidates.add(l2.name)

                                                        else:
                                                            pss4wb.append(None)

                                                    if create_die:
                                                        if new_comp.name.upper() in this.diecomp_pin_padstacks:
                                                            if newpin.name in this.diecomp_pin_padstacks[new_comp.name]:
                                                                this.diecomp_pin_padstacks[new_comp.name][newpin.name].extend(pss4wb)
                                                            else:
                                                                this.diecomp_pin_padstacks[new_comp.name][newpin.name] = pss4wb
                                                    for zpadstack in make_list2(l, 'padstack'):
                                                        if not hasattr(zpadstack, 'conductive'):
                                                            continue
                                                        if hasattr(zpadstack, 'net'):
                                                            nets.add(zpadstack.net)

                                                if hasattr(l, 'pad'):
                                                    if hasattr(l, 'conductive'):
                                                        this.add_pad_to_component(layoutdb, l.pad, new_comp, layoutdb.layer(l.conductive), ps, pin_layer_candidates, ps_needing_net, nets)
                                                if hasattr(l, 'conductive'):
                                                    if hasattr(l, 'refer') or hasattr(l, 'line') or hasattr(l, 'surface'):
                                                        additional_etch_candidates.append(l)
                                                        dblayer = layoutdb.layer(l.conductive)
                                                        if dblayer is not None:
                                                            pin_layer_candidates.add(l.conductive)
                                                        if hasattr(l, 'refer'):
                                                            if hasattr(l.refer, 'net'):
                                                                nets.add(l.refer.net)
                                                    if hasattr(l, 'line') and hasattr(l.line, 'net'):
                                                        nets.add(l.line.net)

                            pin_layer_candidates = list(pin_layer_candidates)
                            if len(pin_layer_candidates) == 1:
                                pin_layer = pin_layer_candidates[0]
                                pin_layer = layoutdb.layer(pin_layer)
                            if embed_comp:
                                if len(pin_ps) > 0:
                                    for ps_t in pin_ps:
                                        if ps_t.position == newpin.position:
                                            if abs(new_comp.layer.number - ps_t.layer_from.number) < abs(new_comp.layer.number - ps_t.layer_to.number):
                                                newpin.layer = ps_t.layer_from
                                            else:
                                                newpin.layer = ps_t.layer_to

                            if pin_layer is not None:
                                newpin.layer = pin_layer
                            if len(nets) == 0:
                                net = layoutdb.net('none')
                            else:
                                net = nets.pop()
                                if len(nets):
                                    print('WARNING: non-unique net for pin %s-%s (taking %s, ignoring %s)' % (new_comp.name, newpin.name, net, nets))
                                layoutdb.add_net_dirty(net)
                                net = layoutdb.net(net)
                            for dps in ps_needing_net:
                                dps.net = net

                            newpin.net = net
                            if new_comp.pin(newpin.name):
                                testpin = new_comp.pin(newpin.name)
                                if not (testpin.position == newpin.position and testpin.net.name == newpin.net.name and testpin.layer == newpin.layer):
                                    new_comp.add_pin(newpin)
                                else:
                                    new_comp.add_pin(newpin)
                                if hasattr(pin, 'bondwire'):
                                    bw_data = pin.bondwire
                                    if hasattr(bw_data, 'bwDiameter'):
                                        w = float(bw_data.bwDiameter) * this.scale
                                    else:
                                        w = 0
                                    prof_name = 'Jedec4-%.10g' % w
                                    if w not in wb_profiles:
                                        wb_profiles.append(w)
                            if hasattr(bw_data, 'bondwire'):
                                has_wirebonds = True
                                new_comp.mount_type = layoutdbPy.MountType.wirebond
                                if die_has_geometry:
                                    create_die = True
                                for bw in make_list(bw_data.bondwire):
                                    wb = layoutdbPy.Wirebond()
                                    if not len(bw.pt) == 2:
                                        raise AssertionError
                                    else:
                                        wb.position_from = bw.pt[0].XY * this.scale
                                        wb.position_to = bw.pt[1].XY * this.scale
                                        wb.net_index = layoutdb.net_index(net.name)
                                        if pin_layer == None:
                                            if ps == 'A':
                                                pin_layer = layoutdb.top_etch_layer()
                                            else:
                                                pin_layer = layoutdb.bottom_etch_layer()
                                        if is_package:
                                            if die_has_geometry:
                                                wb.layer_from = dielayer
                                        wb.layer_from = pin_layer
                                    wb.layer_to = pin_layer
                                    wb.profile_name = prof_name
                                    if new_comp.side == layoutdbPy.WhereType.bottom:
                                        wb.is_top = False
                                    layoutdb.add_wirebond(wb)

                        layers = set()
                        for ip in range(new_comp.n_pins()):
                            l = new_comp.pin(ip).layer
                            if l is not None:
                                layers.add(l.name)

                        layers = list(layers)
                        if len(layers) == 1:
                            l = layoutdb.layer(layers[0])
                            tn = layoutdb.top_etch_layer().number
                            bn = layoutdb.bottom_etch_layer().number
                            if l.number > tn:
                                if l.number < bn:
                                    new_comp.layer = l
                    if create_die:
                        if not is_bga:
                            layoutdb.add_diestack(diestack)
                            if is_top:
                                if is_flip_chip:
                                    layoutdb.add_layer_above(dielayer, None)
                                    layoutdb.add_layer_above(dlayer, None)
                                    diestack.add_layer(dlayer)
                                    diestack.add_layer(dielayer)
                                else:
                                    layoutdb.add_layer_above(dlayer, None)
                                    layoutdb.add_layer_above(dielayer, None)
                                    diestack.add_layer(dielayer)
                                    diestack.add_layer(dlayer)
                            else:
                                if is_flip_chip:
                                    layoutdb.add_layer_below(dielayer, None)
                                    layoutdb.add_layer_below(dlayer, None)
                                    diestack.add_layer(dielayer)
                                    diestack.add_layer(dlayer)
                                else:
                                    layoutdb.add_layer_below(dlayer, None)
                                    layoutdb.add_layer_below(dielayer, None)
                                    diestack.add_layer(dlayer)
                                    diestack.add_layer(dielayer)
                    if is_bga:
                        bigest_bga = None
                        for i in range(new_comp.n_padstacks()):
                            ps = new_comp.padstack(i)
                            padlayer = this.define_wb_layer([ps], ps.position, is_top)
                            pad = ps.library_padstack.pad(padlayer, layoutdbPy.ConnectType.connect)
                            if pad == None:
                                pad = ps.library_padstack.pad(padlayer, layoutdbPy.ConnectType.noconnect)
                            if pad != None:
                                bbox = pad.shape(0).bbox
                                if bbox.xmax - bbox.xmin > bbox.ymax - bbox.ymin:
                                    bgaradius = (bbox.xmax - bbox.xmin) / 2.0
                                else:
                                    bgaradius = (bbox.ymax - bbox.ymin) / 2.0
                            else:
                                bgaradius = layoutdb.tolerance * 10
                            if bigest_bga == None or bigest_bga < bgaradius:
                                bigest_bga = bgaradius
                            bump_shape = CShapeWithHoles(utils2dPy.make_circle_shape(R2(0, 0), bgaradius, True))
                            bump_shape.translate(ps.position)
                            bump_shape = this.sp(bump_shape, sense=1, info='bump')
                            if bump_shape is not None:
                                netname = ps.net.name
                                bump_shape.net_index = layoutdb.net_index(netname)
                                bgalayer.add_plane_shape(bump_shape)

                        if bigest_bga:
                            bgalayer.solder_ball_radius_center = bigest_bga
                            bgalayer.solder_ball_radius_top = bigest_bga / 2.0
                            bgalayer.solder_ball_radius_bottom = bigest_bga / 2.0
                        if hasattr(comp, 'layout'):
                            for layout in make_list(comp.layout):
                                for layer in make_list2(layout, 'layer'):
                                    if hasattr(layer, 'conductive') and (hasattr(layer, 'refer') or hasattr(layer, 'line') or hasattr(layer, 'surface')):
                                        additional_etch_candidates.append(layer)

                        for layer in additional_etch_candidates:
                            dblayer = layoutdb.layer(layer.conductive)
                            if dblayer is None:
                                pass
                            else:
                                list_surface = []
                                list_trace = []
                                if hasattr(layer, 'refer'):
                                    for ref in make_list(layer.refer):
                                        if hasattr(ref, 'surface'):
                                            for sur in make_list(ref.surface):
                                                list_surface.append([sur, True])

                                        if hasattr(ref, 'line'):
                                            for il in make_list(ref.line):
                                                list_trace.append([il, True])

                                if hasattr(layer, 'line'):
                                    for il in make_list(layer.line):
                                        list_trace.append([il, False])

                                if hasattr(layer, 'surface'):
                                    for sur in make_list(layer.surface):
                                        list_surface.append([sur, False])

                                for surf, need_transl in list_surface:
                                    if surf.Type != 'surface':
                                        print("ERROR: unable to interpret 'surface' geometry (skipped):\n%s" % str(surf))
                                    else:
                                        if hasattr(surf, 'net'):
                                            net = surf.net
                                        else:
                                            net = 'NONE'
                                        tmp = extract_geometry((surf.geometry), tolerance=(layoutdb.tolerance / this.scale))
                                        for s in tmp:
                                            s.scale(this.scale)
                                            if need_transl:
                                                s.rotate(rot, R2(0, 0))
                                                s.translate(pos)

                                        for s in tmp:
                                            s.heal(layoutdb.tolerance)
                                            if s.empty():
                                                pass
                                            else:
                                                if s.sense() < 0:
                                                    s.reverse()
                                                cswh = this.sp(s)
                                                layoutdb.add_net_dirty(net)
                                            if cswh is not None:
                                                cswh.net_index = layoutdb.net_index(net)
                                                dblayer.add_plane_shape(cswh)

                                for line, need_transl in list_trace:
                                    segments, widths = vertices2segments(line.geometry.line.vertex.vertices)
                                    if len(segments):
                                        trace = layoutdbPy.Trace()
                                        for i in range(len(segments)):
                                            seg = segments[i]
                                            seg.scale(this.scale)
                                            if need_transl:
                                                seg.rotate(rot, R2(0, 0))
                                                seg.translate(pos)
                                            width = widths[i]
                                            width *= this.scale
                                            if width > 0:
                                                trace.add_segment(seg, width)
                                            else:
                                                print('WARNING: skipped zero-width trace segment: ' + str(seg))

                                        if trace.n_segments() > 0:
                                            if hasattr(line, 'net'):
                                                net = line.net
                                            else:
                                                net = 'NONE'
                                            layoutdb.add_net_dirty(net)
                                            trace.net_index = layoutdb.net_index(net)
                                            dblayer.add_trace(trace)

                        if hasattr(comp, 'layout'):
                            for layout in make_list(comp.layout):
                                for layer in make_list2(layout, 'layer'):
                                    if hasattr(layer, 'systemLayer'):
                                        if layer.systemLayer.type == 'PADSTACK':
                                            additional_padstacks.extend(make_list2(layer, 'padstack'))
                                        if hasattr(layer, 'pad') and hasattr(layer, 'conductive'):
                                            this.add_pad_to_component(layoutdb, layer.pad, new_comp, layoutdb.layer(layer.conductive), ps)

                        ips = 0
                        for padstack in additional_padstacks:
                            dps = this.add_padstack(padstack, ps, layoutdb, True)
                            if dps:
                                if ps != 'A':
                                    dps.is_x_mirrowed = True
                                new_comp.add_padstack(dps)

                        new_comp.em_model = partname
                        value = ''
                        if hasattr(comp, 'passiveComponentValue'):
                            value = comp.passiveComponentValue
                        if hasattr(comp, 'passiveComponentType'):
                            typ = comp.passiveComponentType
                        elif new_comp.n_pins() == 2:
                            if len(refdes) > 0:
                                if refdes[0].upper() in ('R', 'L', 'C'):
                                    typ = new_comp.name[0].upper()
                        else:
                            typ = ''
                        this.em_model_items.append((new_comp.name, partname, typ, value))
                        if ok:
                            layoutdb.add_component(new_comp)
                        if die_has_geometry and new_comp.mount_type not in [layoutdbPy.MountType.flipchip, layoutdbPy.MountType.wirebond, layoutdbPy.MountType.bga]:
                            new_comp.height = comp_geom['thickness']
                            for s in comp_geom['cswhs']:
                                new_comp.add_outline_shape(s)

            from common.layoutdb import check_layer_stackup
            check_layer_stackup(layoutdb)
            layoutdb.update_elevations()
            from common.units import length_unit_convert
            if has_wirebonds:
                for w in wb_profiles:
                    prof_name = 'Jedec4-%.10g' % w
                    wb = layoutdbPy.new_WirebondProfile_JEDEC4(100)
                    if w != 0:
                        wb.diameter = length_unit_convert(layoutdb.length_unit, w, 'um')
                    else:
                        wb.diameter = 20
                    wb.is_forward = True
                    wb.name = prof_name
                    material = layoutdbPy.Material()
                    material.name = 'GOLD'
                    material.eps = material.mu = 1
                    wb.material = material
                    layoutdb.add_wirebond_profile(wb)

            from common.layoutdb import set_read_elements
            print('Reading component values...')
            warnings = set_read_elements(layoutdb, (this.em_model_items), print_warnings=False)
            for w in warnings:
                print(w)

            if len(this.em_model_items):
                filename = this.design_name + '.csv'
                from common.layoutdb import export_lumped_elements_to_csv
                try:
                    export_lumped_elements_to_csv(this.em_model_items, filename)
                    print('INFO: Created CSV file (' + filename + ') with lumped-element values for review/re-import.')
                except:
                    print('WARNING: unable to export lumped elements to CSV file (unable to write to file', filename, ')')

            else:
                print('WARNING: no CSV file created, because no component values found in %s-file ' % (layoutdb.name + '.ruf'))

    def create_padstack(this, name, placementside, xy, angle, lfrom, lto, net, flipX=False, conductive=[], nonconductive=[], layoutdb=None, remove_unused_pads=False):
        lpadstack = this.add_library_padstack(name, placementside, layoutdb)
        if lpadstack is None:
            return
        padstack = layoutdbPy.new_iPadstack()
        padstack.library_padstack = lpadstack
        padstack.position = xy
        padstack.rotation = angle
        padstack.is_x_mirrowed = flipX
        l = layoutdb.layer(lfrom)
        if l is None:
            print('WARNING: lfrom %s not found (padstack at %s)' % (lfrom, str(xy)))
            return
        padstack.layer_from = l
        l = layoutdb.layer(lto)
        if l is None:
            print('WARNING: lto %s not found (padstack at %s)' % (lto, str(xy)))
            return
        else:
            padstack.layer_to = l
            layoutdb.add_net_dirty(net)
            padstack.net = layoutdb.net(net)
            changed = False
            for num, connect, owngeom in conductive:
                layer = layoutdb.layer(num)
                if layer is None:
                    print('WARNING: layer %s not found for connect' % num)
                if connect != layoutdbPy.ConnectType.noconnect or not remove_unused_pads:
                    padstack.connect(layer, connect)
                if owngeom is not None:
                    netindex = layoutdb.net_index(net)
                    cswhs = []
                    for swh in owngeom:
                        swh.translate(-padstack.position)
                        rot = padstack.rotation
                        swh.rotate(-rot, R2(0, 0))
                        if padstack.is_x_mirrowed:
                            swh.x_mirror()
                        cswh = this.sp(swh, sense=1, info='padstack-aux-shape')
                        if cswh is not None:
                            cswhs.append(cswh)

                    if len(cswhs):
                        changed = True
                        lpad = layoutdbPy.new_iLPad()
                        for cswh in cswhs:
                            if isinstance(cswh, layoutdbPy.Trace):
                                cswhs = cswh.shapes(layoutdb.tolerance)
                                for s in cswhs:
                                    lpad.add_shape(s)

                            else:
                                lpad.add_shape(cswh)

                        lps = padstack.library_padstack.clone()
                        lps.pad(layer, connect, lpad)
                        padstack.library_padstack = lps

            if changed:
                lps = padstack.library_padstack.clone()
                lps_name = lps.name
                i = 1
                new_lps_name = lps_name + str(i)
                while layoutdb.has_lpadstack(new_lps_name):
                    i += 1
                    new_lps_name = lps_name + str(i)

                lps.name = new_lps_name
                padstack.library_padstack = lps
                layoutdb.add_lpadstack(lps)
            return padstack

    def add_library_padstack(this, name, placementside, layoutdb):
        if name not in this.padstacks:
            print('WARNING: padstack %s not found' % name)
            return
        else:
            padstack = this.padstacks[name]
            throughmode = padstack.throughMode
            through = throughmode.upper() == 'THROUGH'
            if placementside == 'R':
                placementside = 'B'
            if through:
                placementside += '_THRU'
            dbname = name + '-' + placementside
            if layoutdb.has_lpadstack(dbname):
                return layoutdb.lpadstack(dbname)
            else:
                if placementside in this.foot2boardlayer_maps:
                    foot2clmap = this.foot2boardlayer_maps[placementside]
                else:
                    print("ERROR: no footprint-to-boardlayer mapping for placement '%s'" % placementside)
                return
            new_lpadstack = layoutdbPy.new_iLPadstack()
            new_lpadstack.name = dbname
            pstype = padstack.type
            new_lpadstack.is_via_plated = pstype == 'PLATED' or through
            if hasattr(padstack, 'hole'):
                hole = padstack.hole
                if not hasattr(hole, 'geometry'):
                    print('WARNING: unrecognized via hole (skipped):\n', hole)
                else:
                    if hasattr(hole.geometry, 'circle'):
                        r = float(hole.geometry.circle.data) * this.scale
                        offset = hole.geometry.circle.pt.XY
                        offset *= this.scale
                        if r > 0:
                            new_lpadstack.via_hole_shape = utils2dPy.make_circle_shape(offset, r, True)
                        else:
                            print('WARNING: broken via at position ', offset)
                    else:
                        if hasattr(hole.geometry, 'squareHole'):
                            r = float(hole.geometry.squareHole.r) * this.scale
                            offset = hole.geometry.squareHole.pt.XY
                            offset *= this.scale
                            a, b = offset + R2(-r, -r), offset + R2(r, r)
                            if a != b:
                                new_lpadstack.via_hole_shape = utils2dPy.make_rectangle_shape(a, b, True)
                            else:
                                print('WARNING: broken square via at position ', offset)
                        else:
                            if hasattr(hole.geometry, 'oval'):
                                oval = hole.geometry.oval
                                width = float(oval.width) * this.scale
                                height = float(oval.height) * this.scale
                                if width > height:
                                    width, height = height, width
                                angle = float(oval.ovalAngle) * pi / 180.0
                                pos = oval.pt.XY
                                pos *= this.scale
                                if width == height:
                                    new_lpadstack.via_hole_shape = utils2dPy.make_circle_shape(pos, width / 2.0, True)
                                else:
                                    dx = R2(height * 0.5 - width * 0.5, 0)
                                    seg = CurveSegment(pos - dx, pos + dx)
                                    shape = utils2dPy.thicken_curvesegment(seg, width, True, layoutdb.tolerance, True)
                                    shape = shape.shape
                                    shape.rotate(angle)
                                    new_lpadstack.via_hole_shape = shape
                            else:
                                print('WARNING: unrecognized hole (skipped):\n', hole)
            if hasattr(padstack, 'padSet'):
                for padset in make_list(padstack.padSet):
                    footname = clname = ''
                    if hasattr(padset, 'footLayer'):
                        footname = padset.footLayer
                    if footname not in foot2clmap:
                        pass
                    else:
                        is_conductor_layer, layernames = foot2clmap[footname]
                        for layername in layernames:
                            layer = layoutdb.layer(layername)
                            if hasattr(padset, 'connect'):
                                lpad = this.add_library_pad(padset.connect.pad, layoutdb)
                                new_lpadstack.pad(layer, layoutdbPy.ConnectType.connect, lpad)
                            if hasattr(padset, 'noconnect'):
                                lpad = this.add_library_pad(padset.noconnect.pad, layoutdb)
                                new_lpadstack.pad(layer, layoutdbPy.ConnectType.noconnect, lpad)
                            if hasattr(padset, 'clearance'):
                                lpad = this.add_library_pad(padset.clearance.pad, layoutdb)
                                new_lpadstack.pad(layer, layoutdbPy.ConnectType.clearance, lpad)
                            if hasattr(padset, 'thermal'):
                                lpad = this.add_library_pad(padset.thermal.pad, layoutdb)
                                new_lpadstack.pad(layer, layoutdbPy.ConnectType.thermal, lpad)

            layoutdb.add_lpadstack(new_lpadstack)
            return new_lpadstack

    def add_library_pad(this, name, layoutdb):
        if layoutdb.has_lpad(name):
            return layoutdb.lpad(name)
        else:
            if name not in this.pads:
                print('WARNING: library pad %s not found in .ftf file' % name)
                return
            else:
                pad = this.pads[name]
                assert pad.Type == 'pad'
            shapes = extract_geometry((pad.geometry), convert_line2shape=True, tolerance=(layoutdb.tolerance / this.scale))
            lpad = layoutdbPy.new_iLPad()
            lpad.name = name
            for shape in shapes:
                try:
                    shape.scale(this.scale)
                    cswh = this.sp(shape, sense=1, info='pad')
                    if cswh is not None:
                        lpad.add_shape(cswh)
                except:
                    print('WARNING: unable to process geometry of pad ', name)

            layoutdb.add_lpad(lpad)
            return lpad

    def create_pads(this, pads, connect, layoutdb):
        for lyrnum, connect, owngeom in conductive:
            connect = connect.lower()
            layername = lyrnum
            icl = int(lyrnum)
            if not icl < int(lfrom):
                if icl > int(lto):
                    pass
                else:
                    dblayer = layoutdb.layer(layername)
                    if owngeom is None:
                        if connect == 'connect':
                            if layername in connect_pads:
                                padname = connect_pads[layername]
                            else:
                                if connect == 'noconnect':
                                    if layername in no_connect_pads:
                                        padname = no_connect_pads[layername]
                                if connect == 'clearance':
                                    if layername in clearance_pads:
                                        padname = clearance_pads[layername]
                            if connect == 'thermal':
                                if layername in thermal_pads:
                                    padname = thermal_pads[layername]
                                else:
                                    continue
                                shapes = this.get_padshape(padname, layoutdb.tolerance)
                                if shapes is None:
                                    print('WARNING: pad %s (pos=%s) not found in database' % (padname, str(xy)))
                                    continue
                                    for s in shapes:
                                        if flipX:
                                            s.x_mirror()
                                        if angle != 0:
                                            s.rotate(angle, R2(0, 0))
                                        s.translate(xy)

                                else:
                                    shapes = owngeom
                                    for s in shapes:
                                        s.scale(this.scale)

                                if connect in ('clearance', 'thermal'):
                                    sense = -1
                                else:
                                    if connect == 'noconnect':
                                        if dblayer.positive:
                                            sense = 1
                                            continue
                                        else:
                                            sense = -1
                                    else:
                                        if connect == 'connect':
                                            sense = 1
                                        else:
                                            print('ERROR: unknown connect status %s (%s, %s)' % (str(connect), name, str(lyrnum) + ' ' + str(pos)))
                                            continue
                    for s in shapes:
                        if sense > 0:
                            dblayer.add_shape(s, net=net)
                        else:
                            utils2d.Make_Clockwise(s)
                            dblayer.add_hole2(s)

    def process_rules(this, layoutdb):
        from common.helpers import float_with_unit, interpret_rlc_values
        if this.ruf is None:
            if this.tech_data is None:
                print('WARNING: no Zuken rule file (%s) found: Stackup specification and RLC values will be incomplete' % (layoutdb.name + '.ruf'))
                return
        try:
            if hasattr(this.ruf, 'assign') and hasattr(this.ruf.assign, 'comp'):
                this.em_model_items = []
                for comp in make_list(this.ruf.assign.comp):
                    comp_name = re.sub('"', '', comp.data)
                    if layoutdb.has_component(comp_name):
                        component = layoutdb.component(comp_name)
                        if component:
                            comp_name = component.name
                            typ = comp_name[0].upper()
                            if hasattr(comp, 'assign') and hasattr(comp.assign, 'part'):
                                partname = comp.assign.part
                                value = ''
                                if hasattr(comp, 'value'):
                                    value = comp.value
                                else:
                                    if hasattr(comp, 'Value'):
                                        value = comp.Value
                                if hasattr(comp, 'propertyS'):
                                    for i in make_list(comp.propertyS):
                                        if hasattr(i, 'data'):
                                            data = make_list(i.data)
                                            if len(data) == 2 and data[0].lower() == 'value':
                                                value = data[1]

                                this.em_model_items.append((comp_name, partname, typ, value))

                from common.layoutdb import set_read_elements
                print('Reading component values...')
                warnings = set_read_elements(layoutdb, (this.em_model_items), print_warnings=False)
                print()
                for w in warnings:
                    print(w)

                if len(this.em_model_items):
                    filename = this.design_name + '.csv'
                    from common.layoutdb import export_lumped_elements_to_csv
                    try:
                        export_lumped_elements_to_csv(this.em_model_items, filename)
                        print('INFO: Created CSV file (' + filename + ') with lumped-element values for review/re-import.')
                    except:
                        print('WARNING: unable to export lumped elements to CSV file (unable to write to file', filename, ')')

                else:
                    print('WARNING: no CSV file created, because no component values found in %s-file ' % (layoutdb.name + '.ruf'))
        except:
            return

    def get_padshape(this, name, tolerance):
        if name not in this.pads:
            return
        else:
            pad = this.pads[name]
            if not hasattr(pad, 'cst_shapes'):
                create_padshape(pad, tolerance / this.scale)
            res = [s.clone() for s in pad.cst_shapes]
            for s in res:
                s.scale(this.scale)

            return res

    def check_noconnect_pads(this, layoutdb):
        lpss = []
        for c in layoutdb.components():
            for i in range(c.n_padstacks()):
                p = c.padstack(i)
                lpss.append(p.library_padstack)

        for i in range(layoutdb.n_padstacks()):
            lpss.append(layoutdb.padstack(i).library_padstack)

        for l in [layoutdb.top_etch_layer(), layoutdb.bottom_etch_layer()]:
            for lps in lpss:
                if lps.pad(l, layoutdbPy.ConnectType.noconnect) == None and lps.pad(l, layoutdbPy.ConnectType.connect) != None:
                    lps.pad(l, layoutdbPy.ConnectType.noconnect, lps.pad(l, layoutdbPy.ConnectType.connect))

    def correct_die_pad_layers(this, layoutdb):
        from common.layoutdb import correct_die_pad_layers
        for comp_name in list(this.diePadLayers.keys()):
            oldL_newL = [
             [
              layoutdb.layer('bare-chip'), this.diePadLayers[comp_name]]]
            correct_die_pad_layers(layoutdb, comp_name, oldL_newL)

        layoutdb.delete_layer(layoutdb.layer('bare-chip'))
        for c, pins in this.diecomp_pin_padstacks.items():
            comp = layoutdb.component(c)
            pin_layer = layoutdb.diestack(c).pin_layer(comp, layoutdb)
            for pinname, pss in pins.items():
                for ps in pss:
                    if ps.layer_from == ps.layer_to and ps.layer_from == pin_layer:
                        pin = comp.pin(pinname)
                        pin.position = ps.position
                        pin.layer = pin_layer

    def define_wb_layer(this, ps_list, ps_pos, is_top):
        for ps in ps_list:
            if ps.position == ps_pos:
                if ps.layer_from == ps.layer_to:
                    return ps.layer_from
                else:
                    if is_top:
                        return ps.layer_from
                    return ps.layer_to

    def process_bondwires(this, layoutdb):
        this.profile_diameters = {}
        warning = None
        if hasattr(this.pcf.boardContainer, 'bondwires') and hasattr(this.pcf.boardContainer.bondwires, 'bondwire'):
            for bw in make_list(this.pcf.boardContainer.bondwires.bondwire):
                prof_num = bw.bwProfileNumber
                if bw.bwIsGenerated != 'ON':
                    pass
                else:
                    if hasattr(bw, 'bwDiameter'):
                        w = float(bw.bwDiameter) * this.scale
                    else:
                        w = 20
                if prof_num in this.profile_diameters:
                    if w not in this.profile_diameters[prof_num]:
                        this.profile_diameters[prof_num].append(w)
                    else:
                        this.profile_diameters[prof_num] = [
                         w]
                    prof_name = 'Zuken-' + prof_num + '-' + str(w)
                    wb = layoutdbPy.Wirebond()
                    wb.position_from = bw.bwStartPad.pt.XY * this.scale
                    wb.position_to = bw.bwEndPad.pt.XY * this.scale
                    comp1 = bw.bwStartPad.reference.upper()
                    pin1 = bw.bwStartPad.pin
                    if layoutdb.component(comp1).side == layoutdbPy.WhereType.top:
                        is_top1 = True
                    else:
                        is_top1 = False
                    comp2 = bw.bwEndPad.reference.upper()
                    warning = comp1.upper() in this.diecomp_pin_padstacks and comp1.upper() in this.diecomp_pin_padstacks or 'WARNING: some wirebonds cannot be created because of missing die geometry'
                else:
                    if pin1 in this.diecomp_pin_padstacks[comp1.upper()]:
                        wb.layer_from = this.define_wb_layer(this.diecomp_pin_padstacks[comp1][pin1], wb.position_from, is_top1)
                    else:
                        pin2 = bw.bwEndPad.pin
                        if layoutdb.component(comp2).side == layoutdbPy.WhereType.top:
                            is_top2 = True
                        else:
                            is_top2 = False
                        if pin2 in this.diecomp_pin_padstacks[comp2.upper()]:
                            wb.layer_to = this.define_wb_layer(this.diecomp_pin_padstacks[comp2][pin2], wb.position_to, is_top2)
                        wb.profile_name = prof_name
                        if is_top1 == is_top2:
                            wb.is_top = is_top1
                        else:
                            print('Warning: unclear defined wirebond side!!!!')
                    if wb.layer_to == None or wb.layer_from == None:
                        print('Warning: bondwire layers could not be interpreted, skiped :', bw)
                    else:
                        layoutdb.add_wirebond(wb)

        if warning:
            print(warning)

    def process_wirebond_profiles(this, layoutdb):
        if hasattr(this.pcf.boardContainer, 'bondwires') and hasattr(this.pcf.boardContainer.bondwires, 'bwProfile'):
            from common.units import length_unit_convert
            material = layoutdbPy.Material()
            material.name = 'GOLD'
            material.eps = material.mu = 1
            for pf in make_list(this.pcf.boardContainer.bondwires.bwProfile):
                profile = layoutdbPy.vectorR2()
                if pf.bwReverse == 'OFF':
                    profile.append(utils2dPy.R2(3, float(pf.bwAngle1) * math.pi / 180))
                    profile.append(utils2dPy.R2(1, length_unit_convert(layoutdb.length_unit, float(pf.bwHeight) * this.scale, 'um')))
                    profile.append(utils2dPy.R2(2, float(pf.bwRatio1)))
                    profile.append(utils2dPy.R2(1, length_unit_convert(layoutdb.length_unit, float(pf.bwHeight2) * this.scale, 'um')))
                    profile.append(utils2dPy.R2(4, 0))
                    profile.append(utils2dPy.R2(0, 0))
                    profile.append(utils2dPy.R2(2, float(pf.bwRatio2)))
                    profile.append(utils2dPy.R2(3, float(pf.bwAngle2) * math.pi / 180))
                else:
                    profile.append(utils2dPy.R2(2, float(pf.bwRatio2)))
                    profile.append(utils2dPy.R2(3, float(pf.bwAngle2) * math.pi / 180))
                    profile.append(utils2dPy.R2(2, float(pf.bwRatio1)))
                    profile.append(utils2dPy.R2(5, length_unit_convert(layoutdb.length_unit, float(pf.bwHeight) * this.scale, 'um')))
                    profile.append(utils2dPy.R2(4, 0))
                    profile.append(utils2dPy.R2(0, 0))
                    profile.append(utils2dPy.R2(3, float(pf.bwAngle1) * math.pi / 180))
                    profile.append(utils2dPy.R2(1, length_unit_convert(layoutdb.length_unit, float(pf.bwHeight1) * this.scale, 'um')))
                prof_num = pf.bwProfileNumber
                if prof_num in list(this.profile_diameters.keys()):
                    for w in this.profile_diameters[prof_num]:
                        wb = layoutdbPy.new_WirebondProfile_CADENCE(profile)
                        wb.is_forward = pf.bwReverse == 'OFF'
                        prof_name = 'Zuken-' + prof_num + '-' + str(w)
                        wb.name = prof_name
                        wb.material = material
                        wb.diameter = length_unit_convert(layoutdb.length_unit, w, 'um')
                        layoutdb.add_wirebond_profile(wb)

                    this.profile_diameters[prof_num].append('created_in_ldb')

        for prof_num, diameters in this.profile_diameters.items():
            if 'created_in_ldb' not in diameters:
                print('WARNING: missing definition of bond wire profile %s, use default profile.' % prof_num)
                for w in diameters:
                    prof_name = 'Zuken-' + prof_num + '-' + str(w)
                    wb = layoutdbPy.new_WirebondProfile_JEDEC4(100)
                    wb.diameter = length_unit_convert(layoutdb.length_unit, w, 'um')
                    wb.is_forward = True
                    wb.name = prof_name
                    material = layoutdbPy.Material()
                    material.name = 'GOLD'
                    material.eps = material.mu = 1
                    wb.material = material
                    layoutdb.add_wirebond_profile(wb)

    def create_cavity(this, layoutdb, cavFrom, cavTo, holes):
        lfrom = layoutdb.layer(cavFrom).number
        lto = layoutdb.layer(cavTo).number
        for i in range(lfrom, lto):
            l = layoutdb.layer(i)
            if l.layer_type == layoutdbPy.LayerType.Dielectric:
                if l.outline:
                    shape = l.outline
                else:
                    shape = CShapeWithHoles(layoutdb.board_outline)
                for h in holes:
                    ch = utils2d.CShape(h, layoutdb.tolerance)
                    if ch.sense() == 1:
                        ch.reverse()
                    shape.add_hole(ch)

                l.outline = this.sp(shape, sense=1, info='cavity')

    def process_cavities(this, layoutdb):
        if hasattr(this.pcf.boardContainer, 'boardLayout'):
            for layer in make_list(this.pcf.boardContainer.boardLayout.layout.layer):
                if hasattr(layer, 'nonConductive') and layer.nonConductive.lower() == 'cavity' and hasattr(layer, 'surface'):
                    for surface in make_list(layer.surface):
                        if hasattr(surface, 'cavityFrom') and hasattr(surface, 'cavityTo'):
                            cavFrom = surface.cavityFrom
                            cavTo = surface.cavityTo
                            tmp = extract_geometry((surface.geometry), tolerance=(layoutdb.tolerance / this.scale))
                            for s in tmp:
                                s.scale(this.scale)

                            this.create_cavity(layoutdb, cavFrom, cavTo, tmp)


def read_partback_file(filename):
    from common.layoutdb import make_Part, vectorPin, Pin, Part
    prf = read_z(filename)
    if not hasattr(prf, 'part'):
        print('ERROR: no parts found in file %s.' % filename)
        return []
    else:
        res = []
        for part in make_list(prf.part):
            partno = part.data.strip('"')
            typ, value = (None, None)
            if hasattr(part, 'symbolName1'):
                if part.symbolName1[0].upper() in 'RLC':
                    typ = part.symbolName1[0].upper()
                if typ is not None and hasattr(part, 'value'):
                    from common.helpers import interpret_rlc_values
                    value = interpret_rlc_values(part.value, typ[0])
                    if value is not None:
                        typ2 = {'R':'resistor', 
                         'L':'inductor',  'C':'capacitor'}[typ]
                        pins = vectorPin()
                        pins.append(Pin())
                        pins.append(Pin())
                        partdb = make_Part(typ2, {'value':value,  'number':partno,  'pins':pins})
                        res.append(partdb)
                    else:
                        partdb = Part()
                        partdb.number = partno
                        res.append(partdb)

        return res


def Run(filename, importer):
    print('=' * 60)
    print('Reading Zuken CR-5000/8000 database ...\n')
    e = Export(filenamebase=(importer.filenamebase), progressbar=importer)
    layoutdb = e.to_LayoutDB()
    print('Finished reading database.')
    print('=' * 60)
    if layoutdb is not None:
        importer.db = layoutdb
    return 0


if __name__ == '__main__':
    import sys
    e = Export(filenamebase=(sys.argv[1]))
    db = e.to_LayoutDB()
