# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\itf_import\itf_parser.py
# Compiled at: 2018-09-27 17:04:18
# Size of source mod 2**32: 67895 bytes
from pyparsing import *
COMMENT_IGNORE = NoMatch()
RAW_PARSING = False
ParserElement.enablePackrat()
try:
    try:
        from . import itf_parser_ext
    except:
        import sys
        sys.path.append('.')
        import itf_parser_ext

    try:
        COMMENT_IGNORE = itf_parser_ext.comment_to_ignore()
    except:
        pass

except ImportError:
    pass

def AIR_GAP_VS_SPACING_TABLE():
    """Code that is able to parse:

    AIR_GAP_VS_SPACING {
        SPACINGS { <vector(n)> }
        AIR_GAP_WIDTHS { <vector(n)> }
        AIR_GAP_THICKNESSES { <vector(n)> }
        AIR_GAP_BOTTOM_HEIGHTS { <vector(n)> }
    }"""
    res = (CaselessKeyword('AIR_GAP_VS_SPACING') & Literal('{').suppress() + Group(CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('AIR_GAP_WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('AIR_GAP_THICKNESSES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('AIR_GAP_BOTTOM_HEIGHTS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('AIR_GAP_VS_SPACING_TABLE', res)
    return res


def area_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('area_value', res)
    return res


def BACKGROUND_ER():
    """Code that is able to parse:
 BACKGROUND_ER = <value>"""
    res = Assignment('BACKGROUND_ER', itf_parser_ext.parser('<value>')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('BACKGROUND_ER', res)
    return res


def BACKSIDE_ITF_STATEMENTS():
    """Code that is able to parse:

    <STACK_LAYERS> <VIA_LAYERS>
    [<STACK_LAYERS> [<VIA_LAYERS>]]"""
    res = (STACK_LAYERS() & VIA_LAYERS() & Optional(STACK_LAYERS() & Optional(VIA_LAYERS()))).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('BACKSIDE_ITF_STATEMENTS', res)
    return res


def bool_value():
    """Code that is able to parse:
 'YES | NO'"""
    res = (CaselessKeyword('YES') ^ CaselessKeyword('NO')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('bool_value', res)
    return res


def bottom_thickness_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('bottom_thickness_value', res)
    return res


def BOTTOM_THICKNESS_VS_SI_WIDTH_TABLE():
    """Code that is able to parse:

    BOTTOM_THICKNESS_VS_SI_WIDTH
    ['RESISTIVE_ONLY_ETCH | CAPACITIVE_ONLY_ETCH'] {
        <btvsiw_value_pair>+
    }"""
    res = (CaselessKeyword('BOTTOM_THICKNESS_VS_SI_WIDTH') & Optional(CaselessKeyword('RESISTIVE_ONLY_ETCH') ^ CaselessKeyword('CAPACITIVE_ONLY_ETCH')) & Literal('{').suppress() + Group(OneOrMore(btvsiw_value_pair())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('BOTTOM_THICKNESS_VS_SI_WIDTH_TABLE', res)
    return res


def box_size():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('box_size', res)
    return res


def btvsiw_value_pair():
    """Code that is able to parse:
 ( <si_width_value> [,] <bottom_thickness_value> )"""
    res = Group(Literal('(').suppress() + si_width_value() + Optional(Literal(',').suppress()) + bottom_thickness_value() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('btvsiw_value_pair', res)
    return res


def CONDUCTING_LAYER():
    """Code that is able to parse:
 <CONDUCTOR_KW> <conductor_name_pp> <CONDUCTOR_PARAMS>"""
    res = (CONDUCTOR_KW() & conductor_name_pp() & CONDUCTOR_PARAMS()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('CONDUCTING_LAYER', res)
    return res


def CONDUCTOR_KW():
    """Code that is able to parse:
 CONDUCTOR"""
    res = CaselessKeyword('CONDUCTOR').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('CONDUCTOR_KW', res)
    return res


def conductor_name():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('conductor_name', res)
    return res


def conductor_name_pp():
    """Code that is able to parse:
 <conductor_name>"""
    res = conductor_name().ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('conductor_name_pp', res)
    return res


def CONDUCTOR_PARAMS():
    """Code that is able to parse:
 {
    WMIN = <value> SMIN = <value> THICKNESS = <value>
    [<AIR_GAP_VS_SPACING_TABLE>]
    [<DIEL_FILL_VS_SI_SPACING_TABLE>]
    [BOTTOM_DIELECTRIC_THICKNESS = <value>
    BOTTOM_DIELECTRIC_ER = <value>]
    ['MEASURED_FROM = <dielectric_name> | <BOTTOM_THICKNESS_VS_SI_WIDTH_TABLE>']
    [T0 = <value>]
    ['CRT1 = <value> | CRT2 = <value> | CRT1 = <value> CRT2 = <value> | <CRT_VS_SI_WIDTH_TABLE>']
    [<DENSITY_BOX_WEIGHTING_FACTOR_TABLE>]
    [<DEVICE_TYPE_LIST>]
    [DROP_FACTOR = <value>]
    [ETCH = <value>]
        [CAPACITIVE_ONLY_ETCH = <value>]
        [RESISTIVE_ONLY_ETCH = <value>]
    [<ETCH_VS_WIDTH_AND_SPACING_TABLE>]
    [FILL_RATIO = <value> FILL_WIDTH = <value>
        FILL_SPACING = <value> [FILL_TYPE = 'GROUNDED | FLOATING']]
    [GATE_TO_CONTACT_SMIN = <value>]
    [<GATE_TO_DIFFUSION_CAP_TABLE>]
    [<ILD_VS_WIDTH_AND_SPACING_TABLE>]
    [<IS_PLANAR>]
    [LAYER_TYPE = 'GATE | FIELD_POLY | DIFFUSION | TRENCH_CONTACT | BUMP | FLOATING_GATE' ]
    [<POLYNOMIAL_BASED_THICKNESS_VARIATION_TABLE>]
    [RAISED_DIFFUSION_ETCH = <value>
        RAISED_DIFFUSION_THICKNESS = <value>
        RAISED_DIFFUSION_TO_GATE_SMIN = <value>
        [RAISED_DIFFUSION_GATE_SIDE_CONFORMAL_ER= <value>]]
    ['RPSQ = <value> 
        | RHO = <value> | <RPSQ_VS_SI_WIDTH_TABLE>
        | <RPSQ_VS_WIDTH_AND_SPACING_TABLE>
        | <RHO_VS_SI_WIDTH_AND_THICKNESS_TABLE>
        | <RHO_VS_WIDTH_AND_SPACING_TABLE>']
    [SIDE_TANGENT = <value>]
    [<THICKNESS_VS_DENSITY_TABLE>[<DENSITY_BOX_WEIGHTING_FACTOR_TABLE>]]
    [<THICKNESS_VS_WIDTH_AND_SPACING_TABLE>]
    [<TVF_FILE> <TVF_ADJUSTMENT_TABLES>]
    [<FLOATING_GATE_TO_DIFFUSION_CONTACT_CAP_TABLE>]
}"""
    res = (Literal('{').suppress() + Group(Assignment('WMIN', itf_parser_ext.parser('<value>')) & Assignment('SMIN', itf_parser_ext.parser('<value>')) & Assignment('THICKNESS', itf_parser_ext.parser('<value>')) & Optional(AIR_GAP_VS_SPACING_TABLE()) & Optional(DIEL_FILL_VS_SI_SPACING_TABLE()) & Optional(Assignment('BOTTOM_DIELECTRIC_THICKNESS', itf_parser_ext.parser('<value>')) & Assignment('BOTTOM_DIELECTRIC_ER', itf_parser_ext.parser('<value>'))) & Optional(Assignment('MEASURED_FROM', dielectric_name()) ^ BOTTOM_THICKNESS_VS_SI_WIDTH_TABLE()) & Optional(Assignment('T0', itf_parser_ext.parser('<value>'))) & Optional(Assignment('CRT1', itf_parser_ext.parser('<value>')) ^ Assignment('CRT2', itf_parser_ext.parser('<value>')) ^ Assignment('CRT1', itf_parser_ext.parser('<value>')) & Assignment('CRT2', itf_parser_ext.parser('<value>')) ^ CRT_VS_SI_WIDTH_TABLE()) & Optional(DENSITY_BOX_WEIGHTING_FACTOR_TABLE()) & Optional(DEVICE_TYPE_LIST()) & Optional(Assignment('DROP_FACTOR', itf_parser_ext.parser('<value>'))) & Optional(Assignment('ETCH', itf_parser_ext.parser('<value>'))) & Optional(Assignment('CAPACITIVE_ONLY_ETCH', itf_parser_ext.parser('<value>'))) & Optional(Assignment('RESISTIVE_ONLY_ETCH', itf_parser_ext.parser('<value>'))) & Optional(ETCH_VS_WIDTH_AND_SPACING_TABLE()) & Optional(Assignment('FILL_RATIO', itf_parser_ext.parser('<value>')) & Assignment('FILL_WIDTH', itf_parser_ext.parser('<value>')) & Assignment('FILL_SPACING', itf_parser_ext.parser('<value>')) & Optional(Assignment('FILL_TYPE', CaselessKeyword('GROUNDED') ^ CaselessKeyword('FLOATING')))) & Optional(Assignment('GATE_TO_CONTACT_SMIN', itf_parser_ext.parser('<value>'))) & Optional(GATE_TO_DIFFUSION_CAP_TABLE()) & Optional(ILD_VS_WIDTH_AND_SPACING_TABLE()) & Optional(IS_PLANAR()) & Optional(Assignment('LAYER_TYPE', CaselessKeyword('GATE') ^ CaselessKeyword('FIELD_POLY') ^ CaselessKeyword('DIFFUSION') ^ CaselessKeyword('TRENCH_CONTACT') ^ CaselessKeyword('BUMP') ^ CaselessKeyword('FLOATING_GATE'))) & Optional(POLYNOMIAL_BASED_THICKNESS_VARIATION_TABLE()) & Optional(Assignment('RAISED_DIFFUSION_ETCH', itf_parser_ext.parser('<value>')) & Assignment('RAISED_DIFFUSION_THICKNESS', itf_parser_ext.parser('<value>')) & Assignment('RAISED_DIFFUSION_TO_GATE_SMIN', itf_parser_ext.parser('<value>')) & Optional(Assignment('RAISED_DIFFUSION_GATE_SIDE_CONFORMAL_ER', itf_parser_ext.parser('<value>')))) & Optional(Assignment('RPSQ', itf_parser_ext.parser('<value>')) ^ Assignment('RHO', itf_parser_ext.parser('<value>')) ^ RPSQ_VS_SI_WIDTH_TABLE() ^ RPSQ_VS_WIDTH_AND_SPACING_TABLE() ^ RHO_VS_SI_WIDTH_AND_THICKNESS_TABLE() ^ RHO_VS_WIDTH_AND_SPACING_TABLE()) & Optional(Assignment('SIDE_TANGENT', itf_parser_ext.parser('<value>'))) & Optional(THICKNESS_VS_DENSITY_TABLE() & Optional(DENSITY_BOX_WEIGHTING_FACTOR_TABLE())) & Optional(THICKNESS_VS_WIDTH_AND_SPACING_TABLE()) & Optional(TVF_FILE() & TVF_ADJUSTMENT_TABLES()) & Optional(FLOATING_GATE_TO_DIFFUSION_CONTACT_CAP_TABLE())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('CONDUCTOR_PARAMS', res)
    return res


def crt1_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('crt1_value', res)
    return res


def crt2_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('crt2_value', res)
    return res


def crtva_value_triple():
    """Code that is able to parse:

    ( <via_area_value> [,] <crt1_value> [,] <crt2_value> )"""
    res = Group(Literal('(').suppress() + via_area_value() + Optional(Literal(',').suppress()) + crt1_value() + Optional(Literal(',').suppress()) + crt2_value() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('crtva_value_triple', res)
    return res


def crtvsiw_value_triple():
    """Code that is able to parse:

    ( <si_width_value> [,] <crt1_value> [,] <crt2_value> )"""
    res = Group(Literal('(').suppress() + si_width_value() + Optional(Literal(',').suppress()) + crt1_value() + Optional(Literal(',').suppress()) + crt2_value() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('crtvsiw_value_triple', res)
    return res


def CRT_VS_AREA_TABLE():
    """Code that is able to parse:

    CRT_VS_AREA {
        <crtva_value_triple>+ 
    }"""
    res = (CaselessKeyword('CRT_VS_AREA') & Literal('{').suppress() + Group(OneOrMore(crtva_value_triple())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('CRT_VS_AREA_TABLE', res)
    return res


def CRT_VS_SI_WIDTH_TABLE():
    """Code that is able to parse:

    CRT_VS_SI_WIDTH {
        <crtvsiw_value_triple>+
    }"""
    res = (CaselessKeyword('CRT_VS_SI_WIDTH') & Literal('{').suppress() + Group(OneOrMore(crtvsiw_value_triple())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('CRT_VS_SI_WIDTH_TABLE', res)
    return res


def csub_value_pair():
    """Code that is able to parse:
 ( <tsv_cap> [,] <tsv_spacing> )"""
    res = Group(Literal('(').suppress() + tsv_cap() + Optional(Literal(',').suppress()) + tsv_spacing() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('csub_value_pair', res)
    return res


def dbvw_value_triple():
    """Code that is able to parse:
 ( <width_value> [,] <min_density_value> [,] <max_density_value> )"""
    res = Group(Literal('(').suppress() + width_value() + Optional(Literal(',').suppress()) + min_density_value() + Optional(Literal(',').suppress()) + max_density_value() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('dbvw_value_triple', res)
    return res


def dbwf_value_pair():
    """Code that is able to parse:
 ( <box_size> [,] <weight_factor> )"""
    res = Group(Literal('(').suppress() + box_size() + Optional(Literal(',').suppress()) + weight_factor() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('dbwf_value_pair', res)
    return res


def DENSITY_BOX_WEIGHTING_FACTOR_TABLE():
    """Code that is able to parse:

    DENSITY_BOX_WEIGHTING_FACTOR {
        <dbwf_value_pair>+
    }"""
    res = (CaselessKeyword('DENSITY_BOX_WEIGHTING_FACTOR') & Literal('{').suppress() + Group(OneOrMore(dbwf_value_pair())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('DENSITY_BOX_WEIGHTING_FACTOR_TABLE', res)
    return res


def density_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('density_value', res)
    return res


def DEVICE_TYPE_LIST():
    """Code that is able to parse:

    DEVICE_TYPE { '<device_type_name_list> | ALL | NONE' }"""
    res = (CaselessKeyword('DEVICE_TYPE') & Literal('{').suppress() + Group(device_type_name_list() ^ CaselessKeyword('ALL') ^ CaselessKeyword('NONE')) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('DEVICE_TYPE_LIST', res)
    return res


def device_type_name_list():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('device_type_name_list', res)
    return res


def DIELECTRIC_KW():
    """Code that is able to parse:
 DIELECTRIC"""
    res = CaselessKeyword('DIELECTRIC').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('DIELECTRIC_KW', res)
    return res


def DIELECTRIC_LAYER():
    """Code that is able to parse:
 <DIELECTRIC_KW> <dielectric_name_pp> <DIELECTRIC_PARAMS>"""
    res = (DIELECTRIC_KW() & dielectric_name_pp() & DIELECTRIC_PARAMS()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('DIELECTRIC_LAYER', res)
    return res


def dielectric_name():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('dielectric_name', res)
    return res


def dielectric_name_pp():
    """Code that is able to parse:
 <dielectric_name>"""
    res = dielectric_name().ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('dielectric_name_pp', res)
    return res


def DIELECTRIC_PARAMS():
    """Code that is able to parse:
 {
    ER = <value>
    [<ER_VS_SI_SPACING_TABLE>]
    [THICKNESS = <value>]
    ['<THICKNESS_STATEMENT> | <THICKNESS_STATEMENT_CONF>']
}"""
    res = (Literal('{').suppress() + Group(Assignment('ER', itf_parser_ext.parser('<value>')) & Optional(ER_VS_SI_SPACING_TABLE()) & Optional(Assignment('THICKNESS', itf_parser_ext.parser('<value>'))) & Optional(THICKNESS_STATEMENT() ^ THICKNESS_STATEMENT_CONF())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('DIELECTRIC_PARAMS', res)
    return res


def DIEL_FILL_VS_SI_SPACING_TABLE():
    """Code that is able to parse:

    DIELECTRIC_FILL_VS_SI_SPACING {
        SPACINGS { <vector(n)> }
        WIDTHS { <vector(n)> }
        THICKNESSES { <vector(n)> }
        BOTTOM_HEIGHTS { <vector(n)> }
        SIDE_TANGENTS { <vector(n)> }
        ERS { <vector(n)> }
    }"""
    res = (CaselessKeyword('DIELECTRIC_FILL_VS_SI_SPACING') & Literal('{').suppress() + Group(CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('THICKNESSES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('BOTTOM_HEIGHTS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('SIDE_TANGENTS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('ERS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('DIEL_FILL_VS_SI_SPACING_TABLE', res)
    return res


def diff_layer():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('diff_layer', res)
    return res


def DROP_FACTOR_LATERAL_SPACING():
    """Code that is able to parse:
 DROP_FACTOR_LATERAL_SPACING = <value>"""
    res = Assignment('DROP_FACTOR_LATERAL_SPACING', itf_parser_ext.parser('<value>')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('DROP_FACTOR_LATERAL_SPACING', res)
    return res


def ervsss_value_pair():
    """Code that is able to parse:
 ( <er_value> [,] <si_spacing_value> )"""
    res = Group(Literal('(').suppress() + er_value() + Optional(Literal(',').suppress()) + si_spacing_value() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('ervsss_value_pair', res)
    return res


def er_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('er_value', res)
    return res


def ER_VS_SI_SPACING_TABLE():
    """Code that is able to parse:

    ER_VS_SI_SPACING {
    <ervsss_value_pair>+
}"""
    res = (CaselessKeyword('ER_VS_SI_SPACING') & Literal('{').suppress() + Group(OneOrMore(ervsss_value_pair())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('ER_VS_SI_SPACING_TABLE', res)
    return res


def ETCH_VS_CONTACT_AND_GATE_SPACINGS_TABLE():
    """Code that is able to parse:

    ETCH_VS_CONTACT_AND_GATE_SPACINGS CAPACITIVE_ONLY {
        CONTACT_SPACING { <vector(n)> }
        GATE_SPACING { <vector(m)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('ETCH_VS_CONTACT_AND_GATE_SPACINGS') & CaselessKeyword('CAPACITIVE_ONLY') & Literal('{').suppress() + Group(CaselessKeyword('CONTACT_SPACING') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('GATE_SPACING') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('ETCH_VS_CONTACT_AND_GATE_SPACINGS_TABLE', res)
    return res


def ETCH_VS_WIDTH_AND_LENGTH_TABLE():
    """Code that is able to parse:

    ETCH_VS_WIDTH_AND_LENGTH CAPACITIVE_ONLY {
        LENGTHS { <vector(n)> }
        WIDTHS { <vector(m)> }
        VALUES { <matrix(m,n)> }
}"""
    res = (CaselessKeyword('ETCH_VS_WIDTH_AND_LENGTH') & CaselessKeyword('CAPACITIVE_ONLY') & Literal('{').suppress() + Group(CaselessKeyword('LENGTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('ETCH_VS_WIDTH_AND_LENGTH_TABLE', res)
    return res


def ETCH_VS_WIDTH_AND_SPACING_TABLE():
    """Code that is able to parse:

    ETCH_VS_WIDTH_AND_SPACING {
    ['ETCH_FROM_TOP | RESISTIVE_ONLY | CAPACITIVE_ONLY']
    ['PARALLEL_TO_REFERENCE | PERPENDICULAR_TO_REFERENCE | PARALLEL_TO_GATE']
    [NUMBER_OF_MASKS = <n>]
    [MASKS(<mask1>,<mask2>)]
    SPACINGS { <vector(n)> }
    WIDTHS { <vector(m)> }
    VALUES { <matrix(m,n)> }
}"""
    res = (CaselessKeyword('ETCH_VS_WIDTH_AND_SPACING') & Literal('{').suppress() + Group(Optional(CaselessKeyword('ETCH_FROM_TOP') ^ CaselessKeyword('RESISTIVE_ONLY') ^ CaselessKeyword('CAPACITIVE_ONLY')) & Optional(CaselessKeyword('PARALLEL_TO_REFERENCE') ^ CaselessKeyword('PERPENDICULAR_TO_REFERENCE') ^ CaselessKeyword('PARALLEL_TO_GATE')) & Optional(Assignment('NUMBER_OF_MASKS', itf_parser_ext.parser('<n>'))) & Optional(CaselessKeyword('MASKS') & Group(Literal('(').suppress() + mask1() + Literal(',').suppress() + mask2() + Literal(')').suppress())) & CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('ETCH_VS_WIDTH_AND_SPACING_TABLE', res)
    return res


def FLOATING_GATE_TO_DIFFUSION_CONTACT_CAP_TABLE():
    """Code that is able to parse:

    FLOATING_GATE_TO_DIFFUSION_CONTACT_CAP {
        GATE_POLYGON_LENGTH { <vector(n)> }
        GATE_TO_CONTACT_SPACING { <vector(n)> }
        CAPACITANCE_VALUES { <vector(n)> }
    }"""
    res = (CaselessKeyword('FLOATING_GATE_TO_DIFFUSION_CONTACT_CAP') & Literal('{').suppress() + Group(CaselessKeyword('GATE_POLYGON_LENGTH') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('GATE_TO_CONTACT_SPACING') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('CAPACITANCE_VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('FLOATING_GATE_TO_DIFFUSION_CONTACT_CAP_TABLE', res)
    return res


def FRONTSIDE_ITF_STATEMENTS():
    """Code that is able to parse:

    <STACK_LAYERS> <VIA_LAYERS>
    [<STACK_LAYERS> [<VIA_LAYERS>]]
    [<MULTIGATE_DEVICES>]"""
    res = (STACK_LAYERS() & VIA_LAYERS() & Optional(STACK_LAYERS() & Optional(VIA_LAYERS())) & Optional(MULTIGATE_DEVICES())).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('FRONTSIDE_ITF_STATEMENTS', res)
    return res


def gate_layer():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('gate_layer', res)
    return res


def GATE_TO_DIFFUSION_CAP_TABLE():
    """Code that is able to parse:
 GATE_TO_DIFFUSION_CAP {
    '<one_gtdcap_table> | <multiple_gtd_tables>'
    }"""
    res = (CaselessKeyword('GATE_TO_DIFFUSION_CAP') & Literal('{').suppress() + Group(one_gtdcap_table() ^ multiple_gtd_tables()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('GATE_TO_DIFFUSION_CAP_TABLE', res)
    return res


def gd_pair():
    """Code that is able to parse:
 (<gate_layer> <diff_layer>)"""
    res = Group(Literal('(').suppress() + gate_layer() + diff_layer() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('gd_pair', res)
    return res


def GLOBAL_PARAMETERS():
    """Code that is able to parse:

    [<GLOBAL_TEMPERATURE>]
    [<BACKGROUND_ER>]
    [<HALF_NODE_SCALE_FACTOR>]
    [<USE_SI_DENSITY>]
    [<DROP_FACTOR_LATERAL_SPACING>]
    [<REFERENCE_DIRECTION>]"""
    res = (Optional(GLOBAL_TEMPERATURE()) & Optional(BACKGROUND_ER()) & Optional(HALF_NODE_SCALE_FACTOR()) & Optional(USE_SI_DENSITY()) & Optional(DROP_FACTOR_LATERAL_SPACING()) & Optional(REFERENCE_DIRECTION())).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('GLOBAL_PARAMETERS', res)
    return res


def GLOBAL_TEMPERATURE():
    """Code that is able to parse:
 GLOBAL_TEMPERATURE = <value>"""
    res = Assignment('GLOBAL_TEMPERATURE', itf_parser_ext.parser('<value>')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('GLOBAL_TEMPERATURE', res)
    return res


def HALF_NODE_SCALE_FACTOR():
    """Code that is able to parse:
 HALF_NODE_SCALE_FACTOR = <value>"""
    res = Assignment('HALF_NODE_SCALE_FACTOR', itf_parser_ext.parser('<value>')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('HALF_NODE_SCALE_FACTOR', res)
    return res


def ILD_VS_WIDTH_AND_SPACING_TABLE():
    """Code that is able to parse:
 ILD_VS_WIDTH_AND_SPACING {
    DIELECTRIC = <dielectric_name>
    SPACINGS { <vector(n)> }
    WIDTHS { <vector(m)> }
    'VALUES { <matrix(m,n)> }
        | THICKNESS_CHANGES { <matrix(m,n)> }'
}"""
    res = (CaselessKeyword('ILD_VS_WIDTH_AND_SPACING') & Literal('{').suppress() + Group(Assignment('DIELECTRIC', dielectric_name()) & CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & (CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress() ^ CaselessKeyword('THICKNESS_CHANGES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('ILD_VS_WIDTH_AND_SPACING_TABLE', res)
    return res


def IS_CONFORMAL():
    """Code that is able to parse:
 IS_CONFORMAL"""
    res = CaselessKeyword('IS_CONFORMAL').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('IS_CONFORMAL', res)
    return res


def IS_PLANAR():
    """Code that is able to parse:
 IS_PLANAR"""
    res = CaselessKeyword('IS_PLANAR').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('IS_PLANAR', res)
    return res


def ITF():
    """Code that is able to parse:

    <TECHNOLOGY_STATEMENT>
    [<GLOBAL_PARAMETERS>]
    <FRONTSIDE_ITF_STATEMENTS>
    [<TSV_STATEMENT>
     <BACKSIDE_ITF_STATEMENTS>] 
    [<VARIATION_PARAMETERS>]
    [<EM_INFORMATION>]"""
    res = (TECHNOLOGY_STATEMENT() & Optional(GLOBAL_PARAMETERS()) & FRONTSIDE_ITF_STATEMENTS() & Optional(TSV_STATEMENT() & BACKSIDE_ITF_STATEMENTS()) & Optional(VARIATION_PARAMETERS()) & Optional(itf_parser_ext.parser('<EM_INFORMATION>'))).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('ITF', res)
    return res


def mask1():
    """Code that is able to parse:
 <n>"""
    res = itf_parser_ext.parser('<n>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('mask1', res)
    return res


def mask2():
    """Code that is able to parse:
 <n>"""
    res = itf_parser_ext.parser('<n>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('mask2', res)
    return res


def max_density_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('max_density_value', res)
    return res


def max_thick_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('max_thick_value', res)
    return res


def measured_from_name():
    """Code that is able to parse:
 '<dielectric_name> | TOP_OF_CHIP'"""
    res = (dielectric_name() ^ CaselessKeyword('TOP_OF_CHIP')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('measured_from_name', res)
    return res


def min_density_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('min_density_value', res)
    return res


def min_thick_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('min_thick_value', res)
    return res


def MULTIGATE_DEVICES():
    """Code that is able to parse:
 MULTIGATE <multi_dev_name> {
    FIN_SPACING = <value>
    FIN_WIDTH = <value>
    FIN_LENGTH = <value>
    [FIN_THICKNESS = <value>]
    [RAISED_DIFFUSION_GROWTH = <value>]
    [GATE_POLY_EXTENSION_LENGTH = <value>]
    [TRENCH_CONTACT_EXTENSION_LENGTH = <value>]
    GATE_OXIDE_TOP_T = <value>
    GATE_OXIDE_SIDE_T = <value>
    GATE_OXIDE_ER = <value>
    GATE_POLY_TOP_T = <value>
    GATE_POLY_SIDE_T = <value>
    CHANNEL_ER = <value>
    GATE_DIFFUSION_LAYER_PAIR { <gd_pair>+ }
}"""
    res = (CaselessKeyword('MULTIGATE') & multi_dev_name() & Literal('{').suppress() + Group(Assignment('FIN_SPACING', itf_parser_ext.parser('<value>')) & Assignment('FIN_WIDTH', itf_parser_ext.parser('<value>')) & Assignment('FIN_LENGTH', itf_parser_ext.parser('<value>')) & Optional(Assignment('FIN_THICKNESS', itf_parser_ext.parser('<value>'))) & Optional(Assignment('RAISED_DIFFUSION_GROWTH', itf_parser_ext.parser('<value>'))) & Optional(Assignment('GATE_POLY_EXTENSION_LENGTH', itf_parser_ext.parser('<value>'))) & Optional(Assignment('TRENCH_CONTACT_EXTENSION_LENGTH', itf_parser_ext.parser('<value>'))) & Assignment('GATE_OXIDE_TOP_T', itf_parser_ext.parser('<value>')) & Assignment('GATE_OXIDE_SIDE_T', itf_parser_ext.parser('<value>')) & Assignment('GATE_OXIDE_ER', itf_parser_ext.parser('<value>')) & Assignment('GATE_POLY_TOP_T', itf_parser_ext.parser('<value>')) & Assignment('GATE_POLY_SIDE_T', itf_parser_ext.parser('<value>')) & Assignment('CHANNEL_ER', itf_parser_ext.parser('<value>')) & CaselessKeyword('GATE_DIFFUSION_LAYER_PAIR') & Literal('{').suppress() + Group(OneOrMore(gd_pair())) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('MULTIGATE_DEVICES', res)
    return res


def multiple_gtd_tables():
    """Code that is able to parse:

    NUMBER_OF_TABLES = <n>
    <named_gtd_table>*
}"""
    res = (Assignment('NUMBER_OF_TABLES', itf_parser_ext.parser('<n>')) & ZeroOrMore(named_gtd_table())).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('multiple_gtd_tables', res)
    return res


def multi_dev_name():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('multi_dev_name', res)
    return res


def named_gtd_table():
    """Code that is able to parse:
 <table_name> {
        CONTACT_TO_CONTACT_SPACINGS { <vector(n)> }
        GATE_TO_CONTACT_SPACINGS { <vector(m)> }
        CAPS_PER_MICRON { <matrix(m,n)> }
        [GATE_WIDTHS { <vector(n)> }
        GATE_TO_CONTACT_SPACINGS { <vector(m)> }
        CAPS_PER_MICRON { <matrix(m,n)> } ]
    }"""
    res = (table_name() & Literal('{').suppress() + Group(CaselessKeyword('CONTACT_TO_CONTACT_SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('GATE_TO_CONTACT_SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('CAPS_PER_MICRON') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress() & Optional(CaselessKeyword('GATE_WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('GATE_TO_CONTACT_SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('CAPS_PER_MICRON') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('named_gtd_table', res)
    return res


def one_gtdcap_table():
    """Code that is able to parse:
 {
        CONTACT_TO_CONTACT_SPACINGS { <vector(n)> }
        GATE_TO_CONTACT_SPACINGS { <vector(m)> }
        CAPS_PER_MICRON { <matrix(m,n)> }
        [GATE_WIDTHS { <vector(n)> }
        GATE_TO_CONTACT_SPACINGS { <vector(m)> }
        CAPS_PER_MICRON { <matrix(m,n)> } ]
    }"""
    res = (Literal('{').suppress() + Group(CaselessKeyword('CONTACT_TO_CONTACT_SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('GATE_TO_CONTACT_SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('CAPS_PER_MICRON') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress() & Optional(CaselessKeyword('GATE_WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('GATE_TO_CONTACT_SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('CAPS_PER_MICRON') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('one_gtdcap_table', res)
    return res


def POLYNOMIAL_BASED_THICKNESS_VARIATION_TABLE():
    """Code that is able to parse:

    POLYNOMIAL_BASED_THICKNESS_VARIATION {
    'DENSITY_POLYNOMIAL_ORDERS = { <vector(n)> } 
        | SI_DENSITY_POLYNOMIAL_ORDERS = { <vector(n)> }'
    'WIDTH_POLYNOMIAL_ORDERS = { <vector(m)> }
        | SI_WIDTH_POLYNOMIAL_ORDERS = { <vector(m)> }'
    WIDTH_RANGES = { <vector(r)> }
    POLYNOMIAL_COEFFICIENTS = { <matrix(m,n)> }+
    [DENSITY_BOUNDS_VS_WIDTH {
        <dbvw_value_triple>+ 
    }]
    [THICKNESS_BOUNDS { <min_thick_value> <max_thick_value> } ]
}"""
    res = (CaselessKeyword('POLYNOMIAL_BASED_THICKNESS_VARIATION') & Literal('{').suppress() + Group((Assignment('DENSITY_POLYNOMIAL_ORDERS', Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress()) ^ Assignment('SI_DENSITY_POLYNOMIAL_ORDERS', Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress())) & (Assignment('WIDTH_POLYNOMIAL_ORDERS', Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress()) ^ Assignment('SI_WIDTH_POLYNOMIAL_ORDERS', Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress())) & Assignment('WIDTH_RANGES', Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(r)>')) + Literal('}').suppress()) & OneOrMore(CaselessKeyword('POLYNOMIAL_COEFFICIENTS').suppress() + Literal('=').suppress() + Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress().setResultsName('POLYNOMIAL_COEFFICIENTS', True)) & Optional(CaselessKeyword('DENSITY_BOUNDS_VS_WIDTH') & Literal('{').suppress() + Group(OneOrMore(dbvw_value_triple())) + Literal('}').suppress()) & Optional(CaselessKeyword('THICKNESS_BOUNDS') & Literal('{').suppress() + Group(min_thick_value() & max_thick_value()) + Literal('}').suppress())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('POLYNOMIAL_BASED_THICKNESS_VARIATION_TABLE', res)
    return res


def REFERENCE_DIRECTION():
    """Code that is able to parse:
 REFERENCE_DIRECTION = 'VERTICAL | HORIZONTAL'"""
    res = Assignment('REFERENCE_DIRECTION', CaselessKeyword('VERTICAL') ^ CaselessKeyword('HORIZONTAL')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('REFERENCE_DIRECTION', res)
    return res


def RHO_VS_SI_WIDTH_AND_THICKNESS_TABLE():
    """Code that is able to parse:

    RHO_VS_SI_WIDTH_AND_THICKNESS {
        WIDTH { <vector(n)> }
        THICKNESS { <vector(m)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('RHO_VS_SI_WIDTH_AND_THICKNESS') & Literal('{').suppress() + Group(CaselessKeyword('WIDTH') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('THICKNESS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('RHO_VS_SI_WIDTH_AND_THICKNESS_TABLE', res)
    return res


def RHO_VS_WIDTH_AND_SPACING_TABLE():
    """Code that is able to parse:

    RHO_VS_WIDTH_AND_SPACING {
        SPACINGS { <vector(n)> }
        WIDTHS { <vector(m)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('RHO_VS_WIDTH_AND_SPACING') & Literal('{').suppress() + Group(CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('RHO_VS_WIDTH_AND_SPACING_TABLE', res)
    return res


def rpsqvsiw_value_pair():
    """Code that is able to parse:
 ( <si_width_value> [,] <rpsq_value> )"""
    res = Group(Literal('(').suppress() + si_width_value() + Optional(Literal(',').suppress()) + rpsq_value() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('rpsqvsiw_value_pair', res)
    return res


def rpsq_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('rpsq_value', res)
    return res


def RPSQ_VS_SI_WIDTH_TABLE():
    """Code that is able to parse:
 RPSQ_VS_SI_WIDTH {
    <rpsqvsiw_value_pair>+
}"""
    res = (CaselessKeyword('RPSQ_VS_SI_WIDTH') & Literal('{').suppress() + Group(OneOrMore(rpsqvsiw_value_pair())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('RPSQ_VS_SI_WIDTH_TABLE', res)
    return res


def RPSQ_VS_WIDTH_AND_SPACING_TABLE():
    """Code that is able to parse:

    RPSQ_VS_WIDTH_AND_SPACING {
        SPACINGS { <vector(n)> }
        WIDTHS { <vector(m)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('RPSQ_VS_WIDTH_AND_SPACING') & Literal('{').suppress() + Group(CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('RPSQ_VS_WIDTH_AND_SPACING_TABLE', res)
    return res


def rpvva_pair():
    """Code that is able to parse:
 ( <area_value> [,] <rpv_value> )"""
    res = Group(Literal('(').suppress() + area_value() + Optional(Literal(',').suppress()) + rpv_value() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('rpvva_pair', res)
    return res


def rpv_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('rpv_value', res)
    return res


def RPV_VS_AREA_TABLE():
    """Code that is able to parse:

    RPV_VS_AREA { <rpvva_pair>+ }"""
    res = (CaselessKeyword('RPV_VS_AREA') & Literal('{').suppress() + Group(OneOrMore(rpvva_pair())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('RPV_VS_AREA_TABLE', res)
    return res


def RPV_VS_COVERAGE_TABLES():
    """Code that is able to parse:

    RPV_VS_COVERAGE { <via_size_table>+ }"""
    res = (CaselessKeyword('RPV_VS_COVERAGE') & Literal('{').suppress() + Group(OneOrMore(via_size_table())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('RPV_VS_COVERAGE_TABLES', res)
    return res


def RPV_VS_SI_WIDTH_AND_LENGTH_TABLE():
    """Code that is able to parse:

    RPV_VS_SI_WIDTH_AND_LENGTH {
        LENGTHS { <vector(m)> }
        WIDTHS { <vector(n)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('RPV_VS_SI_WIDTH_AND_LENGTH') & Literal('{').suppress() + Group(CaselessKeyword('LENGTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('RPV_VS_SI_WIDTH_AND_LENGTH_TABLE', res)
    return res


def RPV_VS_WIDTH_AND_LENGTH_TABLE():
    """Code that is able to parse:

    RPV_VS_WIDTH_AND_LENGTH {
        LENGTHS { <vector(m)> }
        WIDTHS { <vector(n)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('RPV_VS_WIDTH_AND_LENGTH') & Literal('{').suppress() + Group(CaselessKeyword('LENGTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('RPV_VS_WIDTH_AND_LENGTH_TABLE', res)
    return res


def rsub_value_pair():
    """Code that is able to parse:
 ( <tsv_res> [,] <tsv_spacing> )"""
    res = Group(Literal('(').suppress() + tsv_res() + Optional(Literal(',').suppress()) + tsv_spacing() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('rsub_value_pair', res)
    return res


def si_spacing_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('si_spacing_value', res)
    return res


def si_width_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('si_width_value', res)
    return res


def SPACER_ER_VS_WIDTH_AND_SPACING_TABLE():
    """Code that is able to parse:

    SPACER_ER_VS_WIDTH_AND_SPACING {
    SPACINGS { <vector(m)> }
    WIDTHS { <vector(n)> }
    VALUES { <matrix(m,n)> }
}"""
    res = (CaselessKeyword('SPACER_ER_VS_WIDTH_AND_SPACING') & Literal('{').suppress() + Group(CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('SPACER_ER_VS_WIDTH_AND_SPACING_TABLE', res)
    return res


def STACK_LAYER():
    """Code that is able to parse:
 '<DIELECTRIC_LAYER>| <CONDUCTING_LAYER>'"""
    res = (DIELECTRIC_LAYER() ^ CONDUCTING_LAYER()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('STACK_LAYER', res)
    return res


def STACK_LAYERS():
    """Code that is able to parse:
 <STACK_LAYER>+"""
    res = OneOrMore(STACK_LAYER()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('STACK_LAYERS', res)
    return res


def STD_VIA():
    """Code that is able to parse:
 {
    FROM = <conductor_name> TO = <conductor_name>
    [T0 = <value>]
    ['CRT1 = <value>
    | CRT2 = <value>
    | CRT1 = <value> CRT2 = <value>
    | <CRT_VS_AREA_TABLE>']
    'RHO = <value>
    | RPV = <value> AREA = <value>
    | <RPV_VS_AREA_TABLE>'
    ['<ETCH_VS_CONTACT_AND_GATE_SPACINGS_TABLE>
    | <ETCH_VS_WIDTH_AND_LENGTH_TABLE>']
    [<RPV_VS_COVERAGE_TABLES>]
}"""
    res = (Literal('{').suppress() + Group(Assignment('FROM', conductor_name()) & Assignment('TO', conductor_name()) & Optional(Assignment('T0', itf_parser_ext.parser('<value>'))) & Optional(Assignment('CRT1', itf_parser_ext.parser('<value>')) ^ Assignment('CRT2', itf_parser_ext.parser('<value>')) ^ Assignment('CRT1', itf_parser_ext.parser('<value>')) & Assignment('CRT2', itf_parser_ext.parser('<value>')) ^ CRT_VS_AREA_TABLE()) & (Assignment('RHO', itf_parser_ext.parser('<value>')) ^ Assignment('RPV', itf_parser_ext.parser('<value>')) & Assignment('AREA', itf_parser_ext.parser('<value>')) ^ RPV_VS_AREA_TABLE()) & Optional(ETCH_VS_CONTACT_AND_GATE_SPACINGS_TABLE() ^ ETCH_VS_WIDTH_AND_LENGTH_TABLE()) & Optional(RPV_VS_COVERAGE_TABLES())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('STD_VIA', res)
    return res


def table_name():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('table_name', res)
    return res


def TC_VIA():
    """Code that is able to parse:
 {
    FROM = <conductor_name> TO = <conductor_name>
    <RPV_VS_WIDTH_AND_LENGTH_TABLE>
}"""
    res = (Literal('{').suppress() + Group(Assignment('FROM', conductor_name()) & Assignment('TO', conductor_name()) & RPV_VS_WIDTH_AND_LENGTH_TABLE()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TC_VIA', res)
    return res


def TC_VIA_SI():
    """Code that is able to parse:
 {
        FROM = <conductor_name> TO = <conductor_name>
        ETCH_ASSOCIATED_LAYER = <string>
        <RPV_VS_SI_WIDTH_AND_LENGTH_TABLE>
    }"""
    res = (Literal('{').suppress() + Group(Assignment('FROM', conductor_name()) & Assignment('TO', conductor_name()) & Assignment('ETCH_ASSOCIATED_LAYER', itf_parser_ext.parser('<string>')) & RPV_VS_SI_WIDTH_AND_LENGTH_TABLE()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TC_VIA_SI', res)
    return res


def TECHNOLOGY_STATEMENT():
    """Code that is able to parse:
 TECHNOLOGY = <string>"""
    res = Assignment('TECHNOLOGY', itf_parser_ext.parser('<string>')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TECHNOLOGY_STATEMENT', res)
    return res


def thickness_change_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('thickness_change_value', res)
    return res


def THICKNESS_STATEMENT():
    """Code that is able to parse:

    MEASURED_FROM = <measured_from_name>
    <WALL_THICKNESS>
    [DAMAGE_THICKNESS = <value> DAMAGE_ER = <value>]"""
    res = (Assignment('MEASURED_FROM', measured_from_name()) & WALL_THICKNESS() & Optional(Assignment('DAMAGE_THICKNESS', itf_parser_ext.parser('<value>')) & Assignment('DAMAGE_ER', itf_parser_ext.parser('<value>')))).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('THICKNESS_STATEMENT', res)
    return res


def THICKNESS_STATEMENT_CONF():
    """Code that is able to parse:

    <IS_CONFORMAL> <WALL_THICKNESS_CONF>
    [ASSOCIATED_CONDUCTOR = <conductor_name> [<SPACER_ER_VS_WIDTH_AND_SPACING_TABLE> ]]"""
    res = (IS_CONFORMAL() & WALL_THICKNESS_CONF() & Optional(Assignment('ASSOCIATED_CONDUCTOR', conductor_name()) & Optional(SPACER_ER_VS_WIDTH_AND_SPACING_TABLE()))).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('THICKNESS_STATEMENT_CONF', res)
    return res


def THICKNESS_VS_DENSITY_TABLE():
    """Code that is able to parse:

    THICKNESS_VS_DENSITY [ 'RESISTIVE_ONLY | CAPACITIVE_ONLY' ]{
        <tvd_value_pair>+
    }"""
    res = (CaselessKeyword('THICKNESS_VS_DENSITY') & Optional(CaselessKeyword('RESISTIVE_ONLY') ^ CaselessKeyword('CAPACITIVE_ONLY')) & Literal('{').suppress() + Group(OneOrMore(tvd_value_pair())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('THICKNESS_VS_DENSITY_TABLE', res)
    return res


def THICKNESS_VS_WIDTH_AND_SPACING_TABLE():
    """Code that is able to parse:

    THICKNESS_VS_WIDTH_AND_SPACING
    [ 'RESISTIVE_ONLY | CAPACITIVE_ONLY' ]{
        SPACINGS { <vector(n)> }
        WIDTHS { <vector(m)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('THICKNESS_VS_WIDTH_AND_SPACING') & Optional(CaselessKeyword('RESISTIVE_ONLY') ^ CaselessKeyword('CAPACITIVE_ONLY')) & Literal('{').suppress() + Group(CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('THICKNESS_VS_WIDTH_AND_SPACING_TABLE', res)
    return res


def tsv_cap():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('tsv_cap', res)
    return res


def TSV_KW():
    """Code that is able to parse:
 TSV"""
    res = CaselessKeyword('TSV').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TSV_KW', res)
    return res


def tsv_name():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('tsv_name', res)
    return res


def tsv_name_pp():
    """Code that is able to parse:
 <tsv_name>"""
    res = tsv_name().ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('tsv_name_pp', res)
    return res


def TSV_PARAMS():
    """Code that is able to parse:
 {
    FROM = <conductor_name>
    TO = <conductor_name>
    RHO = <value>
    AREA = <value>
    THICKNESS = <value>
    INSULATION_THICKNESS = <value>
    INSULATION_ER = <value>
    [T0 = <value>]
    ['CRT1 = <value>
    | CRT2 = <value>
    | CRT1 = <value> CRT2 = <value>']
    [CSUB_VS_SPACING { <csub_value_pair>+ }
    RSUB_BS_SPACING { <rsub_value_pair>+ }]
}"""
    res = (Literal('{').suppress() + Group(Assignment('FROM', conductor_name()) & Assignment('TO', conductor_name()) & Assignment('RHO', itf_parser_ext.parser('<value>')) & Assignment('AREA', itf_parser_ext.parser('<value>')) & Assignment('THICKNESS', itf_parser_ext.parser('<value>')) & Assignment('INSULATION_THICKNESS', itf_parser_ext.parser('<value>')) & Assignment('INSULATION_ER', itf_parser_ext.parser('<value>')) & Optional(Assignment('T0', itf_parser_ext.parser('<value>'))) & Optional(Assignment('CRT1', itf_parser_ext.parser('<value>')) ^ Assignment('CRT2', itf_parser_ext.parser('<value>')) ^ Assignment('CRT1', itf_parser_ext.parser('<value>')) & Assignment('CRT2', itf_parser_ext.parser('<value>'))) & Optional(CaselessKeyword('CSUB_VS_SPACING') & Literal('{').suppress() + Group(OneOrMore(csub_value_pair())) + Literal('}').suppress() & CaselessKeyword('RSUB_BS_SPACING') & Literal('{').suppress() + Group(OneOrMore(rsub_value_pair())) + Literal('}').suppress())) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TSV_PARAMS', res)
    return res


def tsv_res():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('tsv_res', res)
    return res


def tsv_spacing():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('tsv_spacing', res)
    return res


def TSV_STATEMENT():
    """Code that is able to parse:
 <TSV_KW> <tsv_name_pp> <TSV_PARAMS>"""
    res = (TSV_KW() & tsv_name_pp() & TSV_PARAMS()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TSV_STATEMENT', res)
    return res


def tvd_value_pair():
    """Code that is able to parse:
 ( <density_value> [,] <thickness_change_value> )"""
    res = Group(Literal('(').suppress() + density_value() + Optional(Literal(',').suppress()) + thickness_change_value() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('tvd_value_pair', res)
    return res


def TVF_ADJUSTMENT_TABLES():
    """Code that is able to parse:
 TVF_ADJUSTMENT_TABLES {
    '<TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_SPACING_TABLE>
    | <TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_DELTAPD_TABLE>
    | <TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_SPACING_TABLE>
    <TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_DELTAPD_TABLE>'
}"""
    res = (CaselessKeyword('TVF_ADJUSTMENT_TABLES') & Literal('{').suppress() + Group(TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_SPACING_TABLE() ^ TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_DELTAPD_TABLE() ^ TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_SPACING_TABLE() & TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_DELTAPD_TABLE()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TVF_ADJUSTMENT_TABLES', res)
    return res


def TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_DELTAPD_TABLE():
    """Code that is able to parse:

    BOTTOM_THICKNESS_VS_WIDTH_AND_DELTAPD {
        SPACINGS { <vector(n)> }
        WIDTHS { <vector(m)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('BOTTOM_THICKNESS_VS_WIDTH_AND_DELTAPD') & Literal('{').suppress() + Group(CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_DELTAPD_TABLE', res)
    return res


def TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_SPACING_TABLE():
    """Code that is able to parse:

    BOTTOM_THICKNESS_VS_WIDTH_AND_SPACING {
        SPACINGS { <vector(n)> }
        WIDTHS { <vector(m)> }
        VALUES { <matrix(m,n)> }
    }"""
    res = (CaselessKeyword('BOTTOM_THICKNESS_VS_WIDTH_AND_SPACING') & Literal('{').suppress() + Group(CaselessKeyword('SPACINGS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('WIDTHS') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TVF_BOTTOM_THICKNESS_VS_WIDTH_AND_SPACING_TABLE', res)
    return res


def TVF_FILE():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('TVF_FILE', res)
    return res


def USE_SI_DENSITY():
    """Code that is able to parse:
 USE_SI_DENSITY = <bool_value>"""
    res = Assignment('USE_SI_DENSITY', bool_value()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('USE_SI_DENSITY', res)
    return res


def VARIATION_PARAMETERS():
    """Code that is able to parse:
 VARIATION_PARAMETERS { <VAR_TABLE> }"""
    res = (CaselessKeyword('VARIATION_PARAMETERS') & Literal('{').suppress() + Group(VAR_TABLE()) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('VARIATION_PARAMETERS', res)
    return res


def var_coefficient():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('var_coefficient', res)
    return res


def var_layer():
    """Code that is able to parse:
 '<conductor_name> | <dielectric_name>'"""
    res = (conductor_name() ^ dielectric_name()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('var_layer', res)
    return res


def var_name():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('var_name', res)
    return res


def var_parameter_type():
    """Code that is able to parse:
 'THICKNESS | WIDTH | ER | RHO'"""
    res = (CaselessKeyword('THICKNESS') ^ CaselessKeyword('WIDTH') ^ CaselessKeyword('ER') ^ CaselessKeyword('RHO')).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('var_parameter_type', res)
    return res


def VAR_TABLE():
    """Code that is able to parse:
 <var_name> = { <var_triple>+ }"""
    res = var_name().ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('VAR_TABLE', res)
    return res


def var_triple():
    """Code that is able to parse:

    ( <var_layer> [,] <var_parameter_type> [,] <var_coefficient> )"""
    res = Group(Literal('(').suppress() + var_layer() + Optional(Literal(',').suppress()) + var_parameter_type() + Optional(Literal(',').suppress()) + var_coefficient() + Literal(')').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('var_triple', res)
    return res


def via_area_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('via_area_value', res)
    return res


def VIA_KW():
    """Code that is able to parse:
 VIA"""
    res = CaselessKeyword('VIA').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('VIA_KW', res)
    return res


def VIA_LAYER():
    """Code that is able to parse:
 
    <VIA_KW> <via_name_pp> 
    '<STD_VIA> | <TC_VIA> | <TC_VIA_SI>'"""
    res = (VIA_KW() & via_name_pp() & (STD_VIA() ^ TC_VIA() ^ TC_VIA_SI())).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('VIA_LAYER', res)
    return res


def VIA_LAYERS():
    """Code that is able to parse:
 <VIA_LAYER>*"""
    res = ZeroOrMore(VIA_LAYER()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('VIA_LAYERS', res)
    return res


def via_name():
    """Code that is able to parse:
 <string>"""
    res = itf_parser_ext.parser('<string>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('via_name', res)
    return res


def via_name_pp():
    """Code that is able to parse:
 <via_name>"""
    res = via_name().ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('via_name_pp', res)
    return res


def via_size_table():
    """Code that is able to parse:

    VIA_SIZE { <x_size> <y_size> }
    COV_X { <vector(m)> }
    COV_Y { <vector(n)> }
    VALUES { <matrix(m,n)> }"""
    res = (CaselessKeyword('VIA_SIZE') & Literal('{').suppress() + Group(x_size() & y_size()) + Literal('}').suppress() & CaselessKeyword('COV_X') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(m)>')) + Literal('}').suppress() & CaselessKeyword('COV_Y') & Literal('{').suppress() + Group(itf_parser_ext.parser('<vector(n)>')) + Literal('}').suppress() & CaselessKeyword('VALUES') & Literal('{').suppress() + Group(itf_parser_ext.parser('<matrix(m,n)>')) + Literal('}').suppress()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('via_size_table', res)
    return res


def WALL_THICKNESS():
    """Code that is able to parse:
[SW_T = <value>] [TW_T = <value>]"""
    res = (Optional(Assignment('SW_T', itf_parser_ext.parser('<value>'))) & Optional(Assignment('TW_T', itf_parser_ext.parser('<value>')))).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('WALL_THICKNESS', res)
    return res


def WALL_THICKNESS_CONF():
    """Code that is able to parse:

    [BW_T= <value>]
    <WALL_THICKNESS>"""
    res = (Optional(Assignment('BW_T', itf_parser_ext.parser('<value>'))) & WALL_THICKNESS()).ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('WALL_THICKNESS_CONF', res)
    return res


def weight_factor():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('weight_factor', res)
    return res


def width_value():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('width_value', res)
    return res


def x_size():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('x_size', res)
    return res


def y_size():
    """Code that is able to parse:
 <value>"""
    res = itf_parser_ext.parser('<value>').ignore(COMMENT_IGNORE)
    if not RAW_PARSING:
        res = itf_parser_ext.post_def('y_size', res)
    return res


def Assignment(key, expr):
    expr = expr.copy()
    res = CaselessKeyword(key).suppress() + Literal('=').suppress() + expr
    res.addParseAction(itf_parser_ext.ParseInfoHelper(res, legacy=True))
    return res.setResultsName(key)
# okay decompiling itf_parser.pyc
