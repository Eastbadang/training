# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\itf_import\itf_parser_ext.py
# Compiled at: 2017-08-31 19:07:12
# Size of source mod 2**32: 4221 bytes
from pyparsing import *
try:
    from ..common.utils import ParseInfoHelper
except:
    import sys
    sys.path.append('..')
    from common.utils import ParseInfoHelper

def string():
    return Word(alphanums + '_-').setName('<string>')


def value():
    return Regex('[+-]?\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?').setName('<value>').setParseAction(lambda s, l, t: float(t[0]))


def integer():
    return Word(nums).setName('<n>').setParseAction(lambda s, l, t: int(t[0]))


def vector_n():
    return ZeroOrMore(value() + Optional(',').suppress()).setName('<vector(n)>')


def matrix_m_n():
    return vector_n().setName('<matrix(m,n)>')


vector_re = Regex('<vector\\(.+\\)>')
matrix_re = Regex('<matrix\\(.+,.+\\)>')

def comment_to_ignore():
    res = Regex('\\$.*\n').setName('comment')
    return res


def unknown_statement():

    def add_res_name(s, l, t):
        t.__setitem__(t[0], t[0])

    def add_res_name_a(s, l, t):
        name = t[0]
        val = t[1]
        t.clear()
        t.__setitem__(name, val)
        t.append(val)
        return t

    unknown_kw = Word(alphas + '_', alphanums + '_')
    unknown_assignment = unknown_kw + (Literal('=').suppress() + (value() | string()) | Optional(Literal('=').suppress()) + Combine(Literal('{') + SkipTo((Literal('}')), include=True)))
    res = unknown_assignment.addParseAction(add_res_name_a)
    res = res | unknown_kw.addParseAction(add_res_name)
    res.setName('unknown_statement')
    return res


def frontside(s, l, t):
    print('frontside', t)


class cur_block:

    def __init__(self, name):
        self.name = name

    def printt(self, s, l, t):
        debug = False
        if debug:
            print(self.name)
            t.pprint()


def post_def(bnf_name, expr):
    res = expr.copy()
    res = res.addParseAction(cur_block(bnf_name).printt)
    if bnf_name in ('dielectric_name_pp', 'conductor_name_pp', 'via_name_pp'):
        res.addParseAction(ParseInfoHelper(expr, legacy=True))
        res = res.setResultsName('NAME')
    if bnf_name in ('DIELECTRIC_KW', 'CONDUCTOR_KW', 'VIA_KW'):
        res.addParseAction(ParseInfoHelper(expr, legacy=True))
        res = res.setResultsName('TYPE')
    if bnf_name in ('FRONTSIDE_ITF_STATEMENTS', ):
        res = Group(res).setResultsName('FRONTSIDE')
    if bnf_name in ('BACKSIDE_ITF_STATEMENTS', ):
        res = res + NotAny(Literal('TSV') + string() + Literal('{'))
        res = Group(res).setResultsName('BACKSIDE')
    if bnf_name in ('GLOBAL_PARAMETERS', 'TSV_STATEMENT'):
        res = Group(res).setResultsName(bnf_name)
    if bnf_name in ('DIELECTRIC_PARAMS', 'CONDUCTOR_PARAMS', 'STD_VIA', 'TC_VIA', 'TC_VIA_SI'):
        res = res.addParseAction(lambda s, l, t: t[0])
    if bnf_name == 'STACK_LAYER':
        res = Group(res).setResultsName('STACK', True)
    if bnf_name == 'VIA_LAYER':
        res = Group(res).setResultsName('VIAS', True)
    if bnf_name == 'IS_CONFORMAL':
        res.addParseAction(ParseInfoHelper(expr, legacy=True))
        res = res.setResultsName('IS_CONFORMAL')
    if bnf_name == 'IS_PLANAR':
        res.addParseAction(ParseInfoHelper(expr, legacy=True))
        res = res.setResultsName('IS_PLANAR')
    return res


def parser(str):
    if str == '<string>':
        return string()
    else:
        if str == '<n>':
            return integer()
        else:
            if str == '<value>':
                return value()
            if vector_re.matches(str):
                return vector_n()
            if matrix_re.matches(str):
                return matrix_m_n()
        return NoMatch()
# okay decompiling itf_parser_ext.pyc
