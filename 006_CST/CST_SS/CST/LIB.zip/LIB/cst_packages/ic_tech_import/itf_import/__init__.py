# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\itf_import\__init__.py
# Compiled at: 2015-02-09 23:28:47
# Size of source mod 2**32: 6 bytes
pass
# okay decompiling __init__.pyc
