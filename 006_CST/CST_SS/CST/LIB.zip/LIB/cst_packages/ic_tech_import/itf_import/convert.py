# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\itf_import\convert.py
# Compiled at: 2018-04-06 23:01:38
# Size of source mod 2**32: 16831 bytes
import pyparsing
try:
    try:
        from . import itf_parser
        from . import itf_parser_ext
        from ..common.utils import *
    except:
        import sys
        sys.path.append('.')
        import itf_parser, itf_parser_ext
        sys.path.append('..')
        from common.utils import *

except ImportError as e:
    print(e)
    raise

def calc_conductor_resistivity(layer):
    if all(x in layer for x in ('THICKNESS', 'RPSQ')):
        return get_and_track(layer, 'THICKNESS') * get_and_track(layer, 'RPSQ') * 1e-06
    else:
        if 'RHO' in layer:
            return get_and_track(layer, 'RHO') * 1e-06
        track(layer, 'RPSQ_VS_SI_WIDTH', 'WARNING: RPSQ_VS_SI_WIDTH is not supported using PEC meterial instead')
        return 0


def calc_via_resistivity(via):
    if 'RHO' in via:
        return get_and_track(via, 'RHO') * 1e-06
    else:
        if 'RPV' in via:
            if 'AREA' in via:
                return get_and_track(via, 'RPV') * get_and_track(via, 'AREA') * 1e-06
        if 'RPV_VS_AREA' in via:
            values = get_and_track(via, 'RPV_VS_AREA', 'WARNING: Currently multiple per area resistivities are not supported for VIAs. The average is taken instead.')
            n_vals = len(values)
            if n_vals == 0:
                return 0
            else:
                res = 0
                for v in values:
                    if len(v) != 2:
                        pass
                    else:
                        res = res + v[0] * v[1]

                return res
        track(via, 'RPV_VS_COVERAGE', 'WARNING: RPV_VS_COVERAGE option is not supported.')
        return 0


def get_nominal_dielectric_thicknesses(STACK):
    true_die_thickness = {}
    previous_dielectric = None
    dielectrics = []
    for layer in reversed(STACK):
        if layer.TYPE == 'DIELECTRIC':
            thickness = get_and_track(layer, 'THICKNESS')
            layer_name = get_and_track(layer, 'NAME')
            measuredFrom = get_and_track(layer, 'MEASURED_FROM', 'TOP_OF_CHIP')
            if measuredFrom != 'TOP_OF_CHIP':
                idies = iter(dielectrics)
                found = False
                correction_thickness = 0.0
                for i in idies:
                    if i == measuredFrom:
                        found = True
                    else:
                        if found:
                            correction_thickness = correction_thickness + true_die_thickness[i]

                thickness = thickness - correction_thickness
            true_die_thickness[layer_name] = thickness
            dielectrics.append(layer_name)
            previous_dielectric = layer_name

    return true_die_thickness


def convert(itf_file, commands, feedback={}):
    fb = feedback_wrapper(feedback)
    RELATIVE_TO_THICKNESS = 'Relative to Thickness'
    with open(itf_file, 'r') as (myfile):
        feedback['text'] = myfile.read()
    logger.debug('About to parse: ' + itf_file)
    parser = itf_parser.ITF().parseWithTabs()
    try:
        pres = parser.parseFile(itf_file)
    except pyparsing.ParseException as e:
        logger.error(e)
        return False
    except:
        logger.error('Could not parse file')
        logger.error('Unexpected error:', sys.exc_info()[0])
        return False

    cmd = Command('createTechnology', name=(get_and_track(pres, 'TECHNOLOGY')), active=True)
    commands.append(cmd)
    global_drop_factor_lateral_spacing = pres.get('DROP_FACTOR_LATERAL_SPACING', 0.5)
    mask_commands = []
    queue_commands = []
    material_commands = []
    drop_factor = None
    drop_layer_GROWN = None
    previous_dielectric = None
    trench_contact_conductors = []
    die_thicknesses = get_nominal_dielectric_thicknesses(pres.FRONTSIDE.STACK)
    for layer in reversed(pres.FRONTSIDE.STACK):
        layer_name = get_and_track(layer, 'NAME')
        track(layer, 'TYPE')
        measuredFrom = get_and_track(layer, 'MEASURED_FROM', default=previous_dielectric)
        if measuredFrom == 'TOP_OF_CHIP':
            measuredFrom = None
        if layer.TYPE == 'DIELECTRIC':
            track(layer, 'BW_T', 'WARNING: Bottom wall thickness (BW_T) is not supported')
            is_conformal = get_and_track(layer, 'IS_CONFORMAL', 'INFO: IS_CONFORMAL statement is not fully supported.')
            track(layer, 'ASSOCIATED_CONDUCTOR', 'WARNING: A specific associated conductor is not supported. Conforming to top of chip instead.')
            material_name = 'DIEL_MAT_' + layer_name
            material_params = {}
            material_params['er'] = get_and_track(layer, 'ER')
            cmd = Command('createNewMaterial', alias=material_name, name=material_name, parameters=material_params, material_class='Dielectric')
            material_commands.append(cmd)
            thickness = die_thicknesses[layer_name]
            if is_conformal is not None:
                sideThickness = get_and_track(layer, 'SW_T', default=(float(0.0)))
                topThickness = get_and_track(layer, 'TW_T', default=(float(0.0)))
            else:
                if measuredFrom is None:
                    sideThickness = get_and_track(layer, 'SW_T', default=thickness)
                    topThickness = get_and_track(layer, 'TW_T', default=thickness)
                else:
                    sideThickness = get_and_track(layer, 'SW_T', 'WARNING: Side-wall thickness (SW_T) has no meaning when MEASURED_FROM is not TOP_OF_CHIP.', default=(float(0.0)))
                    topThickness = get_and_track(layer, 'TW_T', 'WARNING: Top-wall thickness (TW_T) has no meaning when MEASURED_FROM is not TOP_OF_CHIP.', default=(float(0.0)))
                cmd = Command('createNewStepWithParameters', step_type='Deposition',
                  name=layer_name,
                  parameters=params(thickness=thickness,
                  material=material_name,
                  topThickness=topThickness,
                  topThicknessEnabled=True,
                  sideThickness=sideThickness,
                  sideThicknessEnabled=True,
                  applyTopThickness=RELATIVE_TO_THICKNESS))
                queue_commands.append(cmd)
                previous_dielectric = layer_name
            if layer.TYPE == 'CONDUCTOR':
                is_planar = get_and_track(layer, 'IS_PLANAR')
                logger.debug(layer_name, is_planar)
                if is_planar is not None:
                    drop_factor = None
                material_name = 'COND_MAT_' + layer_name
                material_params = {}
                resistivity = calc_conductor_resistivity(layer)
                library_material = 'PEC'
                if resistivity > 0:
                    library_material = material_name
                    material_params['resistivity'] = resistivity
        cmd = Command('createNewMaterial', alias=material_name, name=library_material, parameters=material_params, material_class='Conductor')
        material_commands.append(cmd)
        track(layer, 'WMIN', 'INFO: Minimum conductor width (WMIN) is not supported')
        track(layer, 'SMIN', 'INFO: Minimum conductor spacing (SMIN) is not supported')
        track(layer, 'FILL_RATIO', 'WARNING: Metal filling options are currently not supported.')
        track(layer, 'FILL_SPACING', 'WARNING: Metal filling options are currently not supported.')
        track(layer, 'FILL_WIDTH', 'WARNING: Metal filling options are currently not supported.')
        track(layer, 'POLYNOMIAL_BASED_THICKNESS_VARIATION', 'WARNING: Thickness variations are currently not supported.')
        track(layer, 'SIDE_TANGENT', 'WARNING: Conductor side tangent option is currently not supported.')
        if 'LAYER_TYPE' in layer:
            if layer.LAYER_TYPE == 'TRENCH_CONTACT':
                trench_contact_conductors.append(get_and_track(layer, 'LAYER_TYPE'))
            else:
                pattern_name = layer_name
                etch = get_and_track(layer, 'ETCH', default=0)
                if etch != 0:
                    derived_layer_ETCH = 'ETCH_' + layer_name
                    pattern_name = derived_layer_ETCH
                    op = 'shrink'
                    if etch < 0:
                        op = 'grow'
                        etch = -etch
                    cmd = Command('createDerivedLayer', derived_layer_name=derived_layer_ETCH,
                      left_layer_name=layer_name,
                      operator_name=op,
                      right=etch)
                    mask_commands.append(cmd)
                thickness = get_and_track(layer, 'THICKNESS')
                if drop_factor is not None:
                    derived_layer_DROP = 'DROP_' + layer_name
                    cmd = Command('createDerivedLayer', derived_layer_name=derived_layer_DROP,
                      left_layer_name=pattern_name,
                      operator_name='NOT',
                      right=drop_layer_GROWN)
                    mask_commands.append(cmd)
                    cmd = Command('createNewStepWithParameters', step_type='Etching',
                      name=derived_layer_DROP,
                      parameters=params(pattern=[
                     derived_layer_DROP, 'drawing'],
                      maximumDepth=drop_factor,
                      maximumDepthEnabled=True))
                    queue_commands.append(cmd)
            cmd = Command('createNewStepWithParameters', step_type='Deposition',
              name=layer_name,
              parameters=params(pattern=[
             pattern_name, 'drawing'],
              thickness=thickness,
              material=material_name))
            queue_commands.append(cmd)
            drop_factor = get_and_track(layer, 'DROP_FACTOR', default=drop_factor)
            if drop_factor is not None:
                drop_layer_GROWN = 'GROW_' + layer_name
                cmd = Command('createDerivedLayer', derived_layer_name=drop_layer_GROWN,
                  left_layer_name=pattern_name,
                  operator_name='grow',
                  right=global_drop_factor_lateral_spacing)
                mask_commands.append(cmd)

    for via in pres.FRONTSIDE.VIAS:
        track(via, 'TYPE')
        via_name = get_and_track(via, 'NAME')
        step_name = 'VIA_' + via_name
        via_material = 'VIA_MAT_' + via_name
        resistivity = calc_via_resistivity(via)
        material_params = {}
        library_material = 'PEC'
        if resistivity > 0:
            library_material = via_material
            material_params['resistivity'] = resistivity
        cmd = Command('createNewMaterial', alias=via_material,
          name=library_material,
          parameters=material_params,
          material_class='Conductor')
        material_commands.append(cmd)
        from_conductor = get_and_track(via, 'FROM')
        to_conductor = get_and_track(via, 'TO')
        pattern_name = via_name
        if 'RPV_VS_SI_WIDTH_AND_LENGTH' in via:
            associated_etch = get_and_track(via, 'ETCH_ASSOCIATED_LAYER')
            if associated_etch in trench_contact_conductors:
                pattern_name = associated_etch
            else:
                if to_conductor in trench_contact_conductors:
                    pattern_name = to_conductor
            if from_conductor in trench_contact_conductors:
                pattern_name = from_conductor
            via_params = params(pattern=[
             pattern_name, 'drawing'],
              to=to_conductor,
              material=via_material)
            via_params['from'] = from_conductor
            via_cmd = Command('createNewStepWithParameters', step_type='CreateVIAs',
              name=step_name,
              parameters=via_params)
            index_insert_via = -1
            index = 0
            for cmd in queue_commands:
                if cmd.command_name == 'createNewStepWithParameters':
                    if cmd.get_arg('name') in [from_conductor, to_conductor]:
                        index_insert_via = index
                index += 1

            if index_insert_via > -1:
                queue_commands.insert(index_insert_via, via_cmd)

    commands.extend(material_commands)
    commands.extend(mask_commands)
    commands.extend(queue_commands)
    data = {}
    collect_feedback(pres, data)
    MSG_UNSPECIFIED = 'UNSPECIFIED'
    msg_list = []
    for k, locs in data.items():
        what = k
        msg_type = MSG_UNSPECIFIED
        split = k.split(':', 1)
        if len(split) == 2:
            what = split[1].strip()
            msg_type = split[0].strip().upper()
        msg_list.append({'what':what,  'type':msg_type,  'where':locs})

    feedback['messages'] = msg_list
    return True


if __name__ == '__main__':
    import sys
    sys.path.append('.')
    import argparse
    parser = argparse.ArgumentParser(description='ITF Convertor.')
    parser.add_argument('-f', '--itf', help='The ITF technology file to be read and converted.', required=True)
    parser.add_argument('--dump', type=bool, default=False, help=(argparse.SUPPRESS))
    parser.add_argument('-i', type=bool, default=False, help=(argparse.SUPPRESS))
    args = parser.parse_args()
    commands = []
    feedback = {}
    res = convert(args.itf, commands, feedback)
    if args.dump:
        import pickle, os
        fnamedump = os.path.splitext(args.itf)[0]
        fnamedump += '.ref'
        with open(fnamedump, 'wb') as (fdump):
            pickle.dump(commands, fdump)
# okay decompiling convert.pyc
