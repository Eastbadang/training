# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\ads_import\convert.py
# Compiled at: 2018-04-24 21:59:02
# Size of source mod 2**32: 15865 bytes
import pyparsing, os
from collections import defaultdict
import sys
try:
    try:
        from . import ads_parser
        from ..common.utils import *
        from ..common.layermap import LayerMap
    except:
        import sys
        this_dir = os.path.dirname(__file__)
        tech_root = os.path.join(this_dir, '../../')
        sys.path = [tech_root] + sys.path
        from ic_tech_import.ads_import import ads_parser
        from ic_tech_import.common.utils import *
        from ic_tech_import.common.layermap import LayerMap

except ImportError as e:
    print(e)
    raise

def to_float(s, default=None):
    if s is None:
        return
    res = 0.0
    try:
        res = float(s)
        return res
    except ValueError:
        return default


def convert(input_file, lmap, commands, feedback={}):
    fb = feedback_wrapper(feedback)
    RELATIVE_TO_THICKNESS = 'Relative to Thickness'
    layer_map = None
    try:
        subst_dir = os.path.dirname(input_file)
        matdb = os.path.join(subst_dir, 'materials.matdb')
        if isinstance(lmap, str):
            if os.path.exists(lmap):
                logger.info('Reading layer map from:' + lmap)
                layer_map = LayerMap(lmap)
        if not os.path.exists(matdb):
            raise ParserError("Missing 'materials.matdb' file. This file should be present next to the .subst file: " + input_file)
        with open(matdb, 'r') as (myfile):
            feedback['text'] = '<!-- Content from {}/>'.format(matdb) + '\n'
            feedback['text'] += myfile.read()
        with open(input_file, 'r') as (myfile):
            feedback['text'] += '\n<!-- Content from {}/>'.format(input_file) + '\n'
            feedback['text'] += '\n' + myfile.read()
        pres_subst, pres_mtdb = ads_parser.ParseCombinedSubstMatDB(feedback['text'])
    except pyparsing.ParseException as e:
        raise ParserError(str(e))
    except ParserError as e:
        raise ParserError(str(e))
    except:
        logger.error('Could not parse file')
        raise ParserError('Unexpected error:' + sys.exc_info()[0])

    tech_name = os.path.basename(os.path.splitext(input_file)[0])
    cmd = Command('createTechnology', name=tech_name, active=True)
    commands.append(cmd)
    material_commands = []
    material_lib = {}
    for m in pres_mtdb.CONDUCTORS_SECTION.CONDUCTORS:
        material_name = get_and_track(m, 'name')
        material_lib[material_name] = m
        material_params = {}
        material_params['ur'] = to_float(get_and_track(m, 'mur_real'))
        material_params['ur_i'] = to_float(get_and_track(m, 'mur_imag'), None)
        material_params['sigma'] = to_float(get_and_track(m, 'real').split(' ')[0])
        material_params['sigma_i'] = to_float(get_and_track(m, 'imag').split(' ')[0])
        m.material_class = 'Conductor'
        cmd = Command('createNewMaterial', alias=material_name, name=material_name, parameters=material_params, material_class=(m.material_class))
        material_commands.append(cmd)

    for m in pres_mtdb.DIELECTRICS_SECTION.DIELECTRICS:
        material_name = get_and_track(m, 'name')
        material_lib[material_name] = m
        material_params = {}
        material_params['er'] = to_float(get_and_track(m, 'er_real'))
        if get_no_track(m, 'er_imag'):
            material_params['er_i'] = to_float(get_and_track(m, 'er_imag'))
        else:
            if get_no_track(m, 'valuefreq'):
                material_params['tan_delta'] = to_float(get_and_track(m, 'er_loss'))
                material_params['tan_delta_freq'] = to_float(get_and_track(m, 'valuefreq'))
            else:
                if get_no_track(m, 'er_loss'):
                    material_params['tan_delta'] = to_float(get_and_track(m, 'er_loss'))
        material_params['ur'] = to_float(get_and_track(m, 'mur_real'))
        material_params['ur_i'] = to_float(get_and_track(m, 'mur_imag'))
        m.material_class = 'Dielectric'
        cmd = Command('createNewMaterial', alias=material_name, name=material_name, parameters=material_params, material_class=(m.material_class))
        material_commands.append(cmd)

    for m in pres_mtdb.SEMICONDUCTORS_SECTION.SEMICONDUCTORS:
        material_name = get_and_track(m, 'name')
        material_lib[material_name] = m
        material_params = {}
        material_params['er'] = to_float(get_and_track(m, 'er_real'))
        material_params['ur'] = to_float(get_and_track(m, 'mur_real'))
        material_params['ur_i'] = to_float(get_and_track(m, 'mur_imag'))
        material_params['resistivity'] = to_float(get_and_track(m, 'resistivity'))
        m.material_class = 'Semiconductor'
        cmd = Command('createNewMaterial', alias=material_name, name=material_name, parameters=material_params, material_class=(m.material_class))
        material_commands.append(cmd)

    commands.extend(material_commands)
    index_to_layer = defaultdict(list)
    for l in pres_subst.LAYERS_SECTION.LAYERS:
        lindex = int(get_and_track(l, 'index'))
        index_to_layer[lindex].append(l)

    index_to_via = defaultdict(list)
    for v in pres_subst.VIAS_SECTION.VIAS:
        i1 = int(get_and_track(v, 'index1'))
        i2 = int(get_and_track(v, 'index2'))
        i = max(i1, i2)
        index_to_via[i].append(v)

    def pattern_name_if_lmap(number):
        if not layer_map:
            return number
        else:
            entrees = layer_map.find_entries(gds_num=(str(number)), gds_purp='0', purpose='drawing')
            if len(entrees) is 0:
                logger.warning('Could not find any corresponding layer in layermap with GDS number ' + str(number))
                return
            if len(entrees) > 1:
                logger.warning('Multiple drawing layers found in layermap matching ' + str(number) + ' selecting first match.')
            e = entrees[0]
            lname = e.get('layer')
            if lname is None:
                logger.error('Data entry in Layermap does not have a layername for GDS number: ' + str(number))
                return
            return lname

    def createVIA(v, queue_commands):
        mask_name = get_and_track(v, 'materialname')
        pattern_number = int(get_and_track(v, 'layer'))
        pattern_name = pattern_name_if_lmap(pattern_number)
        if pattern_name is None:
            logger.warning('Skipping VIA with associated with layer: ' + str(pattern_number))
            return
        via_material = get_and_track(v, 'materialname')
        via_params = params(pattern=[
         pattern_name, 'drawing'],
          material=via_material)
        via_cmd = Command('createNewStepWithParameters', step_type='CreateVIAs',
          name=mask_name,
          parameters=via_params)
        queue_commands.append(via_cmd)

    def create_interface(l, queue_commands, previous_dielectric_cmd):
        expand_thickness = 0.0
        material_name = get_and_track(l, 'materialname')
        pattern_number = int(get_and_track(l, 'layer'))
        pattern_name = pattern_name_if_lmap(pattern_number)
        if pattern_name is None:
            logger.warning('Skipping layer-statement with associated layer: ' + str(pattern_number))
            return
        thicknessunit = get_and_track(l, 'thickunit')
        scale_factor = 1.0
        if thicknessunit == 'micron':
            scale_factor = 1.0
        else:
            if thicknessunit == 'meter':
                scale_factor = 1000000.0
        thickness = scale_factor * to_float(get_and_track(l, 'thick', default=0.0))
        sideThicknessEnabled = False
        if l.expand == '1':
            if thickness < 0 and previous_dielectric_cmd:
                sideThicknessEnabled = True
                thickness = -thickness
                p = previous_dielectric_cmd.get_arg('parameters')
                if p is not None:
                    if 'thickness' in p:
                        p['thickness'] += thickness
                    pname = previous_dielectric_cmd.get_arg('name')
                    expand_cmd = Command('createNewStepWithParameters', step_type='Etching',
                      name=(pname + '_expand_down'),
                      parameters=params(pattern=[
                     pattern_name, 'drawing'],
                      maximumDepth=thickness,
                      maximumDepthEnabled=True))
                    insert_at = 0
                    for i in range(len(queue_commands)):
                        if previous_dielectric_cmd == queue_commands[i]:
                            insert_at = i + 1

                    if insert_at > 0:
                        queue_commands.insert(insert_at, expand_cmd)
            else:
                expand_thickness = thickness
        else:
            if thickness < 0:
                thickness = -thickness
            cmd = Command('createNewStepWithParameters', step_type='Deposition',
              name=material_name,
              parameters=params(thickness=thickness,
              material=material_name,
              pattern=[
             pattern_name, 'drawing'],
              sideThicknessEnabled=sideThicknessEnabled))
            queue_commands.append(cmd)
            return expand_thickness

    queue_commands = []
    interface_index = -1
    expand_thickness = 0.0
    load_wafer_created = False
    previous_dielectric_cmd = None
    for si in pres_subst.STACK_SECTION.STACK_ITEMS:
        if si.tag == 'interface':
            expand_thickness = 0.0
            interface_index += 1
            if interface_index in index_to_via:
                for v in index_to_via[interface_index]:
                    createVIA(v, queue_commands)

            if interface_index in index_to_layer:
                for l in index_to_layer[interface_index]:
                    exp_here = create_interface(l, queue_commands, previous_dielectric_cmd)
                    if isinstance(exp_here, float):
                        expand_thickness = exp_here

            if si.tag == 'material':
                if not si.get('thick'):
                    pass
                else:
                    material_name = get_and_track(si, 'materialname')
                    if not material_name:
                        pass
                    else:
                        if material_name in material_lib:
                            material = material_lib[material_name]
                        else:
                            track(si, 'materialname', 'WARNING: Material not found in database')
                        thicknessunit = si.thickunit
                        scale_factor = 1.0
                        if thicknessunit == 'micron':
                            scale_factor = 1.0
                        else:
                            if thicknessunit == 'meter':
                                scale_factor = 1000000.0
                            thickness = scale_factor * to_float(get_and_track(si, 'thick'), 0.0)
                            thickness += expand_thickness
                            expand_thickness = 0.0
                            if material:
                                if material.material_class == 'Semiconductor':
                                    if not load_wafer_created:
                                        cmd = Command('createNewStepWithParameters', step_type='Load Wafer',
                                          name=material_name,
                                          parameters=params(thickness=thickness,
                                          material=material_name))
                                        load_wafer_created = True
                            cmd = Command('createNewStepWithParameters', step_type='Deposition',
                              name=material_name,
                              parameters=params(thickness=thickness,
                              material=material_name,
                              topThickness=0.0,
                              topThicknessEnabled=True,
                              sideThickness=0.0,
                              sideThicknessEnabled=True,
                              applyTopThickness=RELATIVE_TO_THICKNESS))
                        previous_dielectric_cmd = cmd
                        queue_commands.append(cmd)

    commands.extend(queue_commands)
    msg_list = []
    for pres in [pres_mtdb, pres_subst]:
        data = {}
        collect_feedback(pres, data)
        MSG_UNSPECIFIED = 'UNSPECIFIED'
        for k, locs in data.items():
            what = k
            msg_type = MSG_UNSPECIFIED
            split = k.split(':', 1)
            if len(split) == 2:
                what = split[1].strip()
                msg_type = split[0].strip().upper()
            msg_list.append({'what':what,  'type':msg_type,  'where':locs})

    feedback['messages'] = msg_list
    return True


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='ADS subst/matdb Convertor.')
    parser.add_argument('-f', '--subst', help='The ADS subst technology file to be read and converted.', required=True)
    parser.add_argument('-l', '--lmap', help='The corresponding layer map.', default='')
    parser.add_argument('--dump', type=bool, default=False, help=(argparse.SUPPRESS))
    parser.add_argument('-i', type=bool, default=False, help=(argparse.SUPPRESS))
    args = parser.parse_args()
    commands = []
    feedback = {}
    res = convert(args.subst, args.lmap, commands, feedback)
    if args.dump:
        import pickle, os
        fnamedump = os.path.splitext(args.subst)[0]
        fnamedump += '.ref'
        data = {}
        data['commands'] = commands
        data['feedback'] = feedback
        with open(fnamedump, 'wb') as (fdump):
            pickle.dump(data, fdump)
# okay decompiling convert.pyc
