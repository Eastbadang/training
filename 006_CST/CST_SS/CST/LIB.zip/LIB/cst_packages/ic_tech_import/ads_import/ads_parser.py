# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\ads_import\ads_parser.py
# Compiled at: 2018-04-24 00:31:12
# Size of source mod 2**32: 6030 bytes
from pyparsing import *
import sys
try:
    from ..common.utils import ParseInfoHelper
except:
    print('IIII FAAAAIIIILLLLLEEEDDDD')
    import sys
    sys.path.append('..')
    for p in sys.path:
        print(p)

COMMENT_IGNORE = htmlComment()

def add_res_name(s, l, t):
    newt = ParseResults((t[1:]), name=(t[0]), asList=False)
    return newt


def makeXMLTagsWithParsInfo(tag: str):
    """Internal helper to construct opening and closing tag expressions, given a tag name"""
    resname = tag
    tagStr = Keyword(tag)
    tagAttrName = Word(alphas, alphanums + '_-:')
    tagAttrValue = dblQuotedString.copy().setParseAction(removeQuotes)
    tagAssignment = tagAttrName + Suppress('=') + tagAttrValue
    tagAssignment.addParseAction(add_res_name)
    tagAssignment.addParseAction(ParseInfoHelper(tagAssignment))
    openTag = Suppress('<') + tagStr('tag') + ZeroOrMore(tagAssignment) + Optional('/', default=[False]).setResultsName('empty').setParseAction(lambda s, l, t: t[0] == '/') + Suppress('>')
    closeTag = Combine(Literal('</') + tagStr + '>')
    openTag = openTag.setResultsName('start' + ''.join(resname.replace(':', ' ').title().split())).setName('<%s>' % resname)
    closeTag = closeTag.setResultsName('end' + ''.join(resname.replace(':', ' ').title().split())).setName('</%s>' % resname)
    openTag.tag = resname
    closeTag.tag = resname
    return (openTag, closeTag)


def empty_tag(tag):
    return Literal('<' + tag + '/>').suppress()


def section(tag, content_parser):
    tbegin, tend = makeXMLTagsWithParsInfo(tag)
    section = Group(tbegin + content_parser + tend.suppress() | tbegin)(tag.upper() + '_SECTION')
    return section


def grammerSUBST():
    smodel_begin, smodel_end = makeXMLTagsWithParsInfo('SubstrateModel')
    material_begin, material_end = makeXMLTagsWithParsInfo('material')
    interface_begin, interface_end = makeXMLTagsWithParsInfo('interface')
    layer_begin, layer_end = makeXMLTagsWithParsInfo('layer')
    via_begin, via_end = makeXMLTagsWithParsInfo('via')
    substrate_begin, substrate_end = makeXMLTagsWithParsInfo('substrate')
    stack = section('stack', ZeroOrMore(Group(material_begin | interface_begin))('STACK_ITEMS'))
    layers = section('layers', Group(ZeroOrMore(Group(layer_begin)))('LAYERS'))
    vias = section('vias', Group(ZeroOrMore(Group(via_begin)))('VIAS'))
    substrates = section('substrates', Group(ZeroOrMore(substrate_begin)('SUBSTRATES')))
    grammar = SkipTo(smodel_begin).suppress() + smodel_begin.suppress() + stack + layers + vias + substrates + smodel_end.suppress()
    return grammar


def grammerMATDB():
    smodel_begin, smodel_end = makeXMLTagsWithParsInfo('Materials')
    conductor_begin, conductor_end = makeXMLTagsWithParsInfo('Conductor')
    dielectrics_begin, dielectrics_end = makeXMLTagsWithParsInfo('Dielectric')
    semiconductor_begin, semiconductor_end = makeXMLTagsWithParsInfo('Semiconductor')
    roughness_begin, roughness_end = makeXMLTagsWithParsInfo('roughness')
    Conductors = section('Conductors', ZeroOrMore(Group(conductor_begin))('CONDUCTORS'))
    Dielectrics = section('Dielectrics', ZeroOrMore(Group(dielectrics_begin))('DIELECTRICS'))
    Semiconductors = section('Semiconductors', ZeroOrMore(Group(semiconductor_begin))('SEMICONDUCTORS'))
    roughness = section('roughness', ZeroOrMore(Group(roughness_begin))('ROUGHNESS'))
    grammar = SkipTo(smodel_begin).suppress() + smodel_begin.suppress() + Conductors + Dielectrics + Semiconductors + roughness + SkipTo(smodel_end) + smodel_end.suppress()
    return grammar


def ParseSUBST(file):
    res = ParseResults()
    with open(file, 'r') as (myfile):
        contents = myfile.read()
    res = grammerSUBST().parseString(contents)
    return res


def ParseMatDB(file):
    res = ParseResults()
    with open(file, 'r') as (myfile):
        contents = myfile.read()
    res = grammerMATDB().parseString(contents)
    return res


def ParseCombinedSubstMatDB(contents):
    res_matdb = grammerMATDB().parseString(contents)
    res_subst = grammerSUBST().parseString(contents)
    return (
     res_subst, res_matdb)


if __name__ == '__main__':
    import sys, os
    sys.path.append('.')
    if len(sys.argv) == 2:
        subst_file = sys.argv[1]
        pres = None
        pres = ParseSUBST(subst_file)
        subst_dir = os.path.dirname(subst_file)
        matdb = os.path.join(subst_dir, 'materials.matdb')
        pres_mtdb = ParseMatDB(matdb)
    else:
        dummy_begin, dumm_end = makeXMLTagsWithParsInfo('dummy')
        dummy = '<dummy materialname="fox" BAL_TYPE="INHERIT" thick="0.235" thickunit="micron" BAL_NUM="0"/>'
        res = dummy_begin.parseString(dummy)
# okay decompiling ads_parser.pyc
