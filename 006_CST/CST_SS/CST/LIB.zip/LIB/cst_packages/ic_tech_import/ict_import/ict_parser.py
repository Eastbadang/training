# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\ict_import\ict_parser.py
# Compiled at: 2020-03-31 00:18:24
# Size of source mod 2**32: 4454 bytes
import logging
logger = logging.getLogger(__name__)
COMMENT_SIGN = '#'
from pyparsing import *
try:
    from ..common.utils import ParseInfoHelper
except:
    import sys, os
    this_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.join(this_dir, '..'))
    from common.utils import ParseInfoHelper

def integer():
    return Regex('[+-]?\\d+').setName('<n>').setParseAction(lambda s, l, t: int(t[0]))


def double():
    return Regex('[+-]?\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?').setName('<value>').setParseAction(lambda s, l, t: float(t[0]))


def add_res_name(s, l, t):
    t[0] = t[0].upper()
    newt = ParseResults((t[1:]), name=(t[0]), asList=False)
    logger.debug('{0}, {1}'.format(t, newt))
    return newt


def sub_command(pars):
    import re
    command_type = Regex('sub_\\w+', re.I).setResultsName('COMMAND')
    command_type.addParseAction(ParseInfoHelper(command_type))
    command_name = (QuotedString('"') | Word(alphanums + '_-')).setResultsName('NAME')
    command_name.addParseAction(ParseInfoHelper(command_name))
    lbr = Literal('{').suppress()
    rbr = Literal('}').suppress()
    pars.setResultsName('PARAMETERS')
    command = Group(command_type + command_name + lbr + pars + rbr).setResultsName('SUBCOMMANDS', True)
    return command


def ict_nested_key_values_parser():
    key = Word(alphas + '_', alphanums + '_')
    string = Word(alphanums + ',._"')
    list_of_numbers = Group(double() + OneOrMore(double()))
    list_of_numbers_in_brackets = Group(OneOrMore(Literal('{').suppress() + list_of_numbers + Literal('}').suppress()))
    nested_items = Forward()
    value = list_of_numbers_in_brackets | list_of_numbers | double() | QuotedString('"') | LineEnd().setParseAction(lambda : '') | string
    key_value = key + (value | OneOrMore(Literal('{').suppress() + Group(nested_items) + Literal('}').suppress()))
    key_value.addParseAction(add_res_name)
    key_value.addParseAction(ParseInfoHelper(key_value))
    sc = sub_command(nested_items)
    nested_items << ZeroOrMore(sc | key_value)
    return nested_items


def ict_parser():
    import re
    command_type = Regex('process|diffusion|well|conductor|dielectric|passivation|via', re.I).setResultsName('COMMAND')
    command_type.addParseAction(ParseInfoHelper(command_type))
    command_name = (QuotedString('"') | Word(alphanums + '_-')).setResultsName('NAME')
    command_name.addParseAction(ParseInfoHelper(command_name))
    comment = '#' + restOfLine
    lbr = Literal('{').suppress()
    rbr = Literal('}').suppress()
    kv_parser = ict_nested_key_values_parser()
    parameters = kv_parser.setResultsName('PARAMETERS')
    command = Group(command_type + command_name + lbr + parameters + rbr).setResultsName('COMMANDS', True)
    parser = ZeroOrMore(command)
    parser.ignore(comment)
    return parser


def nested_key_value_list_to_dict(l):
    if not isinstance(l, list):
        return l
    else:
        assert len(l) % 2 == 0
        d = {}
        for i in range(len(l) / 2):
            d[l[(2 * i)]] = nested_key_value_list_to_dict(l[(2 * i + 1)])

        return d


def parse_string(contents):
    try:
        expr = ict_parser()
        results = expr.parseString(contents)
        return results
    except ParseException as err:
        print(err.line)
        print(' ' * (err.column - 1) + '^')
        print(err)


def parse(file):
    with open(file) as (f):
        contents = f.read()
        results = parse_string(contents)
        return results


if __name__ == '__main__':
    import sys
    res = parse(sys.argv[1])
    print(res)
    print('DONE')
# okay decompiling ict_parser.pyc
