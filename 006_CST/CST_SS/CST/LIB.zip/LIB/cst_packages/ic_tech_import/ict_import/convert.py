# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\ict_import\convert.py
# Compiled at: 2020-03-31 00:18:24
# Size of source mod 2**32: 17413 bytes
import pyparsing, os, logging
logger = logging.getLogger(__name__)
try:
    try:
        from . import ict_parser
        from ..common.utils import *
    except:
        import sys
        sys.path.append('.')
        import ict_parser
        sys.path.append('..')
        from common.utils import *

except ImportError as e:
    logger.error(e)
    raise

RELATIVE_TO_THICKNESS = 'Relative to Thickness'

class ICT_StackupItem(object):

    def __init__(self, name):
        self.name = name.strip('"')

    def description(self):
        pass

    def get_name(self):
        return self.name

    def to_command(self):
        print('Not implemented')

    def __lt__(self, other):
        if self.height != other.height:
            return self.height < other.height
        else:
            return isinstance(self, ICT_Conductor)


class ICT_Layer(ICT_StackupItem):

    def __init__(self, name, height=None, thickness=0.0):
        ICT_StackupItem.__init__(self, name)
        self.height = height
        self.thickness = thickness

    def __lt__(self, other):
        if self.height is None:
            return False
        else:
            if other.height is None:
                return True
            if self.height != other.height:
                return self.height + self.thickness < other.height + other.thickness
            return isinstance(self, ICT_Conductor)


class ICT_Conductor(ICT_Layer):

    def __init__(self, name, height, thickness=None):
        ICT_Layer.__init__(self, name, height, thickness)

    def description(self):
        return (
         self.name, 'Conductor', self.height, self.thickness)

    def to_command(self):
        cmd = Command('createNewStepWithParameters', step_type='Deposition',
          name=(self.name),
          parameters=params(pattern=[
         self.name, 'drawing'],
          thickness=(self.thickness),
          material=(self.material),
          topThicknessEnabled=False,
          sideThicknessEnabled=False))
        return cmd


class ICT_Dielectric(ICT_Layer):

    def __init__(self, name, height, thickness=None, dielectric_constant=None):
        ICT_Layer.__init__(self, name, height, thickness)

    def description(self):
        return (
         self.name, 'Dielectric', self.height, self.thickness)

    def to_command(self):
        cmd = Command('createNewStepWithParameters', step_type='Deposition',
          name=(self.name),
          parameters=params(thickness=(self.thickness),
          material=(self.material),
          topThickness=(self.topThickness),
          topThicknessEnabled=True,
          sideThickness=(self.sideThickness),
          sideThicknessEnabled=True,
          applyTopThickness=RELATIVE_TO_THICKNESS))
        return cmd


class ICT_Diffusion(ICT_Layer):

    def __init__(self, name, thickness: float):
        ICT_Layer.__init__(self, name, (-thickness), thickness=thickness)

    def description(self):
        return (
         self.name, 'Diffusion', self.height, self.thickness)


class ICT_Via(ICT_StackupItem):

    def __init__(self, name, top_layer):
        ICT_StackupItem.__init__(self, name)
        self.name = name.strip('"')
        self.top_layer = top_layer

    def description(self):
        return (
         self.name, 'Via', self.top_layer)

    def to_command(self):
        via_params = params(pattern=[
         self.name, 'drawing'],
          material=(self.material))
        via_params['from'] = self.top_layer
        via_cmd = Command('createNewStepWithParameters', step_type='CreateVIAs',
          name=(self.name),
          parameters=via_params)
        return via_cmd


def convert(ict_file, commands, feedback={}):
    fb = feedback_wrapper(feedback)
    with open(ict_file, 'r') as (myfile):
        feedback['text'] = myfile.read()
    logger.info('About to parse: ' + ict_file)
    parser = ict_parser.ict_parser().parseWithTabs()
    try:
        pres = parser.parseFile(ict_file)
    except pyparsing.ParseException as e:
        raise ParserError(e)
        return False
    except:
        raise ParserError('Unexpected error:' + sys.exc_info()[0])
        return False

    process_name_found = False
    for c in pres.COMMANDS:
        cmd_type = get_and_track(c, 'COMMAND')
        if cmd_type.upper() == 'PROCESS':
            process_name_found = True
            cmd = Command('createTechnology', name=(get_and_track(c, 'NAME')), active=True)
            commands.append(cmd)

    if not process_name_found:
        tech_name = os.path.basename(ict_file)
        tech_name = os.path.splitext(tech_name)[0]
        logger.warning('No "process" command found. Creating technology based on file name: ' + tech_name)
        cmd = Command('createTechnology', name=tech_name, active=True)
        commands.append(cmd)
    mask_commands = []
    queue_commands = []
    material_commands = []
    layers = []
    vias = {}

    def get_height_and_thickness(c, lower_layers):
        command_name = get_and_track(c, 'NAME')
        delta_height = get_and_track(c, 'DELTA_HEIGHT')
        delta_layer = get_and_track(c, 'DELTA_LAYER')
        height = get_and_track(c, 'HEIGHT')
        thickness = get_and_track(c, 'THICKNESS')
        upto = get_and_track(c, 'UPTO')
        has_delta_height = delta_height is not None
        has_delta_layer = delta_layer is not None
        has_height = height is not None
        has_thickness = thickness is not None
        has_upto = upto is not None
        if [
         has_height or has_delta_height, has_thickness, has_upto].count(False) > 1:
            msg = 'Command ' + command_name + " is not correctly specified. Expecting at least two statements out of 'height'(or 'delta_height'+'delta_layer'), 'thickness' and 'upto'."
            logger.warning(msg)
            raise InputIncorrect(msg)
        if has_delta_height is not has_delta_layer:
            logger.warning("Missing 'delta_layer' statement for command: " + command_name)
            raise InputIncorrect("Missing 'delta_layer' statement for command: " + command_name)
        if delta_height is not None:
            for l in lower_layers:
                if not isinstance(l, ICT_Layer):
                    pass
                else:
                    if l.get_name() != delta_layer:
                        pass
                    else:
                        height = l.height + l.thickness + delta_height
                        has_height = True

        if not has_height:
            height = upto - thickness
        if not has_thickness:
            thickness = upto - height
        return (height, thickness)

    def get_resistivity(thickness_in_um, rsheet):
        return 1e-06 * thickness_in_um * rsheet

    def average(val):
        if isinstance(val, float):
            return val
        else:
            import statistics
            return statistics.mean(val)

    for c in pres.COMMANDS:
        command_type = get_and_track(c, 'COMMAND').upper()
        command_name = get_and_track(c, 'NAME')
        material_alias = None
        material_name = None
        material_class = 'Dielectric'
        material_params = {}
        try:
            if command_type == 'PROCESS':
                continue
            else:
                if command_type == 'DIELECTRIC':
                    height, thickness = get_height_and_thickness(c, layers)
                    l = ICT_Dielectric(command_name, height=height, thickness=thickness)
                    l.topThickness = get_and_track(c, 'TOPTHICKNESS', default=0.0)
                    l.sideThickness = get_and_track(c, 'SIDEEXPAND', default=0.0)
                    layers.append(l)
                    material_alias = 'DIEL_MAT_' + command_name
                    l.material = material_alias
                    material_params['er'] = get_and_track(c, 'DIELECTRIC_CONSTANT')
                else:
                    if command_type == 'PASSIVATION':
                        height, thickness = get_height_and_thickness(c, layers)
                        l = ICT_Dielectric(command_name, height=height, thickness=thickness)
                        l.topThickness = get_and_track(c, 'TOPTHICKNESS', default=0.0)
                        l.sideThickness = get_and_track(c, 'SIDEEXPAND', default=0.0)
                        layers.append(l)
                        material_alias = 'PASS_MAT_' + command_name
                        l.material = material_alias
                        material_params['er'] = get_and_track(c, 'DIELECTRIC_CONSTANT')
                    else:
                        if command_type == 'CONDUCTOR':
                            height, thickness = get_height_and_thickness(c, layers)
                            l = ICT_Conductor(command_name, height=height, thickness=thickness)
                            layers.append(l)
                            rsheet = get_and_track(c, 'RESISTIVITY', default=None)
                            rho_values = get_and_track(c, 'RHO_VALUES', default=None)
                            material_class = 'Conductor'
                            material_alias = 'COND_MAT_' + command_name
                            l.material = material_alias
                            if rsheet:
                                resistivity = 0
                                if isinstance(rsheet, float):
                                    resistivity = get_resistivity(l.thickness, rsheet)
                                else:
                                    if isinstance(rsheet, pyparsing.ParseResults):
                                        logger.info('Resistivity given as list of value/width pairs [resistivity], taking average of values.')
                                        avg = average(rsheet[::2])
                                        resistivity = get_resistivity(l.thickness, avg)
                                material_params['resistivity'] = resistivity
                            else:
                                if rho_values:
                                    if isinstance(rsheet, pyparsing.ParseResults):
                                        logger.info('Resistivity given as list of values [rho_values], taking average.')
                                    resistivity = average(rho_values)
                                    material_params['resistivity'] = resistivity
                                else:
                                    logger.info('No material information could be extracted for layer "{0}" will use PEC instead.'.format(l.name))
                                    material_name = 'PEC'
                        else:
                            if command_type == 'DIFFUSION':
                                thickness = get_and_track(c, 'THICKNESS')
                                if thickness is not None:
                                    l = ICT_Diffusion(command_name, thickness)
                                    layers.append(l)
                            else:
                                if command_type == 'VIA':
                                    top_layer = get_and_track(c, 'TOP_LAYER')
                                    material_class = 'Conductor'
                                    if top_layer is not None:
                                        top_layer = top_layer.strip('"')
                                        l = ICT_Via(command_name, top_layer)
                                        l.material = 'VIA_MAT_' + command_name
                                        if top_layer in vias:
                                            vias[top_layer].append(l)
                                        else:
                                            vias[top_layer] = [
                                             l]
                                else:
                                    logger.info('Block type not recognized:', command_type)
                if not material_name:
                    material_name = material_alias
                if material_alias is not None:
                    cmd = Command('createNewMaterial', alias=material_alias, name=material_name, parameters=material_params, material_class=material_class)
                    material_commands.append(cmd)
        except Exception as e:
            msg = 'Skipping command ' + command_name
            logger.warning(msg)
            logger.debug(e)

    for mat_cmd in material_commands:
        logger.debug(mat_cmd)

    layers = sorted(layers)
    import copy
    for l in layers:
        if l.name not in vias:
            pass
        else:
            m = None
            for mat_cmd in material_commands:
                if l.material == mat_cmd.get_arg('name'):
                    m = copy.deepcopy(mat_cmd)
                    break

            if not m:
                logger.error('Could not find matching material for VIA: {0}'.format(mat_cmd.get_arg('name')))
            else:
                for via in vias[l.name]:
                    via_mat_name = via.material
                    via_mat_cmd = copy.deepcopy(m)
                    via_mat_cmd.kwargs['name'] = via_mat_name
                    via_mat_cmd.kwargs['alias'] = via_mat_name
                    material_commands.append(via_mat_cmd)

    stackup = []
    for l in layers:
        if l.name in vias:
            stackup.extend(vias[l.name])
        stackup.append(l)

    commands.extend(material_commands)
    for l in stackup:
        cmd = l.to_command()
        if cmd is not None:
            commands.append(cmd)

    data = {}
    collect_feedback(pres, data)
    MSG_UNSPECIFIED = 'UNSPECIFIED'
    msg_list = []
    for k, locs in data.items():
        what = k
        msg_type = MSG_UNSPECIFIED
        split = k.split(':', 1)
        if len(split) == 2:
            what = split[1].strip()
            msg_type = split[0].strip().upper()
        msg_list.append({'what':what,  'type':msg_type,  'where':locs})

    feedback['messages'] = msg_list


if __name__ == '__main__':
    import sys
    sys.path.append('.')
    handler = logging.StreamHandler(sys.stdout)
    logger.addHandler(handler)
    import argparse
    parser = argparse.ArgumentParser(description='ICT Convertor.')
    parser.add_argument('-f', '--ict', help='The ICT technology file to be read and converted.', required=True)
    parser.add_argument('--dump', type=bool, default=False, help=(argparse.SUPPRESS))
    parser.add_argument('-i', type=bool, default=False, help=(argparse.SUPPRESS))
    args = parser.parse_args()
    commands = []
    feedback = {}
    res = convert(args.ict, commands, feedback)
    for c in commands:
        logger.debug(c)

    if args.dump:
        import pickle, os
        fnamedump = os.path.splitext(args.ict)[0]
        fnamedump += '.ref'
        data = {}
        data['commands'] = commands
        data['feedback'] = feedback
        with open(fnamedump, 'wb') as (fdump):
            pickle.dump(data, fdump)
# okay decompiling convert.pyc
