# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\common\layermap.py
# Compiled at: 2018-04-24 02:31:27
# Size of source mod 2**32: 2200 bytes
from pyparsing import *

def parse_layermap_file(lmap):
    comment = '#' + restOfLine
    oaLayerName = Word(alphanums + '_')('layer')
    oaLayerPurpose = Word(alphanums + '_')('purpose')
    gdsLayer = Word(nums)('gds_num')
    gdsPurpose = Word(nums)('gds_purp')
    oaMaterial = Word(alphanums + '_')('material')
    oaMaskNumber = Word(nums)('masknumber')
    lmapLine = oaLayerName + oaLayerPurpose + gdsLayer + gdsPurpose + SkipTo(LineEnd()).suppress()
    grammer = ZeroOrMore(Group(lmapLine))
    grammer.ignore(comment)
    pres = grammer.parseFile(lmap)
    res = []
    for p in pres:
        res.append(p.asDict())

    return res


class LayerMap(object):

    def __init__(self, filename):
        self.data = parse_layermap_file(filename)

    def find_entries(self, **kwargs):

        def filter_data_entry(d, filter):
            for k, v in filter.items():
                dval = d.get(k)
                if dval is None:
                    return False
                if dval != v:
                    return False

            return True

        layers = []
        for d in self.data:
            if not filter_data_entry(d, kwargs):
                pass
            else:
                layers.append(d)

        return layers


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='A layermap file reader.')
    parser.add_argument('-f', '--lmap', help='A layermap file', required=True)
    parser.add_argument('--dump', type=bool, default=False, help=(argparse.SUPPRESS))
    parser.add_argument('-i', type=bool, default=False, help=(argparse.SUPPRESS))
    args = parser.parse_args()
    print(len(parse_layermap_file(args.lmap)))
    data = LayerMap(args.lmap)
    all_RX_drawing = data.find_entries(layer='RX', purpose='drawing')
    all_M1_drawing = data.find_entries(layer='M1', purpose='drawing')
    get_gds15 = data.find_entries(gds_num='15', purpose='drawing')
    if not len(get_gds15) == 1:
        raise AssertionError
# okay decompiling layermap.pyc
