# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\common\utils.py
# Compiled at: 2018-04-26 17:55:21
# Size of source mod 2**32: 7286 bytes
from pyparsing import *
ADD_PARSE_INFO = False
ADD_PARSE_INFO = True

def params(**kwargs):
    return kwargs


IGNORED = 0
OK = 1
NOT_YET_SUPPORTED = 2
TRACKED_DATA = {}

class TrackedParseResult:

    def __init__(self, pres, data=TRACKED_DATA):
        self.pres = pres
        self.data = data
        r = 'remarks'
        if r not in self.data:
            self.remarks = {}
            self.data[r] = self.remarks
        else:
            self.remarks = self.data[r]

    def _get(self, key):
        return self.pres.get(key)

    def _track(self, k, remark):
        t = self._get(k)
        if t is None:
            return
        if isinstance(t, ParseInfo):
            if isinstance(remark, int):
                if remark == IGNORED:
                    remark = 'INFO: Unused'
                else:
                    if remark == OK:
                        remark = 'OK: Ok'
                    elif remark >= NOT_YET_SUPPORTED:
                        remark = 'INFO: Not (yet) supported'
            t.remark = remark

    def get_and_track(self, key, remark, default=None):
        res = self._get(key)
        if res is None:
            return default
        else:
            self._track(key, remark)
            if isinstance(res, ParseInfo):
                return res()
            return res

    def get_no_track(self, key, default=None):
        res = self._get(key)
        if res is None:
            return default
        else:
            if isinstance(res, ParseInfo):
                return res()
            return res

    def track(self, key, remark):
        self._track(key, remark)


def get_no_track(pres, key, default=None):
    return TrackedParseResult(pres).get_no_track(key, default)


def get_and_track(pres, key, remark=1, default=None):
    return TrackedParseResult(pres).get_and_track(key, remark, default)


def track(pres, key, remark=1):
    TrackedParseResult(pres).track(key, remark)


import collections

def collect_feedback(pres, data):
    for v in pres:
        if isinstance(v, str):
            pass
        else:
            if isinstance(v, ParseInfo):
                if v.remark not in data:
                    data[v.remark] = []
                l = data[v.remark]
                l.extend([v.start, v.end])
            else:
                if isinstance(v, collections.Iterable):
                    collect_feedback(v, data)


class ParseInfo:

    def __init__(self, pres, remark, start, end):
        self.pres = pres
        self.remark = remark
        self.start = start
        self.end = end

    def __getitem__(self):
        return self.pres

    def __repr__(self):
        return 'ParseInfo' + str((self.pres, self.remark, self.start, self.end)) + ''

    def __call__(self):
        return self.pres

    def __eq__(self, other):
        return self.__call__() == other


def no_action(s, l, t):
    pass


class ParseInfoHelper:

    def __init__(self, expr, offset=0, legacy=False):
        self.expr = expr.copy()
        self.PARSE_INFO_LEGACY = legacy
        self.expr.setParseAction(no_action)
        self.expr.setName('originalTextFor(' + str(expr) + ')')
        self.offset = offset

    def __call__(self, s, l, t):
        if not ADD_PARSE_INFO:
            return
        if len(t) == 1:
            matched_text = originalTextFor(self.expr).parseString(s[l:])
            lstart = l
            lend = l
            if len(matched_text):
                matched_text = matched_text[0]
                subpos = s[l:].find(matched_text)
                lstart = lstart + subpos
                lend = lstart + len(matched_text)
            lstart += self.offset
            lend += self.offset
            tinfo = ParseInfo(t[0], 'IGNORED: Unused', lstart, lend)
            if self.PARSE_INFO_LEGACY:
                return tinfo
            else:
                if t.haskeys():
                    return ParseResults(tinfo, name=(t.getName()), asList=False)
                return ParseResults(tinfo)


class feedback_wrapper:

    def __init__(self, fb):
        self.fb = fb

    def add_parsed_text(s, l, t):
        self.fb['parsed_text'] = s


class Command:

    def copy_dict_skip_None(self, d):
        res = {}
        for k, v in d.items():
            if v is None:
                pass
            else:
                if isinstance(v, dict):
                    res[k] = self.copy_dict_skip_None(v)
                else:
                    res[k] = v

        return res

    def __init__(self, _Command__command_name, **kwargs):
        self.command_name = _Command__command_name
        self.kwargs = self.copy_dict_skip_None(kwargs)

    def __eq__(self, other):
        if self.command_name != other.command_name:
            return False
        else:
            return self.kwargs == other.kwargs

    def has_arg(self, name):
        return name in self.kwargs

    def get_arg(self, name):
        if self.has_arg(name):
            return self.kwargs[name]

    def __str__(self):
        flat_args = []
        for k, v in self.kwargs.items():
            flat_args.append(k + '=' + str(v))

        return self.command_name + '(' + ', '.join(flat_args) + ')'

    def __repr__(self):
        return self.__str__()


import sys, logging, logging.handlers
logger = logging.getLogger('')
formatter = logging.Formatter('%(levelname)s - %(message)s')
handler = logging.StreamHandler(sys.stdout)
handler.setFormatter(formatter)
logger.addHandler(handler)
logger.setLevel(logging.INFO)

class ParserError(Exception):
    pass


class InputIncorrect(Exception):
    pass
# okay decompiling utils.pyc
