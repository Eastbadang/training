# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\__init__.py
# Compiled at: 2017-02-21 19:19:45
# Size of source mod 2**32: 21 bytes
__all__ = [
 'run']
# okay decompiling __init__.pyc
