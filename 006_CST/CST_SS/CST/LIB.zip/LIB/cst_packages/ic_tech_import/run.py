# uncompyle6 version 3.7.4
# Python bytecode 3.6 (3379)
# Decompiled from: Python 3.8.5 (default, Aug  5 2020, 09:44:06) [MSC v.1916 64 bit (AMD64)]
# Embedded file name: E:\repositories\R16\Source_Code/Library/EDA/IC/ICtoolkit/Imports/python\ic_tech_import\run.py
# Compiled at: 2018-06-19 20:10:40
# Size of source mod 2**32: 1851 bytes
from .common.utils import logger
from io import StringIO

def run(inp, commands, feedback={}):
    import logging
    log_string = StringIO()
    formatter = logging.Formatter('%(levelname)s - %(message)s')
    handler = logging.StreamHandler(log_string)
    handler.setFormatter(formatter)
    lg = logging.getLogger()
    lg.addHandler(handler)
    file = inp['techfile']
    lmap = inp.get('layermap')
    import sys, os
    sys.path.append('.')
    try:
        logger.info('Importing technology from: ' + file)
        filename, ext = os.path.splitext(file)
        ext = ext.lower()
        if ext.lower() == '.itf':
            logger.info('Synopys Interconnect Technology File (ITF) import')
            from .itf_import import convert
            convert.convert(file, commands, feedback)
        else:
            if ext.lower() == '.ict':
                logger.info('Cadence Interconnect Technology File (ICT) import')
                from .ict_import import convert
                convert.convert(file, commands, feedback)
            else:
                if ext.lower() == '.ltd':
                    logger.info('ADS Substrate File (LTD) import')
                    from .ltd_import import convert
                    convert.convert(file, commands, feedback)
                else:
                    if ext.lower() == '.subst':
                        logger.info('ADS Substrate File (SUBST) import')
                        from .ads_import import convert
                        convert.convert(file, lmap, commands, feedback)
                    else:
                        raise UserWarning('File with extension ' + ext + ' is not supported.')
        logger.info('Import finished.')
    except ImportError as e:
        logger.error(e)
    except Exception as e:
        logger.error(e)

    log_string.flush()
    s = log_string.getvalue()
    feedback['log'] = s
    return 0
# okay decompiling run.pyc
