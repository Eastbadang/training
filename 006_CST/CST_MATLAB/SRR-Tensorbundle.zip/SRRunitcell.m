% code written by Symeon Symeonidis and Md Nazmul Hasan

% Put your CST-MATLAB-API path here
addpath(genpath('API PATH HERE'));

cst = actxserver('CSTStudio.application');
mws = cst.invoke('NewMWS');

Geometry = 'um'; 
Frequency = 'GHz';
Time = 'ns';
TemperatureUnit = 'Kelvin';
Voltage = 'V';
Current = 'A';
Resistance = 'Ohm';
Conductance  = 'S';
Capacitance = 'PikoF';
Inductance = 'NanoH';

CstDefineUnits(mws,Geometry, Frequency, Time, TemperatureUnit, Voltage, Current, Resistance, Conductance, Capacitance, Inductance)
ComponentList = 'component1';
CstDefineFrequencyRange(mws,0.5,10)
CstMeshInitiator(mws)

% Defining the boundary conditions. We need to simulate a plane wave here so we need a waveguide-like
% structure therefore the 'walls' of the structure need to be perfect
% electric and perfect magnetic according to the orientation of our
% electromagnetic field
minfrequency = 0.5;
Xmin = 'open';
Xmax = 'open';
Ymin = 'electric';
Ymax = 'electric';
Zmin = 'magnetic';
Zmax = 'magnetic';
CstDefineOpenBoundary(mws,minfrequency,Xmin,Xmax,Ymin,Ymax,Zmin,Zmax)

XminSpace = 0;
XmaxSpace = 0;
YminSpace = 0;
YmaxSpace = 0;
ZminSpace = 5000;
ZmaxSpace = 5000;
CstDefineBackroundMaterial(mws,XminSpace,XmaxSpace, YminSpace, YmaxSpace, ZminSpace, ZmaxSpace)

CstCopperAnnealedLossy(mws)
CstFR4lossy(mws)

Name = 'Substrate';
component = 'component1';
material = 'FR-4 (lossy)';
Xrange = [0 10000];
Yrange = [0 10000];
Zrange = [0 1600];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)

% making the copper wire at the bottom of the substrate
Name = 'Backconductor';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [4500 5500];
Yrange = [0 10000];
Zrange = [-35 0];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)

% Making the outer ring of the SRR
Name = 'frontcond';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [1000 9000];
Yrange = [1000 9000];
Zrange = [1600 1635];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)

Name = 'frontcondcut';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [2000 8000];
Yrange = [2000 8000];
Zrange = [1600 1635];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)


component1 = 'component1:frontcond';
component2 = 'component1:frontcondcut';
CstSubtract(mws,component1,component2)

Name = 'cut1';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [4750 5250];
Yrange = [8000 9000];
Zrange = [1600 1635];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)


component1 = 'component1:frontcond';
component2 = 'component1:cut1';
CstSubtract(mws,component1,component2)

% Making the inner ring of the SRR
Name = 'frontcond2';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [3000 7000];
Yrange = [3000 7000];
Zrange = [1600 1635];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)

Name = 'frontcondcut2';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [4000 6000];
Yrange = [4000 6000];
Zrange = [1600 1635];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)

component1 = 'component1:frontcond2';
component2 = 'component1:frontcondcut2';
CstSubtract(mws,component1,component2)

Name = 'cut2';
component = 'component1';
material = 'Copper (annealed)';
Xrange = [4750 5250];
Yrange = [3000 4000];
Zrange = [1600 1635];
Cstbrick(mws, Name, component, material, Xrange, Yrange, Zrange)

component1 = 'component1:frontcond2';
component2 = 'component1:cut2';
CstSubtract(mws,component1,component2)

%Assigning the ports
PortNumber = 1;
Xrange = [0 0];
Yrange = [0 10000];
Zrange = [-5035 6635];
XrangeAdd = [0 0];
YrangeAdd = [0 0];
ZrangeAdd = [0 0];
CstWaveguidePort(mws,PortNumber, Xrange, Yrange, Zrange, XrangeAdd, YrangeAdd, ZrangeAdd, 'Full','xmin')

PortNumber = 2;
Xrange = [10000 10000];
Yrange = [0 10000];
Zrange = [-5035 6635];
XrangeAdd = [0 0];
YrangeAdd = [0 0];
ZrangeAdd = [0 0];
CstWaveguidePort(mws,PortNumber, Xrange, Yrange, Zrange, XrangeAdd, YrangeAdd, ZrangeAdd, 'Full','xmax')

CstSaveProject(mws) 
CstDefineTimedomainSolver(mws,-40)

% Watch the video "CST MWS Tutorial 23: SRR Metamaterial Unit Cell
% Simulation" at Tensorbundle YouTube Channel
% (https://www.youtube.com/c/tensorbundle) to know about the extraction of
% epsilon, mu, impedance and refractive index of the SRR unit cell
